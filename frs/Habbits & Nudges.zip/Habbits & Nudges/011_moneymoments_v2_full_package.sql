-- ============================================================================
-- Monytix — MoneyMoments v2 : Habits + Nudges Full Package
-- Migration : 011
-- Version   : 2.0  (PostgreSQL 13+)
-- ============================================================================
--
-- EXECUTION ORDER
-- ---------------
--   Step 0  — Schema guard + extend mm_signal_daily
--   Step 1  — mv_mandatory_payment_profile        (refresh monthly)
--   Step 2  — fn_compute_mm_signal_extended()     (run daily per user)
--   Step 3  — Habits engine                       (run monthly per user)
--   Step 4  — Nudge rule seeds                    (run once on deploy)
--   Step 5  — Nudge template seeds                (run once on deploy)
--   Step 6  — fn_evaluate_nudge_candidates()      (run daily per user)
--
-- COLUMN SOURCE MAP (what we read from where)
-- --------------------------------------------
-- spendsense.txn_enriched (direct join via txn_parsed.parsed_id):
--     category_id            TEXT    — dim_category code (e.g. 'dining','loans_payments')
--     subcategory_id         TEXT    — dim_subcategory code (e.g. 'inv_sip','loan_personal')
--     cat_l1                 TEXT    — EXPENSE / LOAN / INVESTMENT / INCOME / TRANSFER / FEE / CASH
--     cat_l2                 TEXT    — human category label
--     channel_type           TEXT    — UPI / NACH / SI / NEFT / IMPS / CARD etc.
--     rulebook_financial_class TEXT  — LOAN_EMI / INSURANCE / INVESTMENT / INCOME etc.
--     merchant_name          TEXT    — resolved merchant name
--     merchant_id            UUID
--     direction              TEXT    — debit / credit
--     amount, txn_date, parsed_id, bank_code
--     NOTE: is_card_payment / is_loan_payment / is_investment are NOT used
--           (confirmed not populated); derive obligation class from cat_l1 +
--           rulebook_financial_class + subcategory_id + channel_type instead.
--
-- spendsense.vw_txn_effective (for budget-layer joins):
--     user_id, txn_id, txn_date, amount, direction, txn_type, category_code,
--     subcategory_code, merchant_name, match_source, confidence
--
-- budgetpilot.budget_user_month_aggregate:
--     income_amt, needs_amt, planned_needs_amt, wants_amt, planned_wants_amt,
--     assets_amt, planned_assets_amt
--
-- goalcompass.goal_compass_snapshot:
--     on_track_flag, suggested_monthly_need, remaining_amount,
--     months_remaining, risk_level, progress_pct
-- ============================================================================

BEGIN;

SET search_path = moneymoments, goalcompass, budgetpilot, goal,
                  spendsense, enrichment, core, public;

-- ============================================================================
-- STEP 0 — Schema guard + extend mm_signal_daily
-- ============================================================================

CREATE SCHEMA IF NOT EXISTS moneymoments;

ALTER TABLE moneymoments.mm_signal_daily
  -- ── Frequency / impulse signals ────────────────────────────────────────
  ADD COLUMN IF NOT EXISTS impulse_txn_share_30d        NUMERIC(6,3),
  -- Debit txns < ₹500 via UPI as share of all debit txns (30d)
  ADD COLUMN IF NOT EXISTS impulse_txn_delta_vs_90d     NUMERIC(6,3),
  -- % change vs user's own 90d baseline (+ = more impulsive than usual)

  ADD COLUMN IF NOT EXISTS weekend_spend_ratio_30d      NUMERIC(6,3),
  -- Weekend (Sat+Sun) debit spend as share of total debit spend (30d)
  ADD COLUMN IF NOT EXISTS weekend_spend_delta_vs_90d   NUMERIC(6,3),
  -- % change vs user's own 90d baseline

  ADD COLUMN IF NOT EXISTS freq_daily_txn_30d           NUMERIC(8,3),
  -- Average debit transactions per calendar day (30d)
  ADD COLUMN IF NOT EXISTS freq_daily_txn_delta_vs_90d  NUMERIC(6,3),
  -- % change vs user's own 90d baseline (+ = transacting more than usual)

  -- ── Merchant concentration signals ─────────────────────────────────────
  ADD COLUMN IF NOT EXISTS top3_merchant_conc_90d       NUMERIC(6,3),
  -- Share of wants-spend going to top-3 merchants (90d)
  ADD COLUMN IF NOT EXISTS repeat_merchant_cnt_90d      INTEGER,
  -- Distinct merchants visited 3+ times in 90d (loyalty / habit depth)

  -- ── Evening / EOD spending ──────────────────────────────────────────────
  ADD COLUMN IF NOT EXISTS eod_spend_ratio_30d          NUMERIC(6,3),
  -- Share of debit spend placed after 20:00 (30d)

  -- ── Income stability ────────────────────────────────────────────────────
  ADD COLUMN IF NOT EXISTS income_3mo_cv                NUMERIC(6,3),
  -- Coefficient of variation of monthly income last 3 full months
  -- (CV = stddev/mean; low = stable salary; high = variable/freelance)

  -- ── Budget health (current month live ratios) ───────────────────────────
  ADD COLUMN IF NOT EXISTS needs_ratio_current_mo       NUMERIC(6,3),
  -- needs_amt / income_amt for month-to-date
  ADD COLUMN IF NOT EXISTS savings_ratio_current_mo     NUMERIC(6,3),
  -- assets_amt / income_amt for month-to-date

  -- ── Goal streak ─────────────────────────────────────────────────────────
  ADD COLUMN IF NOT EXISTS savings_streak_months        SMALLINT,
  -- Consecutive calendar months where at least one goal was on_track_flag=TRUE

  -- ── Mandatory payment coverage ──────────────────────────────────────────
  ADD COLUMN IF NOT EXISTS mandatory_due_amt            NUMERIC(14,2),
  -- Total expected obligation payments this month (from payment profile)
  ADD COLUMN IF NOT EXISTS mandatory_paid_amt           NUMERIC(14,2),
  -- Obligation payments confirmed received this month
  ADD COLUMN IF NOT EXISTS mandatory_coverage_pct       NUMERIC(6,3),
  -- mandatory_paid_amt / mandatory_due_amt  (1.0 = fully covered)
  ADD COLUMN IF NOT EXISTS overdue_mandatory_count      SMALLINT,
  -- Count of individual obligations past their typical_dom but not paid
  ADD COLUMN IF NOT EXISTS overdue_mandatory_amt        NUMERIC(14,2);
  -- Total ₹ amount of overdue obligations

-- ============================================================================
-- STEP 1 — mv_mandatory_payment_profile  (refresh monthly)
-- ============================================================================
-- Identifies recurring obligation transactions by combining all three signals:
--   a) cat_l1 IN ('LOAN','INVESTMENT','FEE') from txn_enriched
--   b) subcategory_id prefix: loan_*, ins_*, inv_sip, inv_nps, inv_ppf
--   c) channel_type IN ('NACH','SI') — standing instruction = always mandatory
--
-- A merchant+type is "recurring mandatory" if it appeared in ≥ 2 of the
-- last 3 full calendar months for the same user.
-- ============================================================================

DROP MATERIALIZED VIEW IF EXISTS moneymoments.mv_mandatory_payment_profile CASCADE;

CREATE MATERIALIZED VIEW moneymoments.mv_mandatory_payment_profile AS
WITH
-- ── 90-day obligation transaction pull ──────────────────────────────────────
raw AS (
  SELECT
    tp.user_id,                                    -- from txn_parsed / txn_fact
    te.merchant_name,
    te.category_id,
    te.subcategory_id,
    te.cat_l1,
    te.channel_type,
    te.rulebook_financial_class,
    te.amount,
    te.txn_date,
    date_trunc('month', te.txn_date)::DATE         AS txn_month,
    -- ── Obligation type label (for nudge copy) ──
    CASE
      WHEN te.rulebook_financial_class = 'LOAN_EMI'              THEN 'EMI / Loan'
      WHEN te.rulebook_financial_class = 'CREDIT_CARD_PAYMENT'   THEN 'CC Bill'
      WHEN te.rulebook_financial_class = 'INSURANCE'             THEN 'Insurance Premium'
      WHEN te.rulebook_financial_class = 'INVESTMENT'
        AND te.subcategory_id ILIKE 'inv_sip%'                   THEN 'SIP'
      WHEN te.rulebook_financial_class = 'INVESTMENT'
        AND te.subcategory_id ILIKE 'inv_nps%'                   THEN 'NPS'
      WHEN te.rulebook_financial_class = 'INVESTMENT'            THEN 'Investment'
      WHEN te.rulebook_financial_class = 'HOUSING'               THEN 'Rent / Housing'
      WHEN te.channel_type IN ('NACH','SI')                      THEN 'Standing Instruction'
      ELSE 'Obligation'
    END AS obligation_type,
    -- ── Canonical bucket for grouping ──
    CASE
      WHEN te.subcategory_id ILIKE 'loan_%'       THEN 'loan'
      WHEN te.subcategory_id ILIKE 'ins_%'        THEN 'insurance'
      WHEN te.subcategory_id ILIKE 'inv_sip%'     THEN 'sip'
      WHEN te.subcategory_id ILIKE 'inv_nps%'     THEN 'nps'
      WHEN te.subcategory_id ILIKE 'inv_ppf%'     THEN 'ppf'
      WHEN te.subcategory_id ILIKE 'inv_%'        THEN 'investment'
      WHEN te.rulebook_financial_class = 'HOUSING' THEN 'housing'
      WHEN te.channel_type IN ('NACH','SI')       THEN 'nach_si'
      ELSE 'other_obligation'
    END AS obligation_bucket
  FROM spendsense.txn_enriched te
  -- Join to get user_id (txn_enriched has parsed_id; user_id is on txn_parsed/txn_fact)
  JOIN spendsense.txn_parsed    tpa ON tpa.parsed_id   = te.parsed_id
  JOIN spendsense.txn_fact      tf  ON tf.txn_id       = tpa.fact_txn_id
  WHERE te.direction = 'debit'
    AND te.txn_date  >= date_trunc('month', CURRENT_DATE) - INTERVAL '90 days'
    AND (
      -- Signal A: rulebook-confirmed financial class
      te.rulebook_financial_class IN (
        'LOAN_EMI','CREDIT_CARD_PAYMENT','INSURANCE','INVESTMENT','HOUSING'
      )
      OR
      -- Signal B: subcategory_id pattern (covers cases where rulebook=MERCHANT_PAYMENT
      --           but subcategory was resolved to an obligation bucket)
      te.subcategory_id ILIKE ANY(ARRAY[
        'loan_%','ins_%','inv_sip%','inv_nps%','inv_ppf%'
      ])
      OR
      -- Signal C: channel = NACH / SI (standing instruction = always mandatory)
      te.channel_type IN ('NACH','SI')
    )
),
-- ── Monthly occurrence aggregation ──────────────────────────────────────────
monthly_agg AS (
  SELECT
    user_id,
    merchant_name,
    obligation_type,
    obligation_bucket,
    subcategory_id,
    txn_month,
    COUNT(*)             AS txn_count_in_month,
    AVG(amount)          AS avg_amount_in_month,
    PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY EXTRACT(day FROM txn_date))
                         AS median_dom   -- typical day-of-month payment lands
  FROM raw
  WHERE txn_month < date_trunc('month', CURRENT_DATE)  -- only full months
  GROUP BY user_id, merchant_name, obligation_type, obligation_bucket,
           subcategory_id, txn_month
),
-- ── Recurrence summary: needs ≥ 2 of last 3 months ──────────────────────────
occurrence_summary AS (
  SELECT
    user_id,
    merchant_name,
    obligation_type,
    obligation_bucket,
    subcategory_id,
    COUNT(DISTINCT txn_month)           AS months_seen,
    ROUND(AVG(avg_amount_in_month), 2)  AS typical_amount,
    ROUND(AVG(median_dom))::INTEGER     AS typical_dom,
    MAX(txn_month)                      AS last_paid_month
  FROM monthly_agg
  GROUP BY user_id, merchant_name, obligation_type, obligation_bucket, subcategory_id
  HAVING COUNT(DISTINCT txn_month) >= 2
),
-- ── What has already been paid this calendar month ──────────────────────────
paid_this_month AS (
  SELECT
    tf.user_id,
    te.merchant_name,
    SUM(te.amount) AS paid_amt
  FROM spendsense.txn_enriched te
  JOIN spendsense.txn_parsed  tpa ON tpa.parsed_id = te.parsed_id
  JOIN spendsense.txn_fact    tf  ON tf.txn_id     = tpa.fact_txn_id
  WHERE te.direction = 'debit'
    AND te.txn_date  >= date_trunc('month', CURRENT_DATE)
    AND (
      te.rulebook_financial_class IN (
        'LOAN_EMI','CREDIT_CARD_PAYMENT','INSURANCE','INVESTMENT','HOUSING'
      )
      OR te.subcategory_id ILIKE ANY(ARRAY['loan_%','ins_%','inv_sip%','inv_nps%','inv_ppf%'])
      OR te.channel_type IN ('NACH','SI')
    )
  GROUP BY tf.user_id, te.merchant_name
)
SELECT
  o.user_id,
  o.merchant_name,
  o.obligation_type,
  o.obligation_bucket,
  o.subcategory_id,
  o.typical_amount,
  o.typical_dom,
  o.months_seen,
  o.last_paid_month,
  COALESCE(p.paid_amt, 0)                                AS paid_amt_this_month,
  -- Overdue: past expected day-of-month and payment not seen yet
  CASE
    WHEN p.paid_amt IS NULL
     AND o.typical_dom <= EXTRACT(day FROM CURRENT_DATE) THEN TRUE
    ELSE FALSE
  END                                                    AS overdue_flag,
  NOW()                                                  AS computed_at
FROM occurrence_summary o
LEFT JOIN paid_this_month p
       ON p.user_id      = o.user_id
      AND LOWER(p.merchant_name) = LOWER(o.merchant_name);

CREATE UNIQUE INDEX IF NOT EXISTS idx_mmp_user_merchant_type
  ON moneymoments.mv_mandatory_payment_profile (user_id, merchant_name, obligation_type);

CREATE INDEX IF NOT EXISTS idx_mmp_user_overdue
  ON moneymoments.mv_mandatory_payment_profile (user_id, overdue_flag)
  WHERE overdue_flag = TRUE;

-- ============================================================================
-- STEP 2 — fn_compute_mm_signal_extended()
-- Extends the existing daily signal computation with all new columns.
-- Call this AFTER the existing mm_signal_daily insert/update for the same
-- user+date, as it only UPDATEs the new columns added in Step 0.
-- Parameters: p_user_id UUID, p_as_of_date DATE
-- ============================================================================

CREATE OR REPLACE FUNCTION moneymoments.fn_compute_mm_signal_extended(
  p_user_id    UUID,
  p_as_of_date DATE
)
RETURNS VOID
LANGUAGE plpgsql
AS $$
DECLARE
  -- ── 90-day baseline scalars ──
  v_baseline_impulse_share   NUMERIC(6,3);
  v_baseline_weekend_ratio   NUMERIC(6,3);
  v_baseline_freq_daily      NUMERIC(8,3);

  -- ── 30-day current window scalars ──
  v_impulse_share_30d        NUMERIC(6,3);
  v_weekend_ratio_30d        NUMERIC(6,3);
  v_freq_daily_30d           NUMERIC(8,3);

  -- ── Merchant concentration ──
  v_top3_conc_90d            NUMERIC(6,3);
  v_repeat_merch_90d         INTEGER;

  -- ── EOD spend ──
  v_eod_ratio_30d            NUMERIC(6,3);

  -- ── Income CV ──
  v_income_cv                NUMERIC(6,3);

  -- ── Budget live ratios ──
  v_needs_ratio              NUMERIC(6,3);
  v_savings_ratio            NUMERIC(6,3);

  -- ── Goal streak ──
  v_savings_streak           SMALLINT;

  -- ── Mandatory payment coverage ──
  v_mandatory_due            NUMERIC(14,2);
  v_mandatory_paid           NUMERIC(14,2);
  v_mandatory_coverage       NUMERIC(6,3);
  v_overdue_count            SMALLINT;
  v_overdue_amt              NUMERIC(14,2);

  -- ── Working vars ──
  v_this_month  DATE := date_trunc('month', p_as_of_date)::DATE;
  v_days_30d    INTEGER := 30;
  v_days_90d    INTEGER := 90;
BEGIN

  -- =========================================================================
  -- A) 90-DAY BASELINE (excludes the current 30d window to keep it clean)
  --    Window: [as_of_date - 90d,  as_of_date - 30d)
  -- =========================================================================
  SELECT
    -- Impulse share baseline: UPI debits < ₹500 / all debits
    ROUND(
      COUNT(*) FILTER (
        WHERE te.channel_type = 'UPI' AND te.amount < 500
      )::NUMERIC / NULLIF(COUNT(*) FILTER (WHERE te.direction='debit'), 0),
    3),
    -- Weekend ratio baseline
    ROUND(
      SUM(te.amount) FILTER (
        WHERE te.direction='debit'
          AND EXTRACT(dow FROM te.txn_date) IN (0,6)
      ) / NULLIF(SUM(te.amount) FILTER (WHERE te.direction='debit'), 0),
    3),
    -- Avg daily txn count baseline
    ROUND(
      COUNT(*) FILTER (WHERE te.direction='debit')::NUMERIC / 60.0,
    3)
  INTO
    v_baseline_impulse_share,
    v_baseline_weekend_ratio,
    v_baseline_freq_daily
  FROM spendsense.txn_enriched te
  JOIN spendsense.txn_parsed  tpa ON tpa.parsed_id = te.parsed_id
  JOIN spendsense.txn_fact    tf  ON tf.txn_id     = tpa.fact_txn_id
  WHERE tf.user_id   = p_user_id
    AND te.txn_date >= p_as_of_date - INTERVAL '90 days'
    AND te.txn_date <  p_as_of_date - INTERVAL '30 days';

  -- =========================================================================
  -- B) 30-DAY CURRENT WINDOW
  --    Window: [as_of_date - 30d, as_of_date]
  -- =========================================================================
  SELECT
    ROUND(
      COUNT(*) FILTER (
        WHERE te.channel_type = 'UPI' AND te.amount < 500
      )::NUMERIC / NULLIF(COUNT(*) FILTER (WHERE te.direction='debit'), 0),
    3),
    ROUND(
      SUM(te.amount) FILTER (
        WHERE te.direction='debit'
          AND EXTRACT(dow FROM te.txn_date) IN (0,6)
      ) / NULLIF(SUM(te.amount) FILTER (WHERE te.direction='debit'), 0),
    3),
    ROUND(
      COUNT(*) FILTER (WHERE te.direction='debit')::NUMERIC / 30.0,
    3),
    -- EOD spend: after 20:00
    ROUND(
      SUM(te.amount) FILTER (
        WHERE te.direction='debit'
          AND te.txn_time IS NOT NULL
          AND EXTRACT(hour FROM te.txn_time) >= 20
      ) / NULLIF(SUM(te.amount) FILTER (WHERE te.direction='debit'), 0),
    3)
  INTO
    v_impulse_share_30d,
    v_weekend_ratio_30d,
    v_freq_daily_30d,
    v_eod_ratio_30d
  FROM spendsense.txn_enriched te
  JOIN spendsense.txn_parsed  tpa ON tpa.parsed_id = te.parsed_id
  JOIN spendsense.txn_fact    tf  ON tf.txn_id     = tpa.fact_txn_id
  WHERE tf.user_id   = p_user_id
    AND te.txn_date >= p_as_of_date - INTERVAL '30 days'
    AND te.txn_date <= p_as_of_date;

  -- =========================================================================
  -- C) MERCHANT CONCENTRATION — 90d (wants only: cat_l1 = 'EXPENSE')
  -- =========================================================================
  WITH merch_spend AS (
    SELECT
      te.merchant_name,
      SUM(te.amount) AS spend
    FROM spendsense.txn_enriched te
    JOIN spendsense.txn_parsed  tpa ON tpa.parsed_id = te.parsed_id
    JOIN spendsense.txn_fact    tf  ON tf.txn_id     = tpa.fact_txn_id
    WHERE tf.user_id    = p_user_id
      AND te.direction  = 'debit'
      AND te.cat_l1     = 'EXPENSE'
      AND te.txn_date  >= p_as_of_date - INTERVAL '90 days'
      AND te.txn_date  <= p_as_of_date
      AND te.merchant_name IS NOT NULL
    GROUP BY te.merchant_name
  ),
  totals AS (
    SELECT SUM(spend) AS total_wants FROM merch_spend
  ),
  top3 AS (
    SELECT SUM(m.spend) AS top3_spend
    FROM (SELECT spend FROM merch_spend ORDER BY spend DESC LIMIT 3) m
  )
  SELECT
    ROUND(t3.top3_spend / NULLIF(tot.total_wants, 0), 3),
    (SELECT COUNT(*) FROM merch_spend WHERE spend >= 3 * (tot.total_wants / NULLIF(
        (SELECT COUNT(*) FROM merch_spend), 1)))
  INTO v_top3_conc_90d, v_repeat_merch_90d
  FROM top3 t3 CROSS JOIN totals tot;

  -- Repeat merchant count: distinct merchants with 3+ transactions in 90d
  SELECT COUNT(DISTINCT te.merchant_name)
  INTO v_repeat_merch_90d
  FROM (
    SELECT te.merchant_name, COUNT(*) AS cnt
    FROM spendsense.txn_enriched te
    JOIN spendsense.txn_parsed  tpa ON tpa.parsed_id = te.parsed_id
    JOIN spendsense.txn_fact    tf  ON tf.txn_id     = tpa.fact_txn_id
    WHERE tf.user_id    = p_user_id
      AND te.direction  = 'debit'
      AND te.txn_date  >= p_as_of_date - INTERVAL '90 days'
      AND te.merchant_name IS NOT NULL
    GROUP BY te.merchant_name
    HAVING COUNT(*) >= 3
  ) sub;

  -- =========================================================================
  -- D) INCOME STABILITY — CV over last 3 full months
  -- =========================================================================
  WITH monthly_income AS (
    SELECT
      date_trunc('month', te.txn_date) AS mo,
      SUM(te.amount) AS income_amt
    FROM spendsense.txn_enriched te
    JOIN spendsense.txn_parsed  tpa ON tpa.parsed_id = te.parsed_id
    JOIN spendsense.txn_fact    tf  ON tf.txn_id     = tpa.fact_txn_id
    WHERE tf.user_id  = p_user_id
      AND te.cat_l1   = 'INCOME'
      AND te.direction = 'credit'
      AND te.txn_date >= v_this_month - INTERVAL '3 months'
      AND te.txn_date <  v_this_month
    GROUP BY 1
  )
  SELECT
    ROUND(
      STDDEV_POP(income_amt) / NULLIF(AVG(income_amt), 0),
    3)
  INTO v_income_cv
  FROM monthly_income;

  -- =========================================================================
  -- E) BUDGET LIVE RATIOS — current month from budget_user_month_aggregate
  -- =========================================================================
  SELECT
    ROUND(b.needs_amt  / NULLIF(b.income_amt, 0), 3),
    ROUND(b.assets_amt / NULLIF(b.income_amt, 0), 3)
  INTO v_needs_ratio, v_savings_ratio
  FROM budgetpilot.budget_user_month_aggregate b
  WHERE b.user_id = p_user_id
    AND b.month   = v_this_month;

  -- =========================================================================
  -- F) SAVINGS STREAK — consecutive months with at least one on-track goal
  -- =========================================================================
  WITH monthly_ontrack AS (
    SELECT
      gcs.month,
      BOOL_OR(gcs.on_track_flag) AS any_on_track
    FROM goalcompass.goal_compass_snapshot gcs
    WHERE gcs.user_id = p_user_id
      AND gcs.month   < v_this_month
    GROUP BY gcs.month
    ORDER BY gcs.month DESC
  ),
  streak_calc AS (
    SELECT
      month,
      any_on_track,
      ROW_NUMBER() OVER (ORDER BY month DESC) AS rn,
      -- streak breaks the moment any_on_track = FALSE
      SUM(CASE WHEN NOT any_on_track THEN 1 ELSE 0 END)
        OVER (ORDER BY month DESC ROWS UNBOUNDED PRECEDING) AS break_count
    FROM monthly_ontrack
  )
  SELECT COUNT(*)::SMALLINT
  INTO v_savings_streak
  FROM streak_calc
  WHERE break_count = 0 AND any_on_track = TRUE;

  -- =========================================================================
  -- G) MANDATORY PAYMENT COVERAGE — from mv_mandatory_payment_profile
  -- =========================================================================
  SELECT
    COALESCE(SUM(typical_amount), 0),
    COALESCE(SUM(paid_amt_this_month), 0),
    COUNT(*) FILTER (WHERE overdue_flag = TRUE),
    COALESCE(SUM(typical_amount) FILTER (WHERE overdue_flag = TRUE), 0)
  INTO
    v_mandatory_due,
    v_mandatory_paid,
    v_overdue_count,
    v_overdue_amt
  FROM moneymoments.mv_mandatory_payment_profile
  WHERE user_id = p_user_id;

  v_mandatory_coverage := ROUND(
    v_mandatory_paid / NULLIF(v_mandatory_due, 0), 3
  );

  -- =========================================================================
  -- H) UPDATE mm_signal_daily — only the new columns
  -- =========================================================================
  UPDATE moneymoments.mm_signal_daily
  SET
    impulse_txn_share_30d       = v_impulse_share_30d,
    impulse_txn_delta_vs_90d    = ROUND(
      (v_impulse_share_30d - v_baseline_impulse_share)
        / NULLIF(v_baseline_impulse_share, 0), 3),

    weekend_spend_ratio_30d     = v_weekend_ratio_30d,
    weekend_spend_delta_vs_90d  = ROUND(
      (v_weekend_ratio_30d - v_baseline_weekend_ratio)
        / NULLIF(v_baseline_weekend_ratio, 0), 3),

    freq_daily_txn_30d          = v_freq_daily_30d,
    freq_daily_txn_delta_vs_90d = ROUND(
      (v_freq_daily_30d - v_baseline_freq_daily)
        / NULLIF(v_baseline_freq_daily, 0), 3),

    top3_merchant_conc_90d      = v_top3_conc_90d,
    repeat_merchant_cnt_90d     = v_repeat_merch_90d,

    eod_spend_ratio_30d         = v_eod_ratio_30d,
    income_3mo_cv               = v_income_cv,

    needs_ratio_current_mo      = v_needs_ratio,
    savings_ratio_current_mo    = v_savings_ratio,

    savings_streak_months       = COALESCE(v_savings_streak, 0),

    mandatory_due_amt           = v_mandatory_due,
    mandatory_paid_amt          = v_mandatory_paid,
    mandatory_coverage_pct      = v_mandatory_coverage,
    overdue_mandatory_count     = COALESCE(v_overdue_count, 0),
    overdue_mandatory_amt       = COALESCE(v_overdue_amt, 0)

  WHERE user_id    = p_user_id
    AND as_of_date = p_as_of_date;

END;
$$;

COMMENT ON FUNCTION moneymoments.fn_compute_mm_signal_extended IS
'Computes all v2 signal columns for a given user+date and writes them to
mm_signal_daily. Call AFTER the existing signal computation that writes
the base row. Reads directly from txn_enriched (joined via txn_parsed +
txn_fact) for category_id, subcategory_id, cat_l1, channel_type, and
rulebook_financial_class. Does NOT use is_card_payment / is_loan_payment /
is_investment (not populated). Mandatory payment detection derives from
cat_l1 + rulebook_financial_class + subcategory_id + channel_type.';

-- ============================================================================
-- STEP 3 — Habits Engine  (monthly write to mm_user_moments)
-- ============================================================================
-- Inserts one row per habit_id per user per month into mm_user_moments.
-- habit_id registry:
--   FREQ_DAILY_TXN         — avg daily transaction frequency vs baseline
--   IMPULSE_SPEND_SHARE    — impulsive micro-spend share vs baseline
--   WEEKEND_SPEND_RATIO    — weekend spend concentration vs baseline
--   EOD_SPEND_RATIO        — evening spend pattern
--   TOP3_MERCHANT_CONC     — merchant concentration (fewer = more loyal)
--   NEEDS_RATIO_HEALTH     — needs spend vs committed budget
--   SAVINGS_RATIO_HEALTH   — savings rate vs committed budget
--   INCOME_STABILITY       — income regularity signal
--   SAVINGS_STREAK         — consecutive months on-track for goals
--   MANDATORY_COVERAGE     — obligation payment coverage rate
-- ============================================================================

CREATE OR REPLACE FUNCTION moneymoments.fn_compute_habits_monthly(
  p_user_id UUID,
  p_month   DATE   -- first day of target month
)
RETURNS VOID
LANGUAGE plpgsql
AS $$
DECLARE
  v_as_of DATE := (date_trunc('month', p_month) + INTERVAL '1 month - 1 day')::DATE;
  -- Use last day of month as signal reference; if month is current, use today
  v_signal moneymoments.mm_signal_daily%ROWTYPE;
  v_bgt    budgetpilot.budget_user_month_aggregate%ROWTYPE;
BEGIN

  -- Pull the most recent signal row for this user in target month
  SELECT * INTO v_signal
  FROM moneymoments.mm_signal_daily
  WHERE user_id    = p_user_id
    AND as_of_date = (
        SELECT MAX(as_of_date) FROM moneymoments.mm_signal_daily
        WHERE user_id = p_user_id
          AND as_of_date >= date_trunc('month', p_month)
          AND as_of_date <= LEAST(v_as_of, CURRENT_DATE)
    );

  -- Pull budget aggregate for the month
  SELECT * INTO v_bgt
  FROM budgetpilot.budget_user_month_aggregate
  WHERE user_id = p_user_id
    AND month   = date_trunc('month', p_month)::DATE;

  -- ── Delete existing habits for this user+month (clean re-compute) ──────────
  DELETE FROM moneymoments.mm_user_moments
  WHERE user_id = p_user_id AND month = date_trunc('month', p_month)::DATE;

  -- ── Insert habit rows ───────────────────────────────────────────────────────
  INSERT INTO moneymoments.mm_user_moments
    (user_id, month, habit_id, value, label, insight_text, confidence)
  VALUES

  -- 1. Transaction frequency vs baseline
  (p_user_id, date_trunc('month', p_month)::DATE,
   'FREQ_DAILY_TXN',
   COALESCE(v_signal.freq_daily_txn_delta_vs_90d, 0),
   CASE
     WHEN v_signal.freq_daily_txn_delta_vs_90d >  0.25 THEN 'High Frequency'
     WHEN v_signal.freq_daily_txn_delta_vs_90d < -0.15 THEN 'Low Frequency'
     ELSE 'Normal Frequency'
   END,
   CASE
     WHEN v_signal.freq_daily_txn_delta_vs_90d >  0.25
       THEN 'You''re transacting ' ||
            ROUND(v_signal.freq_daily_txn_delta_vs_90d * 100) ||
            '% more often than your usual pace this month.'
     WHEN v_signal.freq_daily_txn_delta_vs_90d < -0.15
       THEN 'Fewer transactions than usual — spending has slowed down.'
     ELSE 'Your transaction frequency is in line with your usual pattern.'
   END,
   CASE WHEN v_signal.freq_daily_txn_30d IS NOT NULL THEN 0.85 ELSE 0.40 END
  ),

  -- 2. Impulse spend share vs baseline
  (p_user_id, date_trunc('month', p_month)::DATE,
   'IMPULSE_SPEND_SHARE',
   COALESCE(v_signal.impulse_txn_share_30d, 0),
   CASE
     WHEN v_signal.impulse_txn_share_30d > 0.40 THEN 'High Impulse'
     WHEN v_signal.impulse_txn_share_30d > 0.25 THEN 'Moderate Impulse'
     ELSE 'Low Impulse'
   END,
   CASE
     WHEN v_signal.impulse_txn_delta_vs_90d > 0.20
       THEN ROUND(v_signal.impulse_txn_share_30d * 100) ||
            '% of your transactions this month were small UPI spends — ' ||
            ROUND(v_signal.impulse_txn_delta_vs_90d * 100) ||
            '% more than your usual rate.'
     WHEN v_signal.impulse_txn_share_30d > 0.40
       THEN 'Nearly half your transactions are small impulse payments. Small amounts add up.'
     ELSE
       ROUND(v_signal.impulse_txn_share_30d * 100) ||
       '% of transactions are small impulse payments — within your normal range.'
   END,
   CASE WHEN v_signal.impulse_txn_share_30d IS NOT NULL THEN 0.80 ELSE 0.40 END
  ),

  -- 3. Weekend spend ratio vs baseline
  (p_user_id, date_trunc('month', p_month)::DATE,
   'WEEKEND_SPEND_RATIO',
   COALESCE(v_signal.weekend_spend_ratio_30d, 0),
   CASE
     WHEN v_signal.weekend_spend_ratio_30d > 0.45 THEN 'Weekend Heavy'
     WHEN v_signal.weekend_spend_ratio_30d > 0.35 THEN 'Weekend Leaning'
     ELSE 'Balanced Week'
   END,
   CASE
     WHEN v_signal.weekend_spend_delta_vs_90d > 0.20
       THEN ROUND(v_signal.weekend_spend_ratio_30d * 100) ||
            '% of your spend lands on weekends — notably higher than your usual ' ||
            ROUND((v_signal.weekend_spend_ratio_30d
                   - v_signal.weekend_spend_delta_vs_90d
                     * v_signal.weekend_spend_ratio_30d) * 100) || '%.'
     ELSE
       ROUND(v_signal.weekend_spend_ratio_30d * 100) ||
       '% of your spend is on weekends — consistent with your normal pattern.'
   END,
   CASE WHEN v_signal.weekend_spend_ratio_30d IS NOT NULL THEN 0.80 ELSE 0.40 END
  ),

  -- 4. Evening/EOD spend pattern
  (p_user_id, date_trunc('month', p_month)::DATE,
   'EOD_SPEND_RATIO',
   COALESCE(v_signal.eod_spend_ratio_30d, 0),
   CASE
     WHEN v_signal.eod_spend_ratio_30d > 0.35 THEN 'Evening Spender'
     WHEN v_signal.eod_spend_ratio_30d > 0.20 THEN 'Occasional Evening'
     ELSE 'Daytime Spender'
   END,
   CASE
     WHEN v_signal.eod_spend_ratio_30d > 0.35
       THEN ROUND(v_signal.eod_spend_ratio_30d * 100) ||
            '% of your spending happens after 8 PM — evening impulse purchases tend to be unplanned.'
     ELSE 'Most of your spending happens during the day.'
   END,
   CASE WHEN v_signal.eod_spend_ratio_30d IS NOT NULL THEN 0.75 ELSE 0.35 END
  ),

  -- 5. Merchant concentration
  (p_user_id, date_trunc('month', p_month)::DATE,
   'TOP3_MERCHANT_CONC',
   COALESCE(v_signal.top3_merchant_conc_90d, 0),
   CASE
     WHEN v_signal.top3_merchant_conc_90d > 0.60 THEN 'Highly Concentrated'
     WHEN v_signal.top3_merchant_conc_90d > 0.40 THEN 'Moderately Concentrated'
     ELSE 'Diversified Spend'
   END,
   CASE
     WHEN v_signal.top3_merchant_conc_90d > 0.60
       THEN ROUND(v_signal.top3_merchant_conc_90d * 100) ||
            '% of your discretionary spend is concentrated at your top 3 merchants.'
     ELSE
       'Your discretionary spend is spread across ' ||
       COALESCE(v_signal.repeat_merchant_cnt_90d::TEXT, 'several') ||
       ' regular merchants.'
   END,
   CASE WHEN v_signal.top3_merchant_conc_90d IS NOT NULL THEN 0.80 ELSE 0.40 END
  ),

  -- 6. Needs ratio health vs committed budget
  (p_user_id, date_trunc('month', p_month)::DATE,
   'NEEDS_RATIO_HEALTH',
   COALESCE(v_signal.needs_ratio_current_mo, 0),
   CASE
     WHEN v_bgt.income_amt > 0
       AND v_signal.needs_ratio_current_mo >
           COALESCE(v_bgt.planned_needs_amt / NULLIF(v_bgt.income_amt,0), 0.5) + 0.05
       THEN 'Over Budget on Needs'
     WHEN v_signal.needs_ratio_current_mo IS NOT NULL THEN 'Needs Within Budget'
     ELSE 'No Data'
   END,
   CASE
     WHEN v_bgt.income_amt > 0
       AND v_signal.needs_ratio_current_mo >
           COALESCE(v_bgt.planned_needs_amt / NULLIF(v_bgt.income_amt,0), 0.5) + 0.05
       THEN 'You''ve spent ' ||
            ROUND(v_signal.needs_ratio_current_mo * 100) ||
            '% of income on needs this month — above your ' ||
            ROUND(COALESCE(v_bgt.planned_needs_amt / NULLIF(v_bgt.income_amt,0), 0.5) * 100) ||
            '% plan.'
     ELSE 'Needs spending is within your committed budget this month.'
   END,
   CASE WHEN v_signal.needs_ratio_current_mo IS NOT NULL
         AND v_bgt.income_amt > 0 THEN 0.90 ELSE 0.45 END
  ),

  -- 7. Savings ratio health vs committed budget
  (p_user_id, date_trunc('month', p_month)::DATE,
   'SAVINGS_RATIO_HEALTH',
   COALESCE(v_signal.savings_ratio_current_mo, 0),
   CASE
     WHEN v_bgt.income_amt > 0
       AND v_signal.savings_ratio_current_mo >=
           COALESCE(v_bgt.planned_assets_amt / NULLIF(v_bgt.income_amt,0), 0.2)
       THEN 'Savings On Track'
     WHEN v_bgt.income_amt > 0
       THEN 'Savings Behind Plan'
     ELSE 'No Data'
   END,
   CASE
     WHEN v_bgt.income_amt > 0
       AND v_signal.savings_ratio_current_mo <
           COALESCE(v_bgt.planned_assets_amt / NULLIF(v_bgt.income_amt,0), 0.2)
       THEN 'You''ve saved ' ||
            ROUND(v_signal.savings_ratio_current_mo * 100) ||
            '% of income so far — your target is ' ||
            ROUND(COALESCE(v_bgt.planned_assets_amt / NULLIF(v_bgt.income_amt,0), 0.2) * 100) ||
            '%. There''s still time this month.'
     ELSE 'Savings rate is meeting your monthly target.'
   END,
   CASE WHEN v_signal.savings_ratio_current_mo IS NOT NULL
         AND v_bgt.income_amt > 0 THEN 0.90 ELSE 0.45 END
  ),

  -- 8. Income stability
  (p_user_id, date_trunc('month', p_month)::DATE,
   'INCOME_STABILITY',
   COALESCE(v_signal.income_3mo_cv, 0),
   CASE
     WHEN v_signal.income_3mo_cv < 0.05 THEN 'Very Stable Income'
     WHEN v_signal.income_3mo_cv < 0.15 THEN 'Stable Income'
     WHEN v_signal.income_3mo_cv < 0.30 THEN 'Moderate Variability'
     ELSE 'Variable Income'
   END,
   CASE
     WHEN v_signal.income_3mo_cv > 0.30
       THEN 'Your income has varied significantly over the past 3 months. '
            || 'Building a buffer helps smooth variable income.'
     WHEN v_signal.income_3mo_cv < 0.05
       THEN 'Very consistent income — great foundation for a fixed savings plan.'
     ELSE 'Your income is relatively stable over the last 3 months.'
   END,
   CASE WHEN v_signal.income_3mo_cv IS NOT NULL THEN 0.85 ELSE 0.40 END
  ),

  -- 9. Savings streak
  (p_user_id, date_trunc('month', p_month)::DATE,
   'SAVINGS_STREAK',
   COALESCE(v_signal.savings_streak_months, 0),
   CASE
     WHEN COALESCE(v_signal.savings_streak_months, 0) >= 6 THEN 'Strong Streak'
     WHEN COALESCE(v_signal.savings_streak_months, 0) >= 3 THEN 'Building Streak'
     WHEN COALESCE(v_signal.savings_streak_months, 0) >= 1 THEN 'Early Streak'
     ELSE 'No Streak'
   END,
   CASE
     WHEN COALESCE(v_signal.savings_streak_months, 0) >= 6
       THEN v_signal.savings_streak_months ||
            ' consecutive months on track for your goals — excellent consistency!'
     WHEN COALESCE(v_signal.savings_streak_months, 0) >= 3
       THEN v_signal.savings_streak_months ||
            ' months on track in a row. Keep the momentum going.'
     WHEN COALESCE(v_signal.savings_streak_months, 0) >= 1
       THEN 'You''re on track this month. One more and it''s a streak!'
     ELSE 'No savings streak yet. Hit your goal target this month to start one.'
   END,
   CASE WHEN v_signal.savings_streak_months IS NOT NULL THEN 0.90 ELSE 0.50 END
  ),

  -- 10. Mandatory payment coverage
  (p_user_id, date_trunc('month', p_month)::DATE,
   'MANDATORY_COVERAGE',
   COALESCE(v_signal.mandatory_coverage_pct, 0),
   CASE
     WHEN COALESCE(v_signal.mandatory_coverage_pct, 0) >= 1.0 THEN 'Fully Covered'
     WHEN COALESCE(v_signal.mandatory_coverage_pct, 0) >= 0.5 THEN 'Partially Covered'
     WHEN v_signal.mandatory_due_amt > 0                      THEN 'Uncovered'
     ELSE 'No Obligations'
   END,
   CASE
     WHEN v_signal.overdue_mandatory_count > 0
       THEN v_signal.overdue_mandatory_count ||
            ' obligation payment(s) totalling ₹' ||
            TO_CHAR(v_signal.overdue_mandatory_amt, 'FM99,99,999') ||
            ' appear overdue this month.'
     WHEN COALESCE(v_signal.mandatory_coverage_pct, 1) < 1.0
       THEN ROUND(v_signal.mandatory_coverage_pct * 100) ||
            '% of your obligation payments are confirmed this month (₹' ||
            TO_CHAR(v_signal.mandatory_paid_amt, 'FM99,99,999') ||
            ' of ₹' || TO_CHAR(v_signal.mandatory_due_amt, 'FM99,99,999') || ').'
     ELSE 'All your obligation payments are covered this month.'
   END,
   CASE WHEN v_signal.mandatory_due_amt > 0 THEN 0.88 ELSE 0.50 END
  );

END;
$$;

COMMENT ON FUNCTION moneymoments.fn_compute_habits_monthly IS
'Writes 10 habit rows per user per month into mm_user_moments.
Reads from mm_signal_daily (must be populated first via the existing
signal computation + fn_compute_mm_signal_extended).
Habit IDs: FREQ_DAILY_TXN, IMPULSE_SPEND_SHARE, WEEKEND_SPEND_RATIO,
EOD_SPEND_RATIO, TOP3_MERCHANT_CONC, NEEDS_RATIO_HEALTH,
SAVINGS_RATIO_HEALTH, INCOME_STABILITY, SAVINGS_STREAK, MANDATORY_COVERAGE.';

-- ============================================================================
-- STEP 4 — Nudge Rule Seeds
-- ============================================================================
-- Three tiers, in priority order:
--   Tier 1 (priority 1-9)  : Mandatory payment obligations
--   Tier 2 (priority 10-19): Goal alignment
--   Tier 3 (priority 20-29): Behavioural patterns
--
-- trigger_conditions_json keys must match column names in mm_signal_daily.
-- score_formula_json is evaluated by the candidate evaluation function (Step 6).
-- ============================================================================

INSERT INTO moneymoments.mm_nudge_rule_master
  (rule_id, name, description, target_domain,
   segment_criteria_json, trigger_conditions_json,
   score_formula_json, cooldown_days, daily_cap, priority, active)
VALUES

-- ── TIER 1: MANDATORY PAYMENT NUDGES ────────────────────────────────────────

(gen_random_uuid(),
 'MANDATORY_OVERDUE_ALERT',
 'One or more obligation payments (EMI/SIP/insurance) are past their expected date and not yet seen',
 'mandatory_payments',
 '{"mandatory_due_amt": {"gt": 0}}',
 '{"overdue_mandatory_count": {"gte": 1}, "day_of_month": {"gte": 7}}',
 '{"base": 100, "overdue_count_multiplier": 15}',
 -- base 100 + 15 per overdue payment; cooldown 3d so we re-alert if still unpaid
 3, 1, 1, TRUE),

(gen_random_uuid(),
 'SIP_NOT_EXECUTED',
 'User SIP / investment contribution expected this month not yet received',
 'mandatory_payments',
 '{"mandatory_due_amt": {"gt": 0}}',
 '{
   "mandatory_coverage_pct": {"lt": 1.0},
   "day_of_month": {"gte": 10},
   "obligation_bucket_filter": "sip"
 }',
 '{"base": 90}',
 5, 1, 2, TRUE),

(gen_random_uuid(),
 'INSURANCE_PREMIUM_DUE',
 'Insurance premium due based on recurring pattern, not yet paid',
 'mandatory_payments',
 '{"mandatory_due_amt": {"gt": 0}}',
 '{
   "overdue_mandatory_count": {"gte": 1},
   "obligation_bucket_filter": "insurance",
   "day_of_month": {"gte": 5}
 }',
 '{"base": 88}',
 7, 1, 3, TRUE),

(gen_random_uuid(),
 'LOAN_EMI_COVERAGE_LOW',
 'Loan EMI payment not yet confirmed this month (NACH / rulebook_financial_class = LOAN_EMI)',
 'mandatory_payments',
 '{"mandatory_due_amt": {"gt": 0}}',
 '{
   "mandatory_coverage_pct": {"lt": 1.0},
   "obligation_bucket_filter": "loan",
   "day_of_month": {"gte": 8}
 }',
 '{"base": 95}',
 3, 1, 4, TRUE),

-- ── TIER 2: GOAL ALIGNMENT NUDGES ───────────────────────────────────────────

(gen_random_uuid(),
 'GOAL_CONTRIBUTION_LOW',
 'Savings rate this month is below committed plan AND top goal is underfunded',
 'goals',
 '{}',
 '{
   "assets_vs_plan_pct": {"lt": 0.75},
   "rank1_goal_underfund_pct": {"gt": 0.10}
 }',
 '{"base": 70, "underfund_pct_weight": 30}',
 7, 1, 10, TRUE),

(gen_random_uuid(),
 'SAVINGS_STREAK_AT_RISK',
 'User has an active streak but current month savings ratio is behind plan',
 'goals',
 '{"savings_streak_months": {"gte": 2}}',
 '{
   "savings_ratio_current_mo": {"lt": 0.80},
   "assets_vs_plan_pct": {"lt": 0.80}
 }',
 '{"base": 80, "streak_length_bonus": 5}',
 -- streak_length_bonus * savings_streak_months added to score
 5, 1, 11, TRUE),

(gen_random_uuid(),
 'GOAL_HIGH_RISK',
 'Top-priority goal has moved to high risk level with < 6 months remaining',
 'goals',
 '{}',
 '{
   "rank1_goal_underfund_pct": {"gt": 0.25},
   "months_remaining": {"lte": 6}
 }',
 '{"base": 85}',
 3, 1, 12, TRUE),

(gen_random_uuid(),
 'WANTS_OVERRUN_GOAL_GAP',
 'Wants overspend this month coincides with goal underfunding — causal tradeoff visible',
 'goals',
 '{}',
 '{
   "wants_vs_plan_pct": {"gt": 1.15},
   "rank1_goal_underfund_amt": {"gt": 0}
 }',
 '{"base": 75, "wants_overrun_weight": 20}',
 5, 1, 13, TRUE),

-- ── TIER 3: BEHAVIOURAL PATTERN NUDGES ──────────────────────────────────────

(gen_random_uuid(),
 'IMPULSE_SPEND_SPIKE',
 'User''s impulse transaction share this month is significantly above their own 90d baseline',
 'behavior',
 '{}',
 '{
   "impulse_txn_share_30d": {"gt": 0.35},
   "impulse_txn_delta_vs_90d": {"gt": 0.20}
 }',
 '{"base": 55, "delta_weight": 15}',
 10, 1, 20, TRUE),

(gen_random_uuid(),
 'WEEKEND_SPLURGE',
 'Weekend spending ratio is notably higher than user''s own 90d baseline',
 'behavior',
 '{}',
 '{
   "weekend_spend_ratio_30d": {"gt": 0.45},
   "weekend_spend_delta_vs_90d": {"gt": 0.20}
 }',
 '{"base": 50}',
 14, 1, 21, TRUE),

(gen_random_uuid(),
 'EOD_SPEND_PATTERN',
 'More than 35% of spend is happening after 8 PM — evening impulse pattern',
 'behavior',
 '{}',
 '{"eod_spend_ratio_30d": {"gt": 0.35}}',
 '{"base": 45}',
 14, 1, 22, TRUE),

(gen_random_uuid(),
 'INCOME_VARIABILITY_HIGH',
 'Income has been unstable over last 3 months — prompt buffer-building',
 'behavior',
 '{}',
 '{"income_3mo_cv": {"gt": 0.25}}',
 '{"base": 60}',
 21, 1, 23, TRUE)

ON CONFLICT DO NOTHING;

-- ============================================================================
-- STEP 5 — Nudge Template Seeds
-- ============================================================================
-- Templates use {{token}} placeholders populated at delivery time from
-- mm_nudge_candidate.reason_json or mm_signal_daily.
-- ============================================================================

-- Helper: fetch rule_id by name (used in template inserts below)
DO $$
DECLARE
  r_overdue_id       UUID;
  r_sip_id           UUID;
  r_insurance_id     UUID;
  r_loan_emi_id      UUID;
  r_goal_contrib_id  UUID;
  r_streak_risk_id   UUID;
  r_goal_risk_id     UUID;
  r_wants_gap_id     UUID;
  r_impulse_id       UUID;
  r_weekend_id       UUID;
  r_eod_id           UUID;
  r_income_var_id    UUID;
BEGIN

  SELECT rule_id INTO r_overdue_id
    FROM moneymoments.mm_nudge_rule_master WHERE name = 'MANDATORY_OVERDUE_ALERT' LIMIT 1;
  SELECT rule_id INTO r_sip_id
    FROM moneymoments.mm_nudge_rule_master WHERE name = 'SIP_NOT_EXECUTED' LIMIT 1;
  SELECT rule_id INTO r_insurance_id
    FROM moneymoments.mm_nudge_rule_master WHERE name = 'INSURANCE_PREMIUM_DUE' LIMIT 1;
  SELECT rule_id INTO r_loan_emi_id
    FROM moneymoments.mm_nudge_rule_master WHERE name = 'LOAN_EMI_COVERAGE_LOW' LIMIT 1;
  SELECT rule_id INTO r_goal_contrib_id
    FROM moneymoments.mm_nudge_rule_master WHERE name = 'GOAL_CONTRIBUTION_LOW' LIMIT 1;
  SELECT rule_id INTO r_streak_risk_id
    FROM moneymoments.mm_nudge_rule_master WHERE name = 'SAVINGS_STREAK_AT_RISK' LIMIT 1;
  SELECT rule_id INTO r_goal_risk_id
    FROM moneymoments.mm_nudge_rule_master WHERE name = 'GOAL_HIGH_RISK' LIMIT 1;
  SELECT rule_id INTO r_wants_gap_id
    FROM moneymoments.mm_nudge_rule_master WHERE name = 'WANTS_OVERRUN_GOAL_GAP' LIMIT 1;
  SELECT rule_id INTO r_impulse_id
    FROM moneymoments.mm_nudge_rule_master WHERE name = 'IMPULSE_SPEND_SPIKE' LIMIT 1;
  SELECT rule_id INTO r_weekend_id
    FROM moneymoments.mm_nudge_rule_master WHERE name = 'WEEKEND_SPLURGE' LIMIT 1;
  SELECT rule_id INTO r_eod_id
    FROM moneymoments.mm_nudge_rule_master WHERE name = 'EOD_SPEND_PATTERN' LIMIT 1;
  SELECT rule_id INTO r_income_var_id
    FROM moneymoments.mm_nudge_rule_master WHERE name = 'INCOME_VARIABILITY_HIGH' LIMIT 1;

  INSERT INTO moneymoments.mm_nudge_template_master
    (template_code, rule_id, channel, locale,
     title_template, body_template, cta_text, cta_deeplink, active)
  VALUES

  -- TIER 1 TEMPLATES
  ('OVERDUE_ALERT_INAPP_EN',    r_overdue_id,   'in_app','en',
   '⚠️ {{overdue_count}} payment(s) may be overdue',
   '{{overdue_names}} totalling ₹{{overdue_amt}} were expected around the {{typical_dom}}. '
   || 'Paying late can affect your credit score or cause service disruption.',
   'Review obligations', 'monytix://payments/mandatory', TRUE),

  ('SIP_REMINDER_INAPP_EN',     r_sip_id,       'in_app','en',
   '📈 SIP not confirmed yet this month',
   'Your SIP of ₹{{typical_amount}} at {{merchant_name}} hasn''t appeared yet this month. '
   || 'If it''s been deducted, it may take a day to reflect.',
   'Check investments', 'monytix://goals/investments', TRUE),

  ('INSURANCE_DUE_INAPP_EN',    r_insurance_id, 'in_app','en',
   '🛡️ Insurance premium due — not yet seen',
   '{{merchant_name}} (₹{{typical_amount}}) was expected around the {{typical_dom}}. '
   || 'A missed premium can lapse your cover.',
   'Mark as paid', 'monytix://payments/mandatory', TRUE),

  ('LOAN_EMI_INAPP_EN',         r_loan_emi_id,  'in_app','en',
   '🏦 Loan EMI not confirmed this month',
   'Your EMI of ₹{{typical_amount}} to {{merchant_name}} hasn''t been detected yet. '
   || 'NACH mandates usually debit around the {{typical_dom}}.',
   'View obligations', 'monytix://payments/mandatory', TRUE),

  -- TIER 2 TEMPLATES
  ('GOAL_CONTRIB_INAPP_EN',     r_goal_contrib_id, 'in_app','en',
   '🎯 {{goal_name}} needs ₹{{shortfall_amount}} more this month',
   'You''ve saved ₹{{saved_this_month}} toward your ₹{{suggested_monthly_need}} monthly target. '
   || '{{months_remaining}} months left to stay on track.',
   'Add to savings', 'monytix://goals/{{goal_id}}', TRUE),

  ('STREAK_RISK_INAPP_EN',      r_streak_risk_id,  'in_app','en',
   '🔥 {{streak_months}}-month streak at risk',
   'You''ve been on track for {{streak_months}} months straight — but this month''s savings '
   || 'are running behind. One more push keeps the streak alive.',
   'See savings plan', 'monytix://budget/savings', TRUE),

  ('GOAL_RISK_INAPP_EN',        r_goal_risk_id,    'in_app','en',
   '🚨 {{goal_name}} is at high risk — {{months_remaining}} months left',
   'At your current pace you''ll be ₹{{remaining_shortfall}} short by {{target_date}}. '
   || 'Increasing your monthly contribution to ₹{{suggested_monthly_need}} would get you there.',
   'Adjust goal plan', 'monytix://goals/{{goal_id}}', TRUE),

  ('WANTS_GAP_INAPP_EN',        r_wants_gap_id,    'in_app','en',
   '💸 ₹{{wants_overrun_amt}} extra on wants — {{goal_name}} still short',
   'You''ve spent ₹{{wants_overrun_amt}} above your wants budget this month. '
   || 'Your top goal is still ₹{{rank1_goal_underfund_amt}} away from its monthly target. '
   || 'Small redirects now make a big difference.',
   'Review budget', 'monytix://budget/review', TRUE),

  -- TIER 3 TEMPLATES
  ('IMPULSE_SPIKE_INAPP_EN',    r_impulse_id,   'in_app','en',
   '⚡ Impulse transactions up {{impulse_delta_pct}}% this month',
   '{{impulse_share_pct}}% of your transactions this month are small UPI payments under ₹500 — '
   || '{{impulse_delta_pct}}% more than your usual pattern. Small amounts add up fast.',
   'See spending', 'monytix://spending/categories', TRUE),

  ('WEEKEND_SPLURGE_INAPP_EN',  r_weekend_id,   'in_app','en',
   '🎉 {{weekend_ratio_pct}}% of spend is on weekends',
   'Your weekend spending is higher than your usual pace. '
   || 'Setting a weekend cash limit is an easy way to keep totals in check.',
   'Set a limit', 'monytix://budget/review', TRUE),

  ('EOD_PATTERN_INAPP_EN',      r_eod_id,       'in_app','en',
   '🌙 {{eod_ratio_pct}}% of your spend happens after 8 PM',
   'Evening transactions tend to be more impulsive. '
   || 'Try a 10-minute pause rule before any purchase after 8 PM.',
   'See pattern', 'monytix://spending/insights', TRUE),

  ('INCOME_VAR_INAPP_EN',       r_income_var_id,'in_app','en',
   '📊 Your income has varied significantly lately',
   'Income has fluctuated over the past 3 months. '
   || 'Keeping 1–2 months of expenses as a buffer smooths variable income cycles.',
   'Build a buffer', 'monytix://goals/emergency', TRUE)

  ON CONFLICT DO NOTHING;

END $$;

-- ============================================================================
-- STEP 6 — fn_evaluate_nudge_candidates()
-- Evaluates all active rules for a user on a given date and writes
-- qualifying candidates to mm_nudge_candidate.
-- This is the daily engine: call once per user per day.
-- Parameters: p_user_id UUID, p_as_of_date DATE
-- ============================================================================

CREATE OR REPLACE FUNCTION moneymoments.fn_evaluate_nudge_candidates(
  p_user_id    UUID,
  p_as_of_date DATE
)
RETURNS INTEGER   -- number of candidates written
LANGUAGE plpgsql
AS $$
DECLARE
  v_signal   moneymoments.mm_signal_daily%ROWTYPE;
  v_rule     moneymoments.mm_nudge_rule_master%ROWTYPE;
  v_template moneymoments.mm_nudge_template_master%ROWTYPE;
  v_dom      INTEGER := EXTRACT(day FROM p_as_of_date);
  v_month    DATE    := date_trunc('month', p_as_of_date)::DATE;

  -- Scalar goal values
  v_goal_id              UUID;
  v_goal_name            TEXT;
  v_goal_months_rem      INTEGER;
  v_goal_underfund_amt   NUMERIC(14,2);
  v_goal_underfund_pct   NUMERIC(6,3);
  v_goal_risk            TEXT;
  v_goal_suggested_mo    NUMERIC(14,2);

  -- Budget variance
  v_wants_vs_plan        NUMERIC(6,3);
  v_assets_vs_plan       NUMERIC(6,3);
  v_wants_overrun_amt    NUMERIC(14,2);
  v_saved_this_month     NUMERIC(14,2);
  v_shortfall_amount     NUMERIC(14,2);

  -- Mandatory overdue detail
  v_overdue_names        TEXT;
  v_overdue_typical_dom  INTEGER;
  v_overdue_typical_amt  NUMERIC(14,2);
  v_overdue_merchant     TEXT;

  -- Control
  v_score      NUMERIC(10,3);
  v_fired      INTEGER := 0;
  v_reason_json JSONB;

  -- Cooldown check
  v_last_delivery TIMESTAMPTZ;
BEGIN

  -- ── Pull latest signal row for this user on this date ─────────────────────
  SELECT * INTO v_signal
  FROM moneymoments.mm_signal_daily
  WHERE user_id    = p_user_id
    AND as_of_date = p_as_of_date;

  IF NOT FOUND THEN
    RETURN 0;  -- no signal computed yet for this user/date; skip
  END IF;

  -- ── Pull top-priority active goal scalars ──────────────────────────────────
  SELECT
    gcs.goal_id,
    ugm.goal_name,
    gcs.months_remaining,
    GREATEST(0, gcs.remaining_amount - COALESCE(gcs.suggested_monthly_need, 0)) AS underfund_amt,
    CASE WHEN gcs.suggested_monthly_need > 0
         THEN LEAST(1.0,
              GREATEST(0, gcs.remaining_amount - COALESCE(gcs.suggested_monthly_need,0))
              / gcs.suggested_monthly_need)
         ELSE 0 END AS underfund_pct,
    gcs.risk_level,
    gcs.suggested_monthly_need
  INTO
    v_goal_id, v_goal_name, v_goal_months_rem,
    v_goal_underfund_amt, v_goal_underfund_pct,
    v_goal_risk, v_goal_suggested_mo
  FROM goalcompass.goal_compass_snapshot gcs
  JOIN goal.user_goals_master ugm
    ON ugm.user_id = gcs.user_id AND ugm.goal_id = gcs.goal_id
  WHERE gcs.user_id = p_user_id
    AND gcs.month   = (
          SELECT MAX(month) FROM goalcompass.goal_compass_snapshot
          WHERE user_id = p_user_id AND month <= v_month
        )
    AND ugm.priority_rank = 1
    AND ugm.status = 'active'
  LIMIT 1;

  -- ── Pull budget variance from budget_user_month_aggregate ─────────────────
  SELECT
    CASE WHEN b.planned_wants_amt  > 0
         THEN ROUND(b.wants_amt  / b.planned_wants_amt,  3) ELSE NULL END,
    CASE WHEN b.planned_assets_amt > 0
         THEN ROUND(b.assets_amt / b.planned_assets_amt, 3) ELSE NULL END,
    GREATEST(0, b.wants_amt  - b.planned_wants_amt),
    b.assets_amt
  INTO
    v_wants_vs_plan, v_assets_vs_plan,
    v_wants_overrun_amt, v_saved_this_month
  FROM budgetpilot.budget_user_month_aggregate b
  WHERE b.user_id = p_user_id AND b.month = v_month;

  v_shortfall_amount := GREATEST(0,
    COALESCE(v_goal_suggested_mo, 0) - COALESCE(v_saved_this_month, 0)
  );

  -- ── Overdue mandatory detail (for template tokens) ─────────────────────────
  SELECT
    STRING_AGG(merchant_name, ', ' ORDER BY typical_amount DESC),
    MAX(typical_dom),
    SUM(typical_amount),
    MAX(merchant_name)
  INTO v_overdue_names, v_overdue_typical_dom, v_overdue_typical_amt, v_overdue_merchant
  FROM moneymoments.mv_mandatory_payment_profile
  WHERE user_id     = p_user_id
    AND overdue_flag = TRUE;

  -- ── Evaluate each active rule ──────────────────────────────────────────────
  FOR v_rule IN
    SELECT * FROM moneymoments.mm_nudge_rule_master
    WHERE active = TRUE
    ORDER BY priority ASC
  LOOP

    -- Check cooldown: skip if same rule delivered within cooldown_days
    SELECT MAX(sent_at) INTO v_last_delivery
    FROM moneymoments.mm_nudge_delivery_log
    WHERE user_id = p_user_id AND rule_id = v_rule.rule_id;

    CONTINUE WHEN v_last_delivery IS NOT NULL
              AND v_last_delivery >= (p_as_of_date - (v_rule.cooldown_days || ' days')::INTERVAL);

    -- ── EVALUATE TRIGGER CONDITIONS ──────────────────────────────────────────
    -- Each rule name is evaluated against the signal + derived values.
    -- We use explicit CASE rather than dynamic JSON eval to keep it readable
    -- and avoid injection risk.

    v_score := 0;

    CASE v_rule.name

      WHEN 'MANDATORY_OVERDUE_ALERT' THEN
        IF COALESCE(v_signal.overdue_mandatory_count, 0) >= 1
           AND v_dom >= 7 THEN
          v_score := 100 + (v_signal.overdue_mandatory_count * 15);
          v_reason_json := jsonb_build_object(
            'overdue_count',    v_signal.overdue_mandatory_count,
            'overdue_names',    COALESCE(v_overdue_names, 'obligation payment'),
            'overdue_amt',      TO_CHAR(COALESCE(v_signal.overdue_mandatory_amt,0), 'FM99,99,999'),
            'typical_dom',      COALESCE(v_overdue_typical_dom, v_dom)
          );
        END IF;

      WHEN 'SIP_NOT_EXECUTED' THEN
        IF COALESCE(v_signal.mandatory_coverage_pct, 1) < 1.0
           AND v_dom >= 10
           AND EXISTS (
             SELECT 1 FROM moneymoments.mv_mandatory_payment_profile
             WHERE user_id = p_user_id
               AND obligation_bucket = 'sip'
               AND paid_amt_this_month < typical_amount
           ) THEN
          v_score := 90;
          SELECT merchant_name, typical_amount, typical_dom
          INTO v_overdue_merchant, v_overdue_typical_amt, v_overdue_typical_dom
          FROM moneymoments.mv_mandatory_payment_profile
          WHERE user_id = p_user_id AND obligation_bucket = 'sip'
            AND paid_amt_this_month < typical_amount
          LIMIT 1;
          v_reason_json := jsonb_build_object(
            'merchant_name',   COALESCE(v_overdue_merchant, 'your SIP provider'),
            'typical_amount',  TO_CHAR(COALESCE(v_overdue_typical_amt,0), 'FM99,99,999'),
            'typical_dom',     COALESCE(v_overdue_typical_dom, 10)
          );
        END IF;

      WHEN 'INSURANCE_PREMIUM_DUE' THEN
        IF COALESCE(v_signal.overdue_mandatory_count, 0) >= 1
           AND v_dom >= 5
           AND EXISTS (
             SELECT 1 FROM moneymoments.mv_mandatory_payment_profile
             WHERE user_id = p_user_id
               AND obligation_bucket = 'insurance'
               AND overdue_flag = TRUE
           ) THEN
          v_score := 88;
          SELECT merchant_name, typical_amount, typical_dom
          INTO v_overdue_merchant, v_overdue_typical_amt, v_overdue_typical_dom
          FROM moneymoments.mv_mandatory_payment_profile
          WHERE user_id = p_user_id AND obligation_bucket = 'insurance'
            AND overdue_flag = TRUE
          LIMIT 1;
          v_reason_json := jsonb_build_object(
            'merchant_name',  COALESCE(v_overdue_merchant, 'insurer'),
            'typical_amount', TO_CHAR(COALESCE(v_overdue_typical_amt,0), 'FM99,99,999'),
            'typical_dom',    COALESCE(v_overdue_typical_dom, 5)
          );
        END IF;

      WHEN 'LOAN_EMI_COVERAGE_LOW' THEN
        IF COALESCE(v_signal.mandatory_coverage_pct, 1) < 1.0
           AND v_dom >= 8
           AND EXISTS (
             SELECT 1 FROM moneymoments.mv_mandatory_payment_profile
             WHERE user_id = p_user_id
               AND obligation_bucket = 'loan'
               AND paid_amt_this_month < typical_amount
           ) THEN
          v_score := 95;
          SELECT merchant_name, typical_amount, typical_dom
          INTO v_overdue_merchant, v_overdue_typical_amt, v_overdue_typical_dom
          FROM moneymoments.mv_mandatory_payment_profile
          WHERE user_id = p_user_id AND obligation_bucket = 'loan'
            AND paid_amt_this_month < typical_amount
          LIMIT 1;
          v_reason_json := jsonb_build_object(
            'merchant_name',  COALESCE(v_overdue_merchant, 'lender'),
            'typical_amount', TO_CHAR(COALESCE(v_overdue_typical_amt,0), 'FM99,99,999'),
            'typical_dom',    COALESCE(v_overdue_typical_dom, 8)
          );
        END IF;

      WHEN 'GOAL_CONTRIBUTION_LOW' THEN
        IF COALESCE(v_assets_vs_plan, 1) < 0.75
           AND COALESCE(v_goal_underfund_pct, 0) > 0.10 THEN
          v_score := 70 + LEAST(30, ROUND(v_goal_underfund_pct * 100));
          v_reason_json := jsonb_build_object(
            'goal_id',              v_goal_id,
            'goal_name',            COALESCE(v_goal_name, 'your top goal'),
            'saved_this_month',     TO_CHAR(COALESCE(v_saved_this_month,0), 'FM99,99,999'),
            'suggested_monthly_need', TO_CHAR(COALESCE(v_goal_suggested_mo,0), 'FM99,99,999'),
            'shortfall_amount',     TO_CHAR(COALESCE(v_shortfall_amount,0),  'FM99,99,999'),
            'months_remaining',     COALESCE(v_goal_months_rem, 0)
          );
        END IF;

      WHEN 'SAVINGS_STREAK_AT_RISK' THEN
        IF COALESCE(v_signal.savings_streak_months, 0) >= 2
           AND COALESCE(v_signal.savings_ratio_current_mo, 1) < 0.80
           AND COALESCE(v_assets_vs_plan, 1) < 0.80 THEN
          v_score := 80 + (COALESCE(v_signal.savings_streak_months, 0) * 5);
          v_reason_json := jsonb_build_object(
            'streak_months', v_signal.savings_streak_months
          );
        END IF;

      WHEN 'GOAL_HIGH_RISK' THEN
        IF COALESCE(v_goal_underfund_pct, 0) > 0.25
           AND COALESCE(v_goal_months_rem, 999) <= 6 THEN
          v_score := 85;
          v_reason_json := jsonb_build_object(
            'goal_id',            v_goal_id,
            'goal_name',          COALESCE(v_goal_name, 'your top goal'),
            'months_remaining',   COALESCE(v_goal_months_rem, 0),
            'remaining_shortfall',TO_CHAR(COALESCE(v_goal_underfund_amt, 0), 'FM99,99,999'),
            'suggested_monthly_need', TO_CHAR(COALESCE(v_goal_suggested_mo,0), 'FM99,99,999')
          );
        END IF;

      WHEN 'WANTS_OVERRUN_GOAL_GAP' THEN
        IF COALESCE(v_wants_vs_plan, 0) > 1.15
           AND COALESCE(v_goal_underfund_amt, 0) > 0 THEN
          v_score := 75 + LEAST(20, ROUND((COALESCE(v_wants_vs_plan,1) - 1) * 100));
          v_reason_json := jsonb_build_object(
            'goal_name',              COALESCE(v_goal_name, 'your top goal'),
            'goal_id',                v_goal_id,
            'wants_overrun_amt',      TO_CHAR(COALESCE(v_wants_overrun_amt,0), 'FM99,99,999'),
            'wants_budget_pct',       ROUND(COALESCE(v_wants_vs_plan,1) * 100),
            'rank1_goal_underfund_amt', TO_CHAR(COALESCE(v_goal_underfund_amt,0), 'FM99,99,999')
          );
        END IF;

      WHEN 'IMPULSE_SPEND_SPIKE' THEN
        IF COALESCE(v_signal.impulse_txn_share_30d, 0) > 0.35
           AND COALESCE(v_signal.impulse_txn_delta_vs_90d, 0) > 0.20 THEN
          v_score := 55 + LEAST(15, ROUND(v_signal.impulse_txn_delta_vs_90d * 50));
          v_reason_json := jsonb_build_object(
            'impulse_share_pct', ROUND(v_signal.impulse_txn_share_30d * 100),
            'impulse_delta_pct', ROUND(v_signal.impulse_txn_delta_vs_90d * 100)
          );
        END IF;

      WHEN 'WEEKEND_SPLURGE' THEN
        IF COALESCE(v_signal.weekend_spend_ratio_30d, 0) > 0.45
           AND COALESCE(v_signal.weekend_spend_delta_vs_90d, 0) > 0.20 THEN
          v_score := 50;
          v_reason_json := jsonb_build_object(
            'weekend_ratio_pct', ROUND(v_signal.weekend_spend_ratio_30d * 100)
          );
        END IF;

      WHEN 'EOD_SPEND_PATTERN' THEN
        IF COALESCE(v_signal.eod_spend_ratio_30d, 0) > 0.35 THEN
          v_score := 45;
          v_reason_json := jsonb_build_object(
            'eod_ratio_pct', ROUND(v_signal.eod_spend_ratio_30d * 100)
          );
        END IF;

      WHEN 'INCOME_VARIABILITY_HIGH' THEN
        IF COALESCE(v_signal.income_3mo_cv, 0) > 0.25 THEN
          v_score := 60;
          v_reason_json := jsonb_build_object(
            'income_cv', ROUND(v_signal.income_3mo_cv * 100)
          );
        END IF;

      ELSE
        NULL;  -- unknown rule, skip

    END CASE;

    -- ── If rule fired, find template and write candidate ─────────────────────
    IF v_score > 0 THEN

      SELECT * INTO v_template
      FROM moneymoments.mm_nudge_template_master
      WHERE rule_id = v_rule.rule_id
        AND channel  = 'in_app'
        AND active   = TRUE
      ORDER BY created_at DESC
      LIMIT 1;

      IF FOUND THEN
        INSERT INTO moneymoments.mm_nudge_candidate
          (user_id, as_of_date, rule_id, template_code, score, reason_json, status)
        VALUES
          (p_user_id, p_as_of_date, v_rule.rule_id,
           v_template.template_code, v_score,
           COALESCE(v_reason_json, '{}'::JSONB), 'pending')
        ON CONFLICT DO NOTHING;

        v_fired := v_fired + 1;
      END IF;

    END IF;

    -- Reset for next rule
    v_score       := 0;
    v_reason_json := NULL;

  END LOOP;

  RETURN v_fired;

END;
$$;

COMMENT ON FUNCTION moneymoments.fn_evaluate_nudge_candidates IS
'Daily nudge evaluation engine for one user.
Reads mm_signal_daily (base + extended columns) + mv_mandatory_payment_profile
+ goalcompass.goal_compass_snapshot + budgetpilot.budget_user_month_aggregate.
Evaluates 12 rules across 3 tiers (mandatory > goals > behaviour).
Respects cooldown_days per rule. Writes qualifying rows to mm_nudge_candidate.
Returns count of candidates written.

Usage:
  SELECT moneymoments.fn_evaluate_nudge_candidates(''<user_uuid>'', CURRENT_DATE);

Batch all users for today:
  SELECT user_id, moneymoments.fn_evaluate_nudge_candidates(user_id, CURRENT_DATE)
  FROM (SELECT DISTINCT user_id FROM moneymoments.mm_signal_daily
        WHERE as_of_date = CURRENT_DATE) u;';

-- ============================================================================
-- PIPELINE SUMMARY
-- ============================================================================
--
-- DAILY (per user, in order):
--   1. Run existing signal computation → writes mm_signal_daily base row
--   2. SELECT moneymoments.fn_compute_mm_signal_extended(user_id, CURRENT_DATE)
--      → fills new columns on the same mm_signal_daily row
--   3. SELECT moneymoments.fn_evaluate_nudge_candidates(user_id, CURRENT_DATE)
--      → writes mm_nudge_candidate rows; downstream delivery picks these up
--
-- MONTHLY (per user, after month closes):
--   4. SELECT moneymoments.fn_compute_habits_monthly(user_id, DATE_TRUNC('month', CURRENT_DATE))
--      → writes 10 habit rows to mm_user_moments for the closed month
--
-- MONTHLY (refresh mandatory profile after new data):
--   5. REFRESH MATERIALIZED VIEW CONCURRENTLY
--      moneymoments.mv_mandatory_payment_profile;
--
-- COLUMN DEPENDENCIES ON txn_enriched (via txn_parsed + txn_fact join):
--   category_id              → mandatory bucket detection, concentration
--   subcategory_id           → sip/nps/loan/insurance bucket routing
--   cat_l1                   → INCOME credit filter, EXPENSE wants filter, LOAN/INVESTMENT
--   channel_type             → NACH/SI = standing instruction detection
--   rulebook_financial_class → LOAN_EMI, INSURANCE, INVESTMENT, HOUSING override
--   merchant_name            → mandatory profile grouping, repeat merchant count
--   direction                → debit/credit split
--   amount, txn_date         → all aggregates
--   txn_time                 → EOD spend pattern (hour >= 20)
--   NOTE: is_card_payment / is_loan_payment / is_investment NOT used
-- ============================================================================

COMMIT;
