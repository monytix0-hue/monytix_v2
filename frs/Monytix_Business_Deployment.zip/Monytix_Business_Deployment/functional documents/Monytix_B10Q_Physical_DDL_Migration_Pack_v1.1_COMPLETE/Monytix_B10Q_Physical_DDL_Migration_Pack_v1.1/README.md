# Monytix B10Q Physical DDL & Migration Pack v1.1

## Target
PostgreSQL 15+ / Supabase-compatible database used by the FastAPI backend.

## Apply order
Run files in `migrations/` in lexical order V001..V025 inside the normal deployment migration framework.

## B10Q implementation choices
These are physical decisions introduced here where B10P intentionally remained logical:
- `pgcrypto` UUID generation (`gen_random_uuid()`).
- tenant context through `SET LOCAL app.business_id` for generic RLS scaffolding; wire this to the project's real membership/auth table before production.
- engine registries use a zero UUID seed scope for global templates; production may migrate global registries to separate global-reference tables.
- typed high-value financial columns plus JSONB only for extensible evidence/config payloads.
- PostgreSQL functions are orchestration helpers, not replacements for owning-engine business formulas.

## Production gates before rollout
1. Replace placeholder tenant-context helper with actual Supabase membership authorization.
2. Run all migrations in a clean staging database.
3. Execute tests in `tests/` and B10P P-T01..P-T50 application-level tests.
4. Validate seed checksums and engine contract versions.
5. Verify RLS with two tenants and service roles.
6. Verify full A→O lineage closure on representative flows.

## Rollback principle
Business truth is versioned and superseded; schema rollbacks should prefer forward-fix migrations. Never drop historical authoritative data as a routine rollback.


## v1.1 Production Hardening

B10Q v1.1 is a forward-only hardening release on top of V001-V025. It adds V026-V030 and T004-T009.

- Append-only M.I.L.E. ledger enforcement and dual current/cumulative views.
- Projection group identity, deterministic tie-break persistence, Pulse/Live capacity triggers, and open-card uniqueness.
- Supersession-safe canonical current views.
- B10N/B10O invariant reconciliation view/function.
- Assertion-based tests for immutability, projection capacity, watermark/current-vs-cumulative separation, supersession and tenant RLS.
- Hero winner selection and critical-alert suppression remain B10O service logic; SQL preserves the ranking inputs and suppression audit trail and T009 verifies those integration prerequisites.
