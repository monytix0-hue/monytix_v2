-- Monytix Business B10Q Physical DDL & Migration Pack v1.0
-- PostgreSQL / Supabase-compatible. Generated from B10P logical contract.
-- IMPORTANT: Engine-owned business formulas remain in their owning services/config; this pack implements persistence/orchestration contracts.
SET statement_timeout = 0;
SET lock_timeout = '5s';
SET idle_in_transaction_session_timeout = '60s';

CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS citext;

DO $$ BEGIN
  CREATE TYPE public.execution_status AS ENUM ('PENDING','RUNNING','SUCCEEDED','FAILED','QUARANTINED','CANCELLED');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE TYPE public.record_status AS ENUM ('ACTIVE','SUPERSEDED','INACTIVE','ANONYMIZED','REVIEW_REQUIRED','QUARANTINED');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE TYPE public.scope_type AS ENUM ('RECORD','PARTITION','BATCH','ENTITY','BUSINESS','TIME_WINDOW');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE TYPE public.recon_status AS ENUM ('PENDING','RUNNING','PASSED','PASSED_WITH_WARNINGS','FAILED','REMEDIATING','RECONCILED');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE TYPE public.severity_level AS ENUM ('INFO','WARNING','HIGH','CRITICAL');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE SCHEMA IF NOT EXISTS platform;
CREATE SCHEMA IF NOT EXISTS ingest;
CREATE SCHEMA IF NOT EXISTS parse;
CREATE SCHEMA IF NOT EXISTS normalize;
CREATE SCHEMA IF NOT EXISTS canonical;
CREATE SCHEMA IF NOT EXISTS party;
CREATE SCHEMA IF NOT EXISTS classify;
CREATE SCHEMA IF NOT EXISTS semantic;
CREATE SCHEMA IF NOT EXISTS pattern;
CREATE SCHEMA IF NOT EXISTS weight;
CREATE SCHEMA IF NOT EXISTS state;
CREATE SCHEMA IF NOT EXISTS decision;
CREATE SCHEMA IF NOT EXISTS mission;
CREATE SCHEMA IF NOT EXISTS outcome;
CREATE SCHEMA IF NOT EXISTS mile;
CREATE SCHEMA IF NOT EXISTS projection;
