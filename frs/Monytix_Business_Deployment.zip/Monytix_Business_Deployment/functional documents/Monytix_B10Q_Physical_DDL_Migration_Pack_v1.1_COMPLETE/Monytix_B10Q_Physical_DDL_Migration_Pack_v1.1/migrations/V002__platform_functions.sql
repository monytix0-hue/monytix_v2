-- Monytix Business B10Q Physical DDL & Migration Pack v1.0
-- PostgreSQL / Supabase-compatible. Generated from B10P logical contract.
-- IMPORTANT: Engine-owned business formulas remain in their owning services/config; this pack implements persistence/orchestration contracts.
SET statement_timeout = 0;
SET lock_timeout = '5s';
SET idle_in_transaction_session_timeout = '60s';

CREATE OR REPLACE FUNCTION platform.current_business_id()
RETURNS uuid
LANGUAGE sql STABLE
AS $$
  SELECT NULLIF(current_setting('app.business_id', true),'')::uuid
$$;

CREATE OR REPLACE FUNCTION platform.current_actor_id()
RETURNS uuid
LANGUAGE sql STABLE
AS $$
  SELECT NULLIF(current_setting('app.actor_id', true),'')::uuid
$$;

CREATE OR REPLACE FUNCTION platform.touch_updated_at()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END $$;

CREATE OR REPLACE FUNCTION platform.assert_nonnegative(v numeric)
RETURNS boolean LANGUAGE sql IMMUTABLE AS $$ SELECT v IS NULL OR v >= 0 $$;

CREATE OR REPLACE FUNCTION platform.uuid7_fallback()
RETURNS uuid LANGUAGE sql VOLATILE AS $$ SELECT gen_random_uuid() $$;
