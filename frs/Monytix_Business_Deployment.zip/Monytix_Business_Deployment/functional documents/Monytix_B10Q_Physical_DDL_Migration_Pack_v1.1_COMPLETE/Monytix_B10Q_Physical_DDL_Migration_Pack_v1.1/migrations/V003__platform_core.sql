-- Monytix Business B10Q Physical DDL & Migration Pack v1.0
-- PostgreSQL / Supabase-compatible. Generated from B10P logical contract.
-- IMPORTANT: Engine-owned business formulas remain in their owning services/config; this pack implements persistence/orchestration contracts.
SET statement_timeout = 0;
SET lock_timeout = '5s';
SET idle_in_transaction_session_timeout = '60s';

CREATE TABLE IF NOT EXISTS platform.engine_registry (
  engine_code text PRIMARY KEY,
  schema_name text NOT NULL,
  contract_version text NOT NULL,
  owner_service text,
  status text NOT NULL DEFAULT 'ACTIVE',
  checksum text,
  effective_from timestamptz NOT NULL DEFAULT now(),
  effective_to timestamptz
);

CREATE TABLE IF NOT EXISTS platform.pipeline_execution (
  execution_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  correlation_id uuid NOT NULL DEFAULT gen_random_uuid(),
  business_id uuid,
  legal_entity_id uuid,
  scope_type public.scope_type NOT NULL,
  scope_ref text,
  restart_engine text,
  status public.execution_status NOT NULL DEFAULT 'PENDING',
  started_at timestamptz,
  completed_at timestamptz,
  error_code text,
  error_detail jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS platform.event_outbox (
  event_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_type text NOT NULL,
  event_version integer NOT NULL DEFAULT 1 CHECK(event_version>0),
  occurred_at timestamptz NOT NULL DEFAULT now(),
  producer_engine text NOT NULL,
  business_id uuid,
  legal_entity_id uuid,
  aggregate_type text NOT NULL,
  aggregate_id uuid NOT NULL,
  aggregate_version integer NOT NULL DEFAULT 1,
  correlation_id uuid NOT NULL,
  causation_id uuid,
  scope_type public.scope_type,
  scope_ref text,
  supersedes jsonb NOT NULL DEFAULT '[]'::jsonb,
  payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  rule_versions jsonb NOT NULL DEFAULT '[]'::jsonb,
  published_at timestamptz,
  publish_attempts integer NOT NULL DEFAULT 0,
  last_error text
);

CREATE TABLE IF NOT EXISTS platform.event_inbox (
  consumer_code text NOT NULL,
  event_id uuid NOT NULL,
  processed_at timestamptz,
  result_ref text,
  status public.execution_status NOT NULL DEFAULT 'PENDING',
  error_detail jsonb,
  PRIMARY KEY (consumer_code,event_id)
);

CREATE TABLE IF NOT EXISTS platform.idempotency_key (
  scope text NOT NULL,
  idempotency_key text NOT NULL,
  business_id uuid,
  actor_id uuid,
  request_hash text NOT NULL,
  result_ref text,
  response_code integer,
  response_body jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz,
  PRIMARY KEY(scope,idempotency_key)
);

CREATE TABLE IF NOT EXISTS platform.supersession_edge (
  edge_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id uuid,
  object_type text NOT NULL,
  old_id uuid NOT NULL,
  old_version integer NOT NULL,
  new_id uuid NOT NULL,
  new_version integer NOT NULL,
  reason text,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(object_type,old_id,old_version,new_id,new_version)
);

CREATE TABLE IF NOT EXISTS platform.lineage_edge (
  lineage_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id uuid,
  relation text NOT NULL,
  from_engine text NOT NULL,
  from_type text NOT NULL,
  from_id uuid NOT NULL,
  from_version integer NOT NULL DEFAULT 1,
  to_engine text NOT NULL,
  to_type text NOT NULL,
  to_id uuid NOT NULL,
  to_version integer NOT NULL DEFAULT 1,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(relation,from_type,from_id,from_version,to_type,to_id,to_version)
);

CREATE TABLE IF NOT EXISTS platform.rule_version (
  rule_version_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  engine_code text NOT NULL,
  rule_code text NOT NULL,
  version text NOT NULL,
  checksum text NOT NULL,
  definition jsonb NOT NULL DEFAULT '{}'::jsonb,
  effective_from timestamptz NOT NULL,
  effective_to timestamptz,
  status text NOT NULL DEFAULT 'ACTIVE',
  UNIQUE(engine_code,rule_code,version)
);

CREATE TABLE IF NOT EXISTS platform.job_definition (
  job_code text PRIMARY KEY,
  engine_code text NOT NULL,
  trigger_type text NOT NULL,
  schedule_expr text,
  max_attempts integer NOT NULL DEFAULT 5,
  base_backoff_seconds integer NOT NULL DEFAULT 5,
  max_backoff_seconds integer NOT NULL DEFAULT 900,
  lease_seconds integer NOT NULL DEFAULT 300,
  concurrency_template text NOT NULL,
  enabled boolean NOT NULL DEFAULT true,
  config jsonb NOT NULL DEFAULT '{}'::jsonb
);

CREATE TABLE IF NOT EXISTS platform.job_run (
  job_run_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_code text NOT NULL REFERENCES platform.job_definition(job_code),
  execution_id uuid REFERENCES platform.pipeline_execution(execution_id),
  business_id uuid,
  scope_type public.scope_type,
  scope_ref text,
  attempt integer NOT NULL DEFAULT 1,
  lease_owner text,
  lease_expires_at timestamptz,
  heartbeat_at timestamptz,
  checkpoint jsonb,
  status public.execution_status NOT NULL DEFAULT 'PENDING',
  started_at timestamptz,
  completed_at timestamptz,
  error_class text,
  error_detail jsonb,
  UNIQUE(job_code,execution_id,attempt)
);

CREATE TABLE IF NOT EXISTS platform.reconciliation_run (
  recon_run_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  recon_code text NOT NULL,
  business_id uuid,
  scope_type public.scope_type NOT NULL,
  scope_ref text,
  as_of timestamptz NOT NULL DEFAULT now(),
  status public.recon_status NOT NULL DEFAULT 'PENDING',
  started_at timestamptz,
  completed_at timestamptz,
  summary jsonb NOT NULL DEFAULT '{}'::jsonb,
  supersedes_run_id uuid REFERENCES platform.reconciliation_run(recon_run_id),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS platform.reconciliation_finding (
  finding_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  recon_run_id uuid NOT NULL REFERENCES platform.reconciliation_run(recon_run_id) ON DELETE CASCADE,
  severity public.severity_level NOT NULL,
  rule_code text NOT NULL,
  object_type text,
  object_id uuid,
  expected jsonb,
  actual jsonb,
  detail text,
  remediation_status text NOT NULL DEFAULT 'OPEN',
  remediation_ref text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS platform.dead_letter (
  dead_letter_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id uuid,
  source_kind text NOT NULL CHECK(source_kind IN ('EVENT','JOB','RECORD')),
  source_ref text NOT NULL,
  payload jsonb NOT NULL,
  error_class text NOT NULL,
  error_detail text,
  retry_count integer NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'OPEN',
  created_at timestamptz NOT NULL DEFAULT now(),
  resolved_at timestamptz
);

CREATE TABLE IF NOT EXISTS platform.audit_record (
  audit_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id uuid,
  actor_id uuid,
  actor_type text NOT NULL,
  action text NOT NULL,
  object_type text NOT NULL,
  object_id uuid,
  object_version integer,
  before_ref text,
  after_ref text,
  reason text,
  correlation_id uuid,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS platform.watermark_checkpoint (
  checkpoint_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id uuid,
  owner_code text NOT NULL,
  scope_type public.scope_type NOT NULL,
  scope_ref text,
  checkpoint_key text NOT NULL,
  checkpoint_value jsonb NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(owner_code,business_id,scope_type,scope_ref,checkpoint_key)
);
