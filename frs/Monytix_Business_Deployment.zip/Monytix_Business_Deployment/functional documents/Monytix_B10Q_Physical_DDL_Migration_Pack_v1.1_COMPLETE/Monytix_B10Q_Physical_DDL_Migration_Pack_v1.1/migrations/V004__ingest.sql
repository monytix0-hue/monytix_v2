-- Monytix Business B10Q Physical DDL & Migration Pack v1.0
-- PostgreSQL / Supabase-compatible. Generated from B10P logical contract.
-- IMPORTANT: Engine-owned business formulas remain in their owning services/config; this pack implements persistence/orchestration contracts.
SET statement_timeout = 0;
SET lock_timeout = '5s';
SET idle_in_transaction_session_timeout = '60s';

CREATE TABLE IF NOT EXISTS ingest.source_provider (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
provider_code text NOT NULL,
  provider_type text NOT NULL,
  display_name text NOT NULL,
  capabilities jsonb NOT NULL DEFAULT '{}'::jsonb,
  UNIQUE(business_id,provider_code),

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS ingest.source_connection (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
source_provider_id uuid REFERENCES ingest.source_provider(id),
  connection_type text NOT NULL,
  masked_identifier text,
  sync_watermark_timestamp timestamptz,
  sync_cursor_token text,
  overlap_window_seconds integer NOT NULL DEFAULT 0,
  credential_ref text,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS ingest.source_object (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
source_connection_id uuid REFERENCES ingest.source_connection(id),
  source_object_type text NOT NULL,
  source_identifier text,
  currency_code text,
  source_timezone text,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS ingest.ingestion_batch (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
source_connection_id uuid REFERENCES ingest.source_connection(id),
  execution_mode text NOT NULL CHECK(execution_mode IN ('STRICT_ATOMIC','PERMISSIVE_STREAM')),
  sequence_type text NOT NULL CHECK(sequence_type IN ('REALTIME','HISTORICAL_BACKFILL','REPLAY','CORRECTION')),
  received_at timestamptz NOT NULL DEFAULT now(),
  source_from timestamptz,
  source_to timestamptz,
  row_count integer,
  accepted_count integer,
  rejected_count integer,
  watermark_applied timestamptz,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS ingest.source_artifact (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
ingestion_batch_id uuid REFERENCES ingest.ingestion_batch(id),
  artifact_type text NOT NULL,
  object_path text,
  content_hash text NOT NULL,
  byte_size bigint,
  encrypted boolean NOT NULL DEFAULT true,
  encryption_key_alias text,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS ingest.artifact_partition (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
source_artifact_id uuid REFERENCES ingest.source_artifact(id),
  source_object_id uuid REFERENCES ingest.source_object(id),
  partition_type text NOT NULL,
  partition_ref text NOT NULL,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS ingest.raw_evidence (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
ingestion_batch_id uuid REFERENCES ingest.ingestion_batch(id),
  source_artifact_id uuid REFERENCES ingest.source_artifact(id),
  artifact_partition_id uuid REFERENCES ingest.artifact_partition(id),
  source_object_id uuid REFERENCES ingest.source_object(id),
  source_record_id text,
  source_timestamp timestamptz,
  received_timestamp timestamptz NOT NULL DEFAULT now(),
  raw_payload jsonb NOT NULL,
  payload_hash text NOT NULL,
  encrypted boolean NOT NULL DEFAULT true,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS ingest.evidence_fingerprint (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
ingestion_batch_id uuid REFERENCES ingest.ingestion_batch(id),
  raw_evidence_id uuid REFERENCES ingest.raw_evidence(id),
  code text,
  value jsonb,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS ingest.ingestion_validation (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
ingestion_batch_id uuid REFERENCES ingest.ingestion_batch(id),
  raw_evidence_id uuid REFERENCES ingest.raw_evidence(id),
  code text,
  value jsonb,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS ingest.source_coverage (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
ingestion_batch_id uuid REFERENCES ingest.ingestion_batch(id),
  raw_evidence_id uuid REFERENCES ingest.raw_evidence(id),
  code text,
  value jsonb,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS ingest.ingestion_error (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
ingestion_batch_id uuid REFERENCES ingest.ingestion_batch(id),
  raw_evidence_id uuid REFERENCES ingest.raw_evidence(id),
  code text,
  value jsonb,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
