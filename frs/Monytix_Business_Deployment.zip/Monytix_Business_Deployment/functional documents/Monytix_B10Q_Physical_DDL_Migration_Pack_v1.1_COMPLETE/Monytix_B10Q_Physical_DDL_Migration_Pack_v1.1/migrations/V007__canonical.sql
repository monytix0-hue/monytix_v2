-- Monytix Business B10Q Physical DDL & Migration Pack v1.0
-- PostgreSQL / Supabase-compatible. Generated from B10P logical contract.
-- IMPORTANT: Engine-owned business formulas remain in their owning services/config; this pack implements persistence/orchestration contracts.
SET statement_timeout = 0;
SET lock_timeout = '5s';
SET idle_in_transaction_session_timeout = '60s';

CREATE TABLE IF NOT EXISTS canonical.canonical_event (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
normalized_record_id uuid REFERENCES normalize.normalized_record(id),
  family_code text NOT NULL,
  event_type text NOT NULL,
  amount_abs numeric(38,18),
  currency_code text,
  effective_from timestamptz,
  effective_to timestamptz,
  event_payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  recanonicalization_count integer NOT NULL DEFAULT 0,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS canonical.canonical_object (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
normalized_record_id uuid REFERENCES normalize.normalized_record(id),
  family_code text NOT NULL,
  object_type text NOT NULL,
  as_of timestamptz,
  amount_abs numeric(38,18),
  currency_code text,
  effective_from timestamptz,
  effective_to timestamptz,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS canonical.canonical_link (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
from_event_id uuid,
  from_object_id uuid,
  to_event_id uuid,
  to_object_id uuid,
  relation_type text NOT NULL,
  settlement_status text,
  unsettled_residual_amount numeric(38,18),
  currency_code text,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS canonical.canonical_split_leg (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
canonical_event_id uuid REFERENCES canonical.canonical_event(id),
  leg_type text NOT NULL CHECK(leg_type IN ('GROSS','FEE','TAX','DISCOUNT','NET','OTHER')),
  amount_abs numeric(38,18) NOT NULL CHECK(amount_abs>=0),
  currency_code text NOT NULL,
  leg_order integer NOT NULL DEFAULT 1,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS canonical.canonical_candidate (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
canonical_event_id uuid REFERENCES canonical.canonical_event(id),
  canonical_object_id uuid REFERENCES canonical.canonical_object(id),
  code text,
  value jsonb,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS canonical.canonical_decision (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
canonical_event_id uuid REFERENCES canonical.canonical_event(id),
  canonical_object_id uuid REFERENCES canonical.canonical_object(id),
  code text,
  value jsonb,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS canonical.canonical_issue (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
canonical_event_id uuid REFERENCES canonical.canonical_event(id),
  canonical_object_id uuid REFERENCES canonical.canonical_object(id),
  code text,
  value jsonb,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS canonical.canonical_snapshot (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
canonical_event_id uuid REFERENCES canonical.canonical_event(id),
  canonical_object_id uuid REFERENCES canonical.canonical_object(id),
  code text,
  value jsonb,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
