-- Monytix Business B10Q Physical DDL & Migration Pack v1.0
-- PostgreSQL / Supabase-compatible. Generated from B10P logical contract.
-- IMPORTANT: Engine-owned business formulas remain in their owning services/config; this pack implements persistence/orchestration contracts.
SET statement_timeout = 0;
SET lock_timeout = '5s';
SET idle_in_transaction_session_timeout = '60s';

CREATE TABLE IF NOT EXISTS weight.weight_evidence (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
weight_code text NOT NULL CHECK(weight_code IN ('BW01','BW02','BW03','BW04')),
  economic_fact_id uuid,
  source_type text NOT NULL,
  source_id uuid,
  raw_value numeric(38,18),
  normalized_value numeric(18,12),
  materiality_factor numeric(7,6),
  persistence_factor numeric(7,6),

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS weight.economic_fact_group (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
upstream_economic_fact_id uuid,
  fact_key text NOT NULL,
  UNIQUE(business_id,fact_key),

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS weight.weight_contribution (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
weight_evidence_id uuid REFERENCES weight.weight_evidence(id),
  weight_code text NOT NULL,
  signed_contribution numeric(18,12) NOT NULL,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS weight.weight_normalization_basis (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
weight_code text NOT NULL,
  basis_code text NOT NULL,
  denominator numeric(38,18),
  window_start timestamptz,
  window_end timestamptz,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS weight.weight_snapshot (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
as_of timestamptz NOT NULL,
  bw01_obligation_pressure numeric(18,12),
  bw02_risk_pressure numeric(18,12),
  bw03_protection_adequacy numeric(18,12),
  bw04_dependency_pressure numeric(18,12),
  coverage numeric(7,6),
  evidence_count integer NOT NULL DEFAULT 0,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS weight.weight_explanation (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
weight_snapshot_id uuid REFERENCES weight.weight_snapshot(id),
  code text,
  value jsonb,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS weight.weight_recompute_request (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
weight_snapshot_id uuid REFERENCES weight.weight_snapshot(id),
  code text,
  value jsonb,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
