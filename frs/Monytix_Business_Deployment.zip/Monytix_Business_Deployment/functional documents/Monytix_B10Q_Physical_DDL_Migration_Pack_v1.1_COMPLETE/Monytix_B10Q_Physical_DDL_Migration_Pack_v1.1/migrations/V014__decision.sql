-- Monytix Business B10Q Physical DDL & Migration Pack v1.0
-- PostgreSQL / Supabase-compatible. Generated from B10P logical contract.
-- IMPORTANT: Engine-owned business formulas remain in their owning services/config; this pack implements persistence/orchestration contracts.
SET statement_timeout = 0;
SET lock_timeout = '5s';
SET idle_in_transaction_session_timeout = '60s';

CREATE TABLE IF NOT EXISTS decision.decision_registry (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
decision_code text NOT NULL,
  category text NOT NULL,
  name text NOT NULL,
  active boolean NOT NULL DEFAULT true,
  UNIQUE(business_id,decision_code),

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS decision.decision_candidate (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
decision_code text NOT NULL,
  state_snapshot_id uuid,
  evidence jsonb NOT NULL,
  candidate_score numeric(18,12),

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS decision.eligibility_result (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
decision_code text NOT NULL,
  eligible boolean NOT NULL,
  suppressor_codes text[] NOT NULL DEFAULT '{}',
  prerequisite_codes text[] NOT NULL DEFAULT '{}',
  evaluated_at timestamptz NOT NULL DEFAULT now(),

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS decision.decision_instance (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
decision_code text NOT NULL,
  eligibility_result_id uuid REFERENCES decision.eligibility_result(id),
  lifecycle_state text NOT NULL,
  presented_at timestamptz,
  selected_at timestamptz,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS decision.strategy_option (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
decision_code text NOT NULL,
  option_code text NOT NULL,
  name text NOT NULL,
  option_payload jsonb NOT NULL,
  UNIQUE(business_id,decision_code,option_code),

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS decision.user_selection (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
decision_instance_id uuid REFERENCES decision.decision_instance(id),
  strategy_option_id uuid REFERENCES decision.strategy_option(id),
  selected_by uuid,
  selection_context jsonb,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS decision.goal_specification (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
decision_instance_id uuid REFERENCES decision.decision_instance(id),
  target_amount numeric(38,18),
  currency_code text,
  target_date date,
  cadence text,
  constraints jsonb,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS decision.mechanism_registry (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
mechanism_code text NOT NULL,
  mechanism_type text NOT NULL,
  name text NOT NULL,
  suitability_attributes jsonb NOT NULL,
  UNIQUE(business_id,mechanism_code),

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS decision.mechanism_match (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
decision_instance_id uuid REFERENCES decision.decision_instance(id),
  mechanism_code text NOT NULL,
  suitability_score numeric(7,6),
  reason_codes text[] NOT NULL DEFAULT '{}',

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS decision.suitability_result (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
decision_instance_id uuid REFERENCES decision.decision_instance(id),
  code text,
  value jsonb,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS decision.decision_conflict (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
decision_instance_id uuid REFERENCES decision.decision_instance(id),
  code text,
  value jsonb,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
