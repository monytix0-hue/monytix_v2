-- Monytix Business B10Q Physical DDL & Migration Pack v1.0
-- PostgreSQL / Supabase-compatible. Generated from B10P logical contract.
-- IMPORTANT: Engine-owned business formulas remain in their owning services/config; this pack implements persistence/orchestration contracts.
SET statement_timeout = 0;
SET lock_timeout = '5s';
SET idle_in_transaction_session_timeout = '60s';

CREATE TABLE IF NOT EXISTS mission.mission_registry (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
mission_code text NOT NULL,
  family_code text NOT NULL,
  name text NOT NULL,
  UNIQUE(business_id,mission_code),

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS mission.mission_instance (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
mission_code text NOT NULL,
  source_decision_instance_id uuid,
  lifecycle_state text NOT NULL,
  target_amount numeric(38,18),
  currency_code text,
  target_date date,
  activated_at timestamptz,
  completed_at timestamptz,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS mission.mission_decision_priority (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
mission_instance_id uuid REFERENCES mission.mission_instance(id),
  decision_code text NOT NULL,
  priority_class text NOT NULL CHECK(priority_class IN ('P0','P1','P2','P3','P4','P5')),
  reason text,
  active boolean NOT NULL DEFAULT true,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS mission.milestone (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
mission_instance_id uuid REFERENCES mission.mission_instance(id),
  milestone_code text NOT NULL,
  target_value numeric(38,18),
  achieved_value numeric(38,18),
  due_at timestamptz,
  achieved_at timestamptz,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS mission.action (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
mission_instance_id uuid REFERENCES mission.mission_instance(id),
  milestone_id uuid REFERENCES mission.milestone(id),
  action_code text NOT NULL,
  action_type text NOT NULL,
  lifecycle_state text NOT NULL,
  target_amount numeric(38,18),
  currency_code text,
  due_at timestamptz,
  completed_at timestamptz,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS mission.action_dependency (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
action_id uuid REFERENCES mission.action(id),
  depends_on_action_id uuid REFERENCES mission.action(id),
  dependency_type text NOT NULL,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS mission.funding_schedule (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
mission_instance_id uuid REFERENCES mission.mission_instance(id),
  action_id uuid REFERENCES mission.action(id),
  scheduled_for date NOT NULL,
  amount numeric(38,18) NOT NULL,
  currency_code text NOT NULL,
  status_text text NOT NULL DEFAULT 'PLANNED',

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS mission.economic_pool_reservation (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
mission_instance_id uuid REFERENCES mission.mission_instance(id),
  pool_key text NOT NULL,
  reserved_amount numeric(38,18),
  currency_code text,
  released_at timestamptz,
  UNIQUE(business_id,pool_key,status),

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS mission.execution_evidence (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
mission_instance_id uuid REFERENCES mission.mission_instance(id),
  action_id uuid REFERENCES mission.action(id),
  code text,
  value jsonb,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS mission.progress_snapshot (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
mission_instance_id uuid REFERENCES mission.mission_instance(id),
  action_id uuid REFERENCES mission.action(id),
  code text,
  value jsonb,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS mission.reminder (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
mission_instance_id uuid REFERENCES mission.mission_instance(id),
  action_id uuid REFERENCES mission.action(id),
  code text,
  value jsonb,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS mission.recovery_plan (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
mission_instance_id uuid REFERENCES mission.mission_instance(id),
  action_id uuid REFERENCES mission.action(id),
  code text,
  value jsonb,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS mission.mission_issue (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
mission_instance_id uuid REFERENCES mission.mission_instance(id),
  action_id uuid REFERENCES mission.action(id),
  code text,
  value jsonb,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
