-- Monytix Business B10Q Physical DDL & Migration Pack v1.0
-- PostgreSQL / Supabase-compatible. Generated from B10P logical contract.
-- IMPORTANT: Engine-owned business formulas remain in their owning services/config; this pack implements persistence/orchestration contracts.
SET statement_timeout = 0;
SET lock_timeout = '5s';
SET idle_in_transaction_session_timeout = '60s';

CREATE TABLE IF NOT EXISTS mile.dimension_registry (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
dimension_code text NOT NULL,
  name text NOT NULL,
  description text,
  UNIQUE(business_id,dimension_code),

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS mile.recognition_group (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
improvement_cluster_id text NOT NULL,
  primary_dimension_code text NOT NULL,
  outcome_id uuid,
  impact_id uuid,
  recognized_at timestamptz,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS mile.recognition_eligibility (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
recognition_group_id uuid REFERENCES mile.recognition_group(id),
  eligible boolean NOT NULL,
  reason_codes text[] NOT NULL DEFAULT '{}',
  evaluated_at timestamptz NOT NULL DEFAULT now(),

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS mile.normalization_basis (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
recognition_group_id uuid REFERENCES mile.recognition_group(id),
  dimension_code text NOT NULL,
  target_value numeric(38,18),
  gap_value numeric(38,18),
  denominator numeric(38,18),
  unit text,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS mile.mile_ledger (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
recognition_group_id uuid REFERENCES mile.recognition_group(id),
  dimension_code text NOT NULL,
  entry_type text NOT NULL CHECK(entry_type IN ('RECOGNITION','ADJUSTMENT','CORRECTION')),
  progress_units numeric(38,18) NOT NULL,
  source_delta numeric(38,18),
  source_unit text,
  confidence_factor numeric(7,6),
  durability_factor numeric(7,6),
  recognized_at timestamptz NOT NULL,
  prior_entry_id uuid REFERENCES mile.mile_ledger(id),

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS mile.recognition_watermark (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
improvement_cluster_id text NOT NULL,
  dimension_code text NOT NULL,
  highest_recognized_value numeric(38,18),
  source_unit text,
  UNIQUE(business_id,improvement_cluster_id,dimension_code),

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS mile.current_standing (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
dimension_code text NOT NULL,
  as_of timestamptz NOT NULL,
  current_value numeric(38,18),
  target_value numeric(38,18),
  normalized_progress numeric(18,12),
  UNIQUE(business_id,dimension_code,as_of),

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS mile.cumulative_achievement (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
dimension_code text NOT NULL,
  as_of timestamptz NOT NULL,
  cumulative_units numeric(38,18) NOT NULL,
  UNIQUE(business_id,dimension_code,as_of),

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS mile.improvement_cluster (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
improvement_cluster_id text NOT NULL,
  economic_fact_id uuid,
  outcome_id uuid,
  definition jsonb NOT NULL,
  UNIQUE(business_id,improvement_cluster_id),

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS mile.mile_explanation (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
recognition_group_id uuid REFERENCES mile.recognition_group(id),
  explanation jsonb NOT NULL,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
