-- Monytix Business B10Q Physical DDL & Migration Pack v1.0
-- PostgreSQL / Supabase-compatible. Generated from B10P logical contract.
-- IMPORTANT: Engine-owned business formulas remain in their owning services/config; this pack implements persistence/orchestration contracts.
SET statement_timeout = 0;
SET lock_timeout = '5s';
SET idle_in_transaction_session_timeout = '60s';

CREATE TABLE IF NOT EXISTS projection.projection_source (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
source_engine text NOT NULL,
  source_type text NOT NULL,
  source_id uuid NOT NULL,
  source_version integer NOT NULL,
  source_as_of timestamptz,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS projection.eligibility (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
projection_source_id uuid REFERENCES projection.projection_source(id),
  surface text NOT NULL,
  eligible boolean NOT NULL,
  reason_codes text[] NOT NULL DEFAULT '{}',

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS projection.candidate (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
projection_source_id uuid REFERENCES projection.projection_source(id),
  surface text NOT NULL,
  candidate_type text NOT NULL,
  title text NOT NULL,
  body text,
  severity text,
  action_ref jsonb,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS projection.attention_score (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
candidate_id uuid REFERENCES projection.candidate(id),
  impact numeric(7,6),
  urgency numeric(7,6),
  decisionability numeric(7,6),
  mission_relevance numeric(7,6),
  climate_relevance numeric(7,6),
  total_score numeric(7,6),

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS projection.significance_score (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
candidate_id uuid REFERENCES projection.candidate(id),
  impact numeric(7,6),
  urgency numeric(7,6),
  novelty numeric(7,6),
  decision_potential numeric(7,6),
  mission_relevance numeric(7,6),
  total_score numeric(7,6),

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS projection.suppression (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
candidate_id uuid REFERENCES projection.candidate(id),
  suppressed_by_candidate_id uuid,
  reason_code text NOT NULL,
  starts_at timestamptz NOT NULL DEFAULT now(),
  ends_at timestamptz,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS projection.projection_card (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
candidate_id uuid REFERENCES projection.candidate(id),
  surface text NOT NULL,
  slot_code text,
  rank integer,
  title text NOT NULL,
  subtitle text,
  body text,
  freshness_state text,
  explainability_ref text,
  active_from timestamptz NOT NULL DEFAULT now(),
  active_to timestamptz,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS projection.surface_slot (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
projection_card_id uuid REFERENCES projection.projection_card(id),
  candidate_id uuid REFERENCES projection.candidate(id),
  surface text,
  code text,
  value jsonb,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS projection.freshness (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
projection_card_id uuid REFERENCES projection.projection_card(id),
  candidate_id uuid REFERENCES projection.candidate(id),
  surface text,
  code text,
  value jsonb,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS projection.narrative_template (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
projection_card_id uuid REFERENCES projection.projection_card(id),
  candidate_id uuid REFERENCES projection.candidate(id),
  surface text,
  code text,
  value jsonb,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS projection.explainability_payload (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
projection_card_id uuid REFERENCES projection.projection_card(id),
  candidate_id uuid REFERENCES projection.candidate(id),
  surface text,
  code text,
  value jsonb,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS projection.journey_qualification (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
projection_card_id uuid REFERENCES projection.projection_card(id),
  candidate_id uuid REFERENCES projection.candidate(id),
  surface text,
  code text,
  value jsonb,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS projection.reward_recognition (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
projection_card_id uuid REFERENCES projection.projection_card(id),
  candidate_id uuid REFERENCES projection.candidate(id),
  surface text,
  code text,
  value jsonb,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS projection.molybot_context (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
projection_card_id uuid REFERENCES projection.projection_card(id),
  candidate_id uuid REFERENCES projection.candidate(id),
  surface text,
  code text,
  value jsonb,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS projection.interaction (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
projection_card_id uuid REFERENCES projection.projection_card(id),
  candidate_id uuid REFERENCES projection.candidate(id),
  surface text,
  code text,
  value jsonb,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
CREATE TABLE IF NOT EXISTS projection.projection_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
projection_card_id uuid REFERENCES projection.projection_card(id),
  candidate_id uuid REFERENCES projection.candidate(id),
  surface text,
  code text,
  value jsonb,

  business_id uuid NOT NULL,
  legal_entity_id uuid,
  object_version integer NOT NULL DEFAULT 1 CHECK(object_version>0),
  status public.record_status NOT NULL DEFAULT 'ACTIVE',
  effective_at timestamptz,
  supersedes_id uuid,
  rule_version text,
  model_version text,
  confidence numeric(7,6) CHECK(confidence IS NULL OR (confidence>=0 AND confidence<=1)),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()

);
