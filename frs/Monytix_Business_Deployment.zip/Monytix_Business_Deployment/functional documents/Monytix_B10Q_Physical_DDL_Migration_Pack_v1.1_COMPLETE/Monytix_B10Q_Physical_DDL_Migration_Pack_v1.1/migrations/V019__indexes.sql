-- Monytix Business B10Q Physical DDL & Migration Pack v1.0
-- PostgreSQL / Supabase-compatible. Generated from B10P logical contract.
-- IMPORTANT: Engine-owned business formulas remain in their owning services/config; this pack implements persistence/orchestration contracts.
SET statement_timeout = 0;
SET lock_timeout = '5s';
SET idle_in_transaction_session_timeout = '60s';

CREATE INDEX IF NOT EXISTS ix_outbox_unpublished ON platform.event_outbox(published_at,occurred_at) WHERE published_at IS NULL;
CREATE INDEX IF NOT EXISTS ix_lineage_from ON platform.lineage_edge(business_id,from_type,from_id,from_version);
CREATE INDEX IF NOT EXISTS ix_lineage_to ON platform.lineage_edge(business_id,to_type,to_id,to_version);
CREATE INDEX IF NOT EXISTS ix_job_run_active ON platform.job_run(job_code,business_id,status,lease_expires_at);
CREATE INDEX IF NOT EXISTS ix_recon_findings_open ON platform.reconciliation_finding(recon_run_id,severity,remediation_status);

CREATE INDEX IF NOT EXISTS ix_raw_evidence_batch ON ingest.raw_evidence(business_id,ingestion_batch_id,source_timestamp);
CREATE UNIQUE INDEX IF NOT EXISTS uq_raw_evidence_hash ON ingest.raw_evidence(business_id,payload_hash);
CREATE INDEX IF NOT EXISTS ix_parsed_record_raw ON parse.parsed_record(business_id,raw_evidence_id);
CREATE INDEX IF NOT EXISTS ix_normalized_parsed ON normalize.normalized_record(business_id,parsed_record_id);
CREATE INDEX IF NOT EXISTS ix_canonical_event_time ON canonical.canonical_event(business_id,effective_at,status);
CREATE INDEX IF NOT EXISTS ix_canonical_object_asof ON canonical.canonical_object(business_id,as_of,status);
CREATE INDEX IF NOT EXISTS ix_party_alias_norm ON party.party_alias(business_id,normalized_alias);
CREATE INDEX IF NOT EXISTS ix_party_identifier_hash ON party.party_identifier(business_id,identifier_type,identifier_hash);
CREATE INDEX IF NOT EXISTS ix_category_event ON classify.category_assignment(business_id,canonical_event_id,status);
CREATE INDEX IF NOT EXISTS ix_semantic_event ON semantic.semantic_attribute_assignment(business_id,canonical_event_id,attribute_code,status);
CREATE INDEX IF NOT EXISTS ix_pattern_window ON pattern.pattern_instance(business_id,pattern_code,window_end,status);
CREATE INDEX IF NOT EXISTS ix_profile_asof ON pattern.financial_profile_snapshot(business_id,profile_code,as_of DESC,status);
CREATE INDEX IF NOT EXISTS ix_weight_asof ON weight.weight_snapshot(business_id,as_of DESC,status);
CREATE INDEX IF NOT EXISTS ix_fio_asof ON state.fio_snapshot(business_id,fio_code,as_of DESC,status);
CREATE INDEX IF NOT EXISTS ix_state_asof ON state.derived_state_snapshot(business_id,state_code,as_of DESC,status);
CREATE INDEX IF NOT EXISTS ix_decision_lifecycle ON decision.decision_instance(business_id,decision_code,lifecycle_state,status);
CREATE INDEX IF NOT EXISTS ix_mission_active ON mission.mission_instance(business_id,lifecycle_state,target_date,status);
CREATE INDEX IF NOT EXISTS ix_action_due ON mission.action(business_id,lifecycle_state,due_at,status);
CREATE INDEX IF NOT EXISTS ix_outcome_verified ON outcome.verification_result(business_id,outcome_code,verified_at,status);
CREATE INDEX IF NOT EXISTS ix_mile_ledger_time ON mile.mile_ledger(business_id,dimension_code,recognized_at,status);
CREATE INDEX IF NOT EXISTS ix_projection_surface ON projection.projection_card(business_id,surface,active_from,active_to,status);
