-- Monytix Business B10Q Physical DDL & Migration Pack v1.0
-- PostgreSQL / Supabase-compatible. Generated from B10P logical contract.
-- IMPORTANT: Engine-owned business formulas remain in their owning services/config; this pack implements persistence/orchestration contracts.
SET statement_timeout = 0;
SET lock_timeout = '5s';
SET idle_in_transaction_session_timeout = '60s';

CREATE OR REPLACE VIEW canonical.current_event AS
SELECT DISTINCT ON (business_id,id) * FROM canonical.canonical_event
WHERE status='ACTIVE' ORDER BY business_id,id,object_version DESC;

CREATE OR REPLACE VIEW weight.current_snapshot AS
SELECT DISTINCT ON (business_id) * FROM weight.weight_snapshot
WHERE status='ACTIVE' ORDER BY business_id,as_of DESC,object_version DESC;

CREATE OR REPLACE VIEW state.current_fio AS
SELECT DISTINCT ON (business_id,fio_code) * FROM state.fio_snapshot
WHERE status='ACTIVE' ORDER BY business_id,fio_code,as_of DESC,object_version DESC;

CREATE OR REPLACE VIEW state.current_derived_state AS
SELECT DISTINCT ON (business_id,state_code) * FROM state.derived_state_snapshot
WHERE status='ACTIVE' ORDER BY business_id,state_code,as_of DESC,object_version DESC;

CREATE OR REPLACE VIEW mile.current_portfolio AS
SELECT business_id,
       max(as_of) AS as_of,
       jsonb_object_agg(dimension_code, jsonb_build_object('current_value',current_value,'target_value',target_value,'normalized_progress',normalized_progress)) AS dimensions
FROM mile.current_standing
WHERE status='ACTIVE'
GROUP BY business_id;

CREATE OR REPLACE VIEW projection.active_cards AS
SELECT * FROM projection.projection_card
WHERE status='ACTIVE' AND active_from <= now() AND (active_to IS NULL OR active_to > now());
