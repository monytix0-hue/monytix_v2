-- Monytix Business B10Q Physical DDL & Migration Pack v1.0
-- PostgreSQL / Supabase-compatible. Generated from B10P logical contract.
-- IMPORTANT: Engine-owned business formulas remain in their owning services/config; this pack implements persistence/orchestration contracts.
SET statement_timeout = 0;
SET lock_timeout = '5s';
SET idle_in_transaction_session_timeout = '60s';

-- B10Q implementation choice: tenant context is set server-side through SET LOCAL app.business_id = '<uuid>'.
-- In Supabase, replace/extend this helper with an auth.uid()-backed membership join if the project exposes membership tables.
DO $$
DECLARE r record;
BEGIN
  FOR r IN
    SELECT table_schema, table_name
    FROM information_schema.columns
    WHERE column_name='business_id'
      AND table_schema IN ('platform','ingest','parse','normalize','canonical','party','classify','semantic','pattern','weight','state','decision','mission','outcome','mile','projection')
    GROUP BY table_schema,table_name
  LOOP
    EXECUTE format('ALTER TABLE %I.%I ENABLE ROW LEVEL SECURITY',r.table_schema,r.table_name);
    BEGIN
      EXECUTE format('CREATE POLICY tenant_isolation ON %I.%I USING (business_id = platform.current_business_id()) WITH CHECK (business_id = platform.current_business_id())',r.table_schema,r.table_name);
    EXCEPTION WHEN duplicate_object THEN NULL;
    END;
  END LOOP;
END $$;
