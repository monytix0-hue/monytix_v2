-- Monytix Business B10Q Physical DDL & Migration Pack v1.0
-- PostgreSQL / Supabase-compatible. Generated from B10P logical contract.
-- IMPORTANT: Engine-owned business formulas remain in their owning services/config; this pack implements persistence/orchestration contracts.
SET statement_timeout = 0;
SET lock_timeout = '5s';
SET idle_in_transaction_session_timeout = '60s';

INSERT INTO platform.engine_registry(engine_code,schema_name,contract_version,owner_service,status)
VALUES
('B10A','ingest','1.1','ingestion','ACTIVE'),('B10B','parse','1.1','parser','ACTIVE'),('B10C','normalize','1.1','normalizer','ACTIVE'),
('B10D','canonical','1.1','canonicalizer','ACTIVE'),('B10E','party','1.1','party-resolver','ACTIVE'),('B10F1','classify','1.0','classifier','ACTIVE'),
('B10F','classify','1.0','classifier','ACTIVE'),('B10G','semantic','1.0','semantic-engine','ACTIVE'),('B10H','pattern','1.0','pattern-engine','ACTIVE'),
('B10I','weight','1.0','weight-engine','ACTIVE'),('B10J','state','1.0','state-engine','ACTIVE'),('B10K','decision','1.0','decision-engine','ACTIVE'),
('B10L','mission','1.0','mission-engine','ACTIVE'),('B10M','outcome','1.0','outcome-engine','ACTIVE'),('B10N','mile','1.0','mile-engine','ACTIVE'),
('B10O','projection','1.0','projection-engine','ACTIVE'),('B10P','platform','1.0','platform-orchestrator','ACTIVE')
ON CONFLICT(engine_code) DO UPDATE SET contract_version=excluded.contract_version, schema_name=excluded.schema_name;

INSERT INTO mile.dimension_registry(business_id,dimension_code,name,description)
VALUES
('00000000-0000-0000-0000-000000000000','MONEY','Money','Verified improvement in money retained, recovered, saved or sustainably improved.'),
('00000000-0000-0000-0000-000000000000','PROTECTION','Protection','Verified strengthening of reserves, coverage or protection.'),
('00000000-0000-0000-0000-000000000000','FREEDOM','Freedom','Verified reduction in obligations/debt constraints.'),
('00000000-0000-0000-0000-000000000000','STRENGTH','Strength','Verified reduction in operational/dependency fragility.'),
('00000000-0000-0000-0000-000000000000','READINESS','Readiness','Verified increase in capacity/readiness for the next objective.')
ON CONFLICT(business_id,dimension_code) DO NOTHING;

INSERT INTO state.derived_state_registry(business_id,state_code,name)
VALUES
('00000000-0000-0000-0000-000000000000','DS01','Liquidity'),('00000000-0000-0000-0000-000000000000','DS02','Flexibility'),
('00000000-0000-0000-0000-000000000000','DS03','Resilience'),('00000000-0000-0000-0000-000000000000','DS04','Capacity'),
('00000000-0000-0000-0000-000000000000','DS05','Exposure'),('00000000-0000-0000-0000-000000000000','DS06','Efficiency'),
('00000000-0000-0000-0000-000000000000','DS07','Predictability'),('00000000-0000-0000-0000-000000000000','DS08','Growth Readiness'),
('00000000-0000-0000-0000-000000000000','DS09','Survival Pressure')
ON CONFLICT(business_id,state_code) DO NOTHING;

INSERT INTO decision.decision_registry(business_id,decision_code,category,name)
VALUES
('00000000-0000-0000-0000-000000000000','D01','Reserve & Liquidity','Allocate Available Surplus To Reserve'),
('00000000-0000-0000-0000-000000000000','D02','Reserve & Liquidity','Accelerate Reserve Growth'),
('00000000-0000-0000-0000-000000000000','D03','Reserve & Liquidity','Protect Cash Position'),
('00000000-0000-0000-0000-000000000000','D04','Reserve & Liquidity','Retain Cash Position'),
('00000000-0000-0000-0000-000000000000','D05','Expense Optimization','Review Expense Growth'),
('00000000-0000-0000-0000-000000000000','D06','Expense Optimization','Reduce Vendor Spend'),
('00000000-0000-0000-0000-000000000000','D07','Expense Optimization','Optimize Software Spend'),
('00000000-0000-0000-0000-000000000000','D08','Expense Optimization','Control Operational Leakage'),
('00000000-0000-0000-0000-000000000000','D09','Allocation','Reserve vs Growth Allocation'),
('00000000-0000-0000-0000-000000000000','D10','Allocation','Allocate Growth Budget'),
('00000000-0000-0000-0000-000000000000','D11','Allocation','Split Allocation Strategy'),
('00000000-0000-0000-0000-000000000000','D12','Allocation','Delay Allocation'),
('00000000-0000-0000-0000-000000000000','D13','Risk Management','Increase Reserve Coverage'),
('00000000-0000-0000-0000-000000000000','D14','Risk Management','Review Customer Concentration'),
('00000000-0000-0000-0000-000000000000','D15','Risk Management','Review Vendor Concentration'),
('00000000-0000-0000-0000-000000000000','D16','Strategic Readiness','Improve Operational Efficiency'),
('00000000-0000-0000-0000-000000000000','D17','Strategic Readiness','Strengthen Business Stability'),
('00000000-0000-0000-0000-000000000000','D18','Strategic Readiness','Prepare For Growth')
ON CONFLICT(business_id,decision_code) DO NOTHING;
