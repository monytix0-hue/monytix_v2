-- Monytix Business B10Q Physical DDL & Migration Pack v1.0
-- PostgreSQL / Supabase-compatible. Generated from B10P logical contract.
-- IMPORTANT: Engine-owned business formulas remain in their owning services/config; this pack implements persistence/orchestration contracts.
SET statement_timeout = 0;
SET lock_timeout = '5s';
SET idle_in_transaction_session_timeout = '60s';

CREATE OR REPLACE FUNCTION platform.enqueue_event(
  p_event_type text, p_producer_engine text, p_business_id uuid,
  p_aggregate_type text, p_aggregate_id uuid, p_aggregate_version integer,
  p_correlation_id uuid, p_payload jsonb DEFAULT '{}'::jsonb,
  p_scope_type public.scope_type DEFAULT NULL, p_scope_ref text DEFAULT NULL
) RETURNS uuid LANGUAGE plpgsql AS $$
DECLARE v_id uuid := gen_random_uuid();
BEGIN
  INSERT INTO platform.event_outbox(event_id,event_type,producer_engine,business_id,aggregate_type,aggregate_id,aggregate_version,correlation_id,payload,scope_type,scope_ref)
  VALUES(v_id,p_event_type,p_producer_engine,p_business_id,p_aggregate_type,p_aggregate_id,p_aggregate_version,p_correlation_id,coalesce(p_payload,'{}'::jsonb),p_scope_type,p_scope_ref);
  RETURN v_id;
END $$;

CREATE OR REPLACE FUNCTION platform.claim_job(p_job_code text,p_business_id uuid,p_worker text,p_lease_seconds integer DEFAULT 300)
RETURNS uuid LANGUAGE plpgsql AS $$
DECLARE v_id uuid;
BEGIN
  SELECT job_run_id INTO v_id FROM platform.job_run
  WHERE job_code=p_job_code AND business_id IS NOT DISTINCT FROM p_business_id
    AND status IN ('PENDING','RUNNING')
    AND (lease_expires_at IS NULL OR lease_expires_at < now())
  ORDER BY created_at FOR UPDATE SKIP LOCKED LIMIT 1;
  IF v_id IS NOT NULL THEN
    UPDATE platform.job_run SET status='RUNNING',lease_owner=p_worker,lease_expires_at=now()+make_interval(secs=>p_lease_seconds),heartbeat_at=now(),started_at=coalesce(started_at,now()) WHERE job_run_id=v_id;
  END IF;
  RETURN v_id;
END $$;
