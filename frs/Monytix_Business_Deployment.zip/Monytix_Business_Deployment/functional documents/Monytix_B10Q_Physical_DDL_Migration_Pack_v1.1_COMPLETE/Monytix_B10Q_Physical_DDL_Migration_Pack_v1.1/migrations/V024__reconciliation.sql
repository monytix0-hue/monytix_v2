-- Monytix Business B10Q Physical DDL & Migration Pack v1.0
-- PostgreSQL / Supabase-compatible. Generated from B10P logical contract.
-- IMPORTANT: Engine-owned business formulas remain in their owning services/config; this pack implements persistence/orchestration contracts.
SET statement_timeout = 0;
SET lock_timeout = '5s';
SET idle_in_transaction_session_timeout = '60s';

CREATE OR REPLACE VIEW platform.v_lineage_orphans AS
SELECT le.* FROM platform.lineage_edge le
WHERE le.business_id IS NOT NULL
  AND (le.from_id IS NULL OR le.to_id IS NULL);

CREATE OR REPLACE VIEW platform.v_active_projection_without_source AS
SELECT pc.id AS projection_card_id, pc.business_id, pc.surface, pc.title
FROM projection.projection_card pc
LEFT JOIN projection.candidate c ON c.id=pc.candidate_id
LEFT JOIN projection.projection_source ps ON ps.id=c.projection_source_id
WHERE pc.status='ACTIVE' AND (c.id IS NULL OR ps.id IS NULL);

CREATE OR REPLACE VIEW platform.v_outbox_lag AS
SELECT producer_engine, count(*) AS pending_count, min(occurred_at) AS oldest_pending
FROM platform.event_outbox WHERE published_at IS NULL GROUP BY producer_engine;

CREATE OR REPLACE FUNCTION platform.run_core_reconciliation(p_business_id uuid)
RETURNS uuid LANGUAGE plpgsql AS $$
DECLARE v_run uuid := gen_random_uuid();
BEGIN
  INSERT INTO platform.reconciliation_run(recon_run_id,recon_code,business_id,scope_type,scope_ref,status,started_at)
  VALUES(v_run,'R_CORE',p_business_id,'BUSINESS',p_business_id::text,'RUNNING',now());

  INSERT INTO platform.reconciliation_finding(recon_run_id,severity,rule_code,detail)
  SELECT v_run,'CRITICAL','R17','Active projection missing candidate/source lineage'
  WHERE EXISTS(SELECT 1 FROM platform.v_active_projection_without_source WHERE business_id=p_business_id);

  UPDATE platform.reconciliation_run
  SET status=CASE WHEN EXISTS(SELECT 1 FROM platform.reconciliation_finding WHERE recon_run_id=v_run AND severity='CRITICAL') THEN 'FAILED' ELSE 'PASSED' END,
      completed_at=now()
  WHERE recon_run_id=v_run;
  RETURN v_run;
END $$;
