-- Monytix Business B10Q Physical DDL & Migration Pack v1.0
-- PostgreSQL / Supabase-compatible. Generated from B10P logical contract.
-- IMPORTANT: Engine-owned business formulas remain in their owning services/config; this pack implements persistence/orchestration contracts.
SET statement_timeout = 0;
SET lock_timeout = '5s';
SET idle_in_transaction_session_timeout = '60s';

INSERT INTO platform.job_definition(job_code,engine_code,trigger_type,concurrency_template,config)
VALUES
('J-A1','B10A','SCHEDULE_OR_EVENT','J-A1:{business_id}:{scope_ref}','{}'),
('J-B1','B10B','EVENT','J-B1:{business_id}:{scope_ref}','{}'),
('J-C1','B10C','EVENT','J-C1:{business_id}:{scope_ref}','{}'),
('J-D1','B10D','EVENT','J-D1:{business_id}:{scope_ref}','{}'),
('J-E1','B10E','EVENT','J-E1:{business_id}:{scope_ref}','{}'),
('J-F1','B10F','EVENT','J-F1:{business_id}:{scope_ref}','{}'),
('J-G1','B10G','EVENT','J-G1:{business_id}:{scope_ref}','{}'),
('J-H1','B10H','EVENT_OR_WINDOW','J-H1:{business_id}:{scope_ref}','{}'),
('J-I1','B10I','EVENT','J-I1:{business_id}:{scope_ref}','{}'),
('J-J1','B10J','EVENT','J-J1:{business_id}:{scope_ref}','{}'),
('J-K1','B10K','EVENT','J-K1:{business_id}:{scope_ref}','{}'),
('J-L1','B10L','EVENT','J-L1:{business_id}:{scope_ref}','{}'),
('J-M1','B10M','EVENT_OR_WINDOW','J-M1:{business_id}:{scope_ref}','{}'),
('J-N1','B10N','EVENT','J-N1:{business_id}:{scope_ref}','{}'),
('J-O1','B10O','EVENT_OR_SCHEDULE','J-O1:{business_id}:{scope_ref}','{}')
ON CONFLICT(job_code) DO UPDATE SET engine_code=excluded.engine_code,trigger_type=excluded.trigger_type;
