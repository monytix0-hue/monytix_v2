-- Monytix Business B10Q Physical DDL & Migration Pack v1.1
-- Production hardening: B10N append-only recognition ledger and dual-view accounting.
SET statement_timeout = 0;
SET lock_timeout = '5s';
SET idle_in_transaction_session_timeout = '60s';

ALTER TABLE mile.mile_ledger
  ADD CONSTRAINT ck_mile_ledger_confidence_factor
    CHECK (confidence_factor IS NULL OR (confidence_factor >= 0 AND confidence_factor <= 1)) NOT VALID,
  ADD CONSTRAINT ck_mile_ledger_durability_factor
    CHECK (durability_factor IS NULL OR (durability_factor >= 0 AND durability_factor <= 1)) NOT VALID;

ALTER TABLE mile.mile_ledger VALIDATE CONSTRAINT ck_mile_ledger_confidence_factor;
ALTER TABLE mile.mile_ledger VALIDATE CONSTRAINT ck_mile_ledger_durability_factor;

CREATE OR REPLACE FUNCTION mile.reject_mile_ledger_mutation()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  RAISE EXCEPTION 'mile.mile_ledger is append-only; use ADJUSTMENT or CORRECTION entries instead of %', TG_OP
    USING ERRCODE = '55000';
END $$;

DROP TRIGGER IF EXISTS trg_mile_ledger_append_only ON mile.mile_ledger;
CREATE TRIGGER trg_mile_ledger_append_only
BEFORE UPDATE OR DELETE ON mile.mile_ledger
FOR EACH ROW EXECUTE FUNCTION mile.reject_mile_ledger_mutation();

CREATE UNIQUE INDEX IF NOT EXISTS uq_mile_ledger_idempotency
ON mile.mile_ledger(business_id, recognition_group_id, dimension_code, entry_type, recognized_at, prior_entry_id)
WHERE status='ACTIVE';

CREATE OR REPLACE VIEW mile.current_standing_view AS
SELECT DISTINCT ON (business_id, dimension_code)
       business_id, legal_entity_id, dimension_code, as_of,
       current_value, target_value, normalized_progress,
       confidence, object_version, metadata
FROM mile.current_standing
WHERE status='ACTIVE'
ORDER BY business_id, dimension_code, as_of DESC, object_version DESC, created_at DESC;

CREATE OR REPLACE VIEW mile.cumulative_achievement_view AS
SELECT DISTINCT ON (business_id, dimension_code)
       business_id, legal_entity_id, dimension_code, as_of,
       cumulative_units, confidence, object_version, metadata
FROM mile.cumulative_achievement
WHERE status='ACTIVE'
ORDER BY business_id, dimension_code, as_of DESC, object_version DESC, created_at DESC;

CREATE OR REPLACE VIEW mile.portfolio_view AS
SELECT COALESCE(s.business_id,c.business_id) AS business_id,
       COALESCE(s.dimension_code,c.dimension_code) AS dimension_code,
       s.as_of AS standing_as_of,
       s.current_value,
       s.target_value,
       s.normalized_progress,
       c.as_of AS achievement_as_of,
       c.cumulative_units,
       s.confidence AS standing_confidence,
       c.confidence AS achievement_confidence
FROM mile.current_standing_view s
FULL OUTER JOIN mile.cumulative_achievement_view c
  ON c.business_id=s.business_id AND c.dimension_code=s.dimension_code;

COMMENT ON VIEW mile.portfolio_view IS
'B10N dual-view contract: current standing may deteriorate; cumulative verified achievement remains historical recognition. Do not substitute one for the other.';
