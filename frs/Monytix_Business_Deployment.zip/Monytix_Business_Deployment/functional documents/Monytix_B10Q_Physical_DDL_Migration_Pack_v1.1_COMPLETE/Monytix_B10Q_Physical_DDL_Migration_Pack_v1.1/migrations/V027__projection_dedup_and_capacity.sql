-- Monytix Business B10Q Physical DDL & Migration Pack v1.1
-- Production hardening: B10O projection identity, deduplication, deterministic ranking and surface capacity.
SET statement_timeout = 0;
SET lock_timeout = '5s';
SET idle_in_transaction_session_timeout = '60s';

ALTER TABLE projection.projection_source ADD COLUMN IF NOT EXISTS projection_group_id uuid;
ALTER TABLE projection.candidate ADD COLUMN IF NOT EXISTS projection_group_id uuid;
ALTER TABLE projection.candidate ADD COLUMN IF NOT EXISTS deterministic_tiebreak_key text;
ALTER TABLE projection.projection_card ADD COLUMN IF NOT EXISTS projection_group_id uuid;
ALTER TABLE projection.projection_card ADD COLUMN IF NOT EXISTS deterministic_tiebreak_key text;

UPDATE projection.projection_source SET projection_group_id=id WHERE projection_group_id IS NULL;
UPDATE projection.candidate c
SET projection_group_id=COALESCE(s.projection_group_id,c.id),
    deterministic_tiebreak_key=COALESCE(c.deterministic_tiebreak_key,c.id::text)
FROM projection.projection_source s
WHERE c.projection_source_id=s.id
  AND (c.projection_group_id IS NULL OR c.deterministic_tiebreak_key IS NULL);
UPDATE projection.candidate
SET projection_group_id=id,
    deterministic_tiebreak_key=COALESCE(deterministic_tiebreak_key,id::text)
WHERE projection_group_id IS NULL;
UPDATE projection.projection_card pc
SET projection_group_id=COALESCE(c.projection_group_id,pc.id),
    deterministic_tiebreak_key=COALESCE(pc.deterministic_tiebreak_key,c.deterministic_tiebreak_key,pc.id::text)
FROM projection.candidate c
WHERE pc.candidate_id=c.id
  AND (pc.projection_group_id IS NULL OR pc.deterministic_tiebreak_key IS NULL);
UPDATE projection.projection_card
SET projection_group_id=id,
    deterministic_tiebreak_key=COALESCE(deterministic_tiebreak_key,id::text)
WHERE projection_group_id IS NULL;

ALTER TABLE projection.projection_source ALTER COLUMN projection_group_id SET NOT NULL;
ALTER TABLE projection.candidate ALTER COLUMN projection_group_id SET NOT NULL;
ALTER TABLE projection.candidate ALTER COLUMN deterministic_tiebreak_key SET NOT NULL;
ALTER TABLE projection.projection_card ALTER COLUMN projection_group_id SET NOT NULL;
ALTER TABLE projection.projection_card ALTER COLUMN deterministic_tiebreak_key SET NOT NULL;

ALTER TABLE projection.projection_card
  ADD CONSTRAINT ck_projection_rank_positive CHECK(rank IS NULL OR rank > 0) NOT VALID;
ALTER TABLE projection.projection_card VALIDATE CONSTRAINT ck_projection_rank_positive;

CREATE INDEX IF NOT EXISTS ix_projection_source_group
  ON projection.projection_source(business_id,projection_group_id,source_engine,source_type,status);
CREATE INDEX IF NOT EXISTS ix_projection_candidate_group_surface
  ON projection.candidate(business_id,surface,projection_group_id,status);
CREATE INDEX IF NOT EXISTS ix_projection_card_group_surface
  ON projection.projection_card(business_id,surface,projection_group_id,status,active_to);

CREATE UNIQUE INDEX IF NOT EXISTS uq_projection_open_group_per_surface
ON projection.projection_card(business_id,surface,projection_group_id)
WHERE status='ACTIVE' AND active_to IS NULL;

CREATE UNIQUE INDEX IF NOT EXISTS uq_projection_open_rank_per_surface
ON projection.projection_card(business_id,surface,rank)
WHERE status='ACTIVE' AND active_to IS NULL AND rank IS NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS uq_pulse_open_hero
ON projection.projection_card(business_id)
WHERE surface='PULSE' AND slot_code='HERO' AND status='ACTIVE' AND active_to IS NULL;
CREATE UNIQUE INDEX IF NOT EXISTS uq_pulse_open_mission
ON projection.projection_card(business_id)
WHERE surface='PULSE' AND slot_code='MISSION' AND status='ACTIVE' AND active_to IS NULL;
CREATE UNIQUE INDEX IF NOT EXISTS uq_pulse_open_progress
ON projection.projection_card(business_id)
WHERE surface='PULSE' AND slot_code='PROGRESS' AND status='ACTIVE' AND active_to IS NULL;
CREATE UNIQUE INDEX IF NOT EXISTS uq_pulse_open_foundation
ON projection.projection_card(business_id)
WHERE surface='PULSE' AND slot_code='FOUNDATION' AND status='ACTIVE' AND active_to IS NULL;

CREATE OR REPLACE FUNCTION projection.enforce_surface_capacity()
RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE
  n_total integer;
  n_slot integer;
BEGIN
  IF NEW.status <> 'ACTIVE' OR NEW.active_to IS NOT NULL THEN
    RETURN NEW;
  END IF;

  IF NEW.surface='PULSE' THEN
    SELECT count(*) INTO n_total
    FROM projection.projection_card p
    WHERE p.business_id=NEW.business_id AND p.surface='PULSE'
      AND p.status='ACTIVE' AND p.active_to IS NULL
      AND p.id <> NEW.id;
    IF n_total >= 6 THEN
      RAISE EXCEPTION 'PULSE capacity exceeded: maximum 6 open cards per business' USING ERRCODE='23514';
    END IF;

    IF NEW.slot_code IN ('OPPORTUNITY','ALERT') THEN
      SELECT count(*) INTO n_slot
      FROM projection.projection_card p
      WHERE p.business_id=NEW.business_id AND p.surface='PULSE'
        AND p.slot_code IN ('OPPORTUNITY','ALERT')
        AND p.status='ACTIVE' AND p.active_to IS NULL
        AND p.id <> NEW.id;
      IF n_slot >= 2 THEN
        RAISE EXCEPTION 'PULSE action capacity exceeded: maximum 2 OPPORTUNITY/ALERT cards' USING ERRCODE='23514';
      END IF;
    END IF;
  ELSIF NEW.surface='LIVE' THEN
    IF NEW.slot_code IN ('SIGNAL','ALERT','OPPORTUNITY') THEN
      SELECT count(*) INTO n_slot
      FROM projection.projection_card p
      WHERE p.business_id=NEW.business_id AND p.surface='LIVE'
        AND p.slot_code=NEW.slot_code
        AND p.status='ACTIVE' AND p.active_to IS NULL
        AND p.id <> NEW.id;
      IF (NEW.slot_code='SIGNAL' AND n_slot >= 4)
         OR (NEW.slot_code='ALERT' AND n_slot >= 2)
         OR (NEW.slot_code='OPPORTUNITY' AND n_slot >= 2) THEN
        RAISE EXCEPTION 'LIVE capacity exceeded for slot %', NEW.slot_code USING ERRCODE='23514';
      END IF;
    END IF;
  END IF;
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS trg_projection_surface_capacity ON projection.projection_card;
CREATE TRIGGER trg_projection_surface_capacity
BEFORE INSERT OR UPDATE OF business_id,surface,slot_code,status,active_to
ON projection.projection_card
FOR EACH ROW EXECUTE FUNCTION projection.enforce_surface_capacity();

COMMENT ON COLUMN projection.projection_card.projection_group_id IS
'Stable cross-surface grouping/deduplication identity. Same source intelligence may project differently by surface but not duplicate within a surface.';
COMMENT ON COLUMN projection.projection_card.deterministic_tiebreak_key IS
'Service-supplied stable tie-break key used after score equality; database preserves and indexes the deterministic ordering input.';
