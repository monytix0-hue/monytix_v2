-- Monytix Business B10Q Physical DDL & Migration Pack v1.1
-- Production hardening: supersession-safe current views.
SET statement_timeout = 0;
SET lock_timeout = '5s';
SET idle_in_transaction_session_timeout = '60s';

CREATE INDEX IF NOT EXISTS ix_canonical_event_supersedes
  ON canonical.canonical_event(business_id,supersedes_id,status);
CREATE INDEX IF NOT EXISTS ix_canonical_object_supersedes
  ON canonical.canonical_object(business_id,supersedes_id,status);

CREATE OR REPLACE VIEW canonical.current_event AS
SELECT e.*
FROM canonical.canonical_event e
WHERE e.status='ACTIVE'
  AND NOT EXISTS (
    SELECT 1 FROM canonical.canonical_event child
    WHERE child.business_id=e.business_id
      AND child.supersedes_id=e.id
      AND child.status='ACTIVE'
  );

CREATE OR REPLACE VIEW canonical.current_object AS
SELECT o.*
FROM canonical.canonical_object o
WHERE o.status='ACTIVE'
  AND NOT EXISTS (
    SELECT 1 FROM canonical.canonical_object child
    WHERE child.business_id=o.business_id
      AND child.supersedes_id=o.id
      AND child.status='ACTIVE'
  );

CREATE OR REPLACE VIEW projection.active_cards AS
SELECT p.*
FROM projection.projection_card p
WHERE p.status='ACTIVE'
  AND p.active_from <= now()
  AND (p.active_to IS NULL OR p.active_to > now())
  AND NOT EXISTS (
    SELECT 1 FROM projection.projection_card child
    WHERE child.business_id=p.business_id
      AND child.supersedes_id=p.id
      AND child.status='ACTIVE'
      AND child.active_from <= now()
      AND (child.active_to IS NULL OR child.active_to > now())
  );
