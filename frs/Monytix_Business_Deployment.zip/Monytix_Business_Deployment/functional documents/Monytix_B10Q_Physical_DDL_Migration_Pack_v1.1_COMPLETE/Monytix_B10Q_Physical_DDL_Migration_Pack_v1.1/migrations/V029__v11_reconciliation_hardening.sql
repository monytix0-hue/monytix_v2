-- Monytix Business B10Q Physical DDL & Migration Pack v1.1
-- Reconciliation hardening for B10N/B10O invariants introduced by v1.1.
SET statement_timeout = 0;
SET lock_timeout = '5s';
SET idle_in_transaction_session_timeout = '60s';

CREATE OR REPLACE VIEW platform.v11_invariant_violations AS
SELECT 'Q11-MILE-001'::text AS rule_code, business_id, id AS object_id,
       'MILE confidence/durability factor outside 0..1'::text AS detail
FROM mile.mile_ledger
WHERE (confidence_factor IS NOT NULL AND (confidence_factor<0 OR confidence_factor>1))
   OR (durability_factor IS NOT NULL AND (durability_factor<0 OR durability_factor>1))
UNION ALL
SELECT 'Q11-PROJ-001', business_id, min(id),
       'More than 6 open PULSE cards'
FROM projection.projection_card
WHERE surface='PULSE' AND status='ACTIVE' AND active_to IS NULL
GROUP BY business_id HAVING count(*)>6
UNION ALL
SELECT 'Q11-PROJ-002', business_id, min(id),
       'More than 2 open PULSE opportunity/alert cards'
FROM projection.projection_card
WHERE surface='PULSE' AND slot_code IN ('OPPORTUNITY','ALERT')
  AND status='ACTIVE' AND active_to IS NULL
GROUP BY business_id HAVING count(*)>2
UNION ALL
SELECT 'Q11-PROJ-003', business_id, min(id),
       'Duplicate open projection_group_id within a surface'
FROM projection.projection_card
WHERE status='ACTIVE' AND active_to IS NULL
GROUP BY business_id,surface,projection_group_id HAVING count(*)>1
UNION ALL
SELECT 'Q11-CAN-001', e.business_id, e.id,
       'Active canonical event has more than one active superseding child'
FROM canonical.canonical_event e
JOIN canonical.canonical_event child
  ON child.business_id=e.business_id AND child.supersedes_id=e.id AND child.status='ACTIVE'
WHERE e.status='ACTIVE'
GROUP BY e.business_id,e.id HAVING count(*)>1;

CREATE OR REPLACE FUNCTION platform.run_v11_invariant_reconciliation(p_business_id uuid DEFAULT NULL)
RETURNS integer LANGUAGE plpgsql AS $$
DECLARE
  v_run uuid;
  v_count integer;
BEGIN
  INSERT INTO platform.reconciliation_run(recon_code,business_id,scope_type,scope_ref,status,started_at)
  VALUES('B10Q_V11_HARDENING',p_business_id,
         'BUSINESS'::public.scope_type,
         COALESCE(p_business_id::text,'ALL'),'RUNNING',now())
  RETURNING recon_run_id INTO v_run;

  INSERT INTO platform.reconciliation_finding(recon_run_id,severity,rule_code,object_type,object_id,detail)
  SELECT v_run,'HIGH'::public.severity_level,rule_code,'B10Q_V11',object_id,detail
  FROM platform.v11_invariant_violations
  WHERE p_business_id IS NULL OR business_id=p_business_id;

  GET DIAGNOSTICS v_count = ROW_COUNT;
  UPDATE platform.reconciliation_run
  SET status=CASE WHEN v_count=0 THEN 'PASSED'::public.recon_status ELSE 'FAILED'::public.recon_status END,
      completed_at=now(), summary=jsonb_build_object('finding_count',v_count)
  WHERE recon_run_id=v_run;
  RETURN v_count;
END $$;
