-- Monytix Business B10Q Physical DDL & Migration Pack v1.1
-- Schema guards and documentation for service-vs-database responsibility boundaries.
SET statement_timeout = 0;
SET lock_timeout = '5s';
SET idle_in_transaction_session_timeout = '60s';

CREATE INDEX IF NOT EXISTS ix_projection_tiebreak
ON projection.projection_card(business_id,surface,rank,deterministic_tiebreak_key)
WHERE status='ACTIVE' AND active_to IS NULL;

CREATE INDEX IF NOT EXISTS ix_mile_watermark_lookup
ON mile.recognition_watermark(business_id,improvement_cluster_id,dimension_code,highest_recognized_value)
WHERE status='ACTIVE';

COMMENT ON TABLE projection.suppression IS
'B10O service logic writes suppression relationships here. Critical-alert suppression and ranking winner selection are service decisions; SQL enforces capacity, uniqueness, identity and auditability, not business ranking formulas.';
COMMENT ON TABLE mile.recognition_watermark IS
'High-watermark prevents re-earning previously recognized ground after deterioration/recovery. Current standing may fall without reducing historical achievement by default.';
COMMENT ON TABLE mile.mile_ledger IS
'Append-only verified recognition ledger. Corrections must be new ADJUSTMENT/CORRECTION rows; UPDATE and DELETE are rejected by v1.1 trigger.';
