-- B10Q smoke checks
SELECT engine_code, schema_name, contract_version FROM platform.engine_registry ORDER BY engine_code;
SELECT job_code,engine_code FROM platform.job_definition ORDER BY job_code;
SELECT count(*) AS schemas_present FROM information_schema.schemata WHERE schema_name IN ('platform','ingest','parse','normalize','canonical','party','classify','semantic','pattern','weight','state','decision','mission','outcome','mile','projection');
SELECT table_schema,count(*) FROM information_schema.tables WHERE table_schema IN ('platform','ingest','parse','normalize','canonical','party','classify','semantic','pattern','weight','state','decision','mission','outcome','mile','projection') GROUP BY table_schema ORDER BY table_schema;
