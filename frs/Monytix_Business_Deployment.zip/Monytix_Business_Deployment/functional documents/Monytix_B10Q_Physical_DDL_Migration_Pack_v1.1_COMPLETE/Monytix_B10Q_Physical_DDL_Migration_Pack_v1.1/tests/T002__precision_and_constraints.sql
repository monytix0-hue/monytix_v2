-- Must fail if binary-float columns appear in financial schemas.
SELECT table_schema,table_name,column_name,data_type
FROM information_schema.columns
WHERE table_schema IN ('canonical','weight','state','decision','mission','outcome','mile')
AND data_type IN ('real','double precision');
