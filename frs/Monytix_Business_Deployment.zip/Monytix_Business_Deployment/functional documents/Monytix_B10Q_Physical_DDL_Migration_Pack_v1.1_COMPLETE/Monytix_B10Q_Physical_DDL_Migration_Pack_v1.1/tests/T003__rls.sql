-- Review RLS status for tenant-owned tables.
SELECT n.nspname AS schema_name,c.relname AS table_name,c.relrowsecurity
FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
WHERE n.nspname IN ('platform','ingest','parse','normalize','canonical','party','classify','semantic','pattern','weight','state','decision','mission','outcome','mile','projection')
AND c.relkind='r' ORDER BY 1,2;
