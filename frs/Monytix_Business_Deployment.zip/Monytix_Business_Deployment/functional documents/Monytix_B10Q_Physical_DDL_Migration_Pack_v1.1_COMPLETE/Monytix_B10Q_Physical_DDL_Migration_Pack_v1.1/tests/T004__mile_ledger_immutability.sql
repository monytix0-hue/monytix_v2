-- B10Q v1.1: append-only M.I.L.E. ledger assertion.
BEGIN;
DO $$
DECLARE b uuid := gen_random_uuid(); rid uuid;
BEGIN
  PERFORM set_config('app.business_id',b::text,true);
  INSERT INTO mile.mile_ledger(business_id,dimension_code,entry_type,progress_units,recognized_at)
  VALUES(b,'MONEY','RECOGNITION',1,now()) RETURNING id INTO rid;
  BEGIN
    UPDATE mile.mile_ledger SET progress_units=2 WHERE id=rid;
    RAISE EXCEPTION 'FAIL: mile ledger UPDATE unexpectedly succeeded';
  EXCEPTION WHEN object_not_in_prerequisite_state THEN NULL;
  END;
  BEGIN
    DELETE FROM mile.mile_ledger WHERE id=rid;
    RAISE EXCEPTION 'FAIL: mile ledger DELETE unexpectedly succeeded';
  EXCEPTION WHEN object_not_in_prerequisite_state THEN NULL;
  END;
END $$;
ROLLBACK;
