-- B10Q v1.1: Pulse structural capacity and dedup assertions.
BEGIN;
DO $$
DECLARE b uuid := gen_random_uuid(); c uuid; g uuid; i integer;
BEGIN
  PERFORM set_config('app.business_id',b::text,true);
  FOR i IN 1..2 LOOP
    g:=gen_random_uuid();
    INSERT INTO projection.candidate(business_id,surface,candidate_type,title,projection_group_id,deterministic_tiebreak_key)
    VALUES(b,'PULSE','OPPORTUNITY','Opp '||i,g,g::text) RETURNING id INTO c;
    INSERT INTO projection.projection_card(business_id,candidate_id,surface,slot_code,rank,title,projection_group_id,deterministic_tiebreak_key)
    VALUES(b,c,'PULSE','OPPORTUNITY',i+1,'Opp '||i,g,g::text);
  END LOOP;
  BEGIN
    g:=gen_random_uuid();
    INSERT INTO projection.candidate(business_id,surface,candidate_type,title,projection_group_id,deterministic_tiebreak_key)
    VALUES(b,'PULSE','OPPORTUNITY','Third',g,g::text) RETURNING id INTO c;
    INSERT INTO projection.projection_card(business_id,candidate_id,surface,slot_code,rank,title,projection_group_id,deterministic_tiebreak_key)
    VALUES(b,c,'PULSE','OPPORTUNITY',4,'Third',g,g::text);
    RAISE EXCEPTION 'FAIL: third PULSE action card unexpectedly succeeded';
  EXCEPTION WHEN check_violation THEN NULL;
  END;
END $$;
ROLLBACK;
