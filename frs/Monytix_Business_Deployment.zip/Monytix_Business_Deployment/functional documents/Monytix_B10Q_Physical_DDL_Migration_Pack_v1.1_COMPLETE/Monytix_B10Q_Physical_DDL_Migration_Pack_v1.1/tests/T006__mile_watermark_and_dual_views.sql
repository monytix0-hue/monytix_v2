-- B10Q v1.1: recovery below watermark must not create a second watermark and current standing remains distinct from achievement.
BEGIN;
DO $$
DECLARE b uuid := gen_random_uuid(); n integer;
BEGIN
  PERFORM set_config('app.business_id',b::text,true);
  INSERT INTO mile.recognition_watermark(business_id,improvement_cluster_id,dimension_code,highest_recognized_value,source_unit)
  VALUES(b,'CLUSTER-1','MONEY',100,'INR');
  INSERT INTO mile.current_standing(business_id,dimension_code,as_of,current_value,target_value,normalized_progress)
  VALUES(b,'MONEY',now(),80,100,0.8);
  INSERT INTO mile.cumulative_achievement(business_id,dimension_code,as_of,cumulative_units)
  VALUES(b,'MONEY',now(),100);
  SELECT count(*) INTO n FROM mile.portfolio_view
   WHERE business_id=b AND dimension_code='MONEY' AND current_value=80 AND cumulative_units=100;
  IF n<>1 THEN RAISE EXCEPTION 'FAIL: dual-view accounting not preserved'; END IF;
  BEGIN
    INSERT INTO mile.recognition_watermark(business_id,improvement_cluster_id,dimension_code,highest_recognized_value,source_unit)
    VALUES(b,'CLUSTER-1','MONEY',80,'INR');
    RAISE EXCEPTION 'FAIL: duplicate watermark unexpectedly succeeded';
  EXCEPTION WHEN unique_violation THEN NULL;
  END;
END $$;
ROLLBACK;
