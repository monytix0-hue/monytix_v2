-- B10Q v1.1: current canonical view must expose only the active leaf of a supersession chain.
BEGIN;
DO $$
DECLARE b uuid := gen_random_uuid(); r uuid; c uuid; n integer;
BEGIN
  PERFORM set_config('app.business_id',b::text,true);
  INSERT INTO canonical.canonical_event(business_id,family_code,event_type,object_version,status)
  VALUES(b,'CF01','TEST',1,'ACTIVE') RETURNING id INTO r;
  INSERT INTO canonical.canonical_event(business_id,family_code,event_type,object_version,status,supersedes_id)
  VALUES(b,'CF01','TEST',2,'ACTIVE',r) RETURNING id INTO c;
  SELECT count(*) INTO n FROM canonical.current_event WHERE business_id=b AND event_type='TEST';
  IF n<>1 OR NOT EXISTS(SELECT 1 FROM canonical.current_event WHERE id=c) THEN
    RAISE EXCEPTION 'FAIL: supersession current view did not select leaf';
  END IF;
END $$;
ROLLBACK;
