-- B10Q v1.1: actual tenant isolation assertion. Run as a role subject to RLS (not table owner/superuser).
BEGIN;
DO $$
DECLARE a uuid := gen_random_uuid(); b uuid := gen_random_uuid(); x uuid; n integer;
BEGIN
  PERFORM set_config('app.business_id',a::text,true);
  INSERT INTO canonical.canonical_event(business_id,family_code,event_type,status)
  VALUES(a,'CF01','RLS_SENTINEL','ACTIVE') RETURNING id INTO x;
  PERFORM set_config('app.business_id',b::text,true);
  SELECT count(*) INTO n FROM canonical.canonical_event WHERE id=x;
  IF n<>0 THEN RAISE EXCEPTION 'FAIL: tenant B can read tenant A row'; END IF;
END $$;
ROLLBACK;
