-- B10Q v1.1: database-side prerequisites for B10O service ranking/suppression tests.
-- Hero tie-breaking and critical-alert suppression are service logic; this test asserts the persisted inputs/audit structures required for deterministic integration tests.
DO $$
DECLARE n integer;
BEGIN
  SELECT count(*) INTO n FROM information_schema.columns
  WHERE table_schema='projection' AND table_name='projection_card'
    AND column_name IN ('projection_group_id','deterministic_tiebreak_key','rank');
  IF n<>3 THEN RAISE EXCEPTION 'FAIL: projection ranking/dedup fields missing'; END IF;
  SELECT count(*) INTO n FROM information_schema.tables
  WHERE table_schema='projection' AND table_name='suppression';
  IF n<>1 THEN RAISE EXCEPTION 'FAIL: suppression audit table missing'; END IF;
END $$;
