# Monytix D10-1 - Foundation & Identity

## Purpose
D10-1 is the first executable database wave under **D10 v1.2 FINAL FREEZE**. It creates the clean vNext namespace and identity/account foundation without modifying legacy schemas.

## Files
- `D10_1_foundation_identity.sql` - executable idempotent migration.
- `D10_1_verify.sql` - transactional smoke/verification script; test rows are rolled back.

## Creates
Eight schemas: `core`, `intel`, `evidence`, `context`, `action`, `experience`, `ref`, `ops`.

Foundation objects:
- `ops.uuid_v7()` - RFC 9562 UUIDv7 generator for all new vNext IDs.
- `ops.touch_updated_at()` - common timestamp trigger helper.
- `ops.current_actor_id()` / `ops.current_owner_id()` - A10 request-context readers for RLS.
- `ops.schema_migration` - D10 numbered-wave ledger.
- `ref.institution` - global institution registry; seeded only with F10A wave-1 parser-asset institutions.
- `core.authenticated_actor` - domain/RLS projection of external authentication identity; **no credentials**.
- `core.owner` - PERSON/BUSINESS financial-data owner/tenant.
- `core.actor_owner_membership` - actor authorization within an owner context.
- `core.financial_account` - stable underlying financial account.
- `core.financial_account_instrument` - physical/virtual/add-on/token/replacement instrument lineage.
- `core.account_ownership` - owner-account relationship supporting joint/shared ownership.
- `core.account_currency_bucket` - optional multi-currency bucket context.
- current-state views for membership/account ownership/account reads.

## Important execution rules
1. Run as the vNext schema owner/migration role.
2. Target PostgreSQL 15+ (used for `security_invoker` views) with `pgcrypto`; the migration creates `pgcrypto` if permitted.
3. The script does **not** touch `monytix`, `spendsense`, `moneymoments`, `budgetpilot`, `goalcompass`, `rewards`, or other legacy schemas/tables.
4. RLS is enabled on owner-scoped foundation tables. The migration/schema owner normally bypasses RLS. Application roles must not rely on that bypass.
5. A10 must validate the authenticated principal and owner membership, then set transaction-local:
   - `SET LOCAL app.actor_id = '<actor-uuid>';`
   - `SET LOCAL app.owner_id = '<owner-uuid>';`
6. The helper settings are **context only**; setting them is not authentication or authorization by itself.
7. New vNext IDs use UUIDv7. Legacy UUIDv4/external IDs are preserved later through D10-9 migration/mapping; never regenerate migrated identity.
8. UUID order must never replace event timestamps or domain version numbers.

## Current-state rule
Native lifecycle fields remain authoritative. Views expose a normalized `is_current_active` projection only for read convenience.

## Why no legacy-user migration here?
D10-1 creates the clean target foundation. Legacy Firebase/`monytix.users` identities are migrated/reconciled in D10-9 so identity mapping can be audited and rolled back independently.

## Verification
Run the migration and then `D10_1_verify.sql`. Verification checks:
- all eight schemas exist;
- UUIDv7 version/variant bits;
- all required foundation relations exist;
- owner/actor/account/instrument/bucket rows can be constructed coherently;
- current owner-account view resolves the relationship;
- D10-1 migration ledger record exists.

The smoke data runs inside a transaction and is rolled back.

## Next wave
**D10-2 - Source Intake & Canonical Ledger**: source connections/batches/documents, document sets, statement instances, extraction runs/records, account coverage, logical transactions, canonical transaction versions and transaction evidence links.
