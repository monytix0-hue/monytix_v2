-- ============================================================
-- monytix_engine.sql
-- Monytix Rulebook — ENGINE FUNCTIONS + DIAGNOSTIC VIEWS
--
-- Run once after schema + seeds. Re-run to update logic.
-- All objects use CREATE OR REPLACE — safe to re-run.
--
-- Contents:
--   §1  resolve_virtual_fields()  — master-table JOIN resolver
--   §2  apply_rulebook_to_txn()   — priority-cascade evaluator
--   §3  populate_rulebook_output()— batch processing entry point
--   §4  Diagnostic views
--         vw_rulebook_distribution
--         vw_rule_hit_frequency
--         vw_rulebook_fallbacks
--         vw_low_confidence_classifications
--         vw_user_obligations
--         vw_user_investments
--         vw_fallback_clusters
--         vw_merchant_category_distribution  ← new
--         vw_merch_unresolved_entities        ← new
--         vw_rulebook_priority_map            ← new
--         vw_user_monthly_summary             ← new
-- ============================================================

BEGIN;

SET search_path = spendsense, public;

-- ============================================================
-- §1  resolve_virtual_fields()
--
-- Called ONCE per transaction before the cascade loop.
-- Runs every master-table JOIN and returns all boolean gates
-- + resolved entity names as a single JSONB object.
-- The engine loop never needs to re-JOIN the masters.
--
-- Virtual fields recognised by apply_rulebook_to_txn():
--   user_employer_match     → user_employers
--   lender_master_match     → loan_lenders_master
--   cc_issuer_match         → credit_card_issuers_master
--   investment_entity_match → investment_entities_master
--   insurer_master_match    → insurance_entities_master
--   merchant_entity_match   → merchant_entity_master   ← new
--   merchant_keyword_match  → merchant_keyword          ← new
-- ============================================================

CREATE OR REPLACE FUNCTION spendsense.resolve_virtual_fields(
    p_txn_id            UUID,
    p_user_id           TEXT,
    p_normalized_desc   TEXT,
    p_counterparty_name TEXT,
    p_counterparty_vpa  TEXT,
    p_ach_nach_entity   TEXT,
    p_channel_type      TEXT,
    p_upi_entity_type   TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
STABLE
AS $$
DECLARE
    v_flags             JSONB := '{}'::JSONB;
    v_probe             TEXT;
    -- employer
    v_employer_match    BOOLEAN := FALSE;
    -- lender
    v_lender_match      BOOLEAN := FALSE;
    v_lender_entity     TEXT;
    -- cc
    v_cc_match          BOOLEAN := FALSE;
    v_cc_entity         TEXT;
    -- investment
    v_inv_match         BOOLEAN := FALSE;
    v_inv_entity        TEXT;
    v_inv_instrument    TEXT;
    v_inv_mode          TEXT;
    -- insurer
    v_ins_match         BOOLEAN := FALSE;
    v_ins_entity        TEXT;
    v_ins_subtype       TEXT;
    -- merchant entity
    v_merch_e_match     BOOLEAN := FALSE;
    v_merch_entity      TEXT;
    v_merch_category    TEXT;
    v_merch_subcategory TEXT;
    -- merchant keyword
    v_merch_kw_match    BOOLEAN := FALSE;
    v_merch_kw_cat      TEXT;
    v_merch_kw_subcat   TEXT;
BEGIN
    v_probe := COALESCE(p_normalized_desc,'') || ' ' || COALESCE(p_counterparty_name,'');

    -- User employer
    SELECT TRUE INTO v_employer_match
    FROM spendsense.user_employers
    WHERE user_id = p_user_id
      AND (p_counterparty_name ILIKE '%' || employer || '%'
           OR p_normalized_desc ILIKE '%' || employer || '%')
    LIMIT 1;

    -- Loan lender
    SELECT TRUE, normalized_entity INTO v_lender_match, v_lender_entity
    FROM spendsense.loan_lenders_master
    WHERE is_active AND v_probe ~* match_pattern
    ORDER BY priority_hint LIMIT 1;

    -- CC issuer
    SELECT TRUE, normalized_entity INTO v_cc_match, v_cc_entity
    FROM spendsense.credit_card_issuers_master
    WHERE is_active AND v_probe ~* match_pattern
    ORDER BY priority_hint LIMIT 1;

    -- Investment entity
    SELECT TRUE, normalized_entity, default_instrument_type, default_investment_mode
    INTO v_inv_match, v_inv_entity, v_inv_instrument, v_inv_mode
    FROM spendsense.investment_entities_master
    WHERE is_active AND v_probe ~* match_pattern
    ORDER BY priority_hint LIMIT 1;

    -- Insurer
    SELECT TRUE, normalized_entity, insurance_subtype
    INTO v_ins_match, v_ins_entity, v_ins_subtype
    FROM spendsense.insurance_entities_master
    WHERE is_active AND v_probe ~* match_pattern
    ORDER BY priority_hint LIMIT 1;

    -- Merchant entity master
    SELECT TRUE, normalized_entity, category, subcategory
    INTO v_merch_e_match, v_merch_entity, v_merch_category, v_merch_subcategory
    FROM spendsense.merchant_entity_master
    WHERE is_active AND v_probe ~* match_pattern
    ORDER BY priority_hint LIMIT 1;

    -- Merchant keyword
    SELECT TRUE, category, subcategory
    INTO v_merch_kw_match, v_merch_kw_cat, v_merch_kw_subcat
    FROM spendsense.merchant_keyword
    WHERE is_active AND v_probe ~* match_pattern
    ORDER BY priority_hint LIMIT 1;

    v_flags := jsonb_build_object(
        -- boolean gates
        'user_employer_match',     COALESCE(v_employer_match,  FALSE),
        'lender_master_match',     COALESCE(v_lender_match,    FALSE),
        'cc_issuer_match',         COALESCE(v_cc_match,        FALSE),
        'investment_entity_match', COALESCE(v_inv_match,       FALSE),
        'insurer_master_match',    COALESCE(v_ins_match,       FALSE),
        'merchant_entity_match',   COALESCE(v_merch_e_match,   FALSE),
        'merchant_keyword_match',  COALESCE(v_merch_kw_match,  FALSE),
        -- resolved names
        'resolved_lender',          v_lender_entity,
        'resolved_cc_issuer',       v_cc_entity,
        'resolved_inv_entity',      v_inv_entity,
        'resolved_inv_instrument',  v_inv_instrument,
        'resolved_inv_mode',        v_inv_mode,
        'resolved_insurer',         v_ins_entity,
        'resolved_ins_subtype',     v_ins_subtype,
        'resolved_merchant',        v_merch_entity,
        'resolved_merchant_cat',    v_merch_category,
        'resolved_merchant_subcat', v_merch_subcategory,
        'resolved_kw_cat',          v_merch_kw_cat,
        'resolved_kw_subcat',       v_merch_kw_subcat
    );

    RETURN v_flags;
END;
$$;

COMMENT ON FUNCTION spendsense.resolve_virtual_fields IS
'Resolves all master-table JOIN flags for a single transaction.
 Call once per txn before the rulebook cascade.
 Returns JSONB with boolean gates + resolved entity names.';

-- ============================================================
-- §2  apply_rulebook_to_txn()
--
-- Iterates rulebook in priority_rank ASC.
-- For each rule: resolves match_field → evaluates match_op
-- → checks exclude guard → returns first match as JSONB.
-- Falls back to FALLBACK object if no rule matches.
-- ============================================================

CREATE OR REPLACE FUNCTION spendsense.apply_rulebook_to_txn(
    p_txn_id          UUID,
    p_cr_dr           CHAR(1),
    p_channel_type    TEXT,
    p_upi_entity_type TEXT,
    p_upi_vpa         TEXT,
    p_norm_desc       TEXT,
    p_ach_nach_entity TEXT,
    p_flags           JSONB
)
RETURNS JSONB
LANGUAGE plpgsql
STABLE
AS $$
DECLARE
    r           spendsense.rulebook%ROWTYPE;
    v_flow_type TEXT := CASE p_cr_dr WHEN 'C' THEN 'INFLOW' ELSE 'OUTFLOW' END;
    v_fval      TEXT;
    v_match     BOOLEAN;
    v_excl      BOOLEAN;
BEGIN
    FOR r IN
        SELECT * FROM spendsense.rulebook
        WHERE is_active = TRUE
          AND (flow_type    IS NULL OR flow_type    = v_flow_type)
          AND (channel_filter IS NULL OR channel_filter = p_channel_type)
        ORDER BY priority_rank ASC
    LOOP
        -- resolve match field value
        v_fval := CASE r.match_field
            WHEN 'normalized_description'  THEN p_norm_desc
            WHEN 'entity_name'             THEN p_norm_desc
            WHEN 'ach_nach_entity'         THEN p_ach_nach_entity
            WHEN 'channel_type'            THEN p_channel_type
            WHEN 'upi_entity_type'         THEN p_upi_entity_type
            WHEN 'upi_vpa'                 THEN p_upi_vpa
            -- virtual flags (boolean stored as text in JSONB)
            WHEN 'user_employer_match'     THEN p_flags->>'user_employer_match'
            WHEN 'lender_master_match'     THEN p_flags->>'lender_master_match'
            WHEN 'cc_issuer_match'         THEN p_flags->>'cc_issuer_match'
            WHEN 'investment_entity_match' THEN p_flags->>'investment_entity_match'
            WHEN 'insurer_master_match'    THEN p_flags->>'insurer_master_match'
            WHEN 'merchant_entity_match'   THEN p_flags->>'merchant_entity_match'
            WHEN 'merchant_keyword_match'  THEN p_flags->>'merchant_keyword_match'
            ELSE NULL
        END;

        -- evaluate match
        v_match := CASE r.match_op
            WHEN 'EQUALS'     THEN v_fval = r.match_value
            WHEN 'IREGEX'     THEN v_fval ~* r.match_value
            WHEN 'ILIKE'      THEN v_fval ILIKE r.match_value
            WHEN 'NOT_IREGEX' THEN NOT (v_fval ~* r.match_value)
            ELSE FALSE
        END;

        IF NOT COALESCE(v_match, FALSE) THEN CONTINUE; END IF;

        -- evaluate exclusion guard
        IF r.exclude_field IS NOT NULL THEN
            v_fval := CASE r.exclude_field
                WHEN 'normalized_description' THEN p_norm_desc
                WHEN 'upi_entity_type'        THEN p_upi_entity_type
                WHEN 'insurer_master_match'   THEN p_flags->>'insurer_master_match'
                ELSE p_norm_desc
            END;
            v_excl := CASE r.exclude_op
                WHEN 'EQUALS'     THEN v_fval = r.exclude_value
                WHEN 'IREGEX'     THEN v_fval ~* r.exclude_value
                WHEN 'ILIKE'      THEN v_fval ILIKE r.exclude_value
                WHEN 'NOT_IREGEX' THEN NOT (v_fval ~* r.exclude_value)
                ELSE FALSE
            END;
            IF COALESCE(v_excl, FALSE) THEN CONTINUE; END IF;
        END IF;

        -- match confirmed — return result
        RETURN jsonb_build_object(
            'rule_code',            r.rule_code,
            'rule_group',           r.rule_group,
            'financial_class',      r.financial_class,
            'instrument_type',      COALESCE(r.instrument_type,  p_flags->>'resolved_inv_instrument'),
            'counterparty_type',    r.counterparty_type,
            'investment_mode',      COALESCE(r.investment_mode,  p_flags->>'resolved_inv_mode'),
            'obligation_flag',      r.obligation_flag,
            'merchant_flag',        r.merchant_flag,
            'confidence_score',     r.confidence_score,
            'resolved_entity',      COALESCE(
                                        p_flags->>'resolved_merchant',
                                        p_flags->>'resolved_insurer',
                                        p_flags->>'resolved_inv_entity',
                                        p_flags->>'resolved_lender',
                                        p_flags->>'resolved_cc_issuer'
                                    ),
            'expense_category',     COALESCE(p_flags->>'resolved_merchant_cat',  p_flags->>'resolved_kw_cat'),
            'expense_subcategory',  COALESCE(p_flags->>'resolved_merchant_subcat',p_flags->>'resolved_kw_subcat')
        );
    END LOOP;

    -- no rule matched
    RETURN jsonb_build_object(
        'rule_code',       'FALLBACK',
        'rule_group',      'FALLBACK',
        'financial_class', CASE v_flow_type WHEN 'INFLOW' THEN 'TRANSFER_IN' ELSE 'TRANSFER_OUT' END,
        'instrument_type', 'UNCLASSIFIED',
        'confidence_score', 0.30,
        'obligation_flag',  FALSE,
        'merchant_flag',    FALSE,
        'is_fallback',      TRUE
    );
END;
$$;

COMMENT ON FUNCTION spendsense.apply_rulebook_to_txn IS
'Evaluates rulebook in priority order for one transaction.
 p_flags must be the JSONB from resolve_virtual_fields().
 Returns first matching rule as JSONB, or fallback sentinel.';

-- ============================================================
-- §3  populate_rulebook_output()
--
-- Batch entry point. Processes UPI merchant transactions
-- (entity_type IN MERCHANT | SMALL_MERCHANT | UNKNOWN_MERCHANT).
-- Upserts txn_rulebook_output and txn_categorized rows.
--
-- Usage:
--   -- Process one upload:
--   SELECT * FROM spendsense.populate_rulebook_output('<upload_uuid>');
--   -- Full rebuild:
--   SELECT * FROM spendsense.populate_rulebook_output(NULL);
-- ============================================================

CREATE OR REPLACE FUNCTION spendsense.populate_rulebook_output(
    p_upload_id UUID DEFAULT NULL
)
RETURNS TABLE (
    processed   INT,
    classified  INT,
    fallbacks   INT,
    categorized INT
)
LANGUAGE plpgsql
AS $$
DECLARE
    v_txn         spendsense.txn_upi_classified%ROWTYPE;
    v_parsed      spendsense.txn_parsed_UPI_updated%ROWTYPE;
    v_flags       JSONB;
    v_result      JSONB;
    v_processed   INT := 0;
    v_classified  INT := 0;
    v_fallbacks   INT := 0;
    v_categorized INT := 0;
    v_output_id   BIGINT;
BEGIN
    FOR v_txn IN
        SELECT c.*
        FROM spendsense.txn_upi_classified c
        WHERE c.channel_type  = 'UPI'
          AND c.upi_classified IN ('MERCHANT','SMALL_MERCHANT','UNKNOWN_MERCHANT')
          AND (p_upload_id IS NULL OR c.upload_id = p_upload_id)
    LOOP
        SELECT * INTO v_parsed
        FROM spendsense.txn_parsed_UPI_updated
        WHERE txn_id = v_txn.txn_id;

        v_processed := v_processed + 1;

        v_flags := spendsense.resolve_virtual_fields(
            v_txn.txn_id, v_txn.user_id,
            v_parsed.normalized_description, v_parsed.counterparty_name,
            v_parsed.counterparty_vpa, v_parsed.ach_nach_entity,
            v_txn.channel_type, v_txn.upi_classified
        );

        v_result := spendsense.apply_rulebook_to_txn(
            v_txn.txn_id, v_parsed.cr_dr,
            v_txn.channel_type, v_txn.upi_classified,
            v_parsed.counterparty_vpa, v_parsed.normalized_description,
            v_parsed.ach_nach_entity, v_flags
        );

        -- upsert rulebook output row
        INSERT INTO spendsense.txn_rulebook_output (
            txn_id, user_id, txn_date, amount, cr_dr,
            channel_type, upi_entity_type,
            financial_class, instrument_type, counterparty_type,
            investment_mode, obligation_flag, merchant_flag,
            resolved_entity, rule_code, rule_group,
            confidence_score, classification_source, is_fallback, updated_at
        ) VALUES (
            v_txn.txn_id, v_txn.user_id,
            v_parsed.txn_date, v_parsed.amount, v_parsed.cr_dr,
            v_txn.channel_type, v_txn.upi_classified,
            v_result->>'financial_class',
            v_result->>'instrument_type',
            v_result->>'counterparty_type',
            v_result->>'investment_mode',
            (v_result->>'obligation_flag')::BOOLEAN,
            (v_result->>'merchant_flag')::BOOLEAN,
            v_result->>'resolved_entity',
            v_result->>'rule_code',
            v_result->>'rule_group',
            (v_result->>'confidence_score')::NUMERIC,
            CASE WHEN v_result->>'rule_group' = 'FALLBACK' THEN 'fallback'
                 WHEN (v_flags->>'merchant_entity_match')::BOOLEAN  THEN 'entity_master'
                 WHEN (v_flags->>'merchant_keyword_match')::BOOLEAN THEN 'keyword_match'
                 ELSE 'rulebook' END,
            COALESCE((v_result->>'is_fallback')::BOOLEAN, FALSE),
            NOW()
        )
        ON CONFLICT (txn_id) DO UPDATE SET
            financial_class       = EXCLUDED.financial_class,
            instrument_type       = EXCLUDED.instrument_type,
            counterparty_type     = EXCLUDED.counterparty_type,
            investment_mode       = EXCLUDED.investment_mode,
            obligation_flag       = EXCLUDED.obligation_flag,
            merchant_flag         = EXCLUDED.merchant_flag,
            resolved_entity       = EXCLUDED.resolved_entity,
            rule_code             = EXCLUDED.rule_code,
            rule_group            = EXCLUDED.rule_group,
            confidence_score      = EXCLUDED.confidence_score,
            classification_source = EXCLUDED.classification_source,
            is_fallback           = EXCLUDED.is_fallback,
            updated_at            = NOW()
        RETURNING output_id INTO v_output_id;

        IF COALESCE((v_result->>'is_fallback')::BOOLEAN, FALSE) THEN
            v_fallbacks  := v_fallbacks  + 1;
        ELSE
            v_classified := v_classified + 1;
        END IF;

        -- write txn_categorized if expense_category resolved
        IF v_result->>'expense_category' IS NOT NULL THEN
            INSERT INTO spendsense.txn_categorized (
                output_id, user_id, txn_date, amount, cr_dr,
                expense_category, expense_subcategory, merchant_label,
                matched_via, rule_code, confidence_score
            ) VALUES (
                v_output_id, v_txn.user_id,
                v_parsed.txn_date, v_parsed.amount, v_parsed.cr_dr,
                v_result->>'expense_category',
                v_result->>'expense_subcategory',
                v_result->>'resolved_entity',
                CASE WHEN (v_flags->>'merchant_entity_match')::BOOLEAN  THEN 'entity'
                     WHEN (v_flags->>'merchant_keyword_match')::BOOLEAN THEN 'keyword'
                     ELSE 'rule' END,
                v_result->>'rule_code',
                (v_result->>'confidence_score')::NUMERIC
            )
            ON CONFLICT (output_id) DO UPDATE SET
                expense_category    = EXCLUDED.expense_category,
                expense_subcategory = EXCLUDED.expense_subcategory,
                merchant_label      = EXCLUDED.merchant_label,
                matched_via         = EXCLUDED.matched_via,
                confidence_score    = EXCLUDED.confidence_score;

            v_categorized := v_categorized + 1;
        END IF;
    END LOOP;

    RETURN QUERY SELECT v_processed, v_classified, v_fallbacks, v_categorized;
END;
$$;

COMMENT ON FUNCTION spendsense.populate_rulebook_output IS
'Batch-processes UPI merchant transactions through the rulebook engine.
 Pass upload_id for incremental batch, NULL for full rebuild.
 Returns (processed, classified, fallbacks, categorized) counts.';

-- ============================================================
-- §4  DIAGNOSTIC VIEWS
-- ============================================================

-- Overall classification distribution
CREATE OR REPLACE VIEW spendsense.vw_rulebook_distribution AS
SELECT
    financial_class,
    rule_group,
    classification_source,
    COUNT(*)                                            AS txn_count,
    ROUND(SUM(amount), 2)                               AS total_amount,
    ROUND(AVG(confidence_score), 3)                     AS avg_confidence,
    ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 2)  AS pct_share
FROM spendsense.txn_rulebook_output
GROUP BY financial_class, rule_group, classification_source
ORDER BY txn_count DESC;

-- Rule hit frequency — which rules fire most
CREATE OR REPLACE VIEW spendsense.vw_rule_hit_frequency AS
SELECT
    o.rule_code,
    r.rule_group,
    r.priority_rank,
    COUNT(*)                                            AS hit_count,
    ROUND(AVG(o.confidence_score), 3)                   AS avg_confidence,
    ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 2)  AS pct_of_all
FROM spendsense.txn_rulebook_output o
LEFT JOIN spendsense.rulebook r USING (rule_code)
GROUP BY o.rule_code, r.rule_group, r.priority_rank
ORDER BY hit_count DESC;

-- Fallback transactions — these need new rules
CREATE OR REPLACE VIEW spendsense.vw_rulebook_fallbacks AS
SELECT
    o.txn_id, o.user_id, o.txn_date, o.amount, o.cr_dr,
    o.channel_type, o.upi_entity_type,
    p.normalized_description, p.counterparty_name,
    p.counterparty_vpa, p.ach_nach_entity
FROM spendsense.txn_rulebook_output o
JOIN spendsense.txn_parsed_UPI_updated p ON p.txn_id = o.txn_id
WHERE o.is_fallback = TRUE
ORDER BY o.txn_date DESC;

-- Low-confidence outputs (< 0.75) — candidates for review
CREATE OR REPLACE VIEW spendsense.vw_low_confidence_classifications AS
SELECT
    o.txn_id, o.user_id, o.txn_date, o.amount,
    o.financial_class, o.rule_code, o.confidence_score,
    p.normalized_description, p.counterparty_name, p.upi_entity_type
FROM spendsense.txn_rulebook_output o
JOIN spendsense.txn_parsed_UPI_updated p ON p.txn_id = o.txn_id
WHERE o.confidence_score < 0.75 AND o.is_fallback = FALSE
ORDER BY o.confidence_score ASC, o.txn_date DESC;

-- Obligation summary per user (EMI + Insurance + CC + Housing)
CREATE OR REPLACE VIEW spendsense.vw_user_obligations AS
SELECT
    user_id,
    TO_CHAR(txn_date, 'YYYY-MM')    AS month_year,
    financial_class,
    instrument_type,
    COUNT(*)                         AS txn_count,
    ROUND(SUM(amount), 2)            AS total_committed
FROM spendsense.txn_rulebook_output
WHERE obligation_flag = TRUE
  AND cr_dr = 'D'
  AND financial_class IN ('LOAN_EMI','CREDIT_CARD_PAYMENT','INSURANCE','HOUSING')
GROUP BY user_id, month_year, financial_class, instrument_type
ORDER BY user_id, month_year DESC, total_committed DESC;

-- Investment breakdown per user
CREATE OR REPLACE VIEW spendsense.vw_user_investments AS
SELECT
    user_id,
    TO_CHAR(txn_date, 'YYYY-MM')    AS month_year,
    instrument_type, counterparty_type, investment_mode, resolved_entity,
    COUNT(*)                         AS txn_count,
    ROUND(SUM(amount), 2)            AS total_invested
FROM spendsense.txn_rulebook_output
WHERE financial_class IN ('INVESTMENT','INVESTMENT_INCOME')
GROUP BY user_id, month_year, instrument_type, counterparty_type,
         investment_mode, resolved_entity
ORDER BY user_id, month_year DESC, total_invested DESC;

-- Fallback cluster analysis — groups unclassified txns by shape
CREATE OR REPLACE VIEW spendsense.vw_fallback_clusters AS
SELECT
    REGEXP_REPLACE(
        REGEXP_REPLACE(p.normalized_description, '[0-9]{6,}', 'NUM', 'g'),
    '[A-Z0-9._%+-]+@[A-Z0-9.-]+', 'VPA', 'g')  AS shape_signature,
    o.upi_entity_type, o.channel_type, o.cr_dr,
    COUNT(*)                                      AS txn_count,
    ROUND(AVG(o.amount), 2)                       AS avg_amount,
    MIN(p.normalized_description)                 AS example_1,
    MAX(p.normalized_description)                 AS example_2
FROM spendsense.txn_rulebook_output o
JOIN spendsense.txn_parsed_UPI_updated p ON p.txn_id = o.txn_id
WHERE o.is_fallback = TRUE
GROUP BY shape_signature, o.upi_entity_type, o.channel_type, o.cr_dr
HAVING COUNT(*) >= 3
ORDER BY txn_count DESC;

-- Merchant expense category distribution per user / month
CREATE OR REPLACE VIEW spendsense.vw_merchant_category_distribution AS
SELECT
    c.user_id,
    TO_CHAR(c.txn_date, 'YYYY-MM')  AS month_year,
    c.expense_category,
    c.expense_subcategory,
    c.matched_via,
    COUNT(*)                         AS txn_count,
    ROUND(SUM(c.amount), 2)          AS total_spend,
    ROUND(AVG(c.confidence_score), 3)AS avg_confidence
FROM spendsense.txn_categorized c
GROUP BY c.user_id, month_year, c.expense_category,
         c.expense_subcategory, c.matched_via
ORDER BY c.user_id, month_year DESC, total_spend DESC;

-- MERCHANT_PAYMENT rows with no expense_category — growth list for new entities
CREATE OR REPLACE VIEW spendsense.vw_merch_unresolved_entities AS
SELECT
    o.txn_id, o.user_id, o.txn_date, o.amount,
    o.rule_code, o.upi_entity_type, o.resolved_entity,
    p.normalized_description, p.counterparty_name, p.counterparty_vpa
FROM spendsense.txn_rulebook_output o
JOIN spendsense.txn_parsed_UPI_updated p ON p.txn_id = o.txn_id
LEFT JOIN spendsense.txn_categorized c ON c.output_id = o.output_id
WHERE o.financial_class = 'MERCHANT_PAYMENT'
  AND c.output_id IS NULL
ORDER BY o.txn_date DESC;

-- Full priority ladder — check this before adding any new rule
CREATE OR REPLACE VIEW spendsense.vw_rulebook_priority_map AS
SELECT
    priority_rank,
    rule_code,
    rule_group,
    flow_type,
    channel_filter,
    upi_entity_filter,
    match_field,
    match_op,
    LEFT(match_value, 60)   AS match_value_preview,
    financial_class,
    confidence_score,
    is_active
FROM spendsense.rulebook
ORDER BY priority_rank ASC, rule_code ASC;

-- Per-user monthly summary — single query for app dashboard
CREATE OR REPLACE VIEW spendsense.vw_user_monthly_summary AS
SELECT
    r.user_id,
    TO_CHAR(r.txn_date, 'YYYY-MM')                    AS month_year,
    ROUND(SUM(r.amount) FILTER (
        WHERE r.financial_class = 'INCOME'
          AND r.cr_dr = 'C'), 2)                       AS total_income,
    ROUND(SUM(r.amount) FILTER (
        WHERE r.financial_class = 'MERCHANT_PAYMENT'
          AND r.cr_dr = 'D'), 2)                       AS total_merchant_spend,
    ROUND(SUM(r.amount) FILTER (
        WHERE r.obligation_flag = TRUE
          AND r.cr_dr = 'D'), 2)                       AS total_obligations,
    ROUND(SUM(r.amount) FILTER (
        WHERE r.financial_class = 'INVESTMENT'
          AND r.cr_dr = 'D'), 2)                       AS total_invested,
    ROUND(SUM(r.amount) FILTER (
        WHERE r.financial_class = 'HOUSING'
          AND r.cr_dr = 'D'), 2)                       AS total_housing,
    ROUND(SUM(r.amount) FILTER (
        WHERE r.financial_class = 'TRANSFER_OUT'
          AND r.cr_dr = 'D'), 2)                       AS total_transfers_out,
    COUNT(*) FILTER (WHERE r.is_fallback = TRUE)       AS fallback_count,
    COUNT(*)                                           AS total_txns
FROM spendsense.txn_rulebook_output r
GROUP BY r.user_id, month_year
ORDER BY r.user_id, month_year DESC;

COMMIT;
