-- ============================================================
-- monytix_schema.sql
-- Monytix Rulebook — SCHEMA ONLY
--
-- Run once on a fresh database. Never re-run in production
-- unless you are intentionally altering the data model.
-- Safe to re-run: all statements use CREATE TABLE IF NOT EXISTS.
--
-- Contents (in dependency order):
--   1. Search path
--   2. Master lookup tables (lenders, CC issuers, investments,
--      insurers, merchant entities, merchant keywords)
--   3. User learning tables
--   4. Core rulebook table + indexes
--   5. Parse pattern registry + seed patterns
--   6. Output tables: txn_rulebook_output, txn_categorized
--
-- What does NOT belong here:
--   → Reference data rows (lender names, AMC names, rules)  → monytix_seeds.sql
--   → Engine functions and views                            → monytix_engine.sql
-- ============================================================

BEGIN;

SET search_path = spendsense, public;

-- ============================================================
-- 1. MASTER LOOKUP TABLES
-- ============================================================

-- Loan lenders
CREATE TABLE IF NOT EXISTS spendsense.loan_lenders_master (
    lender_id           BIGSERIAL PRIMARY KEY,
    normalized_entity   TEXT NOT NULL UNIQUE,
    lender_type         TEXT NOT NULL,  -- BANK | NBFC | HFC | FINTECH | BNPL | MFI | GOLD
    loan_category       TEXT,           -- PERSONAL | HOME | GOLD | BNPL | BUSINESS | AUTO
    match_pattern       TEXT NOT NULL,
    priority_hint       INT  DEFAULT 15,
    is_active           BOOLEAN DEFAULT TRUE
);

-- Credit card issuers
CREATE TABLE IF NOT EXISTS spendsense.credit_card_issuers_master (
    issuer_id           BIGSERIAL PRIMARY KEY,
    normalized_entity   TEXT NOT NULL UNIQUE,
    issuer_bank         TEXT,
    issuer_type         TEXT NOT NULL,  -- BANK | NETWORK | FINTECH_PLATFORM
    network             TEXT,           -- VISA | MASTERCARD | AMEX | RUPAY
    match_pattern       TEXT NOT NULL,
    priority_hint       INT  DEFAULT 12,
    is_active           BOOLEAN DEFAULT TRUE
);

-- Investment entities (AMCs, RTAs, brokers, wealth platforms, retirement, digital gold)
CREATE TABLE IF NOT EXISTS spendsense.investment_entities_master (
    entity_id               BIGSERIAL PRIMARY KEY,
    normalized_entity       TEXT NOT NULL UNIQUE,
    provider_type           TEXT NOT NULL,  -- AMC | AMC_RTA | BROKER | WEALTH_PLATFORM | PLATFORM | GOVT
    investment_category     TEXT NOT NULL,  -- MUTUAL_FUND | BROKER | WEALTH_PLATFORM | RETIREMENT | DIGITAL_GOLD
    default_instrument_type TEXT,
    default_investment_mode TEXT DEFAULT 'RECURRING',
    match_pattern           TEXT NOT NULL,
    priority_hint           INT  DEFAULT 36,
    is_active               BOOLEAN DEFAULT TRUE
);

-- Insurance entities
CREATE TABLE IF NOT EXISTS spendsense.insurance_entities_master (
    entity_id           BIGSERIAL PRIMARY KEY,
    normalized_entity   TEXT NOT NULL UNIQUE,
    insurer_type        TEXT NOT NULL,  -- LIFE | HEALTH | GENERAL | PLATFORM
    insurance_subtype   TEXT,           -- LIFE_PREMIUM | HEALTH_PREMIUM | GENERAL_PREMIUM | etc.
    match_pattern       TEXT NOT NULL,
    priority_hint       INT  DEFAULT 52,
    is_active           BOOLEAN DEFAULT TRUE
);

-- Merchant entity master (named brands: Swiggy, Amazon, IRCTC, etc.)
CREATE TABLE IF NOT EXISTS spendsense.merchant_entity_master (
    entity_id           BIGSERIAL PRIMARY KEY,
    normalized_entity   TEXT NOT NULL,
    category            TEXT NOT NULL,  -- FOOD_DINING | GROCERIES | TRANSPORT | HEALTH | etc.
    subcategory         TEXT,
    match_pattern       TEXT NOT NULL,  -- IREGEX pattern
    priority_hint       INT  NOT NULL DEFAULT 83,
    is_active           BOOLEAN NOT NULL DEFAULT TRUE,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_merchant_entity UNIQUE (normalized_entity, category)
);

CREATE INDEX IF NOT EXISTS ix_merchant_entity_category
    ON spendsense.merchant_entity_master(category)
    WHERE is_active;

-- Merchant keyword table (generic words: restaurant, kirana, petrol pump, etc.)
CREATE TABLE IF NOT EXISTS spendsense.merchant_keyword (
    keyword_id          BIGSERIAL PRIMARY KEY,
    keyword             TEXT NOT NULL,
    category            TEXT NOT NULL,
    subcategory         TEXT,
    match_pattern       TEXT NOT NULL,
    priority_hint       INT  NOT NULL DEFAULT 85,
    is_active           BOOLEAN NOT NULL DEFAULT TRUE,
    CONSTRAINT uq_merchant_keyword UNIQUE (keyword, category)
);

CREATE INDEX IF NOT EXISTS ix_merchant_keyword_category
    ON spendsense.merchant_keyword(category)
    WHERE is_active;

-- ============================================================
-- 2. USER LEARNING TABLES
-- Engine JOINs these to personalise classification.
-- ============================================================

-- Known employers (boosts salary detection confidence)
CREATE TABLE IF NOT EXISTS spendsense.user_employers (
    id          BIGSERIAL PRIMARY KEY,
    user_id     TEXT NOT NULL,
    employer    TEXT NOT NULL,
    confirmed   BOOLEAN DEFAULT FALSE,
    created_at  TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE (user_id, employer)
);

-- Known credit cards per user
CREATE TABLE IF NOT EXISTS spendsense.user_credit_cards (
    id          BIGSERIAL PRIMARY KEY,
    user_id     TEXT NOT NULL,
    card_issuer TEXT NOT NULL,
    card_last4  TEXT,
    created_at  TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE (user_id, card_issuer, card_last4)
);

-- Known loans per user
CREATE TABLE IF NOT EXISTS spendsense.user_loans (
    id          BIGSERIAL PRIMARY KEY,
    user_id     TEXT NOT NULL,
    lender      TEXT NOT NULL,
    emi_amount  NUMERIC(18,2),
    loan_type   TEXT,
    created_at  TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE (user_id, lender)
);

-- ============================================================
-- 3. CORE RULEBOOK TABLE
-- One row per rule. Engine evaluates in priority_rank order.
-- First rule that matches wins — no double-firing.
--
-- Priority bands (post-006 fixes):
--   INC     →   8–90   inflow
--   EMI     →  10–20   outflow
--   CRED    →  35–45   outflow (must precede CC)
--   CC      →  50–57   outflow
--   INV     →  60–72   outflow
--   MERCH   →  73–79   outflow  ← added in 006
--   INS     →  79–86   outflow  (INS_003 NACH at 79)
--   CASH    →  95      outflow
--   FEE     → 100–105  outflow
--   TRF     → 120–130  outflow / fallback
-- ============================================================
CREATE TABLE IF NOT EXISTS spendsense.rulebook (
    rule_id             BIGSERIAL PRIMARY KEY,
    rule_code           TEXT NOT NULL UNIQUE,
    rule_group          TEXT NOT NULL,      -- INC | EMI | CRED | CC | INV | MERCH | INS | CASH | FEE | TRF | HOUSING
    priority_rank       INT  NOT NULL,      -- lower = evaluated first
    flow_type           TEXT,               -- INFLOW | OUTFLOW | NULL = both
    channel_filter      TEXT,               -- UPI | NEFT | ACH | NACH | IMPS | ATM | NULL = any
    upi_entity_filter   TEXT,               -- MERCHANT | SMALL_MERCHANT | UNKNOWN_MERCHANT | PERSON | SELF_ACCOUNT | NULL = any
    -- match condition
    match_field         TEXT NOT NULL,      -- see engine contract for all recognised tokens
    match_op            TEXT NOT NULL,      -- IREGEX | ILIKE | EQUALS | NOT_IREGEX
    match_value         TEXT NOT NULL,
    -- exclusion guard (optional — if exclusion fires, skip this rule)
    exclude_field       TEXT,
    exclude_op          TEXT,
    exclude_value       TEXT,
    -- classification outputs
    financial_class     TEXT NOT NULL,
    instrument_type     TEXT,
    counterparty_type   TEXT,
    investment_mode     TEXT,
    obligation_flag     BOOLEAN DEFAULT FALSE,
    merchant_flag       BOOLEAN DEFAULT FALSE,
    confidence_score    NUMERIC(4,2) DEFAULT 0.90,
    is_active           BOOLEAN DEFAULT TRUE,
    notes               TEXT,
    created_at          TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS ix_rulebook_priority ON spendsense.rulebook(priority_rank) WHERE is_active;
CREATE INDEX IF NOT EXISTS ix_rulebook_group    ON spendsense.rulebook(rule_group)    WHERE is_active;
CREATE INDEX IF NOT EXISTS ix_rulebook_flow     ON spendsense.rulebook(flow_type)     WHERE is_active;

-- ============================================================
-- 4. PARSE PATTERN REGISTRY
-- Structural bank statement patterns used by the parser.
-- ============================================================
CREATE TABLE IF NOT EXISTS spendsense.txn_parse_pattern_registry (
    pattern_id          BIGSERIAL PRIMARY KEY,
    channel_type        TEXT NOT NULL,
    pattern_family      TEXT NOT NULL,
    detection_regex     TEXT NOT NULL,
    delimiter           TEXT,
    direction_rule      TEXT,
    rrn_position        INT,
    name_position       INT,
    merchant_position   INT,
    vpa_position        INT,
    bank_position       INT,
    ifsc_position       INT,
    account_position    INT,
    mcc_position        INT,
    ref_position        INT,
    purpose_position    INT,
    parse_confidence    NUMERIC(4,2) DEFAULT 0.90,
    priority            INT  DEFAULT 99,
    example_format      TEXT,
    notes               TEXT,
    is_active           BOOLEAN DEFAULT TRUE,
    UNIQUE (pattern_family, detection_regex)
);

CREATE INDEX IF NOT EXISTS ix_pattern_channel
    ON spendsense.txn_parse_pattern_registry(channel_type)
    WHERE is_active;

-- Seed all bank parse patterns
INSERT INTO spendsense.txn_parse_pattern_registry
(channel_type, pattern_family, detection_regex, delimiter, direction_rule,
 rrn_position, name_position, merchant_position, vpa_position, bank_position,
 ifsc_position, account_position, mcc_position, ref_position, purpose_position,
 parse_confidence, priority, example_format, notes)
VALUES

-- ── UPI ──────────────────────────────────────────────────────
('UPI','UPI_TRANSFER_DR_SLASH','^TO TRANSFER-UPI/DR/','/',  'OUT',
  3,4,NULL,6,5,NULL,NULL,NULL,NULL,7,
  0.95,1,'TO TRANSFER-UPI/DR/<RRN>/<n>/<BANK>/<VPA>/<PURPOSE>','SBI outgoing UPI'),

('UPI','UPI_TRANSFER_CR_SLASH','^BY TRANSFER-UPI/','/',  'IN',
  3,4,NULL,6,5,NULL,NULL,NULL,NULL,NULL,
  0.95,2,'BY TRANSFER-UPI/<RRN>/<n>/<BANK>/<VPA>','SBI incoming UPI'),

('UPI','UPI_SLASH_CR','^UPI/CR/','/',  'IN',
  3,4,NULL,6,5,NULL,NULL,NULL,NULL,NULL,
  0.95,3,'UPI/CR/<RRN>/<n>/<BANK>/<VPA>','Canara/SBI incoming'),

('UPI','UPI_SLASH_DR','^UPI/DR/','/',  'OUT',
  3,4,NULL,6,5,NULL,NULL,NULL,NULL,NULL,
  0.95,4,'UPI/DR/<RRN>/<n>/<BANK>/<VPA>','Canara/SBI outgoing'),

('UPI','UPI_SLASH_REV','^UPI/REV/','/',  'REV',
  3,4,NULL,6,5,NULL,NULL,NULL,NULL,NULL,
  0.95,5,'UPI/REV/<RRN>/<n>/<BANK>/<VPA>','Reversal'),

('UPI','UPI_OUT_SLASH','^UPIOUT/','/',  'OUT',
  2,NULL,NULL,3,NULL,NULL,NULL,5,NULL,NULL,
  0.95,6,'UPIOUT/<RRN>/<VPA>/UPI/<MCC>','Federal Bank UPI'),

('UPI','UPI_IN_SLASH','^UPI IN/','/',  'IN',
  2,NULL,NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,
  0.90,7,'UPI IN/<RRN>/<VPA>','Incoming slash'),

('UPI','UPI_REV_DASH','^REV-UPI-','-',  'REV',
  4,2,NULL,3,4,NULL,NULL,NULL,NULL,NULL,
  0.90,8,'REV-UPI-<n>-<VPA>-<RRN>','Dash reversal'),

('UPI','UPI_DASH','^UPI-','-',  'LEDGER',
  5,2,2,3,4,4,NULL,NULL,NULL,6,
  0.92,9,'UPI-<n>-<VPA>-<BANK/IFSC>-<RRN>-<PURPOSE>','HDFC/ICICI/Axis/Kotak'),

-- ── IMPS ─────────────────────────────────────────────────────
('IMPS','IMPS_MMT_SLASH','^MMT/IMPS/','/',  'LEDGER',
  3,4,NULL,NULL,5,5,NULL,NULL,NULL,NULL,
  0.92,20,'MMT/IMPS/<RRN>/<n>/<IFSC>','ICICI style'),

('IMPS','IMPS_TRANSFER_SLASH','^BY TRANSFER-IMPS/','/',  'LEDGER',
  2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
  0.90,21,'BY TRANSFER-IMPS/<RRN>/...','Transfer IMPS'),

('IMPS','IMPS_RECD_SLASH','^RECD:IMPS/','/',  'IN',
  2,NULL,NULL,NULL,4,NULL,5,NULL,NULL,NULL,
  0.90,22,'RECD:IMPS/<RRN>/<STATUS>/<BANK>/<ACCOUNT>','Kotak received'),

('IMPS','IMPS_INET_CR_SLASH','^INET-IMPS-CR/','/',  'IN',
  NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
  0.88,23,'INET-IMPS-CR/.../<RRN>','Internet IMPS credit'),

('IMPS','IMPS_MB_DR_SLASH','^MB-IMPS-DR/','/',  'OUT',
  NULL,2,NULL,NULL,3,NULL,4,NULL,NULL,NULL,
  0.88,24,'MB-IMPS-DR/<n>/<BANK>/<ACCOUNT>','Canara mobile IMPS'),

('IMPS','IMPS_DASH','^IMPS-','-',  'LEDGER',
  2,3,NULL,NULL,4,NULL,5,NULL,NULL,NULL,
  0.90,25,'IMPS-<RRN>-<n>-<BANK>-<ACCOUNT>','HDFC IMPS'),

-- ── NEFT ─────────────────────────────────────────────────────
('NEFT','NEFT_DASH','^NEFT-','-',  'LEDGER',
  NULL,3,NULL,NULL,4,4,NULL,NULL,2,NULL,
  0.90,30,'NEFT-<UTR>-<n>-<IFSC>','Dash NEFT'),

('NEFT','NEFT_TRANSFER_STAR','^BY TRANSFER-NEFT','*',  'IN',
  NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,3,NULL,
  0.88,31,'BY TRANSFER-NEFT*<IFSC>*<UTR>','Star NEFT'),

-- ── ACH / NACH ───────────────────────────────────────────────
('ACH','ACH_SLASH','^ACH/','/','LEDGER',
  NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,NULL,
  0.90,40,'ACH/<ENTITY>/<REF>','Slash ACH'),

('ACH','ACH_DASH','^ACH D-','-','OUT',
  NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,3,NULL,
  0.90,41,'ACH D-<ENTITY>-<REF>','Dash ACH debit'),

('ACH','ACH_DEBIT_DASH','^DEBIT-ACH','-','OUT',
  NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,3,NULL,
  0.88,42,'DEBIT-ACH-<ENTITY>-<REF>','Debit ACH'),

('NACH','NACH_SPACE','^NACH ',' ','OUT',
  NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,3,NULL,
  0.90,50,'NACH <ENTITY> <REF1> <REF2>','Space NACH'),

('NACH','NACH_DASH','^NACH-','-','OUT',
  NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,3,NULL,
  0.88,51,'NACH-<ENTITY>-<REF>','Dash NACH'),

-- ── ATM / POS / BIL ─────────────────────────────────────────
('ATM','ATM_WDL_DASH','^ATM WDL-','-','OUT',
  NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
  0.90,60,'ATM WDL-ATM CASH <TXN_ID> <LOCATION>--','ATM withdrawal'),

('ATM','ATM_NWD_DASH','^NWD-','-','OUT',
  NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,
  0.88,61,'NWD-<ACCOUNT/CARD>-...','ATM card withdrawal'),

('POS','POS_SPACE','^POS ',' ','OUT',
  NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,
  0.86,70,'POS <CARD_MASK> ...','POS card'),

('BIL','BIL_SLASH','^BIL/','/','LEDGER',
  NULL,NULL,3,NULL,NULL,NULL,NULL,NULL,4,NULL,
  0.88,80,'BIL/.../<BILLER>/<REF>','Bill payment'),

('CARD_BILLPAY','CARD_BILLPAY_DASH','^IB BILLPAY DR-','-','OUT',
  NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,3,NULL,
  0.88,81,'IB BILLPAY DR-<BILLER_CODE>-<CARD_REF>','HDFC card bill pay')

ON CONFLICT (pattern_family, detection_regex) DO NOTHING;

-- ============================================================
-- 5. OUTPUT TABLES
-- ============================================================

-- Primary rulebook output — one row per transaction
CREATE TABLE IF NOT EXISTS spendsense.txn_rulebook_output (
    output_id               BIGSERIAL PRIMARY KEY,
    txn_id                  UUID NOT NULL UNIQUE
                                REFERENCES spendsense.txn_parsed_UPI_updated(txn_id)
                                ON DELETE CASCADE,
    user_id                 TEXT NOT NULL,
    txn_date                DATE NOT NULL,
    amount                  NUMERIC(18,2) NOT NULL,
    cr_dr                   CHAR(1) NOT NULL,
    channel_type            TEXT,
    upi_entity_type         TEXT,           -- carried from UPI classifier
    -- classification outputs
    financial_class         TEXT,
    instrument_type         TEXT,
    counterparty_type       TEXT,
    investment_mode         TEXT,
    obligation_flag         BOOLEAN DEFAULT FALSE,
    merchant_flag           BOOLEAN DEFAULT FALSE,
    resolved_entity         TEXT,           -- normalised entity name that fired
    -- provenance
    rule_code               TEXT,
    rule_group              TEXT,
    confidence_score        NUMERIC(4,2) DEFAULT 0.0,
    classification_source   TEXT,           -- 'rulebook' | 'entity_master' | 'user_learning' | 'fallback'
    is_fallback             BOOLEAN DEFAULT FALSE,
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS ix_rbo_user   ON spendsense.txn_rulebook_output(user_id);
CREATE INDEX IF NOT EXISTS ix_rbo_class  ON spendsense.txn_rulebook_output(financial_class);
CREATE INDEX IF NOT EXISTS ix_rbo_date   ON spendsense.txn_rulebook_output(txn_date DESC);
CREATE INDEX IF NOT EXISTS ix_rbo_source ON spendsense.txn_rulebook_output(classification_source);

-- Merchant category output — written when expense_category resolves
-- FK corrected: references txn_rulebook_output, not the old txn_classified
CREATE TABLE IF NOT EXISTS spendsense.txn_categorized (
    cat_id              BIGSERIAL PRIMARY KEY,
    output_id           BIGINT NOT NULL UNIQUE
                            REFERENCES spendsense.txn_rulebook_output(output_id)
                            ON DELETE CASCADE,
    user_id             TEXT NOT NULL,
    txn_date            DATE NOT NULL,
    amount              NUMERIC(18,2) NOT NULL,
    cr_dr               CHAR(1) NOT NULL,
    expense_category    TEXT,           -- FOOD_DINING | GROCERIES | TRANSPORT | etc.
    expense_subcategory TEXT,
    merchant_label      TEXT,
    matched_via         TEXT,           -- 'entity' | 'keyword' | 'mcc' | 'upi_handle'
    rule_code           TEXT,
    confidence_score    NUMERIC(4,2) DEFAULT 0.0,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS ix_cat_user     ON spendsense.txn_categorized(user_id);
CREATE INDEX IF NOT EXISTS ix_cat_category ON spendsense.txn_categorized(expense_category);
CREATE INDEX IF NOT EXISTS ix_cat_date     ON spendsense.txn_categorized(txn_date DESC);

COMMIT;
