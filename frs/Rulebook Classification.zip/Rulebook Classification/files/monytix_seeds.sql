-- ============================================================
-- monytix_seeds.sql
-- Monytix Rulebook — ALL REFERENCE DATA
--
-- Safe to re-run: every INSERT uses ON CONFLICT DO NOTHING
-- or ON CONFLICT DO UPDATE where noted.
-- Re-run this file to add new lenders, merchants, or rules
-- without touching schema or engine.
--
-- Contents (in dependency order):
--   §1  Loan lenders master
--   §2  Credit card issuers master
--   §3  Investment entities master
--   §4  Insurance entities master
--   §5  Merchant entity master  (all 24 categories)
--   §6  Merchant keyword table  (all 24 categories)
--   §7  Rulebook rules
--       INC  group  (ranks   8–90)
--       EMI  group  (ranks  10–20)  ← EMI_005 patched (tighter exclusion)
--       CRED group  (ranks  35–45)
--       CC   group  (ranks  50–57)
--       INV  group  (ranks  60–72)
--       MERCH group (ranks  73–79)  ← NEW
--       INS  group  (ranks  79–86)  ← INS_003 NACH added at 79
--       CASH group  (rank   95)
--       FEE  group  (ranks 100–105)
--       TRF  group  (ranks 120–130)
--       HOUSING group (rank 79)    ← NEW
--   §8  Post-seed patches (UPDATE existing rules tightened by audit)
-- ============================================================

BEGIN;

SET search_path = spendsense, public;

-- ============================================================
-- §1  LOAN LENDERS MASTER
-- ============================================================

INSERT INTO spendsense.loan_lenders_master
    (normalized_entity, lender_type, loan_category, match_pattern, priority_hint)
VALUES
-- Public sector banks
('STATE BANK OF INDIA',  'BANK','PERSONAL', '(?i)\bsbi\b|state bank of india',         14),
('PUNJAB NATIONAL BANK', 'BANK','PERSONAL', '(?i)\bpnb\b|punjab national bank',         14),
('BANK OF BARODA',       'BANK','PERSONAL', '(?i)bank of baroda|\bbob\b',               14),
('CANARA BANK',          'BANK','PERSONAL', '(?i)canara bank',                          14),
('UNION BANK OF INDIA',  'BANK','PERSONAL', '(?i)union bank',                           14),
('INDIAN BANK',          'BANK','PERSONAL', '(?i)indian bank',                          14),
('BANK OF INDIA',        'BANK','PERSONAL', '(?i)bank of india',                        14),
('CENTRAL BANK OF INDIA','BANK','PERSONAL', '(?i)central bank',                         14),
('INDIAN OVERSEAS BANK', 'BANK','PERSONAL', '(?i)indian overseas',                      14),
('UCO BANK',             'BANK','PERSONAL', '(?i)\buco bank\b',                         14),
('BANK OF MAHARASHTRA',  'BANK','PERSONAL', '(?i)bank of maharashtra',                  14),
('PUNJAB AND SIND BANK', 'BANK','PERSONAL', '(?i)punjab and sind',                      14),
-- Major private banks
('HDFC BANK LOAN',       'BANK','PERSONAL', '(?i)hdfc.*loan|hdfc.*emi',                 14),
('ICICI BANK LOAN',      'BANK','PERSONAL', '(?i)icici.*loan|icici.*emi',               14),
('AXIS BANK LOAN',       'BANK','HOME',     '(?i)axis.*loan|axis.*emi',                 14),
('KOTAK MAHINDRA BANK',  'BANK','PERSONAL', '(?i)kotak.*loan',                          14),
('INDUSIND BANK',        'BANK','PERSONAL', '(?i)indusind.*loan',                       14),
('YES BANK LOAN',        'BANK','PERSONAL', '(?i)yes bank.*loan',                       14),
('IDFC FIRST BANK',      'BANK','PERSONAL', '(?i)idfc.*loan',                           14),
('FEDERAL BANK LOAN',    'BANK','PERSONAL', '(?i)federal.*loan',                        14),
('RBL BANK LOAN',        'BANK','PERSONAL', '(?i)rbl.*loan',                            14),
('BANDHAN BANK',         'BANK','PERSONAL', '(?i)bandhan bank.*loan',                   14),
-- NBFCs
('BAJAJ FINANCE',        'NBFC','PERSONAL', '(?i)bajaj finance',                        14),
('TATA CAPITAL',         'NBFC','PERSONAL', '(?i)tata capital',                         14),
('HDB FINANCIAL',        'NBFC','PERSONAL', '(?i)hdb financial',                        14),
('L&T FINANCE',          'NBFC','PERSONAL', '(?i)l&t finance|l and t finance',          14),
('ADITYA BIRLA FINANCE', 'NBFC','PERSONAL', '(?i)aditya birla finance',                 14),
('INDIABULLS FINANCE',   'NBFC','PERSONAL', '(?i)indiabulls finance',                   14),
('SHRIRAM FINANCE',      'NBFC','PERSONAL', '(?i)shriram finance',                      14),
('MAHINDRA FINANCE',     'NBFC','AUTO',     '(?i)mahindra finance|m&m financial',       14),
('CHOLAMANDALAM',        'NBFC','AUTO',     '(?i)cholamandalam',                        14),
('FULLERTON INDIA',      'NBFC','PERSONAL', '(?i)fullerton',                            14),
('CAPITAL FLOAT',        'NBFC','BUSINESS', '(?i)capital float',                        14),
('LENDINGKART',          'NBFC','BUSINESS', '(?i)lendingkart',                          14),
('OXYZO',                'NBFC','BUSINESS', '(?i)oxyzo',                                14),
('CLIX CAPITAL',         'NBFC','PERSONAL', '(?i)clix capital',                         14),
('EDELWEISS FINANCE',    'NBFC','PERSONAL', '(?i)edelweiss finance',                    14),
('HERO FINCORP',         'NBFC','AUTO',     '(?i)hero fincorp',                         14),
('TVS CREDIT',           'NBFC','AUTO',     '(?i)tvs credit',                           14),
-- Housing finance
('LIC HOUSING FINANCE',  'HFC','HOME',      '(?i)lic housing',                          14),
('PNB HOUSING FINANCE',  'HFC','HOME',      '(?i)pnb housing',                          14),
('CANFIN HOMES',         'HFC','HOME',      '(?i)canfin homes',                         14),
('INDIABULLS HOUSING',   'HFC','HOME',      '(?i)indiabulls housing',                   14),
('APTUS VALUE HOUSING',  'HFC','HOME',      '(?i)aptus value',                          14),
('REPCO HOME FINANCE',   'HFC','HOME',      '(?i)repco home',                           14),
('AAVAS FINANCIERS',     'HFC','HOME',      '(?i)aavas',                                14),
-- Gold loan
('MUTHOOT FINANCE',      'GOLD','GOLD',     '(?i)muthoot',                              14),
('MANAPPURAM FINANCE',   'GOLD','GOLD',     '(?i)manappuram',                           14),
('IIFL GOLD LOAN',       'GOLD','GOLD',     '(?i)iifl gold',                            14),
('RUPEEK',               'GOLD','GOLD',     '(?i)rupeek',                               14),
-- Fintech personal loan apps
('CASHE',                'FINTECH','PERSONAL','(?i)cashe',                              15),
('KISSHT',               'FINTECH','PERSONAL','(?i)kissht',                             15),
('EARLYSALARY',          'FINTECH','PERSONAL','(?i)earlysalary',                        15),
('NAVI',                 'FINTECH','PERSONAL','(?i)\bnavi\b',                           15),
('KREDIT BEE',           'FINTECH','PERSONAL','(?i)kreditbee',                          15),
('MONEYVIEW',            'FINTECH','PERSONAL','(?i)moneyview',                          15),
('FIBE',                 'FINTECH','PERSONAL','(?i)\bfibe\b',                           15),
('STASHFIN',             'FINTECH','PERSONAL','(?i)stashfin',                           15),
('KRAZYBEE',             'FINTECH','PERSONAL','(?i)krazybee',                           15),
('PAYME INDIA',          'FINTECH','PERSONAL','(?i)payme india',                        15),
('SMARTCOIN',            'FINTECH','PERSONAL','(?i)smartcoin',                          15),
('MPOCKET',              'FINTECH','PERSONAL','(?i)mpocket',                            15),
('MONEYTAP',             'FINTECH','PERSONAL','(?i)moneytap',                           15),
-- BNPL
('LAZYPAY',              'BNPL','BNPL',      '(?i)lazypay',                             17),
('ZESTMONEY',            'BNPL','BNPL',      '(?i)zestmoney',                           17),
('SIMPL',                'BNPL','BNPL',      '(?i)\bsimpl\b',                           17),
('AXIO',                 'BNPL','BNPL',      '(?i)\baxio\b',                            17),
('SLICE',                'BNPL','BNPL',      '(?i)\bslice\b',                           17),
('PAYTM POSTPAID',       'BNPL','BNPL',      '(?i)paytm postpaid',                      17),
('AMAZON PAY LATER',     'BNPL','BNPL',      '(?i)amazon pay later',                    17),
('FLIPKART PAY LATER',   'BNPL','BNPL',      '(?i)flipkart pay later',                  17),
-- MFIs
('BANDHAN MFI',          'MFI','PERSONAL',   '(?i)bandhan microfinance',                15),
('UTKARSH MFI',          'MFI','PERSONAL',   '(?i)utkarsh microfinance',                15),
('SPANDANA MFI',         'MFI','PERSONAL',   '(?i)spandana',                            15),
('SATIN CREDITCARE',     'MFI','PERSONAL',   '(?i)satin creditcare',                    15),
('EQUITAS MFI',          'MFI','PERSONAL',   '(?i)equitas micro',                       15),
('UJJIVAN MFI',          'MFI','PERSONAL',   '(?i)ujjivan',                             15),
('ESAF MFI',             'MFI','PERSONAL',   '(?i)esaf micro',                          15),
-- Small finance banks
('AU SMALL FINANCE',     'BANK','PERSONAL',  '(?i)au small finance|au bank',            14),
('EQUITAS SFB',          'BANK','PERSONAL',  '(?i)equitas small finance',               14),
('UJJIVAN SFB',          'BANK','PERSONAL',  '(?i)ujjivan small finance bank',          14),
('ESAF SFB',             'BANK','PERSONAL',  '(?i)esaf small finance bank',             14),
('SURYODAY SFB',         'BANK','PERSONAL',  '(?i)suryoday',                            14),
('FINCARE SFB',          'BANK','PERSONAL',  '(?i)fincare',                             14)
ON CONFLICT (normalized_entity) DO NOTHING;

-- ============================================================
-- §2  CREDIT CARD ISSUERS MASTER
-- ============================================================

INSERT INTO spendsense.credit_card_issuers_master
    (normalized_entity, issuer_bank, issuer_type, network, match_pattern, priority_hint)
VALUES
('SBI CARD',           'SBI',               'BANK',             'VISA',       '(?i)sbi\s?card',                  12),
('HDFC CARD',          'HDFC',              'BANK',             'VISA',       '(?i)hdfc\s?card',                 12),
('ICICI CARD',         'ICICI',             'BANK',             'VISA',       '(?i)icici\s?card',                12),
('AXIS CARD',          'AXIS',              'BANK',             'VISA',       '(?i)axis\s?card',                 12),
('KOTAK CARD',         'KOTAK',             'BANK',             'VISA',       '(?i)kotak\s?card',                12),
('YES BANK CARD',      'YES BANK',          'BANK',             'VISA',       '(?i)yes\s?bank\s?card',           12),
('INDUSIND CARD',      'INDUSIND',          'BANK',             'VISA',       '(?i)indusind\s?card',             12),
('RBL CARD',           'RBL',               'BANK',             'VISA',       '(?i)rbl\s?card',                  12),
('HSBC CARD',          'HSBC',              'BANK',             'VISA',       '(?i)hsbc\s?card',                 12),
('STANDARD CHARTERED', 'STANDARD CHARTERED','BANK',             'VISA',       '(?i)standard\s?chartered\s?card', 12),
('IDFC FIRST CARD',    'IDFC FIRST',        'BANK',             'VISA',       '(?i)idfc\s?card',                 12),
('AU BANK CARD',       'AU BANK',           'BANK',             'VISA',       '(?i)au\s?bank\s?card',            12),
('FEDERAL CARD',       'FEDERAL',           'BANK',             'VISA',       '(?i)federal\s?card',              12),
('CITI CARD',          'CITI',              'BANK',             'VISA',       '(?i)citi\s?card|citibank\s?card', 12),
('AMEX',               NULL,                'NETWORK',          'AMEX',       '(?i)amex|american\s?express',     12),
('VISA CARD',          NULL,                'NETWORK',          'VISA',       '(?i)\bvisa\b',                    20),
('MASTERCARD',         NULL,                'NETWORK',          'MASTERCARD', '(?i)master\s?card',               20),
('RUPAY CARD',         NULL,                'NETWORK',          'RUPAY',      '(?i)rupay',                       20),
('CRED',               NULL,                'FINTECH_PLATFORM',  NULL,        '(?i)\bcred\b',                    15),
('CHEQ',               NULL,                'FINTECH_PLATFORM',  NULL,        '(?i)\bcheq\b',                    15)
ON CONFLICT (normalized_entity) DO NOTHING;

-- ============================================================
-- §3  INVESTMENT ENTITIES MASTER
-- ============================================================

INSERT INTO spendsense.investment_entities_master
    (normalized_entity, provider_type, investment_category,
     default_instrument_type, default_investment_mode, match_pattern, priority_hint)
VALUES
-- AMC-RTAs (highest priority — appear more often than direct AMC names)
('CAMS',              'AMC_RTA','MUTUAL_FUND','SIP',                 'RECURRING',    '(?i)\bcams\b',            34),
('KFINTECH',          'AMC_RTA','MUTUAL_FUND','SIP',                 'RECURRING',    '(?i)kfintech|karvy',      34),
-- Direct AMCs
('HDFC MUTUAL FUND',  'AMC','MUTUAL_FUND',    'SIP',                 'RECURRING',    '(?i)hdfc\s*mf',           36),
('ICICI PRU MF',      'AMC','MUTUAL_FUND',    'SIP',                 'RECURRING',    '(?i)icici\s*pru\s*mf',    36),
('SBI MUTUAL FUND',   'AMC','MUTUAL_FUND',    'SIP',                 'RECURRING',    '(?i)sbi\s*mf',            36),
('NIPPON INDIA MF',   'AMC','MUTUAL_FUND',    'SIP',                 'RECURRING',    '(?i)nippon',              36),
('KOTAK MF',          'AMC','MUTUAL_FUND',    'SIP',                 'RECURRING',    '(?i)kotak\s*mf',          36),
('AXIS MF',           'AMC','MUTUAL_FUND',    'SIP',                 'RECURRING',    '(?i)axis\s*mf',           36),
('MIRAE ASSET MF',    'AMC','MUTUAL_FUND',    'SIP',                 'RECURRING',    '(?i)mirae',               36),
('UTI MF',            'AMC','MUTUAL_FUND',    'SIP',                 'RECURRING',    '(?i)uti\s*mf',            36),
('ADITYA BIRLA MF',   'AMC','MUTUAL_FUND',    'SIP',                 'RECURRING',    '(?i)aditya birla\s*mf',   36),
('DSP MF',            'AMC','MUTUAL_FUND',    'SIP',                 'RECURRING',    '(?i)dsp\s*mf',            36),
('TATA MF',           'AMC','MUTUAL_FUND',    'SIP',                 'RECURRING',    '(?i)tata\s*mf',           36),
('FRANKLIN MF',       'AMC','MUTUAL_FUND',    'SIP',                 'RECURRING',    '(?i)franklin',            36),
('PPFAS MF',          'AMC','MUTUAL_FUND',    'SIP',                 'RECURRING',    '(?i)ppfas',               36),
('MOTILAL OSWAL MF',  'AMC','MUTUAL_FUND',    'SIP',                 'RECURRING',    '(?i)motilal oswal\s*mf',  36),
('QUANT MF',          'AMC','MUTUAL_FUND',    'SIP',                 'RECURRING',    '(?i)quant\s*mf',          36),
('NAVI MF',           'AMC','MUTUAL_FUND',    'LUMP_SUM_MUTUAL_FUND','ONE_TIME',     '(?i)navi\s*mf',           36),
-- Brokers
('ZERODHA',           'BROKER','BROKER',      'BROKER_FUNDING',      'MARKET_LINKED','(?i)zerodha',             38),
('UPSTOX',            'BROKER','BROKER',      'BROKER_FUNDING',      'MARKET_LINKED','(?i)upstox',              38),
('GROWW',             'BROKER','BROKER',      'BROKER_FUNDING',      'MARKET_LINKED','(?i)groww',               38),
('ANGEL ONE',         'BROKER','BROKER',      'BROKER_FUNDING',      'MARKET_LINKED','(?i)angel one|angel broking',38),
('5PAISA',            'BROKER','BROKER',      'BROKER_FUNDING',      'MARKET_LINKED','(?i)5paisa',              38),
('DHAN',              'BROKER','BROKER',      'BROKER_FUNDING',      'MARKET_LINKED','(?i)\bdhan\b',            38),
('MOTILAL OSWAL',     'BROKER','BROKER',      'BROKER_FUNDING',      'MARKET_LINKED','(?i)motilal(?!.*mf)',     38),
('PAYTM MONEY',       'BROKER','BROKER',      'BROKER_FUNDING',      'MARKET_LINKED','(?i)paytm money',         38),
('COIN ZERODHA',      'BROKER','BROKER',      'BROKER_FUNDING',      'MARKET_LINKED','(?i)\bcoin\b',            38),
('SMALLCASE',         'BROKER','BROKER',      'STOCK_PURCHASE',      'MARKET_LINKED','(?i)smallcase',           38),
-- Wealth platforms
('KUVERA',            'WEALTH_PLATFORM','WEALTH_PLATFORM','WEALTH_CONTRIBUTION','GOAL_LINKED','(?i)kuvera',     40),
('INDMONEY',          'WEALTH_PLATFORM','WEALTH_PLATFORM','WEALTH_CONTRIBUTION','GOAL_LINKED','(?i)indmoney',   40),
('ETMONEY',           'WEALTH_PLATFORM','WEALTH_PLATFORM','WEALTH_CONTRIBUTION','GOAL_LINKED','(?i)etmoney',    40),
('FISDOM',            'WEALTH_PLATFORM','WEALTH_PLATFORM','WEALTH_CONTRIBUTION','GOAL_LINKED','(?i)fisdom',     40),
('SCRIPBOX',          'WEALTH_PLATFORM','WEALTH_PLATFORM','WEALTH_CONTRIBUTION','GOAL_LINKED','(?i)scripbox',   40),
-- Retirement
('NPS TRUST',         'GOVT','RETIREMENT',    'RETIREMENT_INVESTMENT','GOAL_LINKED',  '(?i)\bnps\b',            42),
('PPF ACCOUNT',       'GOVT','RETIREMENT',    'RETIREMENT_INVESTMENT','GOAL_LINKED',  '(?i)\bppf\b',            42),
('NSC',               'GOVT','RETIREMENT',    'RETIREMENT_INVESTMENT','GOAL_LINKED',  '(?i)\bnsc\b',            42),
('SUKANYA SAMRIDDHI', 'GOVT','RETIREMENT',    'RETIREMENT_INVESTMENT','GOAL_LINKED',  '(?i)sukanya',            42),
('EPFO',              'GOVT','RETIREMENT',    'RETIREMENT_INVESTMENT','GOAL_LINKED',  '(?i)\bepfo\b',           42),
-- Digital gold
('JAR',               'PLATFORM','DIGITAL_GOLD','DIGITAL_GOLD',     'ONE_TIME',     '(?i)\bjar\b',             44),
('SAFEGOLD',          'PLATFORM','DIGITAL_GOLD','DIGITAL_GOLD',     'ONE_TIME',     '(?i)safegold',            44),
('AUGMONT',           'PLATFORM','DIGITAL_GOLD','DIGITAL_GOLD',     'ONE_TIME',     '(?i)augmont',             44)
ON CONFLICT (normalized_entity) DO NOTHING;

-- ============================================================
-- §4  INSURANCE ENTITIES MASTER
-- ============================================================

INSERT INTO spendsense.insurance_entities_master
    (normalized_entity, insurer_type, insurance_subtype, match_pattern, priority_hint)
VALUES
-- Life
('LIC',                   'LIFE',   'LIFE_PREMIUM',    '(?i)\blic\b|life insurance corporation', 52),
('HDFC LIFE',             'LIFE',   'LIFE_PREMIUM',    '(?i)hdfc life',                          52),
('ICICI PRU LIFE',        'LIFE',   'LIFE_PREMIUM',    '(?i)icici pru life|icici prudential life',52),
('SBI LIFE',              'LIFE',   'LIFE_PREMIUM',    '(?i)sbi life',                           52),
('MAX LIFE',              'LIFE',   'LIFE_PREMIUM',    '(?i)max life',                           52),
('TATA AIA',              'LIFE',   'LIFE_PREMIUM',    '(?i)tata aia',                           52),
('BAJAJ ALLIANZ LIFE',    'LIFE',   'LIFE_PREMIUM',    '(?i)bajaj allianz life',                 52),
('ADITYA BIRLA SUN LIFE', 'LIFE',   'LIFE_PREMIUM',    '(?i)aditya birla sun life',              52),
('PNB METLIFE',           'LIFE',   'LIFE_PREMIUM',    '(?i)pnb metlife',                        52),
('KOTAK LIFE',            'LIFE',   'LIFE_PREMIUM',    '(?i)kotak life',                         52),
('CANARA HSBC LIFE',      'LIFE',   'LIFE_PREMIUM',    '(?i)canara hsbc life',                   52),
('INDIAFIRST LIFE',       'LIFE',   'LIFE_PREMIUM',    '(?i)indiafirst life',                    52),
('EDELWEISS TOKIO LIFE',  'LIFE',   'LIFE_PREMIUM',    '(?i)edelweiss tokio life',               52),
('PRAMERICA LIFE',        'LIFE',   'LIFE_PREMIUM',    '(?i)pramerica life',                     52),
('SHRIRAM LIFE',          'LIFE',   'LIFE_PREMIUM',    '(?i)shriram life',                       52),
-- Health
('STAR HEALTH',           'HEALTH', 'HEALTH_PREMIUM',  '(?i)star health',                        52),
('NIVA BUPA',             'HEALTH', 'HEALTH_PREMIUM',  '(?i)niva bupa',                          52),
('CARE HEALTH',           'HEALTH', 'HEALTH_PREMIUM',  '(?i)care health',                        52),
('ADITYA BIRLA HEALTH',   'HEALTH', 'HEALTH_PREMIUM',  '(?i)aditya birla health',                52),
('MANIPALCIGNA',          'HEALTH', 'HEALTH_PREMIUM',  '(?i)manipalcigna',                       52),
('GALAXY HEALTH',         'HEALTH', 'HEALTH_PREMIUM',  '(?i)galaxy health',                      52),
-- General / motor
('HDFC ERGO',             'GENERAL','GENERAL_PREMIUM', '(?i)hdfc ergo',                          52),
('ICICI LOMBARD',         'GENERAL','GENERAL_PREMIUM', '(?i)icici lombard',                      52),
('IFFCO TOKIO',           'GENERAL','GENERAL_PREMIUM', '(?i)iffco[\s-]?tokio',                   52),
('BAJAJ ALLIANZ GIC',     'GENERAL','GENERAL_PREMIUM', '(?i)bajaj allianz gic|bajaj allianz general',52),
('NEW INDIA ASSURANCE',   'GENERAL','GENERAL_PREMIUM', '(?i)new india assurance',                52),
('NATIONAL INSURANCE',    'GENERAL','GENERAL_PREMIUM', '(?i)national insurance',                 52),
('ORIENTAL INSURANCE',    'GENERAL','GENERAL_PREMIUM', '(?i)oriental insurance',                 52),
('UNITED INDIA',          'GENERAL','GENERAL_PREMIUM', '(?i)united india insurance',             52),
('RELIANCE GENERAL',      'GENERAL','GENERAL_PREMIUM', '(?i)reliance general',                   52),
('SBI GENERAL',           'GENERAL','GENERAL_PREMIUM', '(?i)sbi general',                        52),
('TATA AIG',              'GENERAL','GENERAL_PREMIUM', '(?i)tata aig',                           52),
('GO DIGIT',              'GENERAL','GENERAL_PREMIUM', '(?i)go digit|digit insurance',           52),
('ACKO',                  'GENERAL','GENERAL_PREMIUM', '(?i)\backo\b',                           52),
('ROYAL SUNDARAM',        'GENERAL','GENERAL_PREMIUM', '(?i)royal sundaram',                     52),
('CHOLAMANDALAM MS',      'GENERAL','GENERAL_PREMIUM', '(?i)cholamandalam ms',                   52),
('ZURICH KOTAK',          'GENERAL','GENERAL_PREMIUM', '(?i)zurich kotak|kotak general insurance',52),
('LIBERTY GENERAL',       'GENERAL','GENERAL_PREMIUM', '(?i)liberty general',                    52),
-- Aggregators
('POLICYBAZAAR',          'PLATFORM','INSURANCE_PREMIUM','(?i)policybazaar|pb partner',          56),
('INSURANCEDEKHO',        'PLATFORM','INSURANCE_PREMIUM','(?i)insurancedekho',                   56),
('TURTLEMINT',            'PLATFORM','INSURANCE_PREMIUM','(?i)turtlemint',                       56)
ON CONFLICT (normalized_entity) DO NOTHING;

-- ============================================================
-- §5  MERCHANT ENTITY MASTER
-- ============================================================

INSERT INTO spendsense.merchant_entity_master
    (normalized_entity, category, subcategory, match_pattern)
VALUES
-- Food & dining
('SWIGGY','FOOD_DINING','FOOD_DELIVERY','(?i)swiggy'),
('ZOMATO','FOOD_DINING','FOOD_DELIVERY','(?i)zomato'),
('DOMINOS','FOOD_DINING','FAST_FOOD','(?i)dominos'),
('PIZZA HUT','FOOD_DINING','FAST_FOOD','(?i)pizza hut'),
('MCDONALDS','FOOD_DINING','FAST_FOOD','(?i)mcdonald'),
('KFC','FOOD_DINING','FAST_FOOD','(?i)\bkfc\b'),
('BURGER KING','FOOD_DINING','FAST_FOOD','(?i)burger king'),
('SUBWAY','FOOD_DINING','FAST_FOOD','(?i)\bsubway\b'),
('STARBUCKS','FOOD_DINING','CAFE','(?i)starbucks'),
('CAFE COFFEE DAY','FOOD_DINING','CAFE','(?i)cafe coffee day|\bccd\b'),
('THIRD WAVE COFFEE','FOOD_DINING','CAFE','(?i)third wave'),
('BARBEQUE NATION','FOOD_DINING','RESTAURANT','(?i)barbeque nation'),
('HALDIRAMS','FOOD_DINING','RESTAURANT','(?i)haldiram'),
('MONGINIS','FOOD_DINING','BAKERY','(?i)monginis'),
('THEOBROMA','FOOD_DINING','BAKERY','(?i)theobroma'),
-- Groceries
('BIGBASKET','GROCERIES','ONLINE_GROCERY','(?i)bigbasket'),
('BLINKIT','GROCERIES','QUICK_COMMERCE','(?i)blinkit'),
('SWIGGY INSTAMART','GROCERIES','QUICK_COMMERCE','(?i)instamart'),
('ZEPTO','GROCERIES','QUICK_COMMERCE','(?i)\bzepto\b'),
('DMART','GROCERIES','SUPERMARKET','(?i)\bdmart\b'),
('RELIANCE SMART','GROCERIES','SUPERMARKET','(?i)reliance smart'),
('COUNTRY DELIGHT','GROCERIES','DAIRY','(?i)country delight'),
('MILKBASKET','GROCERIES','DAIRY','(?i)milkbasket'),
('MOTHER DAIRY','GROCERIES','DAIRY','(?i)mother dairy'),
-- Transport
('UBER','TRANSPORT','RIDE_HAILING','(?i)\buber\b'),
('OLA','TRANSPORT','RIDE_HAILING','(?i)\bola\b'),
('RAPIDO','TRANSPORT','BIKE_TAXI','(?i)rapido'),
('BLUSMART','TRANSPORT','RIDE_HAILING','(?i)blusmart'),
('INDIAN OIL','TRANSPORT','FUEL','(?i)indian oil|\bioc\b'),
('HPCL','TRANSPORT','FUEL','(?i)\bhpcl\b'),
('BPCL','TRANSPORT','FUEL','(?i)\bbpcl\b'),
('IRCTC','TRANSPORT','PUBLIC_TRANSPORT','(?i)irctc'),
('DELHI METRO','TRANSPORT','PUBLIC_TRANSPORT','(?i)delhi metro'),
('KSRTC','TRANSPORT','PUBLIC_TRANSPORT','(?i)ksrtc'),
('TSRTC','TRANSPORT','PUBLIC_TRANSPORT','(?i)tsrtc'),
-- Health
('APOLLO PHARMACY','HEALTH','PHARMACY','(?i)apollo pharmacy'),
('MEDPLUS','HEALTH','PHARMACY','(?i)medplus'),
('NETMEDS','HEALTH','PHARMACY','(?i)netmeds'),
('PHARMEASY','HEALTH','PHARMACY','(?i)pharmeasy'),
('1MG','HEALTH','PHARMACY','(?i)1mg|tata 1mg'),
('APOLLO HOSPITAL','HEALTH','HOSPITAL','(?i)apollo hospital'),
('FORTIS','HEALTH','HOSPITAL','(?i)fortis'),
('MANIPAL HOSPITAL','HEALTH','HOSPITAL','(?i)manipal hospital'),
('LAL PATHLABS','HEALTH','DIAGNOSTICS','(?i)lal pathlabs|dr lal'),
('THYROCARE','HEALTH','DIAGNOSTICS','(?i)thyrocare'),
-- Shopping
('AMAZON','SHOPPING','ECOMMERCE','(?i)\bamazon\b'),
('FLIPKART','SHOPPING','ECOMMERCE','(?i)flipkart'),
('MEESHO','SHOPPING','ECOMMERCE','(?i)meesho'),
('MYNTRA','SHOPPING','FASHION','(?i)myntra'),
('AJIO','SHOPPING','FASHION','(?i)ajio'),
('ZUDIO','SHOPPING','FASHION','(?i)zudio'),
('CROMA','SHOPPING','ELECTRONICS_RETAIL','(?i)\bcroma\b'),
('RELIANCE DIGITAL','SHOPPING','ELECTRONICS_RETAIL','(?i)reliance digital'),
('VIJAY SALES','SHOPPING','ELECTRONICS_RETAIL','(?i)vijay sales'),
('SHOPPERS STOP','SHOPPING','DEPARTMENT_STORE','(?i)shoppers stop'),
('LIFESTYLE','SHOPPING','DEPARTMENT_STORE','(?i)lifestyle'),
-- Travel
('MAKEMYTRIP','TRAVEL','TRAVEL_BOOKING','(?i)makemytrip'),
('GOIBIBO','TRAVEL','TRAVEL_BOOKING','(?i)goibibo'),
('CLEARTRIP','TRAVEL','TRAVEL_BOOKING','(?i)cleartrip'),
('YATRA','TRAVEL','TRAVEL_BOOKING','(?i)yatra'),
('INDIGO','TRAVEL','FLIGHTS','(?i)indigo'),
('AIR INDIA','TRAVEL','FLIGHTS','(?i)air india'),
('SPICEJET','TRAVEL','FLIGHTS','(?i)spicejet'),
('OYO','TRAVEL','HOTELS','(?i)oyo'),
('REDBUS','TRAVEL','BUS_TRAVEL','(?i)redbus'),
-- Entertainment
('NETFLIX','ENTERTAINMENT','OTT','(?i)netflix'),
('DISNEY HOTSTAR','ENTERTAINMENT','OTT','(?i)hotstar|disney hotstar'),
('SONY LIV','ENTERTAINMENT','OTT','(?i)sony liv'),
('SPOTIFY','ENTERTAINMENT','MUSIC','(?i)spotify'),
('PVR','ENTERTAINMENT','MOVIES','(?i)\bpvr\b'),
('INOX','ENTERTAINMENT','MOVIES','(?i)\binox\b'),
('BOOKMYSHOW','ENTERTAINMENT','EVENTS','(?i)bookmyshow'),
('DREAM11','ENTERTAINMENT','GAMING','(?i)dream11'),
('STEAM','ENTERTAINMENT','GAMING','(?i)\bsteam\b'),
-- Utilities
('BESCOM','UTILITIES','ELECTRICITY','(?i)bescom'),
('TNEB','UTILITIES','ELECTRICITY','(?i)tneb'),
('BSES','UTILITIES','ELECTRICITY','(?i)bses'),
('AIRTEL MOBILE','UTILITIES','MOBILE','(?i)airtel'),
('JIO MOBILE','UTILITIES','MOBILE','(?i)reliance jio|\bjio\b'),
('VODAFONE IDEA','UTILITIES','MOBILE','(?i)\bvi\b|vodafone|\bidea\b'),
('JIO FIBER','UTILITIES','INTERNET','(?i)jiofiber|jio fiber'),
('TATA PLAY','UTILITIES','DTH','(?i)tata play|tatasky'),
('DISH TV','UTILITIES','DTH','(?i)dish tv'),
('BWSSB','UTILITIES','WATER','(?i)bwssb'),
-- Education
('BYJUS','EDUCATION','ONLINE_EDTECH','(?i)byjus'),
('UNACADEMY','EDUCATION','ONLINE_EDTECH','(?i)unacademy'),
('UDEMY','EDUCATION','COURSES','(?i)udemy'),
('COURSERA','EDUCATION','COURSES','(?i)coursera'),
-- Personal care
('JAWED HABIB','PERSONAL_CARE','SALON','(?i)jawed habib'),
('NATURALS SALON','PERSONAL_CARE','SALON','(?i)naturals salon'),
-- Home
('IKEA','HOME','FURNITURE','(?i)\bikea\b'),
('PEPPERFRY','HOME','FURNITURE','(?i)pepperfry'),
('URBAN LADDER','HOME','FURNITURE','(?i)urban ladder'),
-- Sports & fitness
('CULTFIT','SPORTS','FITNESS_APP','(?i)cultfit|cult fit'),
('DECATHLON','SPORTS','SPORTS_EQUIPMENT','(?i)decathlon'),
-- Pets
('HEADS UP FOR TAILS','PETS','PET_STORE','(?i)heads up for tails'),
-- Housing / rent platforms
('NOBROKER RENT','HOUSING','RENT_PLATFORM','(?i)nobroker'),
-- Gifts & donations
('AKSHAYA PATRA','GIFTS_DONATIONS','CHARITY','(?i)akshaya patra'),
('KETTO','GIFTS_DONATIONS','FUNDRAISER','(?i)ketto')
ON CONFLICT (normalized_entity, category) DO NOTHING;

-- ============================================================
-- §6  MERCHANT KEYWORD TABLE
-- ============================================================

INSERT INTO spendsense.merchant_keyword
    (keyword, category, subcategory, match_pattern)
VALUES
-- Food & dining
('restaurant','FOOD_DINING','RESTAURANT','(?i)restaurant'),
('restro','FOOD_DINING','RESTAURANT','(?i)restro'),
('mess','FOOD_DINING','RESTAURANT','(?i)\bmess\b'),
('canteen','FOOD_DINING','RESTAURANT','(?i)canteen'),
('fast food','FOOD_DINING','FAST_FOOD','(?i)fast food'),
('pizza','FOOD_DINING','FAST_FOOD','(?i)\bpizza\b'),
('burger','FOOD_DINING','FAST_FOOD','(?i)\bburger\b'),
('cafe','FOOD_DINING','CAFE','(?i)\bcafe\b'),
('coffee','FOOD_DINING','CAFE','(?i)\bcoffee\b'),
('bakery','FOOD_DINING','BAKERY','(?i)\bbakery\b'),
('ice cream','FOOD_DINING','BAKERY','(?i)ice cream'),
('juice shop','FOOD_DINING','JUICE_SNACKS','(?i)juice shop'),
('snacks','FOOD_DINING','JUICE_SNACKS','(?i)\bsnacks\b'),
-- Groceries
('grocery','GROCERIES','GENERAL_STORE','(?i)\bgrocery\b'),
('kirana','GROCERIES','GENERAL_STORE','(?i)\bkirana\b'),
('supermarket','GROCERIES','SUPERMARKET','(?i)supermarket'),
('provision store','GROCERIES','GENERAL_STORE','(?i)provision store'),
('general store','GROCERIES','GENERAL_STORE','(?i)general store'),
('milk','GROCERIES','DAIRY','(?i)\bmilk\b'),
('dairy','GROCERIES','DAIRY','(?i)\bdairy\b'),
('vegetables','GROCERIES','FRUITS_VEGETABLES','(?i)vegetables'),
('fruits','GROCERIES','FRUITS_VEGETABLES','(?i)\bfruits\b'),
-- Transport
('petrol','TRANSPORT','FUEL','(?i)\bpetrol\b'),
('diesel','TRANSPORT','FUEL','(?i)\bdiesel\b'),
('fuel','TRANSPORT','FUEL','(?i)\bfuel\b'),
('petrol pump','TRANSPORT','FUEL','(?i)petrol pump'),
('taxi','TRANSPORT','AUTO_TAXI','(?i)\btaxi\b'),
('cab','TRANSPORT','AUTO_TAXI','(?i)\bcab\b'),
('auto','TRANSPORT','AUTO_TAXI','(?i)\bauto\b'),
('parking','TRANSPORT','PARKING','(?i)\bparking\b'),
('fastag','TRANSPORT','TOLL','(?i)fastag'),
('toll','TRANSPORT','TOLL','(?i)\btoll\b'),
-- Health
('pharmacy','HEALTH','PHARMACY','(?i)pharmacy'),
('medical store','HEALTH','MEDICAL_STORE','(?i)medical store'),
('chemist','HEALTH','PHARMACY','(?i)chemist'),
('hospital','HEALTH','HOSPITAL','(?i)hospital'),
('clinic','HEALTH','CLINIC','(?i)clinic'),
('doctor','HEALTH','CLINIC','(?i)doctor'),
('diagnostic','HEALTH','DIAGNOSTICS','(?i)diagnostic'),
('pathology','HEALTH','DIAGNOSTICS','(?i)pathology'),
('blood test','HEALTH','DIAGNOSTICS','(?i)blood test'),
-- Shopping
('fashion','SHOPPING','FASHION','(?i)fashion'),
('clothing','SHOPPING','FASHION','(?i)clothing'),
('garments','SHOPPING','FASHION','(?i)garments'),
('boutique','SHOPPING','FASHION','(?i)boutique'),
('electronics','SHOPPING','ELECTRONICS_RETAIL','(?i)electronics'),
('mobile store','SHOPPING','ELECTRONICS_RETAIL','(?i)mobile store'),
('gadget','SHOPPING','ELECTRONICS_RETAIL','(?i)gadget'),
-- Travel
('flight','TRAVEL','FLIGHTS','(?i)flight'),
('airlines','TRAVEL','FLIGHTS','(?i)airlines'),
('hotel stay','TRAVEL','HOTELS','(?i)hotel stay'),
('resort','TRAVEL','HOTELS','(?i)resort'),
('tour package','TRAVEL','HOLIDAY_PACKAGE','(?i)tour package'),
-- Entertainment
('cinema','ENTERTAINMENT','MOVIES','(?i)\bcinema\b'),
('movie','ENTERTAINMENT','MOVIES','(?i)\bmovie\b'),
('concert','ENTERTAINMENT','EVENTS','(?i)concert'),
('gaming','ENTERTAINMENT','GAMING','(?i)gaming'),
-- Education
('school','EDUCATION','SCHOOL_FEES','(?i)school'),
('coaching','EDUCATION','COACHING','(?i)coaching'),
('tuition','EDUCATION','COACHING','(?i)tuition'),
-- Personal care
('salon','PERSONAL_CARE','SALON','(?i)salon'),
('spa','PERSONAL_CARE','SPA','(?i)\bspa\b'),
('haircut','PERSONAL_CARE','SALON','(?i)haircut'),
-- Home
('furniture','HOME','FURNITURE','(?i)furniture'),
-- Housing
('rent','HOUSING','RENT','(?i)\brent\b'),
-- Sports
('gym','SPORTS','GYM','(?i)\bgym\b'),
('fitness','SPORTS','FITNESS','(?i)fitness'),
-- Pets
('pet','PETS','PET_STORE','(?i)\bpet\b'),
('vet','PETS','VETERINARY','(?i)\bvet\b'),
-- Gifts & donations
('donation','GIFTS_DONATIONS','CHARITY','(?i)\bdonation\b'),
('charity','GIFTS_DONATIONS','CHARITY','(?i)\bcharity\b'),
-- Subscriptions
('subscription','SUBSCRIPTIONS','GENERAL','(?i)subscription')
ON CONFLICT (keyword, category) DO NOTHING;

-- ============================================================
-- §7  RULEBOOK RULES
-- All groups in priority order, single merged INSERT per group.
-- ============================================================

-- ── INC — Income (INFLOW / CREDIT, ranks 8–90) ───────────────
INSERT INTO spendsense.rulebook
(rule_code,rule_group,priority_rank,flow_type,channel_filter,
 match_field,match_op,match_value,
 exclude_field,exclude_op,exclude_value,
 financial_class,instrument_type,counterparty_type,confidence_score,notes)
VALUES
('INC_003','INC',8,'INFLOW',NULL,
 'user_employer_match','EQUALS','TRUE',
 NULL,NULL,NULL,
 'INCOME','SALARY','EMPLOYER',0.99,
 'Matched against user_employers table'),
('INC_001','INC',10,'INFLOW',NULL,
 'normalized_description','IREGEX','\b(sal|salary|salcr|pay|payroll|income|wage|stipend)\b',
 NULL,NULL,NULL,
 'INCOME','SALARY','EMPLOYER',0.98,'Explicit salary words'),
('INC_002','INC',12,'INFLOW',NULL,
 'normalized_description','IREGEX','(pvt ltd|private limited|\bltd\b|llp|technologies|systems|solutions|consulting|services)',
 'normalized_description','IREGEX','(bank|finance|insurance|capital|nbfc|credit|housing|loan disbursement|refund|reversal|cashback)',
 'INCOME','SALARY','EMPLOYER',0.90,
 'Company-type name → likely salary; guards bank/finco inflows'),
('INC_050','INC',15,'INFLOW',NULL,
 'normalized_description','IREGEX','(refund|reversal|chargeback|cashback|cash back|\brev\b)',
 NULL,NULL,NULL,
 'REFUND','REFUND_CREDIT','MERCHANT',0.95,'Refund / reversal credit'),
('INC_010','INC',20,'INFLOW',NULL,
 'normalized_description','IREGEX','(consult|invoice|professional fee|retainer|contract|freelance)',
 NULL,NULL,NULL,
 'INCOME','BUSINESS_INCOME','CLIENT',0.92,'Gig / freelance income'),
('INC_020','INC',22,'INFLOW',NULL,
 'normalized_description','IREGEX','(seller.*payout|payout|adsense|uber.*payout|ola.*payout|swiggy.*payout|zomato.*payout|youtube)',
 NULL,NULL,NULL,
 'INCOME','PLATFORM_PAYOUT','PLATFORM',0.92,'Gig-economy platform payout'),
('INC_025','INC',23,'INFLOW',NULL,
 'merchant_entity_match','EQUALS','TRUE',
 'normalized_description','IREGEX','(refund|reversal|cashback|chargeback)',
 'INCOME','PLATFORM_PAYOUT','PLATFORM',0.88,
 'Inflow from merchant_entity_master — seller/driver payout; refund guard'),
('INC_030','INC',30,'INFLOW',NULL,
 'normalized_description','IREGEX','(dividend|mf redemption|mutual fund payout|int-div)',
 NULL,NULL,NULL,
 'INVESTMENT_INCOME','MF_REDEMPTION','AMC',0.94,'MF dividend or redemption'),
('INC_031','INC',30,'INFLOW',NULL,
 'normalized_description','IREGEX','(zerodha|groww|upstox|angel one|angel broking|5paisa|dhan)',
 NULL,NULL,NULL,
 'INVESTMENT_INCOME','STOCK_PROCEEDS','BROKER',0.94,'Broker payout'),
('INC_060','INC',35,'INFLOW',NULL,
 'normalized_description','IREGEX','(subsidy|pm kisan|dbt|govt benefit|government benefit)',
 NULL,NULL,NULL,
 'INCOME','GOVERNMENT_BENEFIT','GOVT',0.92,'DBT / govt scheme'),
('INC_040','INC',40,'INFLOW',NULL,
 'normalized_description','IREGEX','(interest credit|savings interest|fd interest|rd interest|sbint|int\.pd)',
 NULL,NULL,NULL,
 'INCOME','INTEREST','BANK',0.95,'Bank/FD/RD interest'),
('INC_045','INC',41,'INFLOW',NULL,
 'normalized_description','IREGEX','(cashback|cash back|reward redemption|reward credit|reward point|loyalt|bonus credit|welcome bonus)',
 NULL,NULL,NULL,
 'INCOME','CASHBACK_REWARD','BANK',0.93,'Card cashback / reward redemption credit'),
('INC_041','INC',42,'INFLOW',NULL,
 'normalized_description','IREGEX','(fd premat|fd proceeds|fd maturity|fd closure)',
 NULL,NULL,NULL,
 'INVESTMENT_INCOME','FD_MATURITY','BANK',0.94,'FD closure / maturity'),
('INC_042','INC',44,'INFLOW',NULL,
 'normalized_description','IREGEX','(sweep trf|sweep transfer)',
 NULL,NULL,NULL,
 'TRANSFER_IN','SELF_TRANSFER','BANK',0.92,'Auto-sweep from FD'),
('INC_070','INC',50,'INFLOW','ATM',
 'channel_type','EQUALS','ATM',
 NULL,NULL,NULL,
 'CASH_DEPOSIT','CASH','BANK',0.90,'ATM credit = cash deposit'),
('INC_999','INC',90,'INFLOW',NULL,
 'normalized_description','IREGEX','.*',
 NULL,NULL,NULL,
 'TRANSFER_IN','UPI_TRANSFER','INDIVIDUAL',0.60,'Fallback: unclassified inflow')
ON CONFLICT (rule_code) DO NOTHING;

-- ── EMI — Loan / EMI (OUTFLOW, ranks 10–20) ──────────────────
INSERT INTO spendsense.rulebook
(rule_code,rule_group,priority_rank,flow_type,channel_filter,
 match_field,match_op,match_value,
 exclude_field,exclude_op,exclude_value,
 financial_class,instrument_type,counterparty_type,obligation_flag,confidence_score,notes)
VALUES
('EMI_001','EMI',10,'OUTFLOW',NULL,
 'normalized_description','IREGEX','\bemi\b',
 'normalized_description','IREGEX','(sip|mutual fund|insurance|premium)',
 'LOAN_EMI','EMI','NBFC',TRUE,0.98,'Explicit EMI keyword — SIP/insurance guard'),
('EMI_002','EMI',12,'OUTFLOW',NULL,
 'normalized_description','IREGEX','(loan repayment|loan payment|loan installment)',
 'normalized_description','IREGEX','(sip|mutual fund|insurance)',
 'LOAN_EMI','EMI','NBFC',TRUE,0.96,'Loan repayment keyword'),
('EMI_007','EMI',14,'OUTFLOW',NULL,
 'normalized_description','IREGEX','card\s*emi|emi.*card',
 NULL,NULL,NULL,
 'LOAN_EMI','CARD_EMI','BANK',TRUE,0.96,'Card EMI conversion'),
('EMI_003','EMI',15,'OUTFLOW',NULL,
 'lender_master_match','EQUALS','TRUE',
 'normalized_description','IREGEX','(sip|mutual fund|\bmf\b|insurance|premium)',
 'LOAN_EMI','EMI','NBFC',TRUE,0.96,'Matched loan_lenders_master'),
('EMI_004','EMI',16,'OUTFLOW',NULL,
 'normalized_description','IREGEX','(home loan|personal loan|auto loan|car loan|housing loan)',
 NULL,NULL,NULL,
 'LOAN_EMI','EMI','BANK',TRUE,0.95,'Loan type keywords'),
('EMI_008','EMI',17,'OUTFLOW',NULL,
 'normalized_description','IREGEX','(zestmoney|lazypay|\bsimpl\b|\baxio\b|\bslice\b)',
 NULL,NULL,NULL,
 'LOAN_EMI','BNPL_EMI','NBFC',TRUE,0.95,'BNPL repayment'),
('EMI_005','EMI',18,'OUTFLOW','NACH',
 'ach_nach_entity','IREGEX','(finance|capital|credit|fincorp)',
 'normalized_description','IREGEX','(sip|mutual fund|\bmf\b|insurance|premium|lic|life|health|general insurance|policy)',
 'LOAN_EMI','EMI','NBFC',TRUE,0.94,
 'NACH entity contains finance/credit — tightened guard includes insurer names'),
('EMI_002B','EMI',19,'OUTFLOW',NULL,
 'normalized_description','IREGEX','\bloan\b',
 'normalized_description','IREGEX','(sip|mutual fund|\bmf\b|insurance)',
 'LOAN_EMI','EMI','NBFC',TRUE,0.88,'Generic loan keyword')
ON CONFLICT (rule_code) DO NOTHING;

-- ── CRED — CRED special module (OUTFLOW, ranks 35–45) ────────
INSERT INTO spendsense.rulebook
(rule_code,rule_group,priority_rank,flow_type,
 match_field,match_op,match_value,
 financial_class,instrument_type,counterparty_type,obligation_flag,confidence_score,notes)
VALUES
('CRED_001','CRED',35,'OUTFLOW',
 'normalized_description','IREGEX','cred\.insurance',
 'INSURANCE','INSURANCE_PREMIUM','INSURER',TRUE,0.98,'CRED insurance product'),
('CRED_002','CRED',36,'OUTFLOW',
 'normalized_description','IREGEX','cred\.club|cred\s*cash',
 'LOAN_EMI','EMI','NBFC',TRUE,0.98,'CRED Club / Cash loan'),
('CRED_003','CRED',37,'OUTFLOW',
 'normalized_description','IREGEX','credpay\.',
 'MERCHANT_PAYMENT','MERCHANT_UPI','MERCHANT',FALSE,0.98,'CREDPAY.merchant UPI'),
('CRED_004','CRED',45,'OUTFLOW',
 'normalized_description','IREGEX','\bcred\b',
 'CREDIT_CARD_PAYMENT','CARD_BILL','FINTECH',TRUE,0.70,'Generic CRED — CC payment fallback')
ON CONFLICT (rule_code) DO NOTHING;

-- ── CC — Credit Card Payment (OUTFLOW, ranks 50–57) ──────────
INSERT INTO spendsense.rulebook
(rule_code,rule_group,priority_rank,flow_type,
 match_field,match_op,match_value,
 exclude_field,exclude_op,exclude_value,
 financial_class,instrument_type,counterparty_type,obligation_flag,confidence_score,notes)
VALUES
('CC_001','CC',50,'OUTFLOW',
 'normalized_description','IREGEX','(credit card|cc payment|card payment|cc bill)',
 'normalized_description','IREGEX','\bloan\b',
 'CREDIT_CARD_PAYMENT','CARD_BILL','BANK',TRUE,0.98,'Explicit CC keywords'),
('CC_002','CC',52,'OUTFLOW',
 'cc_issuer_match','EQUALS','TRUE',
 'normalized_description','IREGEX','\bloan\b',
 'CREDIT_CARD_PAYMENT','CARD_BILL','BANK',TRUE,0.96,'Matched credit_card_issuers_master'),
('CC_003','CC',54,'OUTFLOW',
 'normalized_description','IREGEX','xxxx\s?\d{4}',
 NULL,NULL,NULL,
 'CREDIT_CARD_PAYMENT','CARD_BILL','BANK',TRUE,0.95,'Masked card number XXXX1234'),
('CC_005','CC',56,'OUTFLOW',
 'normalized_description','IREGEX','(hdfc\s*cc|icici\s*cc|sbi credit payment|axis credit)',
 'normalized_description','IREGEX','\bloan\b',
 'CREDIT_CARD_PAYMENT','CARD_BILL','BANK',TRUE,0.93,'Issuer + cc shorthand'),
('CC_006','CC',57,'OUTFLOW',
 'normalized_description','IREGEX','auto debit.*card|ach.*card',
 NULL,NULL,NULL,
 'CREDIT_CARD_PAYMENT','CARD_BILL','BANK',TRUE,0.92,'ACH/auto-debit card payment')
ON CONFLICT (rule_code) DO NOTHING;

-- ── INV — Investment (OUTFLOW, ranks 60–72) ───────────────────
INSERT INTO spendsense.rulebook
(rule_code,rule_group,priority_rank,flow_type,
 match_field,match_op,match_value,
 exclude_field,exclude_op,exclude_value,
 financial_class,instrument_type,counterparty_type,investment_mode,confidence_score,notes)
VALUES
('INV_001','INV',60,'OUTFLOW',
 'normalized_description','IREGEX','\b(sip|systematic investment)\b',
 'normalized_description','IREGEX','(loan|emi|insurance|premium)',
 'INVESTMENT','SIP','AMC','RECURRING',0.98,'SIP keyword'),
('INV_002','INV',62,'OUTFLOW',
 'normalized_description','IREGEX','(mutual fund|\bmf\b|folio|scheme|fund purchase)',
 'normalized_description','IREGEX','(loan|emi|insurance|premium)',
 'INVESTMENT','LUMP_SUM_MUTUAL_FUND','AMC','ONE_TIME',0.95,'MF keywords'),
('INV_005','INV',65,'OUTFLOW',
 'investment_entity_match','EQUALS','TRUE',
 'normalized_description','IREGEX','(loan|emi|insurance|premium|repayment)',
 'INVESTMENT',NULL,NULL,NULL,0.96,'Matched investment_entities_master'),
('INV_007','INV',68,'OUTFLOW',
 'normalized_description','IREGEX','(smallcase|stock purchase|equity purchase)',
 NULL,NULL,NULL,
 'INVESTMENT','STOCK_PURCHASE','BROKER','MARKET_LINKED',0.94,'Direct equity'),
('INV_009','INV',70,'OUTFLOW',
 'normalized_description','IREGEX','\b(nps|ppf|pension|retirement fund)\b',
 NULL,NULL,NULL,
 'INVESTMENT','RETIREMENT_INVESTMENT','RETIREMENT_FUND','GOAL_LINKED',0.95,'Retirement contribution'),
('INV_010','INV',72,'OUTFLOW',
 'normalized_description','IREGEX','(digital gold|gold savings|gold purchase)',
 NULL,NULL,NULL,
 'INVESTMENT','DIGITAL_GOLD','PLATFORM','ONE_TIME',0.90,'Digital gold purchase')
ON CONFLICT (rule_code) DO NOTHING;

-- ── MERCH — Merchant payments (OUTFLOW, ranks 73–79) ─────────
-- NEW group: routes UPI merchant entity types to MERCHANT_PAYMENT
-- before TRF fallback. Uses upi_entity_filter column.
INSERT INTO spendsense.rulebook
(rule_code,rule_group,priority_rank,flow_type,channel_filter,upi_entity_filter,
 match_field,match_op,match_value,
 exclude_field,exclude_op,exclude_value,
 financial_class,instrument_type,counterparty_type,
 obligation_flag,merchant_flag,confidence_score,notes)
VALUES
('MERCH_010','MERCH',73,'OUTFLOW','UPI',NULL,
 'upi_vpa','IREGEX','@(razorpay|payu|cashfree|easebuzz|ccavenue|billdesk|paytm|phonepe|gpay|amazonpay|jiomoney)',
 NULL,NULL,NULL,
 'MERCHANT_PAYMENT','GATEWAY_UPI','MERCHANT',
 FALSE,TRUE,0.96,'VPA handle = known payment gateway'),
('MERCH_001','MERCH',74,'OUTFLOW','UPI','MERCHANT',
 'upi_entity_type','EQUALS','MERCHANT',
 NULL,NULL,NULL,
 'MERCHANT_PAYMENT','MERCHANT_UPI','MERCHANT',
 FALSE,TRUE,0.92,'UPI classifier MERCHANT entity'),
('MERCH_002','MERCH',75,'OUTFLOW','UPI','SMALL_MERCHANT',
 'upi_entity_type','EQUALS','SMALL_MERCHANT',
 NULL,NULL,NULL,
 'MERCHANT_PAYMENT','QR_UPI','SMALL_MERCHANT',
 FALSE,TRUE,0.85,'UPI classifier SMALL_MERCHANT — QR / neighbourhood'),
('MERCH_003','MERCH',76,'OUTFLOW','UPI','UNKNOWN_MERCHANT',
 'upi_entity_type','EQUALS','UNKNOWN_MERCHANT',
 NULL,NULL,NULL,
 'MERCHANT_PAYMENT','MERCHANT_UPI','UNKNOWN_MERCHANT',
 FALSE,TRUE,0.65,'UPI classifier UNKNOWN_MERCHANT — low confidence'),
('MERCH_020','MERCH',77,'OUTFLOW',NULL,NULL,
 'merchant_entity_match','EQUALS','TRUE',
 NULL,NULL,NULL,
 'MERCHANT_PAYMENT','MERCHANT_UPI','MERCHANT',
 FALSE,TRUE,0.94,'Matched merchant_entity_master'),
('MERCH_030','MERCH',78,'OUTFLOW',NULL,NULL,
 'merchant_keyword_match','EQUALS','TRUE',
 NULL,NULL,NULL,
 'MERCHANT_PAYMENT','MERCHANT_UPI','MERCHANT',
 FALSE,TRUE,0.82,'Matched merchant_keyword table')
ON CONFLICT (rule_code) DO NOTHING;

-- ── INS — Insurance (OUTFLOW, ranks 79–86) ───────────────────
-- INS_003 at rank 79 catches NACH insurer premiums BEFORE
-- INS_001 (keyword) and AFTER all EMI rules.
INSERT INTO spendsense.rulebook
(rule_code,rule_group,priority_rank,flow_type,channel_filter,
 match_field,match_op,match_value,
 exclude_field,exclude_op,exclude_value,
 financial_class,instrument_type,counterparty_type,obligation_flag,confidence_score,notes)
VALUES
('INS_003','INS',79,'OUTFLOW','NACH',
 'insurer_master_match','EQUALS','TRUE',
 NULL,NULL,NULL,
 'INSURANCE','INSURANCE_PREMIUM','INSURER',TRUE,0.97,
 'NACH channel + insurer_entities_master — prevents EMI misclassification'),
('INS_001','INS',80,'OUTFLOW',NULL,
 'normalized_description','IREGEX','\b(insurance|premium|policy premium|ins prem)\b',
 'normalized_description','IREGEX','(sip|\bmf\b|mutual fund|loan|emi)',
 'INSURANCE','INSURANCE_PREMIUM','INSURER',TRUE,0.98,'Explicit insurance keyword'),
('INS_002','INS',82,'OUTFLOW',NULL,
 'insurer_master_match','EQUALS','TRUE',
 'normalized_description','IREGEX','(sip|\bmf\b|mutual fund)',
 'INSURANCE',NULL,'INSURER',TRUE,0.97,'Matched insurance_entities_master'),
('INS_006','INS',83,'OUTFLOW',NULL,
 'normalized_description','IREGEX','(ulip|unit linked)',
 NULL,NULL,NULL,
 'INSURANCE','ULIP_PREMIUM','INSURER',TRUE,0.95,'ULIP — keep under insurance'),
('INS_005','INS',84,'OUTFLOW',NULL,
 'normalized_description','IREGEX','(policy renewal|sum assured|term plan|mediclaim|health plan)',
 NULL,NULL,NULL,
 'INSURANCE','INSURANCE_PREMIUM','INSURER',TRUE,0.94,'Policy/renewal/mediclaim'),
('INS_008','INS',86,'OUTFLOW',NULL,
 'normalized_description','IREGEX','(insurance.*hdfc|insurance.*icici|insurance.*sbi|premium.*bank)',
 NULL,NULL,NULL,
 'INSURANCE','INSURANCE_PREMIUM','BANK',TRUE,0.89,'Bancassurance')
ON CONFLICT (rule_code) DO NOTHING;

-- ── HOUSING — Rent & society payments (OUTFLOW, rank 79) ─────
INSERT INTO spendsense.rulebook
(rule_code,rule_group,priority_rank,flow_type,
 match_field,match_op,match_value,
 exclude_field,exclude_op,exclude_value,
 financial_class,instrument_type,counterparty_type,obligation_flag,confidence_score,notes)
VALUES
('HOUSING_001','HOUSING',79,'OUTFLOW',
 'normalized_description','IREGEX',
 '(nobroker|housing society|maintenance|flat rent|house rent|pg rent|rental|rent paid)',
 'normalized_description','IREGEX','(loan|emi|insurance)',
 'HOUSING','RENT_PAYMENT','LANDLORD',TRUE,0.90,'Rent / society / PG payment'),
('HOUSING_002','HOUSING',79,'OUTFLOW',
 'merchant_entity_match','EQUALS','TRUE',
 NULL,NULL,NULL,
 'HOUSING','RENT_PAYMENT','RENT_PLATFORM',FALSE,0.92,
 'Matched NoBroker / rent platform in merchant_entity_master')
ON CONFLICT (rule_code) DO NOTHING;

-- ── CASH — ATM Withdrawal (OUTFLOW, rank 95) ─────────────────
INSERT INTO spendsense.rulebook
(rule_code,rule_group,priority_rank,flow_type,channel_filter,
 match_field,match_op,match_value,
 financial_class,instrument_type,counterparty_type,confidence_score,notes)
VALUES
('CASH_001','CASH',95,'OUTFLOW','ATM',
 'channel_type','EQUALS','ATM',
 'CASH_WITHDRAWAL','ATM_CASH','BANK',0.99,'ATM channel debit = cash withdrawal')
ON CONFLICT (rule_code) DO NOTHING;

-- ── FEE — Bank Charges (OUTFLOW, ranks 100–105) ──────────────
INSERT INTO spendsense.rulebook
(rule_code,rule_group,priority_rank,flow_type,
 match_field,match_op,match_value,
 financial_class,instrument_type,counterparty_type,confidence_score,notes)
VALUES
('FEE_001','FEE',100,'OUTFLOW',
 'normalized_description','IREGEX','(bank charge|service charge|account maintenance|minimum balance|non maintenance)',
 'BANK_CHARGE','BANK_FEE','BANK',0.94,'Bank charges'),
('FEE_002','FEE',101,'OUTFLOW',
 'normalized_description','IREGEX','(atm charge|atm fee|atm usage)',
 'BANK_CHARGE','ATM_FEE','BANK',0.94,'ATM charges'),
('FEE_003','FEE',102,'OUTFLOW',
 'normalized_description','IREGEX','(imps charge|neft charge|rtgs charge|upi charge)',
 'BANK_CHARGE','TRANSFER_FEE','BANK',0.94,'Transfer charges'),
('FEE_004','FEE',103,'OUTFLOW',
 'normalized_description','IREGEX','(annual fee|card fee|debit card fee)',
 'BANK_CHARGE','CARD_FEE','BANK',0.94,'Card annual/issuance fee'),
('FEE_005','FEE',104,'OUTFLOW',
 'normalized_description','IREGEX','(gst.*charge|gst debit|tax.*charge)',
 'BANK_CHARGE','GST_ON_CHARGES','BANK',0.92,'GST on bank charges'),
('FEE_006','FEE',105,'OUTFLOW',
 'normalized_description','IREGEX','(dp charge|dpchg)',
 'BANK_CHARGE','DP_CHARGES','BANK',0.94,'Demat / DP charges')
ON CONFLICT (rule_code) DO NOTHING;

-- ── TRF — Transfers / fallbacks (ranks 120–130) ──────────────
INSERT INTO spendsense.rulebook
(rule_code,rule_group,priority_rank,flow_type,
 match_field,match_op,match_value,
 financial_class,instrument_type,counterparty_type,confidence_score,notes)
VALUES
('TRF_001','TRF',120,'OUTFLOW',
 'normalized_description','IREGEX','(self transfer|own account|transfer to self)',
 'TRANSFER_OUT','SELF_TRANSFER','SELF',0.98,'Explicit self-transfer'),
('TRF_002','TRF',122,'OUTFLOW',
 'upi_entity_type','EQUALS','PERSON',
 'TRANSFER_OUT','P2P_TRANSFER','INDIVIDUAL',0.90,'UPI classifier = PERSON'),
('TRF_003','TRF',123,'OUTFLOW',
 'upi_entity_type','EQUALS','SELF_ACCOUNT',
 'TRANSFER_OUT','SELF_TRANSFER','SELF',0.95,'UPI classifier = SELF_ACCOUNT'),
('TRF_999','TRF',130,'OUTFLOW',
 'normalized_description','IREGEX','.*',
 'TRANSFER_OUT','OUTFLOW_UNCLASSIFIED','UNKNOWN',0.40,'Fallback: unclassified outflow')
ON CONFLICT (rule_code) DO NOTHING;

COMMIT;
