-- ============================================================
-- Monytix Rulebook Schema
-- Input : spendsense.txn_parsed_UPI_updated
-- Output: spendsense.txn_rulebook_output
--
-- Design principles:
--   1. Rules live in tables, not code — add/edit without deploys
--   2. Every master table is pattern-based + JOIN-able
--   3. Priority cascade: lower number wins, first match wins
--   4. Guardrails stored as exclusion patterns alongside rules
--   5. All outputs feed dim_category / dim_subcategory / dim_merchant
-- ============================================================

SET search_path = spendsense, public;

-- ============================================================
-- CORE RULEBOOK TABLE
-- One row per rule. Engine evaluates in priority_rank order.
-- First rule that matches wins (no double-firing).
-- ============================================================
CREATE TABLE IF NOT EXISTS spendsense.rulebook (
    rule_id             BIGSERIAL PRIMARY KEY,
    rule_code           TEXT NOT NULL UNIQUE,   -- INC_001, EMI_003, etc.
    rule_group          TEXT NOT NULL,           -- INC | EMI | CC | INV | INS | FEE | TRF | MERCH
    priority_rank       INT NOT NULL,            -- lower = evaluated first
    flow_type           TEXT,                    -- INFLOW | OUTFLOW | NULL = both
    channel_filter      TEXT,                    -- UPI|NEFT|ACH|NACH|IMPS|ATM|NULL=any
    upi_entity_filter   TEXT,                    -- MERCHANT|SMALL_MERCHANT|UNKNOWN_MERCHANT|PERSON|SELF_ACCOUNT|NULL=any
    match_field         TEXT NOT NULL,           -- normalized_description | entity_name | ach_nach_entity | channel_type | upi_vpa
    match_op            TEXT NOT NULL,           -- IREGEX | ILIKE | EQUALS | NOT_IREGEX
    match_value         TEXT NOT NULL,
    -- exclusion guard (optional — if exclusion fires, skip this rule)
    exclude_field       TEXT,
    exclude_op          TEXT,
    exclude_value       TEXT,
    -- outputs
    financial_class     TEXT NOT NULL,
    instrument_type     TEXT,
    counterparty_type   TEXT,
    investment_mode     TEXT,
    obligation_flag     BOOLEAN DEFAULT FALSE,
    merchant_flag       BOOLEAN DEFAULT FALSE,
    confidence_score    NUMERIC(4,2) DEFAULT 0.90,
    is_active           BOOLEAN DEFAULT TRUE,
    notes               TEXT,
    created_at          TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS ix_rulebook_priority  ON spendsense.rulebook(priority_rank) WHERE is_active;
CREATE INDEX IF NOT EXISTS ix_rulebook_group     ON spendsense.rulebook(rule_group) WHERE is_active;
CREATE INDEX IF NOT EXISTS ix_rulebook_flow      ON spendsense.rulebook(flow_type) WHERE is_active;

-- ============================================================
-- USER-LEVEL LEARNING TABLES
-- These are joined by the engine to boost confidence.
-- ============================================================

-- Known employers per user (boosts salary detection)
CREATE TABLE IF NOT EXISTS spendsense.user_employers (
    id          BIGSERIAL PRIMARY KEY,
    user_id     TEXT NOT NULL,
    employer    TEXT NOT NULL,
    confirmed   BOOLEAN DEFAULT FALSE,
    created_at  TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE (user_id, employer)
);

-- Known credit cards per user
CREATE TABLE IF NOT EXISTS spendsense.user_credit_cards (
    id          BIGSERIAL PRIMARY KEY,
    user_id     TEXT NOT NULL,
    card_issuer TEXT NOT NULL,
    card_last4  TEXT,
    created_at  TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE (user_id, card_issuer, card_last4)
);

-- Known loans per user
CREATE TABLE IF NOT EXISTS spendsense.user_loans (
    id          BIGSERIAL PRIMARY KEY,
    user_id     TEXT NOT NULL,
    lender      TEXT NOT NULL,
    emi_amount  NUMERIC(18,2),
    loan_type   TEXT,
    created_at  TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE (user_id, lender)
);

-- ============================================================
-- LOAN LENDERS MASTER
-- ============================================================
CREATE TABLE IF NOT EXISTS spendsense.loan_lenders_master (
    lender_id           BIGSERIAL PRIMARY KEY,
    normalized_entity   TEXT NOT NULL UNIQUE,
    lender_type         TEXT NOT NULL, -- BANK | NBFC | HFC | FINTECH | BNPL | MFI | GOLD
    loan_category       TEXT,          -- PERSONAL | HOME | GOLD | BNPL | BUSINESS | AUTO
    match_pattern       TEXT NOT NULL,
    priority_hint       INT DEFAULT 15,
    is_active           BOOLEAN DEFAULT TRUE
);

-- ============================================================
-- CREDIT CARD ISSUERS MASTER
-- ============================================================
CREATE TABLE IF NOT EXISTS spendsense.credit_card_issuers_master (
    issuer_id           BIGSERIAL PRIMARY KEY,
    normalized_entity   TEXT NOT NULL UNIQUE,
    issuer_bank         TEXT,
    issuer_type         TEXT NOT NULL, -- BANK | NETWORK | FINTECH_PLATFORM
    network             TEXT,          -- VISA | MASTERCARD | AMEX | RUPAY
    match_pattern       TEXT NOT NULL,
    priority_hint       INT DEFAULT 12,
    is_active           BOOLEAN DEFAULT TRUE
);

-- ============================================================
-- INVESTMENT ENTITIES MASTER
-- ============================================================
CREATE TABLE IF NOT EXISTS spendsense.investment_entities_master (
    entity_id               BIGSERIAL PRIMARY KEY,
    normalized_entity       TEXT NOT NULL UNIQUE,
    provider_type           TEXT NOT NULL, -- AMC | AMC_RTA | BROKER | WEALTH_PLATFORM | PLATFORM | GOVT
    investment_category     TEXT NOT NULL, -- MUTUAL_FUND | BROKER | WEALTH_PLATFORM | RETIREMENT | DIGITAL_GOLD
    default_instrument_type TEXT,
    default_investment_mode TEXT DEFAULT 'RECURRING',
    match_pattern           TEXT NOT NULL,
    priority_hint           INT DEFAULT 36,
    is_active               BOOLEAN DEFAULT TRUE
);

-- ============================================================
-- INSURANCE ENTITIES MASTER
-- ============================================================
CREATE TABLE IF NOT EXISTS spendsense.insurance_entities_master (
    entity_id           BIGSERIAL PRIMARY KEY,
    normalized_entity   TEXT NOT NULL UNIQUE,
    insurer_type        TEXT NOT NULL, -- LIFE | HEALTH | GENERAL | PLATFORM
    insurance_subtype   TEXT,          -- LIFE_PREMIUM | HEALTH_PREMIUM | GENERAL_PREMIUM | etc.
    match_pattern       TEXT NOT NULL,
    priority_hint       INT DEFAULT 52,
    is_active           BOOLEAN DEFAULT TRUE
);

-- ============================================================
-- RULEBOOK OUTPUT TABLE
-- Written by the engine. One row per transaction.
-- ============================================================
CREATE TABLE IF NOT EXISTS spendsense.txn_rulebook_output (
    output_id               BIGSERIAL PRIMARY KEY,
    -- FK back to UPI-classified parsed table
    txn_id                  UUID NOT NULL UNIQUE
                                REFERENCES spendsense.txn_parsed_UPI_updated(txn_id)
                                ON DELETE CASCADE,
    user_id                 TEXT NOT NULL,
    txn_date                DATE NOT NULL,
    amount                  NUMERIC(18,2) NOT NULL,
    cr_dr                   CHAR(1) NOT NULL,
    channel_type            TEXT,
    upi_entity_type         TEXT,   -- carried from UPI classifier

    -- Classification outputs
    financial_class         TEXT,
    instrument_type         TEXT,
    counterparty_type       TEXT,
    investment_mode         TEXT,
    obligation_flag         BOOLEAN DEFAULT FALSE,
    merchant_flag           BOOLEAN DEFAULT FALSE,
    resolved_entity         TEXT,   -- normalized entity name that fired

    -- Provenance
    rule_code               TEXT,   -- which rule fired
    rule_group              TEXT,
    confidence_score        NUMERIC(4,2) DEFAULT 0.0,
    classification_source   TEXT,   -- 'rulebook' | 'entity_master' | 'user_learning' | 'fallback'
    is_fallback             BOOLEAN DEFAULT FALSE,

    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS ix_rbo_user      ON spendsense.txn_rulebook_output(user_id);
CREATE INDEX IF NOT EXISTS ix_rbo_class     ON spendsense.txn_rulebook_output(financial_class);
CREATE INDEX IF NOT EXISTS ix_rbo_date      ON spendsense.txn_rulebook_output(txn_date DESC);
CREATE INDEX IF NOT EXISTS ix_rbo_source    ON spendsense.txn_rulebook_output(classification_source);
