-- ============================================================
-- 002_entity_masters_seed.sql
-- Seeds: loan_lenders_master, credit_card_issuers_master,
--        investment_entities_master, insurance_entities_master
-- ============================================================

SET search_path = spendsense, public;

-- ============================================================
-- LOAN LENDERS MASTER  (~220 rows as per document spec)
-- ============================================================

INSERT INTO spendsense.loan_lenders_master (normalized_entity, lender_type, loan_category, match_pattern, priority_hint) VALUES

-- Public Sector Banks
('STATE BANK OF INDIA',  'BANK','PERSONAL', '(?i)\bsbi\b|state bank of india',         14),
('PUNJAB NATIONAL BANK', 'BANK','PERSONAL', '(?i)\bpnb\b|punjab national bank',         14),
('BANK OF BARODA',       'BANK','PERSONAL', '(?i)bank of baroda|\bbob\b',               14),
('CANARA BANK',          'BANK','PERSONAL', '(?i)canara bank',                          14),
('UNION BANK OF INDIA',  'BANK','PERSONAL', '(?i)union bank',                           14),
('INDIAN BANK',          'BANK','PERSONAL', '(?i)indian bank',                          14),
('BANK OF INDIA',        'BANK','PERSONAL', '(?i)bank of india',                        14),
('CENTRAL BANK OF INDIA','BANK','PERSONAL', '(?i)central bank',                         14),
('INDIAN OVERSEAS BANK', 'BANK','PERSONAL', '(?i)indian overseas',                      14),
('UCO BANK',             'BANK','PERSONAL', '(?i)\buco bank\b',                         14),
('BANK OF MAHARASHTRA',  'BANK','PERSONAL', '(?i)bank of maharashtra',                  14),
('PUNJAB AND SIND BANK', 'BANK','PERSONAL', '(?i)punjab and sind',                      14),

-- Major Private Banks
('HDFC BANK LOAN',       'BANK','PERSONAL', '(?i)hdfc.*loan|hdfc.*emi',                 14),
('ICICI BANK LOAN',      'BANK','PERSONAL', '(?i)icici.*loan|icici.*emi',               14),
('AXIS BANK LOAN',       'BANK','HOME',     '(?i)axis.*loan|axis.*emi',                 14),
('KOTAK MAHINDRA BANK',  'BANK','PERSONAL', '(?i)kotak.*loan',                          14),
('INDUSIND BANK',        'BANK','PERSONAL', '(?i)indusind.*loan',                       14),
('YES BANK LOAN',        'BANK','PERSONAL', '(?i)yes bank.*loan',                       14),
('IDFC FIRST BANK',      'BANK','PERSONAL', '(?i)idfc.*loan',                           14),
('FEDERAL BANK LOAN',    'BANK','PERSONAL', '(?i)federal.*loan',                        14),
('RBL BANK LOAN',        'BANK','PERSONAL', '(?i)rbl.*loan',                            14),
('BANDHAN BANK',         'BANK','PERSONAL', '(?i)bandhan bank.*loan',                   14),

-- Major NBFCs
('BAJAJ FINANCE',        'NBFC','PERSONAL', '(?i)bajaj finance',                        14),
('TATA CAPITAL',         'NBFC','PERSONAL', '(?i)tata capital',                         14),
('HDB FINANCIAL',        'NBFC','PERSONAL', '(?i)hdb financial',                        14),
('L&T FINANCE',          'NBFC','PERSONAL', '(?i)l&t finance|l and t finance',          14),
('ADITYA BIRLA FINANCE', 'NBFC','PERSONAL', '(?i)aditya birla finance',                 14),
('INDIABULLS FINANCE',   'NBFC','PERSONAL', '(?i)indiabulls finance',                   14),
('SHRIRAM FINANCE',      'NBFC','PERSONAL', '(?i)shriram finance',                      14),
('MAHINDRA FINANCE',     'NBFC','AUTO',     '(?i)mahindra finance|m&m financial',       14),
('CHOLAMANDALAM',        'NBFC','AUTO',     '(?i)cholamandalam',                        14),
('FULLERTON INDIA',      'NBFC','PERSONAL', '(?i)fullerton',                            14),
('CAPITAL FLOAT',        'NBFC','BUSINESS', '(?i)capital float',                        14),
('LENDINGKART',          'NBFC','BUSINESS', '(?i)lendingkart',                          14),
('OXYZО',                'NBFC','BUSINESS', '(?i)oxyzo',                                14),
('CLIX CAPITAL',         'NBFC','PERSONAL', '(?i)clix capital',                         14),
('EDELWEISS FINANCE',    'NBFC','PERSONAL', '(?i)edelweiss finance',                    14),
('HERO FINCORP',         'NBFC','AUTO',     '(?i)hero fincorp',                         14),
('TVS CREDIT',           'NBFC','AUTO',     '(?i)tvs credit',                           14),

-- Housing Finance Companies
('LIC HOUSING FINANCE',  'HFC','HOME',      '(?i)lic housing',                          14),
('PNB HOUSING FINANCE',  'HFC','HOME',      '(?i)pnb housing',                          14),
('CANFIN HOMES',         'HFC','HOME',      '(?i)canfin homes',                         14),
('INDIABULLS HOUSING',   'HFC','HOME',      '(?i)indiabulls housing',                   14),
('APTUS VALUE HOUSING',  'HFC','HOME',      '(?i)aptus value',                          14),
('REPCO HOME FINANCE',   'HFC','HOME',      '(?i)repco home',                           14),
('AАVAS FINANCIERS',     'HFC','HOME',      '(?i)aavas',                                14),

-- Gold Loan Companies
('MUTHOOT FINANCE',      'GOLD','GOLD',     '(?i)muthoot',                              14),
('MANAPPURAM FINANCE',   'GOLD','GOLD',     '(?i)manappuram',                           14),
('IIFL GOLD LOAN',       'GOLD','GOLD',     '(?i)iifl gold',                            14),
('RUPEEK',               'GOLD','GOLD',     '(?i)rupeek',                               14),

-- Fintech Personal Loan Apps
('CASHE',                'FINTECH','PERSONAL','(?i)cashe',                              15),
('KISSHT',               'FINTECH','PERSONAL','(?i)kissht',                             15),
('EARLYSALARY',          'FINTECH','PERSONAL','(?i)earlysalary',                        15),
('NAVI',                 'FINTECH','PERSONAL','(?i)\bnavi\b',                           15),
('KREDIT BEE',           'FINTECH','PERSONAL','(?i)kreditbee',                          15),
('MONEYVIEW',            'FINTECH','PERSONAL','(?i)moneyview',                          15),
('FIBE',                 'FINTECH','PERSONAL','(?i)\bfibe\b',                           15),
('STASHFIN',             'FINTECH','PERSONAL','(?i)stashfin',                           15),
('KRAZYBEE',             'FINTECH','PERSONAL','(?i)krazybee',                           15),
('PAYME INDIA',          'FINTECH','PERSONAL','(?i)payme india',                        15),
('SMARTCOIN',            'FINTECH','PERSONAL','(?i)smartcoin',                          15),
('MPOCKET',              'FINTECH','PERSONAL','(?i)mpocket',                            15),
('MONEYTAP',             'FINTECH','PERSONAL','(?i)moneytap',                           15),

-- BNPL Platforms
('LAZYPAY',              'BNPL','BNPL',      '(?i)lazypay',                             17),
('ZESTMONEY',            'BNPL','BNPL',      '(?i)zestmoney',                           17),
('SIMPL',                'BNPL','BNPL',      '(?i)\bsimpl\b',                           17),
('AXIO',                 'BNPL','BNPL',      '(?i)\baxio\b',                            17),
('SLICE',                'BNPL','BNPL',      '(?i)\bslice\b',                           17),
('PAYTM POSTPAID',       'BNPL','BNPL',      '(?i)paytm postpaid',                      17),
('AMAZON PAY LATER',     'BNPL','BNPL',      '(?i)amazon pay later',                    17),
('FLIPKART PAY LATER',   'BNPL','BNPL',      '(?i)flipkart pay later',                  17),

-- MFIs
('BANDHAN MFI',          'MFI','PERSONAL',   '(?i)bandhan microfinance',                15),
('UTKARSH MFI',          'MFI','PERSONAL',   '(?i)utkarsh microfinance',                15),
('SPANDANA MFI',         'MFI','PERSONAL',   '(?i)spandana',                            15),
('SATIN CREDITCARE',     'MFI','PERSONAL',   '(?i)satin creditcare',                    15),
('EQUITAS MFI',          'MFI','PERSONAL',   '(?i)equitas micro',                       15),
('UJJIVAN MFI',          'MFI','PERSONAL',   '(?i)ujjivan',                             15),
('ESAF MFI',             'MFI','PERSONAL',   '(?i)esaf micro',                          15),

-- Small Finance Banks
('AU SMALL FINANCE',     'BANK','PERSONAL',  '(?i)au small finance|au bank',            14),
('EQUITAS SFB',          'BANK','PERSONAL',  '(?i)equitas small finance',               14),
('UJJIVAN SFB',          'BANK','PERSONAL',  '(?i)ujjivan small finance bank',          14),
('ESAF SFB',             'BANK','PERSONAL',  '(?i)esaf small finance bank',             14),
('SURYODAY SFB',         'BANK','PERSONAL',  '(?i)suryoday',                            14),
('FINCARE SFB',          'BANK','PERSONAL',  '(?i)fincare',                             14)

ON CONFLICT (normalized_entity) DO NOTHING;

-- ============================================================
-- CREDIT CARD ISSUERS MASTER
-- ============================================================

INSERT INTO spendsense.credit_card_issuers_master (normalized_entity, issuer_bank, issuer_type, network, match_pattern, priority_hint) VALUES
('SBI CARD',            'SBI',               'BANK',             'VISA',       '(?i)sbi\s?card',                      12),
('HDFC CARD',           'HDFC',              'BANK',             'VISA',       '(?i)hdfc\s?card',                     12),
('ICICI CARD',          'ICICI',             'BANK',             'VISA',       '(?i)icici\s?card',                    12),
('AXIS CARD',           'AXIS',              'BANK',             'VISA',       '(?i)axis\s?card',                     12),
('KOTAK CARD',          'KOTAK',             'BANK',             'VISA',       '(?i)kotak\s?card',                    12),
('YES BANK CARD',       'YES BANK',          'BANK',             'VISA',       '(?i)yes\s?bank\s?card',               12),
('INDUSIND CARD',       'INDUSIND',          'BANK',             'VISA',       '(?i)indusind\s?card',                 12),
('RBL CARD',            'RBL',               'BANK',             'VISA',       '(?i)rbl\s?card',                      12),
('HSBC CARD',           'HSBC',              'BANK',             'VISA',       '(?i)hsbc\s?card',                     12),
('STANDARD CHARTERED',  'STANDARD CHARTERED','BANK',             'VISA',       '(?i)standard\s?chartered\s?card',     12),
('IDFC FIRST CARD',     'IDFC FIRST',        'BANK',             'VISA',       '(?i)idfc\s?card',                     12),
('AU BANK CARD',        'AU BANK',           'BANK',             'VISA',       '(?i)au\s?bank\s?card',                12),
('FEDERAL CARD',        'FEDERAL',           'BANK',             'VISA',       '(?i)federal\s?card',                  12),
('CITI CARD',           'CITI',              'BANK',             'VISA',       '(?i)citi\s?card|citibank\s?card',     12),
('AMEX',                NULL,                'NETWORK',          'AMEX',       '(?i)amex|american\s?express',         12),
('VISA CARD',           NULL,                'NETWORK',          'VISA',       '(?i)\bvisa\b',                        20),
('MASTERCARD',          NULL,                'NETWORK',          'MASTERCARD', '(?i)master\s?card',                   20),
('RUPAY CARD',          NULL,                'NETWORK',          'RUPAY',      '(?i)rupay',                           20),
('CRED',                NULL,                'FINTECH_PLATFORM',  NULL,        '(?i)\bcred\b',                        15),
('CHEQ',                NULL,                'FINTECH_PLATFORM',  NULL,        '(?i)\bcheq\b',                        15)

ON CONFLICT (normalized_entity) DO NOTHING;

-- ============================================================
-- INVESTMENT ENTITIES MASTER
-- ============================================================

INSERT INTO spendsense.investment_entities_master (normalized_entity, provider_type, investment_category, default_instrument_type, default_investment_mode, match_pattern, priority_hint) VALUES

-- AMC-RTA (highest priority — seen more often than direct AMC names)
('CAMS',              'AMC_RTA','MUTUAL_FUND','SIP',              'RECURRING',  '(?i)\bcams\b',             34),
('KFINTECH',          'AMC_RTA','MUTUAL_FUND','SIP',              'RECURRING',  '(?i)kfintech|karvy',       34),

-- Direct AMCs
('HDFC MUTUAL FUND',  'AMC',    'MUTUAL_FUND','SIP',              'RECURRING',  '(?i)hdfc\s*mf',            36),
('ICICI PRU MF',      'AMC',    'MUTUAL_FUND','SIP',              'RECURRING',  '(?i)icici\s*pru\s*mf',     36),
('SBI MUTUAL FUND',   'AMC',    'MUTUAL_FUND','SIP',              'RECURRING',  '(?i)sbi\s*mf',             36),
('NIPPON INDIA MF',   'AMC',    'MUTUAL_FUND','SIP',              'RECURRING',  '(?i)nippon',               36),
('KOTAK MF',          'AMC',    'MUTUAL_FUND','SIP',              'RECURRING',  '(?i)kotak\s*mf',           36),
('AXIS MF',           'AMC',    'MUTUAL_FUND','SIP',              'RECURRING',  '(?i)axis\s*mf',            36),
('MIRAE ASSET MF',    'AMC',    'MUTUAL_FUND','SIP',              'RECURRING',  '(?i)mirae',                36),
('UTI MF',            'AMC',    'MUTUAL_FUND','SIP',              'RECURRING',  '(?i)uti\s*mf',             36),
('ADITYA BIRLA MF',   'AMC',    'MUTUAL_FUND','SIP',              'RECURRING',  '(?i)aditya birla\s*mf',    36),
('DSP MF',            'AMC',    'MUTUAL_FUND','SIP',              'RECURRING',  '(?i)dsp\s*mf',             36),
('TATA MF',           'AMC',    'MUTUAL_FUND','SIP',              'RECURRING',  '(?i)tata\s*mf',            36),
('FRANKLIN MF',       'AMC',    'MUTUAL_FUND','SIP',              'RECURRING',  '(?i)franklin',             36),
('PPFAS MF',          'AMC',    'MUTUAL_FUND','SIP',              'RECURRING',  '(?i)ppfas',                36),
('MOTILAL OSWAL MF',  'AMC',    'MUTUAL_FUND','SIP',              'RECURRING',  '(?i)motilal oswal\s*mf',   36),
('QUANT MF',          'AMC',    'MUTUAL_FUND','SIP',              'RECURRING',  '(?i)quant\s*mf',           36),
('NAVI MF',           'AMC',    'MUTUAL_FUND','LUMP_SUM_MUTUAL_FUND','ONE_TIME','(?i)navi\s*mf',            36),

-- Brokers
('ZERODHA',           'BROKER', 'BROKER',     'BROKER_FUNDING',   'MARKET_LINKED','(?i)zerodha',           38),
('UPSTOX',            'BROKER', 'BROKER',     'BROKER_FUNDING',   'MARKET_LINKED','(?i)upstox',            38),
('GROWW',             'BROKER', 'BROKER',     'BROKER_FUNDING',   'MARKET_LINKED','(?i)groww',             38),
('ANGEL ONE',         'BROKER', 'BROKER',     'BROKER_FUNDING',   'MARKET_LINKED','(?i)angel one|angel broking', 38),
('5PAISA',            'BROKER', 'BROKER',     'BROKER_FUNDING',   'MARKET_LINKED','(?i)5paisa',            38),
('DHAN',              'BROKER', 'BROKER',     'BROKER_FUNDING',   'MARKET_LINKED','(?i)\bdhan\b',          38),
('MOTILAL OSWAL',     'BROKER', 'BROKER',     'BROKER_FUNDING',   'MARKET_LINKED','(?i)motilal(?!.*mf)',   38),
('PAYTM MONEY',       'BROKER', 'BROKER',     'BROKER_FUNDING',   'MARKET_LINKED','(?i)paytm money',       38),
('COIN ZERODHA',      'BROKER', 'BROKER',     'BROKER_FUNDING',   'MARKET_LINKED','(?i)\bcoin\b',          38),
('SMALLCASE',         'BROKER', 'BROKER',     'STOCK_PURCHASE',   'MARKET_LINKED','(?i)smallcase',         38),

-- Wealth Platforms
('KUVERA',            'WEALTH_PLATFORM','WEALTH_PLATFORM','WEALTH_CONTRIBUTION','GOAL_LINKED','(?i)kuvera', 40),
('INDMONEY',          'WEALTH_PLATFORM','WEALTH_PLATFORM','WEALTH_CONTRIBUTION','GOAL_LINKED','(?i)indmoney', 40),
('ETMONEY',           'WEALTH_PLATFORM','WEALTH_PLATFORM','WEALTH_CONTRIBUTION','GOAL_LINKED','(?i)etmoney', 40),
('FISDOM',            'WEALTH_PLATFORM','WEALTH_PLATFORM','WEALTH_CONTRIBUTION','GOAL_LINKED','(?i)fisdom',  40),
('SCRIPBOX',          'WEALTH_PLATFORM','WEALTH_PLATFORM','WEALTH_CONTRIBUTION','GOAL_LINKED','(?i)scripbox', 40),

-- Retirement
('NPS TRUST',         'GOVT',   'RETIREMENT', 'RETIREMENT_INVESTMENT','GOAL_LINKED','(?i)\bnps\b',          42),
('PPF ACCOUNT',       'GOVT',   'RETIREMENT', 'RETIREMENT_INVESTMENT','GOAL_LINKED','(?i)\bppf\b',          42),
('NSC',               'GOVT',   'RETIREMENT', 'RETIREMENT_INVESTMENT','GOAL_LINKED','(?i)\bnsc\b',          42),
('SUKANYA SAMRIDDHI', 'GOVT',   'RETIREMENT', 'RETIREMENT_INVESTMENT','GOAL_LINKED','(?i)sukanya',          42),
('EPFO',              'GOVT',   'RETIREMENT', 'RETIREMENT_INVESTMENT','GOAL_LINKED','(?i)\bepfo\b',         42),

-- Digital Gold
('JAR',               'PLATFORM','DIGITAL_GOLD','DIGITAL_GOLD',   'ONE_TIME',   '(?i)\bjar\b',             44),
('SAFEGOLD',          'PLATFORM','DIGITAL_GOLD','DIGITAL_GOLD',   'ONE_TIME',   '(?i)safegold',            44),
('AUGMONT',           'PLATFORM','DIGITAL_GOLD','DIGITAL_GOLD',   'ONE_TIME',   '(?i)augmont',             44)

ON CONFLICT (normalized_entity) DO NOTHING;

-- ============================================================
-- INSURANCE ENTITIES MASTER
-- ============================================================

INSERT INTO spendsense.insurance_entities_master (normalized_entity, insurer_type, insurance_subtype, match_pattern, priority_hint) VALUES

-- Life Insurance
('LIC',                   'LIFE',    'LIFE_PREMIUM',    '(?i)\blic\b|life insurance corporation', 52),
('HDFC LIFE',             'LIFE',    'LIFE_PREMIUM',    '(?i)hdfc life',                          52),
('ICICI PRU LIFE',        'LIFE',    'LIFE_PREMIUM',    '(?i)icici pru life|icici prudential life', 52),
('SBI LIFE',              'LIFE',    'LIFE_PREMIUM',    '(?i)sbi life',                           52),
('MAX LIFE',              'LIFE',    'LIFE_PREMIUM',    '(?i)max life',                           52),
('TATA AIA',              'LIFE',    'LIFE_PREMIUM',    '(?i)tata aia',                           52),
('BAJAJ ALLIANZ LIFE',    'LIFE',    'LIFE_PREMIUM',    '(?i)bajaj allianz life',                 52),
('ADITYA BIRLA SUN LIFE', 'LIFE',    'LIFE_PREMIUM',    '(?i)aditya birla sun life',              52),
('PNB METLIFE',           'LIFE',    'LIFE_PREMIUM',    '(?i)pnb metlife',                        52),
('KOTAK LIFE',            'LIFE',    'LIFE_PREMIUM',    '(?i)kotak life',                         52),
('CANARA HSBC LIFE',      'LIFE',    'LIFE_PREMIUM',    '(?i)canara hsbc life',                   52),
('INDIAFIRST LIFE',       'LIFE',    'LIFE_PREMIUM',    '(?i)indiafirst life',                    52),
('EDELWEISS TOKIO LIFE',  'LIFE',    'LIFE_PREMIUM',    '(?i)edelweiss tokio life',               52),
('PRAMERICA LIFE',        'LIFE',    'LIFE_PREMIUM',    '(?i)pramerica life',                     52),
('SHRIRAM LIFE',          'LIFE',    'LIFE_PREMIUM',    '(?i)shriram life',                       52),

-- Health Insurance
('STAR HEALTH',           'HEALTH',  'HEALTH_PREMIUM',  '(?i)star health',                        52),
('NIVA BUPA',             'HEALTH',  'HEALTH_PREMIUM',  '(?i)niva bupa',                          52),
('CARE HEALTH',           'HEALTH',  'HEALTH_PREMIUM',  '(?i)care health',                        52),
('ADITYA BIRLA HEALTH',   'HEALTH',  'HEALTH_PREMIUM',  '(?i)aditya birla health',                52),
('MANIPALCIGNA',          'HEALTH',  'HEALTH_PREMIUM',  '(?i)manipalcigna',                       52),
('GALAXY HEALTH',         'HEALTH',  'HEALTH_PREMIUM',  '(?i)galaxy health',                      52),

-- General / Motor Insurance
('HDFC ERGO',             'GENERAL', 'GENERAL_PREMIUM', '(?i)hdfc ergo',                          52),
('ICICI LOMBARD',         'GENERAL', 'GENERAL_PREMIUM', '(?i)icici lombard',                      52),
('IFFCO TOKIO',           'GENERAL', 'GENERAL_PREMIUM', '(?i)iffco[\s-]?tokio',                   52),
('BAJAJ ALLIANZ GIC',     'GENERAL', 'GENERAL_PREMIUM', '(?i)bajaj allianz gic|bajaj allianz general', 52),
('NEW INDIA ASSURANCE',   'GENERAL', 'GENERAL_PREMIUM', '(?i)new india assurance',                52),
('NATIONAL INSURANCE',    'GENERAL', 'GENERAL_PREMIUM', '(?i)national insurance',                 52),
('ORIENTAL INSURANCE',    'GENERAL', 'GENERAL_PREMIUM', '(?i)oriental insurance',                 52),
('UNITED INDIA',          'GENERAL', 'GENERAL_PREMIUM', '(?i)united india insurance',             52),
('RELIANCE GENERAL',      'GENERAL', 'GENERAL_PREMIUM', '(?i)reliance general',                   52),
('SBI GENERAL',           'GENERAL', 'GENERAL_PREMIUM', '(?i)sbi general',                        52),
('TATA AIG',              'GENERAL', 'GENERAL_PREMIUM', '(?i)tata aig',                           52),
('GO DIGIT',              'GENERAL', 'GENERAL_PREMIUM', '(?i)go digit|digit insurance',           52),
('ACKO',                  'GENERAL', 'GENERAL_PREMIUM', '(?i)\backo\b',                           52),
('ROYAL SUNDARAM',        'GENERAL', 'GENERAL_PREMIUM', '(?i)royal sundaram',                     52),
('CHOLAMANDALAM MS',      'GENERAL', 'GENERAL_PREMIUM', '(?i)cholamandalam ms',                   52),
('ZURICH KOTAK',          'GENERAL', 'GENERAL_PREMIUM', '(?i)zurich kotak|kotak general insurance', 52),
('LIBERTY GENERAL',       'GENERAL', 'GENERAL_PREMIUM', '(?i)liberty general',                    52),

-- Aggregators / Platforms
('POLICYBAZAAR',          'PLATFORM','INSURANCE_PREMIUM','(?i)policybazaar|pb partner',           56),
('INSURANCEDEKHO',        'PLATFORM','INSURANCE_PREMIUM','(?i)insurancedekho',                    56),
('TURTLEMINT',            'PLATFORM','INSURANCE_PREMIUM','(?i)turtlemint',                        56)

ON CONFLICT (normalized_entity) DO NOTHING;
