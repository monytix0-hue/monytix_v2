-- ============================================================
-- 002_pattern_registry.sql
-- Seed all structural patterns for Indian banks
-- ============================================================

INSERT INTO spendsense.txn_parse_pattern_registry
(channel_type, pattern_family, detection_regex, delimiter, direction_rule,
 rrn_position, name_position, merchant_position, vpa_position, bank_position,
 ifsc_position, account_position, mcc_position, ref_position, purpose_position,
 parse_confidence, priority, example_format, notes)
VALUES

-- ============================================================
-- UPI PATTERNS
-- ============================================================
('UPI','UPI_TRANSFER_DR_SLASH','^TO TRANSFER-UPI/DR/','/',  'OUT',
  3,4,NULL,6,5,NULL,NULL,NULL,NULL,7,
  0.95,1,'TO TRANSFER-UPI/DR/<RRN>/<n>/<BANK>/<VPA>/<PURPOSE>','SBI outgoing UPI'),

('UPI','UPI_TRANSFER_CR_SLASH','^BY TRANSFER-UPI/','/',  'IN',
  3,4,NULL,6,5,NULL,NULL,NULL,NULL,NULL,
  0.95,2,'BY TRANSFER-UPI/<RRN>/<n>/<BANK>/<VPA>','SBI incoming UPI'),

('UPI','UPI_SLASH_CR','^UPI/CR/','/',  'IN',
  3,4,NULL,6,5,NULL,NULL,NULL,NULL,NULL,
  0.95,3,'UPI/CR/<RRN>/<n>/<BANK>/<VPA>','Canara/SBI incoming'),

('UPI','UPI_SLASH_DR','^UPI/DR/','/',  'OUT',
  3,4,NULL,6,5,NULL,NULL,NULL,NULL,NULL,
  0.95,4,'UPI/DR/<RRN>/<n>/<BANK>/<VPA>','Canara/SBI outgoing'),

('UPI','UPI_SLASH_REV','^UPI/REV/','/',  'REV',
  3,4,NULL,6,5,NULL,NULL,NULL,NULL,NULL,
  0.95,5,'UPI/REV/<RRN>/<n>/<BANK>/<VPA>','Reversal'),

('UPI','UPI_OUT_SLASH','^UPIOUT/','/',  'OUT',
  2,NULL,NULL,3,NULL,NULL,NULL,5,NULL,NULL,
  0.95,6,'UPIOUT/<RRN>/<VPA>/UPI/<MCC>','Federal Bank UPI'),

('UPI','UPI_IN_SLASH','^UPI IN/','/',  'IN',
  2,NULL,NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,
  0.90,7,'UPI IN/<RRN>/<VPA>','Incoming slash'),

('UPI','UPI_REV_DASH','^REV-UPI-','-',  'REV',
  4,2,NULL,3,4,NULL,NULL,NULL,NULL,NULL,
  0.90,8,'REV-UPI-<n>-<VPA>-<RRN>','Dash reversal'),

('UPI','UPI_DASH','^UPI-','-',  'LEDGER',
  5,2,2,3,4,4,NULL,NULL,NULL,6,
  0.92,9,'UPI-<n>-<VPA>-<BANK/IFSC>-<RRN>-<PURPOSE>','HDFC/ICICI/Axis/Kotak'),

-- ============================================================
-- IMPS PATTERNS
-- ============================================================
('IMPS','IMPS_MMT_SLASH','^MMT/IMPS/','/',  'LEDGER',
  3,4,NULL,NULL,5,5,NULL,NULL,NULL,NULL,
  0.92,20,'MMT/IMPS/<RRN>/<n>/<IFSC>','ICICI style'),

('IMPS','IMPS_TRANSFER_SLASH','^BY TRANSFER-IMPS/','/',  'LEDGER',
  2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
  0.90,21,'BY TRANSFER-IMPS/<RRN>/...','Transfer IMPS'),

('IMPS','IMPS_RECD_SLASH','^RECD:IMPS/','/',  'IN',
  2,NULL,NULL,NULL,4,NULL,5,NULL,NULL,NULL,
  0.90,22,'RECD:IMPS/<RRN>/<STATUS>/<BANK>/<ACCOUNT>','Kotak received'),

('IMPS','IMPS_INET_CR_SLASH','^INET-IMPS-CR/','/',  'IN',
  NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
  0.88,23,'INET-IMPS-CR/.../<RRN>','Internet IMPS credit'),

('IMPS','IMPS_MB_DR_SLASH','^MB-IMPS-DR/','/',  'OUT',
  NULL,2,NULL,NULL,3,NULL,4,NULL,NULL,NULL,
  0.88,24,'MB-IMPS-DR/<n>/<BANK>/<ACCOUNT>','Canara mobile IMPS'),

('IMPS','IMPS_DASH','^IMPS-','-',  'LEDGER',
  2,3,NULL,NULL,4,NULL,5,NULL,NULL,NULL,
  0.90,25,'IMPS-<RRN>-<n>-<BANK>-<ACCOUNT>','HDFC IMPS'),

-- ============================================================
-- NEFT PATTERNS
-- ============================================================
('NEFT','NEFT_DASH','^NEFT-','-',  'LEDGER',
  NULL,3,NULL,NULL,4,4,NULL,NULL,2,NULL,
  0.90,30,'NEFT-<UTR>-<n>-<IFSC>','Dash NEFT'),

('NEFT','NEFT_TRANSFER_STAR','^BY TRANSFER-NEFT','*',  'IN',
  NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,3,NULL,
  0.88,31,'BY TRANSFER-NEFT*<IFSC>*<UTR>','Star NEFT'),

-- ============================================================
-- ACH / NACH
-- ============================================================
('ACH','ACH_SLASH','^ACH/','/','LEDGER',
  NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,NULL,
  0.90,40,'ACH/<ENTITY>/<REF>','Slash ACH'),

('ACH','ACH_DASH','^ACH D-','-','OUT',
  NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,3,NULL,
  0.90,41,'ACH D-<ENTITY>-<REF>','Dash ACH debit'),

('ACH','ACH_DEBIT_DASH','^DEBIT-ACH','-','OUT',
  NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,3,NULL,
  0.88,42,'DEBIT-ACH-<ENTITY>-<REF>','Debit ACH'),

('NACH','NACH_SPACE','^NACH ',' ','OUT',
  NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,3,NULL,
  0.90,50,'NACH <ENTITY> <REF1> <REF2>','Space NACH'),

('NACH','NACH_DASH','^NACH-','-','OUT',
  NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,3,NULL,
  0.88,51,'NACH-<ENTITY>-<REF>','Dash NACH'),

-- ============================================================
-- ATM / POS / BIL
-- ============================================================
('ATM','ATM_WDL_DASH','^ATM WDL-','-','OUT',
  NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
  0.90,60,'ATM WDL-ATM CASH <TXN_ID> <LOCATION>--','ATM withdrawal'),

('ATM','ATM_NWD_DASH','^NWD-','-','OUT',
  NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,
  0.88,61,'NWD-<ACCOUNT/CARD>-...','ATM card withdrawal'),

('POS','POS_SPACE','^POS ',' ','OUT',
  NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,
  0.86,70,'POS <CARD_MASK> ...','POS card'),

('BIL','BIL_SLASH','^BIL/','/','LEDGER',
  NULL,NULL,3,NULL,NULL,NULL,NULL,NULL,4,NULL,
  0.88,80,'BIL/.../<BILLER>/<REF>','Bill payment'),

('CARD_BILLPAY','CARD_BILLPAY_DASH','^IB BILLPAY DR-','-','OUT',
  NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,3,NULL,
  0.88,81,'IB BILLPAY DR-<BILLER_CODE>-<CARD_REF>','HDFC card bill pay')

ON CONFLICT (pattern_family, detection_regex) DO NOTHING;
