-- ============================================================
-- 003_rulebook_seed.sql
-- All rules seeded into spendsense.rulebook
-- Priority bands:
--   INC  →  8–90   (INFLOW / CREDIT)
--   EMI  → 10–20   (OUTFLOW / DEBIT)
--   CC   → 30–40
--   INV  → 50–70
--   INS  → 80–95
--   FEE  → 100–110
--   TRF  → 120–130
--   CRED → 35–45   (special — must run before generic CC at 30)
-- ============================================================

SET search_path = spendsense, public;

-- ============================================================
-- GROUP: INC — Income (INFLOW / CREDIT)
-- ============================================================
INSERT INTO spendsense.rulebook
(rule_code,rule_group,priority_rank,flow_type,channel_filter,
 match_field,match_op,match_value,
 exclude_field,exclude_op,exclude_value,
 financial_class,instrument_type,counterparty_type,confidence_score,notes)
VALUES

-- User-known employer (highest priority — personalised)
('INC_003','INC',8,'INFLOW',NULL,
 'user_employer_match','EQUALS','TRUE',
 NULL,NULL,NULL,
 'INCOME','SALARY','EMPLOYER',0.99,
 'Matched against user_employers table — caller sets this flag'),

-- Salary keywords
('INC_001','INC',10,'INFLOW',NULL,
 'normalized_description','IREGEX','\b(sal|salary|salcr|pay|payroll|income|wage|stipend)\b',
 NULL,NULL,NULL,
 'INCOME','SALARY','EMPLOYER',0.98,'Explicit salary words'),

-- Company entity in description
('INC_002','INC',12,'INFLOW',NULL,
 'normalized_description','IREGEX','(pvt ltd|private limited|\bltd\b|llp|technologies|systems|solutions|consulting|services)',
 NULL,NULL,NULL,
 'INCOME','SALARY','EMPLOYER',0.90,'Company-type name → likely salary'),

-- Refund / reversal — credit side (must beat salary detection)
('INC_050','INC',15,'INFLOW',NULL,
 'normalized_description','IREGEX','(refund|reversal|chargeback|cashback|cash back|\brev\b)',
 NULL,NULL,NULL,
 'REFUND','REFUND_CREDIT','MERCHANT',0.95,'Refund takes priority over transfer-in'),

-- Business / freelance income
('INC_010','INC',20,'INFLOW',NULL,
 'normalized_description','IREGEX','(consult|invoice|professional fee|retainer|contract|freelance)',
 NULL,NULL,NULL,
 'INCOME','BUSINESS_INCOME','CLIENT',0.92,'Gig / freelance income'),

-- Platform payouts (Swiggy, Zomato, Uber driver, Amazon seller)
('INC_020','INC',22,'INFLOW',NULL,
 'normalized_description','IREGEX','(seller.*payout|payout|adsense|uber.*payout|ola.*payout|swiggy.*payout|zomato.*payout|youtube)',
 NULL,NULL,NULL,
 'INCOME','PLATFORM_PAYOUT','PLATFORM',0.92,'Gig-economy platform payout'),

-- MF redemption / dividend
('INC_030','INC',30,'INFLOW',NULL,
 'normalized_description','IREGEX','(dividend|mf redemption|mutual fund payout|int-div)',
 NULL,NULL,NULL,
 'INVESTMENT_INCOME','MF_REDEMPTION','AMC',0.94,'MF dividend or redemption'),

-- Broker / stock proceeds
('INC_031','INC',30,'INFLOW',NULL,
 'normalized_description','IREGEX','(zerodha|groww|upstox|angel one|angel broking|5paisa|dhan)',
 NULL,NULL,NULL,
 'INVESTMENT_INCOME','STOCK_PROCEEDS','BROKER',0.94,'Broker payout'),

-- Government benefits (DBT, PM-KISAN)
('INC_060','INC',35,'INFLOW',NULL,
 'normalized_description','IREGEX','(subsidy|pm kisan|dbt|govt benefit|government benefit)',
 NULL,NULL,NULL,
 'INCOME','GOVERNMENT_BENEFIT','GOVT',0.92,'DBT / govt scheme'),

-- Bank interest
('INC_040','INC',40,'INFLOW',NULL,
 'normalized_description','IREGEX','(interest credit|savings interest|fd interest|rd interest|sbint|int\.pd)',
 NULL,NULL,NULL,
 'INCOME','INTEREST','BANK',0.95,'Bank/FD/RD interest'),

-- FD premature closure proceeds
('INC_041','INC',42,'INFLOW',NULL,
 'normalized_description','IREGEX','(fd premat|fd proceeds|fd maturity|fd closure)',
 NULL,NULL,NULL,
 'INVESTMENT_INCOME','FD_MATURITY','BANK',0.94,'FD closure'),

-- Sweep transfer from FD
('INC_042','INC',44,'INFLOW',NULL,
 'normalized_description','IREGEX','(sweep trf|sweep transfer)',
 NULL,NULL,NULL,
 'TRANSFER_IN','SELF_TRANSFER','BANK',0.92,'Auto-sweep from FD'),

-- Cash deposit
('INC_070','INC',50,'INFLOW','ATM',
 'channel_type','EQUALS','ATM',
 NULL,NULL,NULL,
 'CASH_DEPOSIT','CASH','BANK',0.90,'ATM credit = cash deposit'),

-- Fallback: generic INFLOW transfer-in (lowest priority)
('INC_999','INC',90,'INFLOW',NULL,
 'normalized_description','IREGEX','.*',
 NULL,NULL,NULL,
 'TRANSFER_IN','UPI_TRANSFER','INDIVIDUAL',0.60,'Fallback: unclassified inflow')

ON CONFLICT (rule_code) DO NOTHING;

-- ============================================================
-- GROUP: EMI — Loan / EMI (OUTFLOW / DEBIT)
-- ============================================================
INSERT INTO spendsense.rulebook
(rule_code,rule_group,priority_rank,flow_type,channel_filter,
 match_field,match_op,match_value,
 exclude_field,exclude_op,exclude_value,
 financial_class,instrument_type,counterparty_type,obligation_flag,confidence_score,notes)
VALUES

-- Explicit EMI keyword (strongest signal)
('EMI_001','EMI',10,'OUTFLOW',NULL,
 'normalized_description','IREGEX','\bemi\b',
 'normalized_description','IREGEX','(sip|mutual fund|insurance|premium)',
 'LOAN_EMI','EMI','NBFC',TRUE,0.98,'Explicit EMI keyword — guard against SIP mislabel'),

-- Loan keyword
('EMI_002','EMI',12,'OUTFLOW',NULL,
 'normalized_description','IREGEX','(loan repayment|loan payment|loan installment)',
 'normalized_description','IREGEX','(sip|mutual fund|insurance)',
 'LOAN_EMI','EMI','NBFC',TRUE,0.96,'Loan repayment keyword'),

-- Card EMI (separate from full card bill)
('EMI_007','EMI',14,'OUTFLOW',NULL,
 'normalized_description','IREGEX','card\s*emi|emi.*card',
 NULL,NULL,NULL,
 'LOAN_EMI','CARD_EMI','BANK',TRUE,0.96,'Card EMI conversion'),

-- Known NBFC lenders (via master table JOIN — flag passed by engine)
('EMI_003','EMI',15,'OUTFLOW',NULL,
 'lender_master_match','EQUALS','TRUE',
 'normalized_description','IREGEX','(sip|mutual fund|\bmf\b|insurance|premium)',
 'LOAN_EMI','EMI','NBFC',TRUE,0.96,'Matched loan_lenders_master — guardrail excludes MF/insurance'),

-- Bank loan types
('EMI_004','EMI',16,'OUTFLOW',NULL,
 'normalized_description','IREGEX','(home loan|personal loan|auto loan|car loan|housing loan)',
 NULL,NULL,NULL,
 'LOAN_EMI','EMI','BANK',TRUE,0.95,'Loan type keywords'),

-- BNPL
('EMI_008','EMI',17,'OUTFLOW',NULL,
 'normalized_description','IREGEX','(zestmoney|lazypay|\bsimpl\b|\baxio\b|\bslice\b)',
 NULL,NULL,NULL,
 'LOAN_EMI','BNPL_EMI','NBFC',TRUE,0.95,'BNPL repayment'),

-- NACH entity match
('EMI_005','EMI',18,'OUTFLOW','NACH',
 'ach_nach_entity','IREGEX','(finance|capital|credit|fincorp)',
 'normalized_description','IREGEX','(sip|mutual fund|\bmf\b|insurance)',
 'LOAN_EMI','EMI','NBFC',TRUE,0.94,'NACH entity contains finance/credit — guard MF/insurance'),

-- General \bloan\b keyword (broad, lower priority)
('EMI_002B','EMI',19,'OUTFLOW',NULL,
 'normalized_description','IREGEX','\bloan\b',
 'normalized_description','IREGEX','(sip|mutual fund|\bmf\b|insurance)',
 'LOAN_EMI','EMI','NBFC',TRUE,0.88,'Generic loan keyword')

ON CONFLICT (rule_code) DO NOTHING;

-- ============================================================
-- GROUP: CRED — CRED special module (must run before CC group)
-- ============================================================
INSERT INTO spendsense.rulebook
(rule_code,rule_group,priority_rank,flow_type,
 match_field,match_op,match_value,
 financial_class,instrument_type,counterparty_type,obligation_flag,confidence_score,notes)
VALUES

('CRED_001','CRED',35,'OUTFLOW',
 'normalized_description','IREGEX','cred\.insurance',
 'INSURANCE','INSURANCE_PREMIUM','INSURER',TRUE,0.98,'CRED insurance — beats generic CRED'),

('CRED_002','CRED',36,'OUTFLOW',
 'normalized_description','IREGEX','cred\.club|cred\s*cash',
 'LOAN_EMI','EMI','NBFC',TRUE,0.98,'CRED Club / Cash loan repayment'),

('CRED_003','CRED',37,'OUTFLOW',
 'normalized_description','IREGEX','credpay\.',
 'MERCHANT_PAYMENT','MERCHANT_UPI','MERCHANT',FALSE,0.98,'CREDPAY.merchant — extract merchant after dot'),

('CRED_004','CRED',45,'OUTFLOW',
 'normalized_description','IREGEX','\bcred\b',
 'CREDIT_CARD_PAYMENT','CARD_BILL','FINTECH',TRUE,0.70,'Generic CRED — CC payment fallback')

ON CONFLICT (rule_code) DO NOTHING;

-- ============================================================
-- GROUP: CC — Credit Card Payment (OUTFLOW / DEBIT)
-- ============================================================
INSERT INTO spendsense.rulebook
(rule_code,rule_group,priority_rank,flow_type,
 match_field,match_op,match_value,
 exclude_field,exclude_op,exclude_value,
 financial_class,instrument_type,counterparty_type,obligation_flag,confidence_score,notes)
VALUES

('CC_001','CC',50,'OUTFLOW',
 'normalized_description','IREGEX','(credit card|cc payment|card payment|cc bill)',
 'normalized_description','IREGEX','\bloan\b',
 'CREDIT_CARD_PAYMENT','CARD_BILL','BANK',TRUE,0.98,'Explicit CC keywords — loan guard'),

-- Card issuer master match (via engine JOIN flag)
('CC_002','CC',52,'OUTFLOW',
 'cc_issuer_match','EQUALS','TRUE',
 'normalized_description','IREGEX','\bloan\b',
 'CREDIT_CARD_PAYMENT','CARD_BILL','BANK',TRUE,0.96,'Matched credit_card_issuers_master'),

-- Masked card number
('CC_003','CC',54,'OUTFLOW',
 'normalized_description','IREGEX','xxxx\s?\d{4}',
 NULL,NULL,NULL,
 'CREDIT_CARD_PAYMENT','CARD_BILL','BANK',TRUE,0.95,'Masked card number XXXX1234'),

-- Card issuer short patterns
('CC_005','CC',56,'OUTFLOW',
 'normalized_description','IREGEX','(hdfc\s*cc|icici\s*cc|sbi credit payment|axis credit)',
 'normalized_description','IREGEX','\bloan\b',
 'CREDIT_CARD_PAYMENT','CARD_BILL','BANK',TRUE,0.93,'Issuer + cc/credit shorthand'),

-- ACH autopay for card
('CC_006','CC',57,'OUTFLOW',
 'normalized_description','IREGEX','auto debit.*card|ach.*card',
 NULL,NULL,NULL,
 'CREDIT_CARD_PAYMENT','CARD_BILL','BANK',TRUE,0.92,'ACH/auto-debit card payment')

ON CONFLICT (rule_code) DO NOTHING;

-- ============================================================
-- GROUP: INV — Investment (OUTFLOW / DEBIT)
-- ============================================================
INSERT INTO spendsense.rulebook
(rule_code,rule_group,priority_rank,flow_type,
 match_field,match_op,match_value,
 exclude_field,exclude_op,exclude_value,
 financial_class,instrument_type,counterparty_type,investment_mode,confidence_score,notes)
VALUES

-- Explicit SIP keyword
('INV_001','INV',60,'OUTFLOW',
 'normalized_description','IREGEX','\b(sip|systematic investment)\b',
 'normalized_description','IREGEX','(loan|emi|insurance|premium)',
 'INVESTMENT','SIP','AMC','RECURRING',0.98,'SIP keyword — EMI/insurance guard'),

-- MF / folio / scheme keyword
('INV_002','INV',62,'OUTFLOW',
 'normalized_description','IREGEX','(mutual fund|\bmf\b|folio|scheme|fund purchase)',
 'normalized_description','IREGEX','(loan|emi|insurance|premium)',
 'INVESTMENT','LUMP_SUM_MUTUAL_FUND','AMC','ONE_TIME',0.95,'MF keywords'),

-- Investment entity master match (AMC/RTA/broker/wealth/retirement/gold)
('INV_005','INV',65,'OUTFLOW',
 'investment_entity_match','EQUALS','TRUE',
 'normalized_description','IREGEX','(loan|emi|insurance|premium|repayment)',
 'INVESTMENT',NULL,NULL,NULL,0.96,'Matched investment_entities_master — outputs carried from master'),

-- Direct investing (Coin, Smallcase)
('INV_007','INV',68,'OUTFLOW',
 'normalized_description','IREGEX','(smallcase|stock purchase|equity purchase)',
 NULL,NULL,NULL,
 'INVESTMENT','STOCK_PURCHASE','BROKER','MARKET_LINKED',0.94,'Direct equity investing'),

-- NPS/PPF/retirement keywords
('INV_009','INV',70,'OUTFLOW',
 'normalized_description','IREGEX','\b(nps|ppf|pension|retirement fund)\b',
 NULL,NULL,NULL,
 'INVESTMENT','RETIREMENT_INVESTMENT','RETIREMENT_FUND','GOAL_LINKED',0.95,'Retirement contribution'),

-- Digital gold keywords
('INV_010','INV',72,'OUTFLOW',
 'normalized_description','IREGEX','(digital gold|gold savings|gold purchase)',
 NULL,NULL,NULL,
 'INVESTMENT','DIGITAL_GOLD','PLATFORM','ONE_TIME',0.90,'Digital gold purchase')

ON CONFLICT (rule_code) DO NOTHING;

-- ============================================================
-- GROUP: INS — Insurance (OUTFLOW / DEBIT)
-- ============================================================
INSERT INTO spendsense.rulebook
(rule_code,rule_group,priority_rank,flow_type,
 match_field,match_op,match_value,
 exclude_field,exclude_op,exclude_value,
 financial_class,instrument_type,counterparty_type,obligation_flag,confidence_score,notes)
VALUES

-- Explicit insurance/premium keyword
('INS_001','INS',80,'OUTFLOW',
 'normalized_description','IREGEX','\b(insurance|premium|policy premium|ins prem)\b',
 'normalized_description','IREGEX','(sip|\bmf\b|mutual fund|loan|emi)',
 'INSURANCE','INSURANCE_PREMIUM','INSURER',TRUE,0.98,'Explicit insurance keyword'),

-- Insurance entity master match
('INS_002','INS',82,'OUTFLOW',
 'insurer_master_match','EQUALS','TRUE',
 'normalized_description','IREGEX','(sip|\bmf\b|mutual fund)',
 'INSURANCE',NULL,'INSURER',TRUE,0.97,'Matched insurance_entities_master'),

-- ULIP (hybrid — keep under insurance)
('INS_006','INS',83,'OUTFLOW',
 'normalized_description','IREGEX','(ulip|unit linked)',
 NULL,NULL,NULL,
 'INSURANCE','ULIP_PREMIUM','INSURER',TRUE,0.95,'ULIP — keep under insurance, not investment'),

-- Policy/renewal/term keywords
('INS_005','INS',84,'OUTFLOW',
 'normalized_description','IREGEX','(policy renewal|sum assured|term plan|mediclaim|health plan)',
 NULL,NULL,NULL,
 'INSURANCE','INSURANCE_PREMIUM','INSURER',TRUE,0.94,'Policy/renewal/mediclaim keywords'),

-- Bancassurance (bank-collected premium — description shows bank name)
('INS_008','INS',86,'OUTFLOW',
 'normalized_description','IREGEX','(insurance.*hdfc|insurance.*icici|insurance.*sbi|premium.*bank)',
 NULL,NULL,NULL,
 'INSURANCE','INSURANCE_PREMIUM','BANK',TRUE,0.89,'Bancassurance — bank collects premium')

ON CONFLICT (rule_code) DO NOTHING;

-- ============================================================
-- GROUP: FEE — Bank Charges (OUTFLOW)
-- ============================================================
INSERT INTO spendsense.rulebook
(rule_code,rule_group,priority_rank,flow_type,
 match_field,match_op,match_value,
 financial_class,instrument_type,counterparty_type,confidence_score,notes)
VALUES

('FEE_001','FEE',100,'OUTFLOW',
 'normalized_description','IREGEX','(bank charge|service charge|account maintenance|minimum balance|non maintenance)',
 'BANK_CHARGE','BANK_FEE','BANK',0.94,'Bank charges'),

('FEE_002','FEE',101,'OUTFLOW',
 'normalized_description','IREGEX','(atm charge|atm fee|atm usage)',
 'BANK_CHARGE','ATM_FEE','BANK',0.94,'ATM charges'),

('FEE_003','FEE',102,'OUTFLOW',
 'normalized_description','IREGEX','(imps charge|neft charge|rtgs charge|upi charge)',
 'BANK_CHARGE','TRANSFER_FEE','BANK',0.94,'Transfer charges'),

('FEE_004','FEE',103,'OUTFLOW',
 'normalized_description','IREGEX','(annual fee|card fee|debit card fee)',
 'BANK_CHARGE','CARD_FEE','BANK',0.94,'Card annual/issuance fee'),

('FEE_005','FEE',104,'OUTFLOW',
 'normalized_description','IREGEX','(gst.*charge|gst debit|tax.*charge)',
 'BANK_CHARGE','GST_ON_CHARGES','BANK',0.92,'GST on bank charges'),

('FEE_006','FEE',105,'OUTFLOW',
 'normalized_description','IREGEX','(dp charge|dpchg)',
 'BANK_CHARGE','DP_CHARGES','BANK',0.94,'Demat / DP charges')

ON CONFLICT (rule_code) DO NOTHING;

-- ============================================================
-- GROUP: CASH — ATM Withdrawal
-- ============================================================
INSERT INTO spendsense.rulebook
(rule_code,rule_group,priority_rank,flow_type,channel_filter,
 match_field,match_op,match_value,
 financial_class,instrument_type,counterparty_type,confidence_score,notes)
VALUES

('CASH_001','CASH',95,'OUTFLOW','ATM',
 'channel_type','EQUALS','ATM',
 'CASH_WITHDRAWAL','ATM_CASH','BANK',0.99,'ATM channel debit = cash withdrawal')

ON CONFLICT (rule_code) DO NOTHING;

-- ============================================================
-- GROUP: TRF — Transfers (OUTFLOW / INFLOW fallbacks)
-- ============================================================
INSERT INTO spendsense.rulebook
(rule_code,rule_group,priority_rank,flow_type,
 match_field,match_op,match_value,
 financial_class,instrument_type,counterparty_type,confidence_score,notes)
VALUES

-- Explicit self transfer
('TRF_001','TRF',120,'OUTFLOW',
 'normalized_description','IREGEX','(self transfer|own account|transfer to self)',
 'TRANSFER_OUT','SELF_TRANSFER','SELF',0.98,'Explicit self-transfer'),

-- UPI P2P (PERSON entity from UPI classifier)
('TRF_002','TRF',122,'OUTFLOW',
 'upi_entity_type','EQUALS','PERSON',
 'TRANSFER_OUT','P2P_TRANSFER','INDIVIDUAL',0.90,'UPI classifier = PERSON'),

-- Self account (from UPI classifier)
('TRF_003','TRF',123,'OUTFLOW',
 'upi_entity_type','EQUALS','SELF_ACCOUNT',
 'TRANSFER_OUT','SELF_TRANSFER','SELF',0.95,'UPI classifier = SELF_ACCOUNT'),

-- Fallback: unclassified outflow
('TRF_999','TRF',130,'OUTFLOW',
 'normalized_description','IREGEX','.*',
 'TRANSFER_OUT','OUTFLOW_UNCLASSIFIED','UNKNOWN',0.40,'Fallback: unclassified outflow')

ON CONFLICT (rule_code) DO NOTHING;
