-- ============================================================
-- 004_diagnostic_views.sql
-- Operational views for monitoring rulebook quality
-- ============================================================

SET search_path = spendsense, public;

-- ──────────────────────────────────────────────────────────────
-- Overall classification distribution
-- ──────────────────────────────────────────────────────────────
CREATE OR REPLACE VIEW spendsense.vw_rulebook_distribution AS
SELECT
    financial_class,
    rule_group,
    classification_source,
    COUNT(*)                                        AS txn_count,
    ROUND(SUM(amount), 2)                           AS total_amount,
    ROUND(AVG(confidence_score), 3)                 AS avg_confidence,
    ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 2) AS pct_share
FROM spendsense.txn_rulebook_output
GROUP BY financial_class, rule_group, classification_source
ORDER BY txn_count DESC;

-- ──────────────────────────────────────────────────────────────
-- Rule hit frequency — which rules fire most
-- ──────────────────────────────────────────────────────────────
CREATE OR REPLACE VIEW spendsense.vw_rule_hit_frequency AS
SELECT
    o.rule_code,
    r.rule_group,
    r.priority_rank,
    COUNT(*)                                        AS hit_count,
    ROUND(AVG(o.confidence_score), 3)               AS avg_confidence,
    ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 2) AS pct_of_all
FROM spendsense.txn_rulebook_output o
LEFT JOIN spendsense.rulebook r USING (rule_code)
GROUP BY o.rule_code, r.rule_group, r.priority_rank
ORDER BY hit_count DESC;

-- ──────────────────────────────────────────────────────────────
-- Fallback / unclassified transactions — these need new rules
-- ──────────────────────────────────────────────────────────────
CREATE OR REPLACE VIEW spendsense.vw_rulebook_fallbacks AS
SELECT
    o.txn_id,
    o.user_id,
    o.txn_date,
    o.amount,
    o.cr_dr,
    o.channel_type,
    o.upi_entity_type,
    p.normalized_description,
    p.counterparty_name,
    p.counterparty_vpa,
    p.ach_nach_entity
FROM spendsense.txn_rulebook_output o
JOIN spendsense.txn_parsed_UPI_updated p ON p.txn_id = o.txn_id
WHERE o.is_fallback = TRUE
ORDER BY o.txn_date DESC;

-- ──────────────────────────────────────────────────────────────
-- Low-confidence outputs (< 0.75) — candidates for review
-- ──────────────────────────────────────────────────────────────
CREATE OR REPLACE VIEW spendsense.vw_low_confidence_classifications AS
SELECT
    o.txn_id,
    o.user_id,
    o.txn_date,
    o.amount,
    o.financial_class,
    o.rule_code,
    o.confidence_score,
    p.normalized_description,
    p.counterparty_name,
    p.upi_entity_type
FROM spendsense.txn_rulebook_output o
JOIN spendsense.txn_parsed_UPI_updated p ON p.txn_id = o.txn_id
WHERE o.confidence_score < 0.75
  AND o.is_fallback = FALSE
ORDER BY o.confidence_score ASC, o.txn_date DESC;

-- ──────────────────────────────────────────────────────────────
-- Obligation summary per user (EMI + Insurance + CC)
-- ──────────────────────────────────────────────────────────────
CREATE OR REPLACE VIEW spendsense.vw_user_obligations AS
SELECT
    user_id,
    TO_CHAR(txn_date, 'YYYY-MM')            AS month_year,
    financial_class,
    instrument_type,
    COUNT(*)                                 AS txn_count,
    ROUND(SUM(amount), 2)                    AS total_committed
FROM spendsense.txn_rulebook_output
WHERE obligation_flag = TRUE
  AND cr_dr = 'D'
GROUP BY user_id, month_year, financial_class, instrument_type
ORDER BY user_id, month_year DESC, total_committed DESC;

-- ──────────────────────────────────────────────────────────────
-- Investment breakdown per user
-- ──────────────────────────────────────────────────────────────
CREATE OR REPLACE VIEW spendsense.vw_user_investments AS
SELECT
    user_id,
    TO_CHAR(txn_date, 'YYYY-MM')            AS month_year,
    instrument_type,
    counterparty_type,
    investment_mode,
    resolved_entity,
    COUNT(*)                                 AS txn_count,
    ROUND(SUM(amount), 2)                    AS total_invested
FROM spendsense.txn_rulebook_output
WHERE financial_class IN ('INVESTMENT', 'INVESTMENT_INCOME')
GROUP BY user_id, month_year, instrument_type, counterparty_type,
         investment_mode, resolved_entity
ORDER BY user_id, month_year DESC, total_invested DESC;

-- ──────────────────────────────────────────────────────────────
-- Unknown patterns needing new rules
-- Groups fallback txns by shape signature for easy rule authoring
-- ──────────────────────────────────────────────────────────────
CREATE OR REPLACE VIEW spendsense.vw_fallback_clusters AS
SELECT
    -- Strip digits/refs to expose structural shape
    REGEXP_REPLACE(
        REGEXP_REPLACE(p.normalized_description, '[0-9]{6,}', 'NUM', 'g'),
    '[A-Z0-9._%+-]+@[A-Z0-9.-]+', 'VPA', 'g')   AS shape_signature,
    o.upi_entity_type,
    o.channel_type,
    o.cr_dr,
    COUNT(*)                                       AS txn_count,
    ROUND(AVG(o.amount), 2)                        AS avg_amount,
    MIN(p.normalized_description)                  AS example_1,
    MAX(p.normalized_description)                  AS example_2
FROM spendsense.txn_rulebook_output o
JOIN spendsense.txn_parsed_UPI_updated p ON p.txn_id = o.txn_id
WHERE o.is_fallback = TRUE
GROUP BY shape_signature, o.upi_entity_type, o.channel_type, o.cr_dr
HAVING COUNT(*) >= 3
ORDER BY txn_count DESC;
