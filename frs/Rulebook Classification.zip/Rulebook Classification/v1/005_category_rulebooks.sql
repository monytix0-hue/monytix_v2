-- ============================================================
-- 005_category_rulebooks.sql
-- Merchant entity masters + keyword tables for all 24 categories
-- ============================================================

-- Universal merchant entity master (all categories in one table)
CREATE TABLE IF NOT EXISTS spendsense.merchant_entity_master (
    entity_id           BIGSERIAL PRIMARY KEY,
    normalized_entity   TEXT NOT NULL,
    category            TEXT NOT NULL,      -- FOOD_DELIVERY | GROCERIES | TRANSPORT | etc.
    subcategory         TEXT,
    match_pattern       TEXT NOT NULL,      -- IREGEX pattern
    priority_hint       INT NOT NULL DEFAULT 83,
    is_active           BOOLEAN NOT NULL DEFAULT TRUE,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_merchant_entity UNIQUE (normalized_entity, category)
);

CREATE INDEX IF NOT EXISTS ix_merchant_entity_category ON spendsense.merchant_entity_master(category);

-- Universal keyword table
CREATE TABLE IF NOT EXISTS spendsense.merchant_keyword (
    keyword_id          BIGSERIAL PRIMARY KEY,
    keyword             TEXT NOT NULL,
    category            TEXT NOT NULL,
    subcategory         TEXT,
    match_pattern       TEXT NOT NULL,
    priority_hint       INT NOT NULL DEFAULT 85,
    is_active           BOOLEAN NOT NULL DEFAULT TRUE,
    CONSTRAINT uq_merchant_keyword UNIQUE (keyword, category)
);

CREATE INDEX IF NOT EXISTS ix_merchant_keyword_category ON spendsense.merchant_keyword(category);

-- ============================================================
-- FOOD & DINING entities
-- ============================================================
INSERT INTO spendsense.merchant_entity_master (normalized_entity,category,subcategory,match_pattern) VALUES
('SWIGGY','FOOD_DINING','FOOD_DELIVERY','(?i)swiggy'),
('ZOMATO','FOOD_DINING','FOOD_DELIVERY','(?i)zomato'),
('DOMINOS','FOOD_DINING','FAST_FOOD','(?i)dominos'),
('PIZZA HUT','FOOD_DINING','FAST_FOOD','(?i)pizza hut'),
('MCDONALDS','FOOD_DINING','FAST_FOOD','(?i)mcdonald'),
('KFC','FOOD_DINING','FAST_FOOD','(?i)\\bkfc\\b'),
('BURGER KING','FOOD_DINING','FAST_FOOD','(?i)burger king'),
('SUBWAY','FOOD_DINING','FAST_FOOD','(?i)\\bsubway\\b'),
('STARBUCKS','FOOD_DINING','CAFE','(?i)starbucks'),
('CAFE COFFEE DAY','FOOD_DINING','CAFE','(?i)cafe coffee day|\\bccd\\b'),
('THIRD WAVE COFFEE','FOOD_DINING','CAFE','(?i)third wave'),
('BARBEQUE NATION','FOOD_DINING','RESTAURANT','(?i)barbeque nation'),
('HALDIRAMS','FOOD_DINING','RESTAURANT','(?i)haldiram'),
('MONGINIS','FOOD_DINING','BAKERY','(?i)monginis'),
('THEOBROMA','FOOD_DINING','BAKERY','(?i)theobroma')
ON CONFLICT (normalized_entity,category) DO NOTHING;

INSERT INTO spendsense.merchant_keyword (keyword,category,subcategory,match_pattern) VALUES
('restaurant','FOOD_DINING','RESTAURANT','(?i)restaurant'),
('restro','FOOD_DINING','RESTAURANT','(?i)restro'),
('mess','FOOD_DINING','RESTAURANT','(?i)\\bmess\\b'),
('canteen','FOOD_DINING','RESTAURANT','(?i)canteen'),
('fast food','FOOD_DINING','FAST_FOOD','(?i)fast food'),
('pizza','FOOD_DINING','FAST_FOOD','(?i)\\bpizza\\b'),
('burger','FOOD_DINING','FAST_FOOD','(?i)\\bburger\\b'),
('cafe','FOOD_DINING','CAFE','(?i)\\bcafe\\b'),
('coffee','FOOD_DINING','CAFE','(?i)\\bcoffee\\b'),
('bakery','FOOD_DINING','BAKERY','(?i)\\bbakery\\b'),
('ice cream','FOOD_DINING','BAKERY','(?i)ice cream'),
('juice shop','FOOD_DINING','JUICE_SNACKS','(?i)juice shop'),
('snacks','FOOD_DINING','JUICE_SNACKS','(?i)\\bsnacks\\b')
ON CONFLICT (keyword,category) DO NOTHING;

-- ============================================================
-- GROCERIES entities
-- ============================================================
INSERT INTO spendsense.merchant_entity_master (normalized_entity,category,subcategory,match_pattern) VALUES
('BIGBASKET','GROCERIES','ONLINE_GROCERY','(?i)bigbasket'),
('BLINKIT','GROCERIES','QUICK_COMMERCE','(?i)blinkit'),
('SWIGGY INSTAMART','GROCERIES','QUICK_COMMERCE','(?i)instamart'),
('ZEPTO','GROCERIES','QUICK_COMMERCE','(?i)\\bzepto\\b'),
('DMART','GROCERIES','SUPERMARKET','(?i)\\bdmart\\b'),
('RELIANCE SMART','GROCERIES','SUPERMARKET','(?i)reliance smart'),
('COUNTRY DELIGHT','GROCERIES','DAIRY','(?i)country delight'),
('MILKBASKET','GROCERIES','DAIRY','(?i)milkbasket'),
('MOTHER DAIRY','GROCERIES','DAIRY','(?i)mother dairy')
ON CONFLICT (normalized_entity,category) DO NOTHING;

INSERT INTO spendsense.merchant_keyword (keyword,category,subcategory,match_pattern) VALUES
('grocery','GROCERIES','GENERAL_STORE','(?i)\\bgrocery\\b'),
('kirana','GROCERIES','GENERAL_STORE','(?i)\\bkirana\\b'),
('supermarket','GROCERIES','SUPERMARKET','(?i)supermarket'),
('provision store','GROCERIES','GENERAL_STORE','(?i)provision store'),
('general store','GROCERIES','GENERAL_STORE','(?i)general store'),
('milk','GROCERIES','DAIRY','(?i)\\bmilk\\b'),
('dairy','GROCERIES','DAIRY','(?i)\\bdairy\\b'),
('vegetables','GROCERIES','FRUITS_VEGETABLES','(?i)vegetables'),
('fruits','GROCERIES','FRUITS_VEGETABLES','(?i)\\bfruits\\b')
ON CONFLICT (keyword,category) DO NOTHING;

-- ============================================================
-- TRANSPORT entities
-- ============================================================
INSERT INTO spendsense.merchant_entity_master (normalized_entity,category,subcategory,match_pattern) VALUES
('UBER','TRANSPORT','RIDE_HAILING','(?i)\\buber\\b'),
('OLA','TRANSPORT','RIDE_HAILING','(?i)\\bola\\b'),
('RAPIDO','TRANSPORT','BIKE_TAXI','(?i)rapido'),
('BLUSMART','TRANSPORT','RIDE_HAILING','(?i)blusmart'),
('INDIAN OIL','TRANSPORT','FUEL','(?i)indian oil|\\bioc\\b'),
('HPCL','TRANSPORT','FUEL','(?i)\\bhpcl\\b'),
('BPCL','TRANSPORT','FUEL','(?i)\\bbpcl\\b'),
('IRCTC','TRANSPORT','PUBLIC_TRANSPORT','(?i)irctc'),
('DELHI METRO','TRANSPORT','PUBLIC_TRANSPORT','(?i)delhi metro'),
('KSRTC','TRANSPORT','PUBLIC_TRANSPORT','(?i)ksrtc'),
('TSRTC','TRANSPORT','PUBLIC_TRANSPORT','(?i)tsrtc')
ON CONFLICT (normalized_entity,category) DO NOTHING;

INSERT INTO spendsense.merchant_keyword (keyword,category,subcategory,match_pattern) VALUES
('petrol','TRANSPORT','FUEL','(?i)\\bpetrol\\b'),
('diesel','TRANSPORT','FUEL','(?i)\\bdiesel\\b'),
('fuel','TRANSPORT','FUEL','(?i)\\bfuel\\b'),
('petrol pump','TRANSPORT','FUEL','(?i)petrol pump'),
('taxi','TRANSPORT','AUTO_TAXI','(?i)\\btaxi\\b'),
('cab','TRANSPORT','AUTO_TAXI','(?i)\\bcab\\b'),
('auto','TRANSPORT','AUTO_TAXI','(?i)\\bauto\\b'),
('parking','TRANSPORT','PARKING','(?i)\\bparking\\b'),
('fastag','TRANSPORT','TOLL','(?i)fastag'),
('toll','TRANSPORT','TOLL','(?i)\\btoll\\b')
ON CONFLICT (keyword,category) DO NOTHING;

-- ============================================================
-- HEALTH entities
-- ============================================================
INSERT INTO spendsense.merchant_entity_master (normalized_entity,category,subcategory,match_pattern) VALUES
('APOLLO PHARMACY','HEALTH','PHARMACY','(?i)apollo pharmacy'),
('MEDPLUS','HEALTH','PHARMACY','(?i)medplus'),
('NETMEDS','HEALTH','PHARMACY','(?i)netmeds'),
('PHARMEASY','HEALTH','PHARMACY','(?i)pharmeasy'),
('1MG','HEALTH','PHARMACY','(?i)1mg|tata 1mg'),
('APOLLO HOSPITAL','HEALTH','HOSPITAL','(?i)apollo hospital'),
('FORTIS','HEALTH','HOSPITAL','(?i)fortis'),
('MANIPAL HOSPITAL','HEALTH','HOSPITAL','(?i)manipal hospital'),
('LAL PATHLABS','HEALTH','DIAGNOSTICS','(?i)lal pathlabs|dr lal'),
('THYROCARE','HEALTH','DIAGNOSTICS','(?i)thyrocare')
ON CONFLICT (normalized_entity,category) DO NOTHING;

INSERT INTO spendsense.merchant_keyword (keyword,category,subcategory,match_pattern) VALUES
('pharmacy','HEALTH','PHARMACY','(?i)pharmacy'),
('medical store','HEALTH','MEDICAL_STORE','(?i)medical store'),
('chemist','HEALTH','PHARMACY','(?i)chemist'),
('hospital','HEALTH','HOSPITAL','(?i)hospital'),
('clinic','HEALTH','CLINIC','(?i)clinic'),
('doctor','HEALTH','CLINIC','(?i)doctor'),
('diagnostic','HEALTH','DIAGNOSTICS','(?i)diagnostic'),
('pathology','HEALTH','DIAGNOSTICS','(?i)pathology'),
('blood test','HEALTH','DIAGNOSTICS','(?i)blood test')
ON CONFLICT (keyword,category) DO NOTHING;

-- ============================================================
-- SHOPPING entities
-- ============================================================
INSERT INTO spendsense.merchant_entity_master (normalized_entity,category,subcategory,match_pattern) VALUES
('AMAZON','SHOPPING','ECOMMERCE','(?i)\\bamazon\\b'),
('FLIPKART','SHOPPING','ECOMMERCE','(?i)flipkart'),
('MEESHO','SHOPPING','ECOMMERCE','(?i)meesho'),
('MYNTRA','SHOPPING','FASHION','(?i)myntra'),
('AJIO','SHOPPING','FASHION','(?i)ajio'),
('ZUDIO','SHOPPING','FASHION','(?i)zudio'),
('CROMA','SHOPPING','ELECTRONICS_RETAIL','(?i)\\bcroma\\b'),
('RELIANCE DIGITAL','SHOPPING','ELECTRONICS_RETAIL','(?i)reliance digital'),
('VIJAY SALES','SHOPPING','ELECTRONICS_RETAIL','(?i)vijay sales'),
('SHOPPERS STOP','SHOPPING','DEPARTMENT_STORE','(?i)shoppers stop'),
('LIFESTYLE','SHOPPING','DEPARTMENT_STORE','(?i)lifestyle')
ON CONFLICT (normalized_entity,category) DO NOTHING;

INSERT INTO spendsense.merchant_keyword (keyword,category,subcategory,match_pattern) VALUES
('fashion','SHOPPING','FASHION','(?i)fashion'),
('clothing','SHOPPING','FASHION','(?i)clothing'),
('garments','SHOPPING','FASHION','(?i)garments'),
('boutique','SHOPPING','FASHION','(?i)boutique'),
('electronics','SHOPPING','ELECTRONICS_RETAIL','(?i)electronics'),
('mobile store','SHOPPING','ELECTRONICS_RETAIL','(?i)mobile store'),
('gadget','SHOPPING','ELECTRONICS_RETAIL','(?i)gadget')
ON CONFLICT (keyword,category) DO NOTHING;

-- ============================================================
-- TRAVEL entities
-- ============================================================
INSERT INTO spendsense.merchant_entity_master (normalized_entity,category,subcategory,match_pattern) VALUES
('MAKEMYTRIP','TRAVEL','TRAVEL_BOOKING','(?i)makemytrip'),
('GOIBIBO','TRAVEL','TRAVEL_BOOKING','(?i)goibibo'),
('CLEARTRIP','TRAVEL','TRAVEL_BOOKING','(?i)cleartrip'),
('YATRA','TRAVEL','TRAVEL_BOOKING','(?i)yatra'),
('INDIGO','TRAVEL','FLIGHTS','(?i)indigo'),
('AIR INDIA','TRAVEL','FLIGHTS','(?i)air india'),
('SPICEJET','TRAVEL','FLIGHTS','(?i)spicejet'),
('OYO','TRAVEL','HOTELS','(?i)oyo'),
('REDBUS','TRAVEL','BUS_TRAVEL','(?i)redbus')
ON CONFLICT (normalized_entity,category) DO NOTHING;

INSERT INTO spendsense.merchant_keyword (keyword,category,subcategory,match_pattern) VALUES
('flight','TRAVEL','FLIGHTS','(?i)flight'),
('airlines','TRAVEL','FLIGHTS','(?i)airlines'),
('hotel stay','TRAVEL','HOTELS','(?i)hotel stay'),
('resort','TRAVEL','HOTELS','(?i)resort'),
('tour package','TRAVEL','HOLIDAY_PACKAGE','(?i)tour package')
ON CONFLICT (keyword,category) DO NOTHING;

-- ============================================================
-- ENTERTAINMENT entities
-- ============================================================
INSERT INTO spendsense.merchant_entity_master (normalized_entity,category,subcategory,match_pattern) VALUES
('NETFLIX','ENTERTAINMENT','OTT','(?i)netflix'),
('DISNEY HOTSTAR','ENTERTAINMENT','OTT','(?i)hotstar|disney hotstar'),
('SONY LIV','ENTERTAINMENT','OTT','(?i)sony liv'),
('SPOTIFY','ENTERTAINMENT','MUSIC','(?i)spotify'),
('PVR','ENTERTAINMENT','MOVIES','(?i)\\bpvr\\b'),
('INOX','ENTERTAINMENT','MOVIES','(?i)\\binox\\b'),
('BOOKMYSHOW','ENTERTAINMENT','EVENTS','(?i)bookmyshow'),
('DREAM11','ENTERTAINMENT','GAMING','(?i)dream11'),
('STEAM','ENTERTAINMENT','GAMING','(?i)\\bsteam\\b')
ON CONFLICT (normalized_entity,category) DO NOTHING;

INSERT INTO spendsense.merchant_keyword (keyword,category,subcategory,match_pattern) VALUES
('cinema','ENTERTAINMENT','MOVIES','(?i)\\bcinema\\b'),
('movie','ENTERTAINMENT','MOVIES','(?i)\\bmovie\\b'),
('concert','ENTERTAINMENT','EVENTS','(?i)concert'),
('gaming','ENTERTAINMENT','GAMING','(?i)gaming')
ON CONFLICT (keyword,category) DO NOTHING;

-- ============================================================
-- UTILITIES entities
-- ============================================================
INSERT INTO spendsense.merchant_entity_master (normalized_entity,category,subcategory,match_pattern) VALUES
('BESCOM','UTILITIES','ELECTRICITY','(?i)bescom'),
('TNEB','UTILITIES','ELECTRICITY','(?i)tneb'),
('BSES','UTILITIES','ELECTRICITY','(?i)bses'),
('AIRTEL MOBILE','UTILITIES','MOBILE','(?i)airtel'),
('JIO MOBILE','UTILITIES','MOBILE','(?i)reliance jio|\\bjio\\b'),
('VODAFONE IDEA','UTILITIES','MOBILE','(?i)\\bvi\\b|vodafone|\\bidea\\b'),
('JIO FIBER','UTILITIES','INTERNET','(?i)jiofiber|jio fiber'),
('TATA PLAY','UTILITIES','DTH','(?i)tata play|tatasky'),
('DISH TV','UTILITIES','DTH','(?i)dish tv'),
('BWSSB','UTILITIES','WATER','(?i)bwssb')
ON CONFLICT (normalized_entity,category) DO NOTHING;

-- ============================================================
-- EDUCATION, PERSONAL_CARE, HOME, HOUSING, SPORTS, PETS, GIFTS
-- (abbreviated - same pattern as above)
-- ============================================================
INSERT INTO spendsense.merchant_entity_master (normalized_entity,category,subcategory,match_pattern) VALUES
('BYJUS','EDUCATION','ONLINE_EDTECH','(?i)byjus'),
('UNACADEMY','EDUCATION','ONLINE_EDTECH','(?i)unacademy'),
('UDEMY','EDUCATION','COURSES','(?i)udemy'),
('COURSERA','EDUCATION','COURSES','(?i)coursera'),
('JAWED HABIB','PERSONAL_CARE','SALON','(?i)jawed habib'),
('NATURALS SALON','PERSONAL_CARE','SALON','(?i)naturals salon'),
('IKEA','HOME','FURNITURE','(?i)\\bikea\\b'),
('PEPPERFRY','HOME','FURNITURE','(?i)pepperfry'),
('URBAN LADDER','HOME','FURNITURE','(?i)urban ladder'),
('CULTFIT','SPORTS','FITNESS_APP','(?i)cultfit|cult fit'),
('DECATHLON','SPORTS','SPORTS_EQUIPMENT','(?i)decathlon'),
('HEADS UP FOR TAILS','PETS','PET_STORE','(?i)heads up for tails'),
('NOBROKER RENT','HOUSING','RENT_PLATFORM','(?i)nobroker'),
('AKSHAYA PATRA','GIFTS_DONATIONS','CHARITY','(?i)akshaya patra'),
('KETTO','GIFTS_DONATIONS','FUNDRAISER','(?i)ketto')
ON CONFLICT (normalized_entity,category) DO NOTHING;

INSERT INTO spendsense.merchant_keyword (keyword,category,subcategory,match_pattern) VALUES
('school','EDUCATION','SCHOOL_FEES','(?i)school'),
('coaching','EDUCATION','COACHING','(?i)coaching'),
('tuition','EDUCATION','COACHING','(?i)tuition'),
('salon','PERSONAL_CARE','SALON','(?i)salon'),
('spa','PERSONAL_CARE','SPA','(?i)\\bspa\\b'),
('haircut','PERSONAL_CARE','SALON','(?i)haircut'),
('furniture','HOME','FURNITURE','(?i)furniture'),
('rent','HOUSING','RENT','(?i)\\brent\\b'),
('gym','SPORTS','GYM','(?i)\\bgym\\b'),
('fitness','SPORTS','FITNESS','(?i)fitness'),
('pet','PETS','PET_STORE','(?i)\\bpet\\b'),
('vet','PETS','VETERINARY','(?i)\\bvet\\b'),
('donation','GIFTS_DONATIONS','CHARITY','(?i)\\bdonation\\b'),
('charity','GIFTS_DONATIONS','CHARITY','(?i)\\bcharity\\b'),
('subscription','SUBSCRIPTIONS','GENERAL','(?i)subscription')
ON CONFLICT (keyword,category) DO NOTHING;

-- txn_categorized: final merchant category output
CREATE TABLE IF NOT EXISTS spendsense.txn_categorized (
    cat_id              BIGSERIAL PRIMARY KEY,
    classified_id       BIGINT NOT NULL UNIQUE
                            REFERENCES spendsense.txn_classified(classified_id) ON DELETE CASCADE,
    user_id             TEXT NOT NULL,
    txn_date            DATE NOT NULL,
    amount              NUMERIC(18,2) NOT NULL,
    cr_dr               CHAR(1) NOT NULL,
    expense_category    TEXT,           -- FOOD_DINING | GROCERIES | TRANSPORT | etc.
    expense_subcategory TEXT,
    merchant_label      TEXT,
    matched_via         TEXT,           -- 'entity' | 'keyword' | 'mcc' | 'upi_handle'
    rule_code           TEXT,
    confidence_score    NUMERIC(4,2) DEFAULT 0.0,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS ix_cat_user     ON spendsense.txn_categorized(user_id);
CREATE INDEX IF NOT EXISTS ix_cat_category ON spendsense.txn_categorized(expense_category);
CREATE INDEX IF NOT EXISTS ix_cat_date     ON spendsense.txn_categorized(txn_date DESC);
