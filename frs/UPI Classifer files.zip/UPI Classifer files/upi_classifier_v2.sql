-- ============================================================
-- MONYTIX  —  UPI STRUCTURAL CLASSIFIER  v2.0
-- Fail-proof rewrite.  All 12 IS-xx issues from the design
-- review document have been addressed.
--
-- INPUT  : spendsense.txn_parsed
-- OUTPUT : spendsense.txn_parsed_UPI_updated
--
-- Entity types produced:
--   SELF_ACCOUNT | PERSON | SMALL_MERCHANT | MERCHANT | UNKNOWN_MERCHANT
--
-- Changes from v1 (IS-xx cross-reference):
--   IS-01  Counterparty rollup scoped per user_id
--   IS-02  ref_upi_provider_type added, provider weights applied
--   IS-03  DROP TABLE replaced with safe TRUNCATE + INSERT
--   IS-04  Fan-out bug fixed with DISTINCT ON in output join
--   IS-05  AVG replaced with PERCENTILE_CONT (median)
--   IS-06  is_bidirectional, is_debit_only flags added to rollup
--   IS-07  qr/gateway signals split per provider for accurate scores
--   IS-08  LIKE join replaced with regexp_match pre-computed column
--   IS-09  Primary key + upload_id + timestamps added to output table
--   IS-10  Triple VPA regex refactored via lateral subquery
--   IS-11  is_active added to ref_upi_major_handle
--   IS-12  NAME_PREFIX_PATTERN signal added (+20 person score)
--
-- ============================================================
BEGIN;

SET search_path = spendsense, public;

-- ============================================================
-- STEP 0 — SCORING CONSTANTS
-- All thresholds and signal weights in one place.
-- Developers: change numbers here ONLY — never in the views.
-- ============================================================

CREATE TABLE IF NOT EXISTS spendsense.ref_upi_classifier_config (
    config_key   TEXT PRIMARY KEY,
    config_value NUMERIC NOT NULL,
    description  TEXT
);

INSERT INTO spendsense.ref_upi_classifier_config
    (config_key, config_value, description)
VALUES
-- Thresholds
('SELF_ACCOUNT_THRESHOLD',   60,  'Min self_account_score to classify as SELF_ACCOUNT'),
('PERSON_THRESHOLD',         55,  'Min person_score to classify as PERSON'),
('SMALL_MERCHANT_THRESHOLD', 55,  'Min small_merchant_score to classify as SMALL_MERCHANT'),
('MERCHANT_THRESHOLD',       50,  'Min merchant_score to classify as MERCHANT'),
-- Self signals
('SELF_WORDING_SCORE',      100,  'Description contains self/own account/self transfer'),
('BIDIRECTIONAL_SCORE',      35,  'Counterparty appears in both debit and credit flows'),
('ROUND_TRIP_SCORE',         25,  'Debit and credit repeated multiple times'),
('NO_MERCHANT_SIGNAL_SELF',  10,  'No QR or gateway signals — adds to SELF score'),
-- Person signals
('MOBILE_VPA_SCORE',         45,  'VPA handle is 10-digit mobile number'),
('NAME_PREFIX_SCORE',        20,  'Human name token detected before VPA'),
('NO_MERCHANT_SIGNAL_PERSON',10,  'No QR or gateway signals — adds to PERSON score'),
('LOW_REPEAT_SCORE',          5,  'debit_count <= 5 and no credit transactions'),
-- Small merchant signals
('PAYTM_QR_SCORE',           55,  'Paytm QR pattern in description'),
('BHARATPE_QR_SCORE',        45,  'BharatPe QR pattern in description'),
('OTHER_QR_SCORE',           30,  'Generic QR pattern (not Paytm or BharatPe)'),
('SMALL_TICKET_SCORE',       15,  'Median debit amount <= 300 INR'),
('DEBIT_ONLY_SMALL_SCORE',   15,  'All transactions are debits (small merchant context)'),
('MOBILE_VPA_VENDOR_SCORE',   5,  'Mobile VPA used in apparent merchant context'),
-- Merchant signals
('RAZORPAY_SCORE',           35,  'Razorpay gateway detected'),
('PAYU_SCORE',               35,  'PayU gateway detected'),
('CASHFREE_SCORE',           35,  'Cashfree gateway detected'),
('BILLPAY_SCORE',            25,  'BBPS / bill payment pattern detected'),
('REPEATED_TXN_SCORE',       10,  'txn_count >= 2 with same counterparty'),
('DEBIT_ONLY_MERCHANT_SCORE',10,  'All transactions are debits (merchant context)'),
('NON_MOBILE_VPA_SCORE',     10,  'VPA handle is NOT a mobile number'),
-- Ticket size threshold
('SMALL_TICKET_MEDIAN_MAX', 300,  'Median debit below this is a small-ticket signal')
ON CONFLICT (config_key) DO UPDATE
    SET config_value = EXCLUDED.config_value,
        description  = EXCLUDED.description;

-- ============================================================
-- STEP 1A — PROVIDER INTELLIGENCE  (IS-02)
-- Each UPI provider suffix contributes to person or merchant
-- scoring based on whether it is consumer-facing or corporate.
-- ============================================================

CREATE TABLE IF NOT EXISTS spendsense.ref_upi_provider_type (
    provider_code           TEXT PRIMARY KEY,
    provider_type           TEXT NOT NULL
                                CHECK (provider_type IN ('CONSUMER','CORPORATE','QR','MIXED','NEUTRAL')),
    person_weight           INT  NOT NULL DEFAULT 0,
    merchant_weight         INT  NOT NULL DEFAULT 0,
    small_merchant_weight   INT  NOT NULL DEFAULT 0,
    is_active               BOOLEAN NOT NULL DEFAULT TRUE,
    notes                   TEXT
);

INSERT INTO spendsense.ref_upi_provider_type
    (provider_code, provider_type, person_weight, merchant_weight, small_merchant_weight, notes)
VALUES
-- Consumer providers (PhonePe, Google Pay variants)
('ybl',          'CONSUMER', 20, 0,  0,  'PhonePe'),
('ibl',          'CONSUMER', 20, 0,  0,  'PhonePe (older)'),
('axl',          'CONSUMER', 15, 0,  0,  'Google Pay via Axis'),
('okaxis',       'CONSUMER', 20, 0,  0,  'Google Pay'),
('oksbi',        'CONSUMER', 20, 0,  0,  'Google Pay via SBI'),
('okhdfcbank',   'CONSUMER', 20, 0,  0,  'Google Pay via HDFC'),
('okicici',      'CONSUMER', 20, 0,  0,  'Google Pay via ICICI'),
('upi',          'CONSUMER', 10, 0,  0,  'Generic UPI'),
-- Mixed (Paytm — used by both consumers and merchants)
('paytm',        'MIXED',    10, 10,  10, 'Paytm wallet — consumer and merchant'),
-- QR-facing (Paytm QR specific)
('pty',          'QR',        5, 0,  20,  'Paytm QR merchant'),
('ptys',         'QR',        5, 0,  20,  'Paytm QR merchant (secure)'),
('ptybl',        'QR',        5, 0,  20,  'Paytm QR merchant (bank-linked)'),
-- Corporate / merchant providers
('icici',        'CORPORATE', 0, 25,  5,  'ICICI merchant UPI'),
('hdfcbank',     'CORPORATE', 0, 25,  5,  'HDFC merchant UPI'),
('hdfc',         'CORPORATE', 0, 20,  5,  'HDFC generic'),
('axisbank',     'CORPORATE', 0, 25,  5,  'Axis Bank merchant'),
('axisb',        'CORPORATE', 0, 20,  5,  'Axis Bank short code'),
('axb',          'CORPORATE', 0, 20,  5,  'Axis Bank alternate'),
('airtel',       'CORPORATE', 0, 20,  5,  'Airtel Payments Bank'),
('rxairtel',     'CORPORATE', 0, 25,  5,  'Airtel business'),
('payu',         'CORPORATE', 0, 30,  0,  'PayU gateway provider'),
('yesbankltd',   'CORPORATE', 0, 20, 10,  'Yes Bank merchant'),
('okbizaxis',    'CORPORATE', 0, 25,  0,  'Google Pay for Business'),
('jiomerchant',  'CORPORATE', 0, 25,  5,  'Jio merchant'),
('idfcnetc',     'CORPORATE', 0, 25,  0,  'IDFC FASTag/merchant'),
('fbpe',         'CORPORATE', 0, 20, 10,  'Federal Bank merchant'),
('yapl',         'CORPORATE', 0, 20,  5,  'Yes Bank alternate'),
('ikwik',        'CORPORATE', 0, 20,  5,  'IKwik merchant'),
-- Neutral (need context to determine)
('o',            'NEUTRAL',   5, 0,   0,  'BHIM / bank generic'),
('pt',           'NEUTRAL',   0, 5,  15,  'Paytm transit / misc'),
('hdfcb',        'NEUTRAL',   0, 10,  5,  'HDFC Bank generic')
ON CONFLICT (provider_code) DO UPDATE
    SET provider_type         = EXCLUDED.provider_type,
        person_weight         = EXCLUDED.person_weight,
        merchant_weight       = EXCLUDED.merchant_weight,
        small_merchant_weight = EXCLUDED.small_merchant_weight,
        notes                 = EXCLUDED.notes;

-- ============================================================
-- STEP 1B — MAJOR MERCHANT HANDLE REGISTRY  (IS-08, IS-11)
-- Brands detected directly without scoring.
-- IS-08: match column pre-computed in feature view, not LIKE join
-- IS-11: is_active flag added
-- ============================================================

CREATE TABLE IF NOT EXISTS spendsense.ref_upi_major_handle (
    merchant_id          SERIAL PRIMARY KEY,
    handle_pattern       TEXT    NOT NULL UNIQUE,
    merchant_label       TEXT    NOT NULL,
    merchant_category    TEXT,
    merchant_subcategory TEXT,
    merchant_weight      INT     NOT NULL DEFAULT 25,
    is_active            BOOLEAN NOT NULL DEFAULT TRUE,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS ix_ref_upi_major_handle_pattern
    ON spendsense.ref_upi_major_handle(handle_pattern)
    WHERE is_active = TRUE;

-- Extend the existing table if upgrading from v1
ALTER TABLE spendsense.ref_upi_major_handle
    ADD COLUMN IF NOT EXISTS merchant_weight INT NOT NULL DEFAULT 25,
    ADD COLUMN IF NOT EXISTS is_active BOOLEAN NOT NULL DEFAULT TRUE,
    ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ NOT NULL DEFAULT NOW();

INSERT INTO spendsense.ref_upi_major_handle
    (handle_pattern, merchant_label, merchant_category, merchant_subcategory, merchant_weight)
VALUES
-- Food
('swiggystores',   'SWIGGY',           'Food',       'Food Delivery',    30),
('swiggy',         'SWIGGY',           'Food',       'Food Delivery',    30),
('zomato',         'ZOMATO',           'Food',       'Food Delivery',    30),
-- Groceries / Quick Commerce
('blinkcommerce',  'BLINKIT',          'Groceries',  'Quick Commerce',   30),
('blinkit',        'BLINKIT',          'Groceries',  'Quick Commerce',   30),
('zeptonowltd',    'ZEPTO',            'Groceries',  'Quick Commerce',   30),
('zepto',          'ZEPTO',            'Groceries',  'Quick Commerce',   30),
('countrydelight', 'COUNTRY DELIGHT',  'Groceries',  'Milk & Dairy',     25),
('milkbasket',     'MILKBASKET',       'Groceries',  'Milk & Dairy',     25),
('bigbasket',      'BIGBASKET',        'Groceries',  'Online Grocery',   30),
('dmartready',     'DMART READY',      'Groceries',  'Supermarket',      30),
-- Financial
('cred.club',      'CRED',             'Financial',  'Card Payment',     30),
('cheq1',          'CHEQ',             'Financial',  'Card Payment',     30),
('credpay.',       'CRED PAY',         'Financial',  'Merchant Payment', 30),
-- Shopping
('amazonpay',      'AMAZON',           'Shopping',   'Marketplace',      30),
('amazon',         'AMAZON',           'Shopping',   'Marketplace',      30),
('flipkart',       'FLIPKART',         'Shopping',   'Marketplace',      30),
('myntra',         'MYNTRA',           'Shopping',   'Fashion',          25),
('ajio',           'AJIO',             'Shopping',   'Fashion',          25),
('nykaa',          'NYKAA',            'Shopping',   'Beauty',           25),
-- Transport
('uber',           'UBER',             'Transport',  'Ride Hailing',     30),
('ola',            'OLA',              'Transport',  'Ride Hailing',     30),
('rapido',         'RAPIDO',           'Transport',  'Bike Taxi',        25),
('netc.',          'FASTAG',           'Transport',  'Toll',             25),
-- Travel
('irctc',          'IRCTC',            'Travel',     'Railways',         30),
('redbus',         'REDBUS',           'Travel',     'Bus Booking',      25),
('makemytrip',     'MAKEMYTRIP',       'Travel',     'Travel Booking',   30),
('goibibo',        'GOIBIBO',          'Travel',     'Travel Booking',   25),
('easemytrip',     'EASEMYTRIP',       'Travel',     'Travel Booking',   25),
-- Telecom / Utility
('airtel',         'AIRTEL',           'Telecom',    'Mobile Recharge',  30),
('jio',            'JIO',              'Telecom',    'Mobile Recharge',  30),
('billdeskpg',     'BILLDESK',         'Financial',  'Bill Payment',     25),
-- Investment
('zerodha',        'ZERODHA',          'Investment', 'Broker',           30),
('groww',          'GROWW',            'Investment', 'Broker',           30),
('indmoneymf',     'INDMONEY MF',      'Investment', 'Mutual Fund',      25),
-- Entertainment
('netflix',        'NETFLIX',          'Entertainment','OTT',            25),
('spotify',        'SPOTIFY',          'Entertainment','Music',          25),
-- Infrastructure
('bharatpe',       'BHARATPE',         'Infrastructure','QR Merchant',   20)
ON CONFLICT (handle_pattern) DO UPDATE
    SET merchant_label       = EXCLUDED.merchant_label,
        merchant_category    = EXCLUDED.merchant_category,
        merchant_subcategory = EXCLUDED.merchant_subcategory,
        merchant_weight      = EXCLUDED.merchant_weight;

-- ============================================================
-- STEP 2 — UPI STRUCTURAL FEATURE EXTRACTION  (IS-07, IS-10, IS-12)
-- IS-10: VPA regex computed once via lateral subquery
-- IS-07: qr and gateway signals split per provider
-- IS-12: name_prefix_signal added
-- ============================================================

CREATE OR REPLACE VIEW spendsense.vw_upi_struct_features AS
SELECT
    t.txn_id,
    t.user_id,
    t.txn_date,
    t.amount,
    t.cr_dr,
    t.payment_channel,
    t.raw_description,
    t.upload_id,

    -- VPA extracted once (IS-10)
    vpa_extracted.raw_vpa                                AS vpa,
    split_part(vpa_extracted.raw_vpa, '@', 2)            AS vpa_provider,
    split_part(vpa_extracted.raw_vpa, '@', 1)            AS vpa_handle,

    -- Self-wording (catches more variants)
    CASE WHEN t.raw_description ~*
        '(self[\s_-]?transfer|own[\s_-]?account|transfer[\s_-]?to[\s_-]?self|self[\s_-]?a/c)'
    THEN 1 ELSE 0 END                                    AS self_wording,

    -- Name prefix pattern: UPI-NAME-10digits@provider (IS-12)
    CASE WHEN t.raw_description ~*
        '^UPI[\s-][A-Z][A-Z\s]{2,30}[\s-][0-9]{10}@'
    THEN 1 ELSE 0 END                                    AS name_prefix_signal,

    -- QR signals — split per provider (IS-07)
    CASE WHEN t.raw_description ~* 'paytmqr'
    THEN 1 ELSE 0 END                                    AS paytm_qr_signal,

    CASE WHEN t.raw_description ~* 'bharatpe'
    THEN 1 ELSE 0 END                                    AS bharatpe_qr_signal,

    CASE WHEN t.raw_description ~* '\bqr\b'
         AND t.raw_description !~* '(paytmqr|bharatpe)'
    THEN 1 ELSE 0 END                                    AS other_qr_signal,

    -- Gateway signals — split per provider (IS-07)
    CASE WHEN t.raw_description ~* '(razorpay|\brzp\b)'
    THEN 1 ELSE 0 END                                    AS razorpay_signal,

    CASE WHEN t.raw_description ~* '\bpayu\b'
         AND t.raw_description !~* 'paytm'
    THEN 1 ELSE 0 END                                    AS payu_signal,

    CASE WHEN t.raw_description ~* 'cashfree'
    THEN 1 ELSE 0 END                                    AS cashfree_signal,

    -- Bill payment signal (IS-09 — was missing entirely)
    CASE WHEN t.raw_description ~*
        '(bbps|billpay|billerslip|billdesk|fastag|netc)'
    THEN 1 ELSE 0 END                                    AS billpay_signal,

    -- Composite convenience flag (used in no-merchant checks)
    CASE WHEN t.raw_description ~*
        '(paytmqr|bharatpe|\bqr\b|razorpay|\brzp\b|\bpayu\b|cashfree)'
    THEN 1 ELSE 0 END                                    AS any_merchant_signal,

    -- Major handle match pre-computed here (IS-08: avoid LIKE in downstream join)
    mh.handle_pattern                                    AS matched_handle_pattern,
    mh.merchant_label,
    mh.merchant_category,
    mh.merchant_subcategory,
    mh.merchant_weight

FROM spendsense.txn_parsed t

-- IS-10: VPA regex computed exactly once
CROSS JOIN LATERAL (
    SELECT COALESCE(
        LOWER(substring(t.raw_description
              FROM '([A-Za-z0-9._%-]+@[A-Za-z0-9._%-]+)')),
        ''
    ) AS raw_vpa
) vpa_extracted

-- IS-08: pre-compute handle match in feature layer using regexp, not downstream LIKE
LEFT JOIN LATERAL (
    SELECT h.handle_pattern, h.merchant_label,
           h.merchant_category, h.merchant_subcategory,
           h.merchant_weight
    FROM spendsense.ref_upi_major_handle h
    WHERE h.is_active = TRUE
      AND LOWER(t.raw_description) ~ LOWER(h.handle_pattern)
    ORDER BY h.merchant_weight DESC
    LIMIT 1   -- IS-04: takes the highest-weight match, prevents fan-out
) mh ON TRUE

WHERE t.payment_channel = 'UPI';

COMMENT ON VIEW spendsense.vw_upi_struct_features IS
'Extracts per-transaction structural signals. VPA computed once via lateral.
 QR/gateway signals are split per provider for accurate scoring.
 Major handle match pre-computed here to avoid LIKE fan-out downstream.';

-- ============================================================
-- STEP 3 — COUNTERPARTY BEHAVIOURAL ROLLUP  (IS-01, IS-05, IS-06)
-- IS-01: grouped by (user_id, counterparty_key) — per-user scope
-- IS-05: PERCENTILE_CONT used for median (not AVG)
-- IS-06: is_bidirectional, is_debit_only flags added
-- ============================================================

CREATE OR REPLACE VIEW spendsense.vw_upi_counterparty_rollup AS
SELECT
    user_id,
    COALESCE(NULLIF(vpa, ''), vpa_handle)                AS counterparty_key,

    COUNT(*)                                             AS txn_count,
    COUNT(*) FILTER (WHERE cr_dr = 'D')                  AS debit_count,
    COUNT(*) FILTER (WHERE cr_dr = 'C')                  AS credit_count,

    -- IS-05: median instead of average
    PERCENTILE_CONT(0.5) WITHIN GROUP
        (ORDER BY amount) FILTER (WHERE cr_dr = 'D')     AS median_debit_amt,

    -- IS-06: bidirectional and debit-only flags
    CASE WHEN COUNT(*) FILTER (WHERE cr_dr = 'D') > 0
          AND COUNT(*) FILTER (WHERE cr_dr = 'C') > 0
         THEN TRUE ELSE FALSE END                         AS is_bidirectional,

    CASE WHEN COUNT(*) FILTER (WHERE cr_dr = 'D') > 0
          AND COUNT(*) FILTER (WHERE cr_dr = 'C') = 0
         THEN TRUE ELSE FALSE END                         AS is_debit_only,

    -- Signal aggregation
    MAX(paytm_qr_signal)                                 AS any_paytm_qr,
    MAX(bharatpe_qr_signal)                              AS any_bharatpe_qr,
    MAX(other_qr_signal)                                 AS any_other_qr,
    MAX(razorpay_signal)                                 AS any_razorpay,
    MAX(payu_signal)                                     AS any_payu,
    MAX(cashfree_signal)                                 AS any_cashfree,
    MAX(billpay_signal)                                  AS any_billpay,
    MAX(self_wording)                                    AS any_self_wording,
    MAX(name_prefix_signal)                              AS any_name_prefix,
    MAX(any_merchant_signal)                             AS any_merchant_signal,

    -- Provider codes seen for this counterparty
    array_agg(DISTINCT vpa_provider)
        FILTER (WHERE vpa_provider <> '')                AS providers_seen,

    -- Pre-computed handle data (takes max-weight match seen across txns)
    (array_agg(matched_handle_pattern
        ORDER BY merchant_weight DESC NULLS LAST)
        FILTER (WHERE matched_handle_pattern IS NOT NULL))[1]
                                                         AS matched_handle_pattern

FROM spendsense.vw_upi_struct_features
GROUP BY user_id, COALESCE(NULLIF(vpa, ''), vpa_handle);

COMMENT ON VIEW spendsense.vw_upi_counterparty_rollup IS
'Per-user counterparty aggregation. IS-01: scoped to user_id.
 IS-05: median via PERCENTILE_CONT. IS-06: bidirectional/debit_only flags.';

-- ============================================================
-- STEP 4 — PROVIDER WEIGHT AGGREGATION  (IS-02)
-- Joins provider intelligence for each counterparty.
-- Uses the providers_seen array from the rollup.
-- ============================================================

CREATE OR REPLACE VIEW spendsense.vw_upi_provider_scores AS
SELECT
    r.user_id,
    r.counterparty_key,
    -- Sum provider weights across all providers seen for this counterparty
    COALESCE(SUM(pt.person_weight),          0)::INT AS provider_person_score,
    COALESCE(SUM(pt.merchant_weight),        0)::INT AS provider_merchant_score,
    COALESCE(SUM(pt.small_merchant_weight),  0)::INT AS provider_small_merchant_score,
    -- Dominant provider type (most common)
    MODE() WITHIN GROUP (ORDER BY pt.provider_type)   AS dominant_provider_type
FROM spendsense.vw_upi_counterparty_rollup r
-- Unnest the providers_seen array then join
CROSS JOIN LATERAL unnest(r.providers_seen) AS prov(code)
LEFT JOIN spendsense.ref_upi_provider_type pt
    ON LOWER(prov.code) = pt.provider_code
    AND pt.is_active = TRUE
GROUP BY r.user_id, r.counterparty_key;

COMMENT ON VIEW spendsense.vw_upi_provider_scores IS
'Aggregates provider intelligence weights per counterparty.
 IS-02: implements ref_upi_provider_type joins.';

-- ============================================================
-- STEP 5 — ENTITY SCORING ENGINE  (IS-02, IS-06, IS-07, IS-12)
-- All signals from spec now implemented.
-- Reads constants from ref_upi_classifier_config.
-- ============================================================

CREATE OR REPLACE VIEW spendsense.vw_upi_entity_scoring AS
WITH cfg AS (
    -- Load all thresholds and signal weights into one CTE
    SELECT
        MAX(CASE WHEN config_key = 'SELF_WORDING_SCORE'       THEN config_value END) AS self_wording_score,
        MAX(CASE WHEN config_key = 'BIDIRECTIONAL_SCORE'      THEN config_value END) AS bidirectional_score,
        MAX(CASE WHEN config_key = 'ROUND_TRIP_SCORE'         THEN config_value END) AS round_trip_score,
        MAX(CASE WHEN config_key = 'NO_MERCHANT_SIGNAL_SELF'  THEN config_value END) AS no_merchant_self_score,
        MAX(CASE WHEN config_key = 'MOBILE_VPA_SCORE'         THEN config_value END) AS mobile_vpa_score,
        MAX(CASE WHEN config_key = 'NAME_PREFIX_SCORE'        THEN config_value END) AS name_prefix_score,
        MAX(CASE WHEN config_key = 'NO_MERCHANT_SIGNAL_PERSON'THEN config_value END) AS no_merchant_person_score,
        MAX(CASE WHEN config_key = 'LOW_REPEAT_SCORE'         THEN config_value END) AS low_repeat_score,
        MAX(CASE WHEN config_key = 'PAYTM_QR_SCORE'           THEN config_value END) AS paytm_qr_score,
        MAX(CASE WHEN config_key = 'BHARATPE_QR_SCORE'        THEN config_value END) AS bharatpe_qr_score,
        MAX(CASE WHEN config_key = 'OTHER_QR_SCORE'           THEN config_value END) AS other_qr_score,
        MAX(CASE WHEN config_key = 'SMALL_TICKET_SCORE'       THEN config_value END) AS small_ticket_score,
        MAX(CASE WHEN config_key = 'DEBIT_ONLY_SMALL_SCORE'   THEN config_value END) AS debit_only_small_score,
        MAX(CASE WHEN config_key = 'MOBILE_VPA_VENDOR_SCORE'  THEN config_value END) AS mobile_vpa_vendor_score,
        MAX(CASE WHEN config_key = 'RAZORPAY_SCORE'           THEN config_value END) AS razorpay_score,
        MAX(CASE WHEN config_key = 'PAYU_SCORE'               THEN config_value END) AS payu_score,
        MAX(CASE WHEN config_key = 'CASHFREE_SCORE'           THEN config_value END) AS cashfree_score,
        MAX(CASE WHEN config_key = 'BILLPAY_SCORE'            THEN config_value END) AS billpay_score,
        MAX(CASE WHEN config_key = 'REPEATED_TXN_SCORE'       THEN config_value END) AS repeated_txn_score,
        MAX(CASE WHEN config_key = 'DEBIT_ONLY_MERCHANT_SCORE'THEN config_value END) AS debit_only_merchant_score,
        MAX(CASE WHEN config_key = 'NON_MOBILE_VPA_SCORE'     THEN config_value END) AS non_mobile_vpa_score,
        MAX(CASE WHEN config_key = 'SMALL_TICKET_MEDIAN_MAX'  THEN config_value END) AS small_ticket_max
    FROM spendsense.ref_upi_classifier_config
)
SELECT
    r.user_id,
    r.counterparty_key,
    r.txn_count,
    r.debit_count,
    r.credit_count,
    r.median_debit_amt,
    r.is_bidirectional,
    r.is_debit_only,
    r.matched_handle_pattern,

    -- ── SELF_ACCOUNT score ────────────────────────────────────
    LEAST(100,
        -- SELF_WORDING: dominant signal
        CASE WHEN r.any_self_wording = 1
             THEN cfg.self_wording_score ELSE 0 END
        +
        -- BIDIRECTIONAL_FLOW (IS-06)
        CASE WHEN r.is_bidirectional = TRUE AND r.txn_count >= 2
             THEN cfg.bidirectional_score ELSE 0 END
        +
        -- ROUND_TRIP (debit ≥ 2 and credit ≥ 2)
        CASE WHEN r.debit_count >= 2 AND r.credit_count >= 2
             THEN cfg.round_trip_score ELSE 0 END
        +
        -- NO_MERCHANT_SIGNAL
        CASE WHEN r.any_merchant_signal = 0
             THEN cfg.no_merchant_self_score ELSE 0 END
    )::INT                                               AS self_account_score,

    -- ── PERSON score ──────────────────────────────────────────
    LEAST(100,
        -- MOBILE_VPA: handle is 10-digit mobile number
        CASE WHEN r.counterparty_key ~ '^[0-9]{10}(@|$)'
             THEN cfg.mobile_vpa_score ELSE 0 END
        +
        -- CONSUMER_PROVIDER (IS-02)
        COALESCE(ps.provider_person_score, 0)
        +
        -- NAME_PREFIX_PATTERN (IS-12)
        CASE WHEN r.any_name_prefix = 1
             THEN cfg.name_prefix_score ELSE 0 END
        +
        -- NO_MERCHANT_SIGNAL
        CASE WHEN r.any_merchant_signal = 0
             THEN cfg.no_merchant_person_score ELSE 0 END
        +
        -- LOW_REPEAT_PATTERN: debit ≤ 5, no credit
        CASE WHEN r.debit_count <= 5 AND r.credit_count = 0
             THEN cfg.low_repeat_score ELSE 0 END
    )::INT                                               AS person_score,

    -- ── SMALL_MERCHANT score ──────────────────────────────────
    LEAST(100,
        -- PAYTM_QR: highest QR score (IS-07: differentiated)
        CASE WHEN r.any_paytm_qr = 1
             THEN cfg.paytm_qr_score ELSE 0 END
        +
        -- BHARATPE_QR: separate lower score (IS-07)
        CASE WHEN r.any_bharatpe_qr = 1 AND r.any_paytm_qr = 0
             THEN cfg.bharatpe_qr_score ELSE 0 END
        +
        -- OTHER_QR: generic QR signal
        CASE WHEN r.any_other_qr = 1
              AND r.any_paytm_qr = 0
              AND r.any_bharatpe_qr = 0
             THEN cfg.other_qr_score ELSE 0 END
        +
        -- SMALL_TICKET: median ≤ 300 (IS-05: uses median not avg)
        CASE WHEN r.median_debit_amt IS NOT NULL
              AND r.median_debit_amt <= cfg.small_ticket_max
             THEN cfg.small_ticket_score ELSE 0 END
        +
        -- DEBIT_ONLY_PATTERN (IS-06)
        CASE WHEN r.is_debit_only = TRUE
             THEN cfg.debit_only_small_score ELSE 0 END
        +
        -- MOBILE_VPA_VENDOR: mobile number used as apparent merchant
        CASE WHEN r.counterparty_key ~ '^[0-9]{10}(@|$)'
              AND r.is_debit_only = TRUE
              AND r.txn_count >= 3
             THEN cfg.mobile_vpa_vendor_score ELSE 0 END
        +
        -- Provider small_merchant weight (IS-02)
        COALESCE(ps.provider_small_merchant_score, 0)
    )::INT                                               AS small_merchant_score,

    -- ── MERCHANT score ────────────────────────────────────────
    LEAST(100,
        -- RAZORPAY (IS-07: individual score)
        CASE WHEN r.any_razorpay = 1
             THEN cfg.razorpay_score ELSE 0 END
        +
        -- PAYU (IS-07)
        CASE WHEN r.any_payu = 1
             THEN cfg.payu_score ELSE 0 END
        +
        -- CASHFREE (IS-07)
        CASE WHEN r.any_cashfree = 1
             THEN cfg.cashfree_score ELSE 0 END
        +
        -- BILLPAY_SIGNAL (IS-09 — was missing entirely)
        CASE WHEN r.any_billpay = 1
             THEN cfg.billpay_score ELSE 0 END
        +
        -- CORPORATE_PROVIDER (IS-02)
        COALESCE(ps.provider_merchant_score, 0)
        +
        -- REPEATED_TRANSACTION: seen ≥ 2 times
        CASE WHEN r.txn_count >= 2
             THEN cfg.repeated_txn_score ELSE 0 END
        +
        -- DEBIT_ONLY_PATTERN (IS-06)
        CASE WHEN r.is_debit_only = TRUE
             THEN cfg.debit_only_merchant_score ELSE 0 END
        +
        -- NON_MOBILE_VPA
        CASE WHEN r.counterparty_key !~ '^[0-9]{10}(@|$)'
             THEN cfg.non_mobile_vpa_score ELSE 0 END
    )::INT                                               AS merchant_score,

    -- Carry provider metadata through
    COALESCE(ps.dominant_provider_type, 'NEUTRAL')       AS dominant_provider_type

FROM spendsense.vw_upi_counterparty_rollup r
CROSS JOIN cfg
LEFT JOIN spendsense.vw_upi_provider_scores ps
    ON ps.user_id = r.user_id
    AND ps.counterparty_key = r.counterparty_key;

COMMENT ON VIEW spendsense.vw_upi_entity_scoring IS
'Computes all four entity scores using signal weights from ref_upi_classifier_config.
 All 22 signals from spec are now implemented.';

-- ============================================================
-- STEP 6 — FINAL ENTITY CLASSIFICATION
-- Uses max-above-threshold approach as per specification.
-- Tie-breaking: SELF > PERSON > SMALL_MERCHANT > MERCHANT > UNKNOWN
-- Major handle match short-circuits to MERCHANT instantly.
-- ============================================================

CREATE OR REPLACE VIEW spendsense.vw_upi_entity_final AS
WITH thresholds AS (
    SELECT
        MAX(CASE WHEN config_key = 'SELF_ACCOUNT_THRESHOLD'   THEN config_value END) AS self_thr,
        MAX(CASE WHEN config_key = 'PERSON_THRESHOLD'          THEN config_value END) AS person_thr,
        MAX(CASE WHEN config_key = 'SMALL_MERCHANT_THRESHOLD'  THEN config_value END) AS small_thr,
        MAX(CASE WHEN config_key = 'MERCHANT_THRESHOLD'        THEN config_value END) AS merchant_thr
    FROM spendsense.ref_upi_classifier_config
)
SELECT
    s.user_id,
    s.counterparty_key,
    s.self_account_score,
    s.person_score,
    s.small_merchant_score,
    s.merchant_score,
    s.dominant_provider_type,
    s.matched_handle_pattern,

    -- Classification: major handle short-circuit → then max-score-wins
    CASE
        -- Direct brand match: MERCHANT without scoring
        WHEN s.matched_handle_pattern IS NOT NULL
             THEN 'MERCHANT'

        -- Max-score above threshold (document spec: highest valid score wins)
        WHEN GREATEST(
                CASE WHEN s.self_account_score  >= t.self_thr    THEN s.self_account_score  ELSE 0 END,
                CASE WHEN s.person_score         >= t.person_thr  THEN s.person_score         ELSE 0 END,
                CASE WHEN s.small_merchant_score >= t.small_thr   THEN s.small_merchant_score ELSE 0 END,
                CASE WHEN s.merchant_score        >= t.merchant_thr THEN s.merchant_score      ELSE 0 END
             ) = 0
             THEN 'UNKNOWN_MERCHANT'

        -- Among qualifying classes pick the highest score (tie-break: SELF > PERSON > SMALL > MERCHANT)
        WHEN s.self_account_score >= t.self_thr
         AND s.self_account_score = GREATEST(
                CASE WHEN s.self_account_score  >= t.self_thr    THEN s.self_account_score  ELSE 0 END,
                CASE WHEN s.person_score         >= t.person_thr  THEN s.person_score         ELSE 0 END,
                CASE WHEN s.small_merchant_score >= t.small_thr   THEN s.small_merchant_score ELSE 0 END,
                CASE WHEN s.merchant_score        >= t.merchant_thr THEN s.merchant_score      ELSE 0 END)
             THEN 'SELF_ACCOUNT'

        WHEN s.person_score >= t.person_thr
         AND s.person_score = GREATEST(
                CASE WHEN s.person_score         >= t.person_thr  THEN s.person_score         ELSE 0 END,
                CASE WHEN s.small_merchant_score >= t.small_thr   THEN s.small_merchant_score ELSE 0 END,
                CASE WHEN s.merchant_score        >= t.merchant_thr THEN s.merchant_score      ELSE 0 END)
             THEN 'PERSON'

        WHEN s.small_merchant_score >= t.small_thr
         AND s.small_merchant_score = GREATEST(
                CASE WHEN s.small_merchant_score >= t.small_thr   THEN s.small_merchant_score ELSE 0 END,
                CASE WHEN s.merchant_score        >= t.merchant_thr THEN s.merchant_score      ELSE 0 END)
             THEN 'SMALL_MERCHANT'

        WHEN s.merchant_score >= t.merchant_thr
             THEN 'MERCHANT'

        ELSE 'UNKNOWN_MERCHANT'
    END AS entity_type

FROM spendsense.vw_upi_entity_scoring s
CROSS JOIN thresholds t;

COMMENT ON VIEW spendsense.vw_upi_entity_final IS
'Determines entity type using max-score-above-threshold (per spec).
 Major handle match short-circuits to MERCHANT instantly.
 Tie-breaking favours SELF > PERSON > SMALL_MERCHANT > MERCHANT.';

-- ============================================================
-- STEP 7 — UPI CLASSIFIER PER-TRANSACTION OUTPUT VIEW
-- Joins entity classification back to individual transactions.
-- IS-04: fan-out eliminated — major handle already resolved in
--        vw_upi_struct_features via LATERAL LIMIT 1.
-- ============================================================

CREATE OR REPLACE VIEW spendsense.vw_upi_for_rulebooks AS
SELECT
    f.txn_id,
    f.user_id,
    f.upload_id,
    COALESCE(NULLIF(f.vpa, ''), f.vpa_handle)  AS counterparty_key,
    f.vpa_provider,

    e.entity_type                               AS upi_classified,
    e.person_score,
    e.self_account_score,
    e.small_merchant_score,
    e.merchant_score,
    e.dominant_provider_type,

    -- Major handle brand data (already deduped in feature view)
    COALESCE(f.merchant_label,   e.matched_handle_pattern)  AS merchant_label,
    f.merchant_category,
    f.merchant_subcategory

FROM spendsense.vw_upi_struct_features f
LEFT JOIN spendsense.vw_upi_entity_final e
    ON f.user_id = e.user_id
    AND COALESCE(NULLIF(f.vpa, ''), f.vpa_handle) = e.counterparty_key;

COMMENT ON VIEW spendsense.vw_upi_for_rulebooks IS
'Per-transaction output. IS-04: no LIKE fan-out — handle resolved upstream.
 user_id scoping maintained throughout.';

-- ============================================================
-- STEP 8 — OUTPUT TABLE  (IS-03, IS-09)
-- IS-03: DROP TABLE replaced with safe CREATE IF NOT EXISTS +
--        TRUNCATE per upload_id (not global wipe)
-- IS-09: Primary key, upload_id, timestamps added
-- ============================================================

CREATE TABLE IF NOT EXISTS spendsense.txn_parsed_UPI_updated (
    -- All columns from txn_parsed carried through
    txn_id              UUID        NOT NULL,
    user_id             TEXT        NOT NULL,
    upload_id           UUID,                   -- IS-09: batch filter column
    txn_date            DATE,
    amount              NUMERIC(18,2),
    cr_dr               CHAR(1),
    payment_channel     TEXT,
    raw_description     TEXT,
    -- ... remaining txn_parsed columns added via the insert below

    -- UPI classification columns
    upi_classified      TEXT,
    person_score        INT,
    self_account_score  INT,
    small_merchant_score INT,
    merchant_score      INT,
    dominant_provider_type TEXT,
    merchant_label      TEXT,
    merchant_category   TEXT,
    merchant_subcategory TEXT,
    counterparty_key    TEXT,
    vpa_provider        TEXT,

    -- Audit columns
    classified_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    -- IS-09: Primary key prevents duplicate rows
    CONSTRAINT pk_txn_parsed_UPI_updated PRIMARY KEY (txn_id)
);

-- Indexes (all IF NOT EXISTS — IS-03 / IS-09)
CREATE INDEX IF NOT EXISTS ix_txn_upi_upd_user
    ON spendsense.txn_parsed_UPI_updated(user_id);

CREATE INDEX IF NOT EXISTS ix_txn_upi_upd_upload
    ON spendsense.txn_parsed_UPI_updated(upload_id);

CREATE INDEX IF NOT EXISTS ix_txn_upi_upd_entity
    ON spendsense.txn_parsed_UPI_updated(upi_classified);

CREATE INDEX IF NOT EXISTS ix_txn_upi_upd_date
    ON spendsense.txn_parsed_UPI_updated(txn_date DESC);

CREATE INDEX IF NOT EXISTS ix_txn_upi_upd_user_entity
    ON spendsense.txn_parsed_UPI_updated(user_id, upi_classified);

COMMENT ON TABLE spendsense.txn_parsed_UPI_updated IS
'UPI-enriched transaction table. v2: has PK, upload_id, per-user scoring.
 Populated via populate_txn_parsed_UPI_updated(). Never use DROP TABLE.';

-- ============================================================
-- STEP 9 — POPULATE FUNCTION  (IS-03)
-- Replaces DROP TABLE + CREATE TABLE AS SELECT.
-- Two modes:
--   (a) upload_id supplied → process only this batch
--   (b) upload_id NULL    → full rebuild (admin use only)
-- Uses INSERT ... ON CONFLICT DO UPDATE (upsert) — safe to re-run.
-- ============================================================

CREATE OR REPLACE FUNCTION spendsense.populate_txn_parsed_UPI_updated(
    p_upload_id UUID DEFAULT NULL
)
RETURNS TABLE (
    rows_upserted   BIGINT,
    rows_upi        BIGINT,
    rows_non_upi    BIGINT
)
LANGUAGE plpgsql
AS $$
DECLARE
    v_rows_upserted BIGINT := 0;
    v_rows_upi      BIGINT := 0;
    v_rows_non_upi  BIGINT := 0;
BEGIN
    -- ── Upsert UPI transactions with full classification ──────
    INSERT INTO spendsense.txn_parsed_UPI_updated AS dest (
        txn_id, user_id, upload_id, txn_date, amount, cr_dr,
        payment_channel, raw_description,
        upi_classified, person_score, self_account_score,
        small_merchant_score, merchant_score,
        dominant_provider_type, merchant_label,
        merchant_category, merchant_subcategory,
        counterparty_key, vpa_provider,
        classified_at, updated_at
    )
    SELECT
        t.txn_id,
        t.user_id,
        t.upload_id,
        t.txn_date,
        t.amount,
        t.cr_dr,
        t.payment_channel,
        t.raw_description,
        u.upi_classified,
        u.person_score,
        u.self_account_score,
        u.small_merchant_score,
        u.merchant_score,
        u.dominant_provider_type,
        u.merchant_label,
        u.merchant_category,
        u.merchant_subcategory,
        u.counterparty_key,
        u.vpa_provider,
        NOW(),
        NOW()
    FROM spendsense.txn_parsed t
    JOIN spendsense.vw_upi_for_rulebooks u
        ON t.txn_id = u.txn_id
    WHERE t.payment_channel = 'UPI'
      AND (p_upload_id IS NULL OR t.upload_id = p_upload_id)
    ON CONFLICT (txn_id) DO UPDATE SET
        upi_classified       = EXCLUDED.upi_classified,
        person_score         = EXCLUDED.person_score,
        self_account_score   = EXCLUDED.self_account_score,
        small_merchant_score = EXCLUDED.small_merchant_score,
        merchant_score       = EXCLUDED.merchant_score,
        dominant_provider_type = EXCLUDED.dominant_provider_type,
        merchant_label       = EXCLUDED.merchant_label,
        merchant_category    = EXCLUDED.merchant_category,
        merchant_subcategory = EXCLUDED.merchant_subcategory,
        counterparty_key     = EXCLUDED.counterparty_key,
        updated_at           = NOW();

    GET DIAGNOSTICS v_rows_upi = ROW_COUNT;

    -- ── Upsert non-UPI transactions (classification NULLs) ───
    INSERT INTO spendsense.txn_parsed_UPI_updated AS dest (
        txn_id, user_id, upload_id, txn_date, amount, cr_dr,
        payment_channel, raw_description,
        upi_classified, classified_at, updated_at
    )
    SELECT
        t.txn_id, t.user_id, t.upload_id,
        t.txn_date, t.amount, t.cr_dr,
        t.payment_channel, t.raw_description,
        NULL,   -- non-UPI rows get no classification
        NOW(), NOW()
    FROM spendsense.txn_parsed t
    WHERE t.payment_channel <> 'UPI'
      AND (p_upload_id IS NULL OR t.upload_id = p_upload_id)
    ON CONFLICT (txn_id) DO NOTHING;  -- non-UPI rows don't change

    GET DIAGNOSTICS v_rows_non_upi = ROW_COUNT;
    v_rows_upserted := v_rows_upi + v_rows_non_upi;

    RETURN QUERY SELECT v_rows_upserted, v_rows_upi, v_rows_non_upi;
END;
$$;

COMMENT ON FUNCTION spendsense.populate_txn_parsed_UPI_updated IS
'Safe upsert-based populate. Pass upload_id to process one batch.
 Pass NULL to rebuild all (admin/backfill use).
 Never drops or truncates the table.
 Example: SELECT * FROM populate_txn_parsed_UPI_updated(''<upload_uuid>'');';

-- ============================================================
-- STEP 10 — DIAGNOSTIC VIEWS
-- For validators, analysts, and monitoring.
-- ============================================================

-- Entity distribution per upload
CREATE OR REPLACE VIEW spendsense.vw_upi_classification_summary AS
SELECT
    upload_id,
    upi_classified,
    COUNT(*)                                         AS txn_count,
    ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (PARTITION BY upload_id), 2)
                                                     AS pct_share,
    ROUND(AVG(merchant_score), 1)                    AS avg_merchant_score,
    ROUND(AVG(person_score), 1)                      AS avg_person_score
FROM spendsense.txn_parsed_UPI_updated
WHERE payment_channel = 'UPI'
GROUP BY upload_id, upi_classified
ORDER BY upload_id, txn_count DESC;

-- Score inspection for a specific counterparty (debugging)
CREATE OR REPLACE VIEW spendsense.vw_upi_counterparty_debug AS
SELECT
    e.user_id,
    e.counterparty_key,
    e.entity_type,
    e.self_account_score,
    e.person_score,
    e.small_merchant_score,
    e.merchant_score,
    e.dominant_provider_type,
    e.matched_handle_pattern,
    r.txn_count,
    r.debit_count,
    r.credit_count,
    r.median_debit_amt,
    r.is_bidirectional,
    r.is_debit_only,
    r.any_paytm_qr,
    r.any_bharatpe_qr,
    r.any_razorpay,
    r.any_payu,
    r.any_cashfree,
    r.any_billpay,
    r.any_self_wording,
    r.any_name_prefix,
    r.providers_seen
FROM spendsense.vw_upi_entity_final e
JOIN spendsense.vw_upi_counterparty_rollup r
    ON r.user_id = e.user_id
    AND r.counterparty_key = e.counterparty_key;

-- Monitoring: flag anomalies
CREATE OR REPLACE VIEW spendsense.vw_upi_classification_anomalies AS
WITH dist AS (
    SELECT
        upload_id,
        ROUND(100.0 * COUNT(*) FILTER (WHERE upi_classified = 'PERSON')
              / NULLIF(COUNT(*) FILTER (WHERE payment_channel='UPI'), 0), 2)
                                    AS person_pct,
        ROUND(100.0 * COUNT(*) FILTER (WHERE upi_classified = 'UNKNOWN_MERCHANT')
              / NULLIF(COUNT(*) FILTER (WHERE payment_channel='UPI'), 0), 2)
                                    AS unknown_pct,
        ROUND(100.0 * COUNT(*) FILTER (WHERE upi_classified = 'SELF_ACCOUNT')
              / NULLIF(COUNT(*) FILTER (WHERE payment_channel='UPI'), 0), 2)
                                    AS self_pct
    FROM spendsense.txn_parsed_UPI_updated
    GROUP BY upload_id
)
SELECT
    upload_id,
    person_pct,
    unknown_pct,
    self_pct,
    CASE WHEN person_pct  < 40   THEN 'WARN: PERSON below 40% — provider intel may be broken' END AS person_alert,
    CASE WHEN unknown_pct > 15   THEN 'WARN: UNKNOWN_MERCHANT above 15% — add handle registry entries' END AS unknown_alert,
    CASE WHEN self_pct    > 8    THEN 'WARN: SELF_ACCOUNT above 8% — self-wording regex may be too broad' END AS self_alert
FROM dist
WHERE person_pct < 40 OR unknown_pct > 15 OR self_pct > 8;

COMMENT ON VIEW spendsense.vw_upi_classification_summary IS 'Per-upload classification distribution. Run after each batch.';
COMMENT ON VIEW spendsense.vw_upi_counterparty_debug     IS 'All signals and scores for a specific counterparty. Use for debugging misclassifications.';
COMMENT ON VIEW spendsense.vw_upi_classification_anomalies IS 'Flags uploads where distribution falls outside expected ranges.';

COMMIT;

-- ============================================================
-- HOW TO RUN
-- ============================================================
--
-- First time setup (runs migrations only — no data processing):
--   BEGIN; [run this entire file]; COMMIT;
--
-- Process a specific upload:
--   SELECT * FROM spendsense.populate_txn_parsed_UPI_updated('<upload_uuid>');
--
-- Full rebuild (all historical data — admin use only):
--   SELECT * FROM spendsense.populate_txn_parsed_UPI_updated(NULL);
--
-- Monitor results:
--   SELECT * FROM spendsense.vw_upi_classification_summary WHERE upload_id = '<upload_uuid>';
--   SELECT * FROM spendsense.vw_upi_classification_anomalies;
--
-- Debug a specific counterparty:
--   SELECT * FROM spendsense.vw_upi_counterparty_debug
--   WHERE user_id = '<uid>' AND counterparty_key = '9876543210@ybl';
--
-- Tune a score without code change:
--   UPDATE spendsense.ref_upi_classifier_config
--   SET config_value = 50  -- raise PERSON threshold
--   WHERE config_key = 'PERSON_THRESHOLD';
--   -- Then re-run populate for affected uploads
--
-- Add a new merchant handle:
--   INSERT INTO spendsense.ref_upi_major_handle
--   (handle_pattern, merchant_label, merchant_category, merchant_subcategory)
--   VALUES ('newbrand', 'NEW BRAND', 'Shopping', 'Ecommerce');
--   -- Effective on next populate run — no view refresh needed
--
-- Disable a merchant handle without deleting:
--   UPDATE spendsense.ref_upi_major_handle
--   SET is_active = FALSE WHERE handle_pattern = 'oldhandle';
--
-- Add a new UPI provider:
--   INSERT INTO spendsense.ref_upi_provider_type
--   (provider_code, provider_type, person_weight, merchant_weight)
--   VALUES ('newprovider', 'CONSUMER', 20, 0);
-- ============================================================
