-- ============================================================
-- MONYTIX  —  UPI STRUCTURAL CLASSIFIER  v3.0
-- Complete rewrite addressing all v2 bugs + new Tier 0 gate.
--
-- INPUT  : spendsense.txn_parsed
-- OUTPUT : spendsense.txn_upi_classified
--
-- Entity types produced:
--   SELF_ACCOUNT | PERSON | SMALL_MERCHANT | MERCHANT | UNKNOWN_MERCHANT
--
-- What changed from v2:
--   FIX-01  payment_channel → channel_type throughout
--   FIX-02  VPA sourced from counterparty_vpa (already validated by parser),
--           not re-extracted from raw_description
--   FIX-03  NEW Tier 0 gate: fn_upi_bank_signal() reads parse_format
--           and short-circuits before scoring engine fires
--   FIX-04  NEW ref_upi_p2a_name_patterns registry for P2A name probe
--           (JYOTI INDUSTRIES → MERCHANT, ARJUN KAI → PERSON)
--   FIX-05  bank_confirmed_type added to output table for traceability
--   FIX-06  Output table renamed txn_upi_classified (clean break from v2)
--   FIX-07  All v2 IS-xx fixes retained (provider weights, median,
--           bidirectional flags, fan-out guard, etc.)
--
-- Classification tiers (in priority order):
--   Tier 0 — Bank-confirmed: parse_format + P2A name probe
--   Tier 1 — Major handle registry: brand direct-match
--   Tier 2 — Scoring engine: four-dimension signal scorer
--   Tier 3 — Threshold decision: max-score-above-threshold
-- ============================================================

BEGIN;

SET search_path = spendsense, public;

-- ============================================================
-- STEP 0A — SCORING CONSTANTS  (unchanged from v2)
-- ============================================================

CREATE TABLE IF NOT EXISTS spendsense.ref_upi_classifier_config (
    config_key   TEXT PRIMARY KEY,
    config_value NUMERIC NOT NULL,
    description  TEXT
);

INSERT INTO spendsense.ref_upi_classifier_config
    (config_key, config_value, description)
VALUES
-- Thresholds
('SELF_ACCOUNT_THRESHOLD',   60,  'Min self_account_score to classify as SELF_ACCOUNT'),
('PERSON_THRESHOLD',         55,  'Min person_score to classify as PERSON'),
('SMALL_MERCHANT_THRESHOLD', 55,  'Min small_merchant_score to classify as SMALL_MERCHANT'),
('MERCHANT_THRESHOLD',       50,  'Min merchant_score to classify as MERCHANT'),
-- Self signals
('SELF_WORDING_SCORE',      100,  'Description contains self/own account/self transfer'),
('BIDIRECTIONAL_SCORE',      35,  'Counterparty appears in both debit and credit flows'),
('ROUND_TRIP_SCORE',         25,  'Debit and credit repeated multiple times'),
('NO_MERCHANT_SIGNAL_SELF',  10,  'No QR or gateway signals — adds to SELF score'),
-- Person signals
('MOBILE_VPA_SCORE',         45,  'VPA handle is 10-digit mobile number'),
('NAME_PREFIX_SCORE',        20,  'Human name token detected before VPA'),
('NO_MERCHANT_SIGNAL_PERSON',10,  'No QR or gateway signals — adds to PERSON score'),
('LOW_REPEAT_SCORE',          5,  'debit_count <= 5 and no credit transactions'),
-- Small merchant signals
('PAYTM_QR_SCORE',           55,  'Paytm QR pattern in description'),
('BHARATPE_QR_SCORE',        45,  'BharatPe QR pattern in description'),
('OTHER_QR_SCORE',           30,  'Generic QR pattern (not Paytm or BharatPe)'),
('SMALL_TICKET_SCORE',       15,  'Median debit amount <= 300 INR'),
('DEBIT_ONLY_SMALL_SCORE',   15,  'All transactions are debits (small merchant context)'),
('MOBILE_VPA_VENDOR_SCORE',   5,  'Mobile VPA used in apparent merchant context'),
-- Merchant signals
('RAZORPAY_SCORE',           35,  'Razorpay gateway detected'),
('PAYU_SCORE',               35,  'PayU gateway detected'),
('CASHFREE_SCORE',           35,  'Cashfree gateway detected'),
('BILLPAY_SCORE',            25,  'BBPS / bill payment pattern detected'),
('REPEATED_TXN_SCORE',       10,  'txn_count >= 2 with same counterparty'),
('DEBIT_ONLY_MERCHANT_SCORE',10,  'All transactions are debits (merchant context)'),
('NON_MOBILE_VPA_SCORE',     10,  'VPA handle is NOT a mobile number'),
-- Ticket size threshold
('SMALL_TICKET_MEDIAN_MAX', 300,  'Median debit below this is a small-ticket signal')
ON CONFLICT (config_key) DO UPDATE
    SET config_value = EXCLUDED.config_value,
        description  = EXCLUDED.description;

-- ============================================================
-- STEP 0B — NEW: P2A NAME PATTERN REGISTRY  (FIX-03, FIX-04)
--
-- Drives the Tier 0 P2A name probe.
-- When parse_format = 'UPI_P2A_SLASH', counterparty_name is
-- matched against these patterns to split MERCHANT from PERSON.
--
-- pattern_type:
--   MERCHANT — business keyword → classify as MERCHANT
--   PERSON   — personal transfer keyword → classify as PERSON
--   SELF     — own-account transfer keyword → SELF_ACCOUNT
--
-- match_regex: applied case-insensitively to counterparty_name
-- confidence:  passed through to bank_confirmed_confidence
-- priority:    lower = checked first; first match wins
-- ============================================================

CREATE TABLE IF NOT EXISTS spendsense.ref_upi_p2a_name_patterns (
    pattern_id    SERIAL PRIMARY KEY,
    match_regex   TEXT    NOT NULL UNIQUE,
    pattern_type  TEXT    NOT NULL
                      CHECK (pattern_type IN ('MERCHANT','PERSON','SELF')),
    confidence    NUMERIC(4,2) NOT NULL DEFAULT 0.90,
    priority      INT     NOT NULL DEFAULT 100,
    notes         TEXT,
    is_active     BOOLEAN NOT NULL DEFAULT TRUE,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS ix_p2a_name_priority
    ON spendsense.ref_upi_p2a_name_patterns(priority, pattern_id)
    WHERE is_active = TRUE;

-- Seed: MERCHANT keywords  (business entity indicators)
INSERT INTO spendsense.ref_upi_p2a_name_patterns
    (match_regex, pattern_type, confidence, priority, notes)
VALUES
-- Legal entity suffixes — very high confidence
('\bPVT\.?\s*LTD\b',         'MERCHANT', 0.98, 10, 'Private limited company'),
('\bLIMITED\b',              'MERCHANT', 0.97, 11, 'Public/private limited'),
('\bLLP\b',                  'MERCHANT', 0.97, 12, 'Limited liability partnership'),
('\bINC\b',                  'MERCHANT', 0.95, 13, 'Incorporated'),
('\bCORP\b',                 'MERCHANT', 0.95, 14, 'Corporation'),
('\bPARTNERSHIP\b',          'MERCHANT', 0.93, 15, 'Partnership firm'),
-- Business type keywords
('\bINDUSTRIES\b',           'MERCHANT', 0.92, 20, 'e.g. JYOTI INDUSTRIES'),
('\bINDUSTRY\b',             'MERCHANT', 0.92, 21, NULL),
('\bTRADERS?\b',             'MERCHANT', 0.92, 22, 'Traders / Trader'),
('\bTRADING\b',              'MERCHANT', 0.92, 23, NULL),
('\bENTERPRISES?\b',         'MERCHANT', 0.92, 24, 'Enterprise / Enterprises'),
('\bSOLUTIONS?\b',           'MERCHANT', 0.88, 25, NULL),
('\bSERVICES?\b',            'MERCHANT', 0.85, 26, NULL),
('\bAGENCY\b',               'MERCHANT', 0.88, 27, NULL),
('\bAGENCIES\b',             'MERCHANT', 0.88, 28, NULL),
('\bSUPPLIERS?\b',           'MERCHANT', 0.88, 29, NULL),
('\bDISTRIBUTORS?\b',        'MERCHANT', 0.90, 30, NULL),
('\bDEALERS?\b',             'MERCHANT', 0.88, 31, NULL),
('\bSTORES?\b',              'MERCHANT', 0.82, 35, 'Shop / store names'),
('\bSHOPS?\b',               'MERCHANT', 0.82, 36, NULL),
('\bMARKET\b',               'MERCHANT', 0.80, 37, NULL),
('\bMART\b',                 'MERCHANT', 0.82, 38, NULL),
('\bBAZAAR\b',               'MERCHANT', 0.82, 39, NULL),
('\bSTEEL\b',                'MERCHANT', 0.88, 40, 'Steel / metals business'),
('\bCEMENT\b',               'MERCHANT', 0.88, 41, NULL),
('\bCONSTRUCTION\b',         'MERCHANT', 0.90, 42, NULL),
('\bBUILDERS?\b',            'MERCHANT', 0.88, 43, NULL),
('\bDEVELOPERS?\b',          'MERCHANT', 0.85, 44, NULL),
('\bINFRASTRUCTURE\b',       'MERCHANT', 0.90, 45, NULL),
('\bCONSULTANCY\b',          'MERCHANT', 0.88, 46, NULL),
('\bCONSULTING\b',           'MERCHANT', 0.88, 47, NULL),
('\bTECHNOLOGY\b',           'MERCHANT', 0.88, 48, NULL),
('\bTECH\b',                 'MERCHANT', 0.80, 49, NULL),
('\bFINANCE\b',              'MERCHANT', 0.85, 50, NULL),
('\bCAPITAL\b',              'MERCHANT', 0.85, 51, NULL),
('\bINVESTMENTS?\b',         'MERCHANT', 0.83, 52, NULL),
('\bGROUP\b',                'MERCHANT', 0.80, 55, 'Corporate group'),
('\bFOODS?\b',               'MERCHANT', 0.82, 60, 'Food business'),
('\bCAFE\b',                 'MERCHANT', 0.85, 61, NULL),
('\bRESTAURANT\b',           'MERCHANT', 0.88, 62, NULL),
('\bHOTEL\b',                'MERCHANT', 0.85, 63, NULL),
('\bHOSPITAL\b',             'MERCHANT', 0.88, 64, NULL),
('\bCLINIC\b',               'MERCHANT', 0.85, 65, NULL),
('\bPHARMA\b',               'MERCHANT', 0.88, 66, NULL),
('\bMEDICAL\b',              'MERCHANT', 0.85, 67, NULL),
('\bPACKAGING\b',            'MERCHANT', 0.88, 68, NULL),
('\bMFG\b',                  'MERCHANT', 0.88, 69, 'Manufacturing abbreviation'),
('\bMFRS?\b',                'MERCHANT', 0.88, 70, NULL),
('\bEXPORTS?\b',             'MERCHANT', 0.88, 71, NULL),
('\bIMPORTS?\b',             'MERCHANT', 0.88, 72, NULL),
('\bLOGISTICS\b',            'MERCHANT', 0.90, 73, NULL),
('\bTRANSPORT\b',            'MERCHANT', 0.85, 74, NULL),
('\bCARGO\b',                'MERCHANT', 0.85, 75, NULL),

-- PERSON keywords — bank narration patterns indicating P2P intent
('^SENT USI$',               'PERSON',   0.95, 10, 'HDFC P2A narration for person transfers'),
('^SEND USI$',               'PERSON',   0.95, 11, NULL),
('^BENEFICIARY$',            'PERSON',   0.88, 20, NULL),
('^TRANSFER$',               'PERSON',   0.80, 25, NULL),

-- SELF keywords — own-account transfers
('^SELF$',                   'SELF',     0.99, 10, NULL),
('^OWN\s+A/?C$',             'SELF',     0.99, 11, NULL),
('^OWN\s+ACCOUNT$',          'SELF',     0.99, 12, NULL),
('^SELF\s+TRANSFER$',        'SELF',     0.99, 13, NULL),
('^SELF\s+A/?C$',            'SELF',     0.99, 14, NULL)

ON CONFLICT (match_regex) DO UPDATE
    SET pattern_type = EXCLUDED.pattern_type,
        confidence   = EXCLUDED.confidence,
        priority     = EXCLUDED.priority,
        notes        = EXCLUDED.notes;

-- ============================================================
-- STEP 1A — PROVIDER INTELLIGENCE  (unchanged from v2)
-- ============================================================

CREATE TABLE IF NOT EXISTS spendsense.ref_upi_provider_type (
    provider_code           TEXT PRIMARY KEY,
    provider_type           TEXT NOT NULL
                                CHECK (provider_type IN ('CONSUMER','CORPORATE','QR','MIXED','NEUTRAL')),
    person_weight           INT  NOT NULL DEFAULT 0,
    merchant_weight         INT  NOT NULL DEFAULT 0,
    small_merchant_weight   INT  NOT NULL DEFAULT 0,
    is_active               BOOLEAN NOT NULL DEFAULT TRUE,
    notes                   TEXT
);

INSERT INTO spendsense.ref_upi_provider_type
    (provider_code, provider_type, person_weight, merchant_weight, small_merchant_weight, notes)
VALUES
('ybl',          'CONSUMER', 20, 0,  0,  'PhonePe'),
('ibl',          'CONSUMER', 20, 0,  0,  'PhonePe (older)'),
('axl',          'CONSUMER', 15, 0,  0,  'Google Pay via Axis'),
('okaxis',       'CONSUMER', 20, 0,  0,  'Google Pay'),
('oksbi',        'CONSUMER', 20, 0,  0,  'Google Pay via SBI'),
('okhdfcbank',   'CONSUMER', 20, 0,  0,  'Google Pay via HDFC'),
('okicici',      'CONSUMER', 20, 0,  0,  'Google Pay via ICICI'),
('upi',          'CONSUMER', 10, 0,  0,  'Generic UPI'),
('paytm',        'MIXED',    10, 10,  10, 'Paytm wallet'),
('pty',          'QR',        5, 0,  20,  'Paytm QR merchant'),
('ptys',         'QR',        5, 0,  20,  'Paytm QR merchant (secure)'),
('ptybl',        'QR',        5, 0,  20,  'Paytm QR merchant (bank-linked)'),
('icici',        'CORPORATE', 0, 25,  5,  'ICICI merchant UPI'),
('hdfcbank',     'CORPORATE', 0, 25,  5,  'HDFC merchant UPI'),
('hdfc',         'CORPORATE', 0, 20,  5,  'HDFC generic'),
('axisbank',     'CORPORATE', 0, 25,  5,  'Axis Bank merchant'),
('axisb',        'CORPORATE', 0, 20,  5,  'Axis Bank short code'),
('axb',          'CORPORATE', 0, 20,  5,  'Axis Bank alternate'),
('airtel',       'CORPORATE', 0, 20,  5,  'Airtel Payments Bank'),
('rxairtel',     'CORPORATE', 0, 25,  5,  'Airtel business'),
('payu',         'CORPORATE', 0, 30,  0,  'PayU gateway provider'),
('yesbankltd',   'CORPORATE', 0, 20, 10,  'Yes Bank merchant'),
('okbizaxis',    'CORPORATE', 0, 25,  0,  'Google Pay for Business'),
('jiomerchant',  'CORPORATE', 0, 25,  5,  'Jio merchant'),
('idfcnetc',     'CORPORATE', 0, 25,  0,  'IDFC FASTag/merchant'),
('fbpe',         'CORPORATE', 0, 20, 10,  'Federal Bank merchant'),
('yapl',         'CORPORATE', 0, 20,  5,  'Yes Bank alternate'),
('ikwik',        'CORPORATE', 0, 20,  5,  'IKwik merchant'),
('o',            'NEUTRAL',   5, 0,   0,  'BHIM / bank generic'),
('pt',           'NEUTRAL',   0, 5,  15,  'Paytm transit / misc'),
('hdfcb',        'NEUTRAL',   0, 10,  5,  'HDFC Bank generic')
ON CONFLICT (provider_code) DO UPDATE
    SET provider_type         = EXCLUDED.provider_type,
        person_weight         = EXCLUDED.person_weight,
        merchant_weight       = EXCLUDED.merchant_weight,
        small_merchant_weight = EXCLUDED.small_merchant_weight,
        notes                 = EXCLUDED.notes;

-- ============================================================
-- STEP 1B — MAJOR MERCHANT HANDLE REGISTRY  (unchanged from v2)
-- ============================================================

CREATE TABLE IF NOT EXISTS spendsense.ref_upi_major_handle (
    merchant_id          SERIAL PRIMARY KEY,
    handle_pattern       TEXT    NOT NULL UNIQUE,
    merchant_label       TEXT    NOT NULL,
    merchant_category    TEXT,
    merchant_subcategory TEXT,
    merchant_weight      INT     NOT NULL DEFAULT 25,
    is_active            BOOLEAN NOT NULL DEFAULT TRUE,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS ix_ref_upi_major_handle_pattern
    ON spendsense.ref_upi_major_handle(handle_pattern)
    WHERE is_active = TRUE;

INSERT INTO spendsense.ref_upi_major_handle
    (handle_pattern, merchant_label, merchant_category, merchant_subcategory, merchant_weight)
VALUES
('swiggystores',   'SWIGGY',           'Food',          'Food Delivery',    30),
('swiggy',         'SWIGGY',           'Food',          'Food Delivery',    30),
('zomato',         'ZOMATO',           'Food',          'Food Delivery',    30),
('blinkcommerce',  'BLINKIT',          'Groceries',     'Quick Commerce',   30),
('blinkit',        'BLINKIT',          'Groceries',     'Quick Commerce',   30),
('zeptonowltd',    'ZEPTO',            'Groceries',     'Quick Commerce',   30),
('zepto',          'ZEPTO',            'Groceries',     'Quick Commerce',   30),
('countrydelight', 'COUNTRY DELIGHT',  'Groceries',     'Milk & Dairy',     25),
('milkbasket',     'MILKBASKET',       'Groceries',     'Milk & Dairy',     25),
('bigbasket',      'BIGBASKET',        'Groceries',     'Online Grocery',   30),
('dmartready',     'DMART READY',      'Groceries',     'Supermarket',      30),
('cred.club',      'CRED',             'Financial',     'Card Payment',     30),
('cheq1',          'CHEQ',             'Financial',     'Card Payment',     30),
('credpay.',       'CRED PAY',         'Financial',     'Merchant Payment', 30),
('amazonpay',      'AMAZON',           'Shopping',      'Marketplace',      30),
('amazon',         'AMAZON',           'Shopping',      'Marketplace',      30),
('flipkart',       'FLIPKART',         'Shopping',      'Marketplace',      30),
('myntra',         'MYNTRA',           'Shopping',      'Fashion',          25),
('ajio',           'AJIO',             'Shopping',      'Fashion',          25),
('nykaa',          'NYKAA',            'Shopping',      'Beauty',           25),
('uber',           'UBER',             'Transport',     'Ride Hailing',     30),
('ola',            'OLA',              'Transport',     'Ride Hailing',     30),
('rapido',         'RAPIDO',           'Transport',     'Bike Taxi',        25),
('netc.',          'FASTAG',           'Transport',     'Toll',             25),
('irctc',          'IRCTC',            'Travel',        'Railways',         30),
('redbus',         'REDBUS',           'Travel',        'Bus Booking',      25),
('makemytrip',     'MAKEMYTRIP',       'Travel',        'Travel Booking',   30),
('goibibo',        'GOIBIBO',          'Travel',        'Travel Booking',   25),
('easemytrip',     'EASEMYTRIP',       'Travel',        'Travel Booking',   25),
('airtel',         'AIRTEL',           'Telecom',       'Mobile Recharge',  30),
('jio',            'JIO',              'Telecom',       'Mobile Recharge',  30),
('billdeskpg',     'BILLDESK',         'Financial',     'Bill Payment',     25),
('zerodha',        'ZERODHA',          'Investment',    'Broker',           30),
('groww',          'GROWW',            'Investment',    'Broker',           30),
('indmoneymf',     'INDMONEY MF',      'Investment',    'Mutual Fund',      25),
('netflix',        'NETFLIX',          'Entertainment', 'OTT',              25),
('spotify',        'SPOTIFY',          'Entertainment', 'Music',            25),
('bharatpe',       'BHARATPE',         'Infrastructure','QR Merchant',      20)
ON CONFLICT (handle_pattern) DO UPDATE
    SET merchant_label       = EXCLUDED.merchant_label,
        merchant_category    = EXCLUDED.merchant_category,
        merchant_subcategory = EXCLUDED.merchant_subcategory,
        merchant_weight      = EXCLUDED.merchant_weight;

COMMIT;

-- ============================================================
-- STEP 2 — TIER 0: BANK SIGNAL FUNCTION  (FIX-03, FIX-04)
--
-- Reads parse_format from txn_parsed and returns:
--   bank_confirmed_type       TEXT  — the short-circuit classification
--   bank_confirmed_confidence NUMERIC
--   bank_confirmed_reason     TEXT  — audit trail
--
-- Returns NULL bank_confirmed_type when no short-circuit applies
-- (row falls through to the scoring engine).
--
-- Called per-row from vw_upi_struct_features.
-- ============================================================

BEGIN;

CREATE OR REPLACE FUNCTION spendsense.fn_upi_bank_signal(
    p_parse_format      TEXT,   -- from txn_parsed.parse_format
    p_counterparty_name TEXT,   -- from txn_parsed.counterparty_name
    p_merchant_name     TEXT,   -- from txn_parsed.merchant_name
    p_normalized_desc   TEXT    -- from txn_parsed.normalized_description
)
RETURNS TABLE (
    bank_confirmed_type       TEXT,
    bank_confirmed_confidence NUMERIC,
    bank_confirmed_reason     TEXT
)
LANGUAGE plpgsql STABLE AS $$
DECLARE
    v_name        TEXT;
    v_pat         RECORD;
    v_conf        NUMERIC;
    v_reason      TEXT;
BEGIN
    -- ── Case 1: REV_DASH — always a reversal, never classify ──
    IF p_parse_format = 'REV_DASH' THEN
        RETURN QUERY SELECT 'SKIP'::TEXT, 0.99::NUMERIC, 'Reversal transaction'::TEXT;
        RETURN;
    END IF;

    -- ── Case 2: UPI_P2M_SLASH — bank explicitly labels as merchant ──
    -- P2M = Person to Merchant; this is the strongest possible signal
    IF p_parse_format = 'UPI_P2M_SLASH' THEN
        IF p_merchant_name IS NOT NULL THEN
            RETURN QUERY SELECT
                'MERCHANT'::TEXT,
                0.97::NUMERIC,
                ('P2M format, merchant_name=' || p_merchant_name)::TEXT;
        ELSE
            RETURN QUERY SELECT
                'MERCHANT'::TEXT,
                0.90::NUMERIC,
                'P2M format confirmed by bank (merchant_name unparsed)'::TEXT;
        END IF;
        RETURN;
    END IF;

    -- ── Case 3: UPI_P2A_SLASH — bank says account transfer ──
    -- P2A can be: PERSON, SELF_ACCOUNT, or MERCHANT (business a/c)
    -- Probe the counterparty name against the pattern registry.
    IF p_parse_format IN ('UPI_P2A_SLASH', 'IMPS_P2A_SLASH') THEN
        -- Use merchant_name if present, else counterparty_name
        v_name := UPPER(TRIM(COALESCE(
            NULLIF(p_merchant_name, ''),
            NULLIF(p_counterparty_name, ''),
            ''
        )));

        IF v_name <> '' THEN
            -- First match wins (ordered by priority ASC)
            SELECT pat.pattern_type, pat.confidence
            INTO v_pat
            FROM spendsense.ref_upi_p2a_name_patterns pat
            WHERE pat.is_active = TRUE
              AND v_name ~* pat.match_regex
            ORDER BY pat.priority ASC, pat.pattern_id ASC
            LIMIT 1;

            IF FOUND THEN
                RETURN QUERY SELECT
                    v_pat.pattern_type::TEXT,
                    v_pat.confidence::NUMERIC,
                    ('P2A name probe matched: ' || v_name)::TEXT;
                RETURN;
            END IF;
        END IF;

        -- No name pattern matched — fall through to check description
        -- Check for self-wording in description directly
        IF p_normalized_desc ~*
            '(self[\s_-]?transfer|own[\s_-]?account|transfer[\s_-]?to[\s_-]?self|self[\s_-]?a/c)'
        THEN
            RETURN QUERY SELECT
                'SELF_ACCOUNT'::TEXT,
                0.92::NUMERIC,
                'P2A with self-wording in description'::TEXT;
            RETURN;
        END IF;

        -- P2A with no name match — default to PERSON (account transfer, unknown name)
        -- This is intentionally conservative: treat unknown P2A as person
        -- until the name registry grows
        RETURN QUERY SELECT
            'PERSON'::TEXT,
            0.72::NUMERIC,
            'P2A format, no business keyword found in name — defaulting to PERSON'::TEXT;
        RETURN;
    END IF;

    -- ── Case 4: UPI_CRDRREV_SLASH with REV direction ──
    IF p_parse_format = 'UPI_CRDRREV_SLASH'
       AND p_normalized_desc ~* '^UPI/REV/' THEN
        RETURN QUERY SELECT 'SKIP'::TEXT, 0.98::NUMERIC, 'UPI reversal (CR/DR/REV slash)'::TEXT;
        RETURN;
    END IF;

    -- ── No short-circuit — fall through to scoring engine ──
    RETURN QUERY SELECT NULL::TEXT, NULL::NUMERIC, NULL::TEXT;
    RETURN;
END;
$$;

COMMENT ON FUNCTION spendsense.fn_upi_bank_signal IS
'Tier 0 gate. Reads parse_format from txn_parsed to short-circuit classification
 before the scoring engine fires.
 Returns NULL bank_confirmed_type when no match — row enters scoring tier.
 P2M → MERCHANT (always). P2A → name probe via ref_upi_p2a_name_patterns.
 REV → SKIP (excluded from output). Others → NULL (score normally).';

COMMIT;

-- ============================================================
-- STEP 3 — STRUCTURAL FEATURE EXTRACTION  (FIX-01, FIX-02)
--
-- FIX-01: channel_type replaces payment_channel throughout
-- FIX-02: VPA sourced from counterparty_vpa (validated by parser),
--         not re-extracted from raw_description
-- ============================================================

BEGIN;

CREATE OR REPLACE VIEW spendsense.vw_upi_struct_features AS
SELECT
    t.fact_txn_id                                           AS txn_id,
    t.user_id,
    t.txn_date,
    t.amount,
    t.cr_dr,
    t.channel_type,                          -- FIX-01: was payment_channel
    t.raw_description,
    t.normalized_description,
    t.upload_id,
    t.parse_format,
    t.counterparty_name,
    t.merchant_name,

    -- FIX-02: use already-validated VPA from parser output
    -- fall back to re-extraction only when counterparty_vpa is NULL
    COALESCE(
        NULLIF(LOWER(TRIM(t.counterparty_vpa)), ''),
        LOWER(COALESCE(
            (regexp_match(t.normalized_description,
                '([A-Za-z0-9._%-]+@[A-Za-z0-9._%-]+)'))[1],
            ''
        ))
    )                                                       AS vpa,

    split_part(
        COALESCE(
            NULLIF(LOWER(TRIM(t.counterparty_vpa)), ''),
            LOWER(COALESCE(
                (regexp_match(t.normalized_description,
                    '([A-Za-z0-9._%-]+@[A-Za-z0-9._%-]+)'))[1],
                ''
            ))
        ), '@', 2
    )                                                       AS vpa_provider,

    split_part(
        COALESCE(
            NULLIF(LOWER(TRIM(t.counterparty_vpa)), ''),
            LOWER(COALESCE(
                (regexp_match(t.normalized_description,
                    '([A-Za-z0-9._%-]+@[A-Za-z0-9._%-]+)'))[1],
                ''
            ))
        ), '@', 1
    )                                                       AS vpa_handle,

    -- ── Tier 0: bank-confirmed signal (NEW FIX-03) ───────────
    bs.bank_confirmed_type,
    bs.bank_confirmed_confidence,
    bs.bank_confirmed_reason,

    -- ── Self-wording signal ───────────────────────────────────
    CASE WHEN t.normalized_description ~*
        '(self[\s_-]?transfer|own[\s_-]?account|transfer[\s_-]?to[\s_-]?self|self[\s_-]?a/c)'
    THEN 1 ELSE 0 END                                       AS self_wording,

    -- ── Name prefix pattern (human name before mobile VPA) ───
    CASE WHEN t.normalized_description ~*
        '^UPI[\s-][A-Z][A-Z\s]{2,30}[\s-][0-9]{10}@'
    THEN 1 ELSE 0 END                                       AS name_prefix_signal,

    -- ── QR signals — split per provider ──────────────────────
    CASE WHEN t.normalized_description ~* 'paytmqr'
    THEN 1 ELSE 0 END                                       AS paytm_qr_signal,

    CASE WHEN t.normalized_description ~* 'bharatpe'
    THEN 1 ELSE 0 END                                       AS bharatpe_qr_signal,

    CASE WHEN t.normalized_description ~* '\bqr\b'
         AND t.normalized_description !~* '(paytmqr|bharatpe)'
    THEN 1 ELSE 0 END                                       AS other_qr_signal,

    -- ── Gateway signals — split per provider ─────────────────
    CASE WHEN t.normalized_description ~* '(razorpay|\brzp\b)'
    THEN 1 ELSE 0 END                                       AS razorpay_signal,

    CASE WHEN t.normalized_description ~* '\bpayu\b'
         AND t.normalized_description !~* 'paytm'
    THEN 1 ELSE 0 END                                       AS payu_signal,

    CASE WHEN t.normalized_description ~* 'cashfree'
    THEN 1 ELSE 0 END                                       AS cashfree_signal,

    -- ── Bill payment signal ───────────────────────────────────
    CASE WHEN t.normalized_description ~*
        '(bbps|billpay|billerslip|billdesk|fastag|netc)'
    THEN 1 ELSE 0 END                                       AS billpay_signal,

    -- ── Composite convenience flag ────────────────────────────
    CASE WHEN t.normalized_description ~*
        '(paytmqr|bharatpe|\bqr\b|razorpay|\brzp\b|\bpayu\b|cashfree)'
    THEN 1 ELSE 0 END                                       AS any_merchant_signal,

    -- ── Major handle pre-match (prevent fan-out downstream) ──
    mh.handle_pattern                                       AS matched_handle_pattern,
    mh.merchant_label,
    mh.merchant_category,
    mh.merchant_subcategory,
    mh.merchant_weight

FROM spendsense.txn_parsed t

-- Tier 0: bank signal computed once per row
CROSS JOIN LATERAL (
    SELECT * FROM spendsense.fn_upi_bank_signal(
        t.parse_format,
        t.counterparty_name,
        t.merchant_name,
        t.normalized_description
    )
) bs

-- Major handle match: highest-weight match, LIMIT 1 prevents fan-out
LEFT JOIN LATERAL (
    SELECT h.handle_pattern, h.merchant_label,
           h.merchant_category, h.merchant_subcategory,
           h.merchant_weight
    FROM spendsense.ref_upi_major_handle h
    WHERE h.is_active = TRUE
      AND LOWER(t.normalized_description) ~ LOWER(h.handle_pattern)
    ORDER BY h.merchant_weight DESC
    LIMIT 1
) mh ON TRUE

WHERE t.channel_type = 'UPI';              -- FIX-01

COMMENT ON VIEW spendsense.vw_upi_struct_features IS
'Per-transaction features. FIX-01: channel_type. FIX-02: VPA from counterparty_vpa.
 FIX-03: bank_confirmed_type from fn_upi_bank_signal (Tier 0 gate).
 SKIP rows (reversals) are excluded in vw_upi_entity_final.';

-- ============================================================
-- STEP 4 — COUNTERPARTY BEHAVIOURAL ROLLUP  (unchanged logic)
-- FIX-01 propagated: channel_type reference updated
-- ============================================================

CREATE OR REPLACE VIEW spendsense.vw_upi_counterparty_rollup AS
SELECT
    user_id,
    COALESCE(NULLIF(vpa, ''), vpa_handle)                   AS counterparty_key,

    COUNT(*)                                                 AS txn_count,
    COUNT(*) FILTER (WHERE cr_dr = 'D')                     AS debit_count,
    COUNT(*) FILTER (WHERE cr_dr = 'C')                     AS credit_count,

    PERCENTILE_CONT(0.5) WITHIN GROUP
        (ORDER BY amount) FILTER (WHERE cr_dr = 'D')        AS median_debit_amt,

    CASE WHEN COUNT(*) FILTER (WHERE cr_dr = 'D') > 0
          AND COUNT(*) FILTER (WHERE cr_dr = 'C') > 0
         THEN TRUE ELSE FALSE END                            AS is_bidirectional,

    CASE WHEN COUNT(*) FILTER (WHERE cr_dr = 'D') > 0
          AND COUNT(*) FILTER (WHERE cr_dr = 'C') = 0
         THEN TRUE ELSE FALSE END                            AS is_debit_only,

    MAX(paytm_qr_signal)                                    AS any_paytm_qr,
    MAX(bharatpe_qr_signal)                                 AS any_bharatpe_qr,
    MAX(other_qr_signal)                                    AS any_other_qr,
    MAX(razorpay_signal)                                    AS any_razorpay,
    MAX(payu_signal)                                        AS any_payu,
    MAX(cashfree_signal)                                    AS any_cashfree,
    MAX(billpay_signal)                                     AS any_billpay,
    MAX(self_wording)                                       AS any_self_wording,
    MAX(name_prefix_signal)                                 AS any_name_prefix,
    MAX(any_merchant_signal)                                AS any_merchant_signal,

    array_agg(DISTINCT vpa_provider)
        FILTER (WHERE vpa_provider <> '')                   AS providers_seen,

    (array_agg(matched_handle_pattern
        ORDER BY merchant_weight DESC NULLS LAST)
        FILTER (WHERE matched_handle_pattern IS NOT NULL))[1]
                                                            AS matched_handle_pattern,

    -- Tier 0: carry bank-confirmed signal to rollup level
    -- If ANY transaction for this counterparty has a bank-confirmed type,
    -- propagate it (highest confidence wins when there is disagreement)
    (array_agg(bank_confirmed_type
        ORDER BY bank_confirmed_confidence DESC NULLS LAST)
        FILTER (WHERE bank_confirmed_type IS NOT NULL
                  AND bank_confirmed_type <> 'SKIP'))[1]   AS bank_confirmed_type,

    MAX(bank_confirmed_confidence)
        FILTER (WHERE bank_confirmed_type IS NOT NULL
                  AND bank_confirmed_type <> 'SKIP')       AS bank_confirmed_confidence

FROM spendsense.vw_upi_struct_features
-- Exclude reversals from rollup: they do not represent real counterparty behaviour
WHERE COALESCE(bank_confirmed_type, '') <> 'SKIP'
GROUP BY user_id, COALESCE(NULLIF(vpa, ''), vpa_handle);

-- ============================================================
-- STEP 5 — PROVIDER WEIGHT AGGREGATION  (unchanged)
-- ============================================================

CREATE OR REPLACE VIEW spendsense.vw_upi_provider_scores AS
SELECT
    r.user_id,
    r.counterparty_key,
    COALESCE(SUM(pt.person_weight),          0)::INT AS provider_person_score,
    COALESCE(SUM(pt.merchant_weight),        0)::INT AS provider_merchant_score,
    COALESCE(SUM(pt.small_merchant_weight),  0)::INT AS provider_small_merchant_score,
    MODE() WITHIN GROUP (ORDER BY pt.provider_type)   AS dominant_provider_type
FROM spendsense.vw_upi_counterparty_rollup r
CROSS JOIN LATERAL unnest(r.providers_seen) AS prov(code)
LEFT JOIN spendsense.ref_upi_provider_type pt
    ON LOWER(prov.code) = pt.provider_code
    AND pt.is_active = TRUE
GROUP BY r.user_id, r.counterparty_key;

-- ============================================================
-- STEP 6 — ENTITY SCORING ENGINE  (unchanged signals)
-- Tier 0 bank_confirmed_type propagated through — used in
-- Step 7 final decision, not here.
-- ============================================================

CREATE OR REPLACE VIEW spendsense.vw_upi_entity_scoring AS
WITH cfg AS (
    SELECT
        MAX(CASE WHEN config_key = 'SELF_WORDING_SCORE'        THEN config_value END) AS self_wording_score,
        MAX(CASE WHEN config_key = 'BIDIRECTIONAL_SCORE'       THEN config_value END) AS bidirectional_score,
        MAX(CASE WHEN config_key = 'ROUND_TRIP_SCORE'          THEN config_value END) AS round_trip_score,
        MAX(CASE WHEN config_key = 'NO_MERCHANT_SIGNAL_SELF'   THEN config_value END) AS no_merchant_self_score,
        MAX(CASE WHEN config_key = 'MOBILE_VPA_SCORE'          THEN config_value END) AS mobile_vpa_score,
        MAX(CASE WHEN config_key = 'NAME_PREFIX_SCORE'         THEN config_value END) AS name_prefix_score,
        MAX(CASE WHEN config_key = 'NO_MERCHANT_SIGNAL_PERSON' THEN config_value END) AS no_merchant_person_score,
        MAX(CASE WHEN config_key = 'LOW_REPEAT_SCORE'          THEN config_value END) AS low_repeat_score,
        MAX(CASE WHEN config_key = 'PAYTM_QR_SCORE'            THEN config_value END) AS paytm_qr_score,
        MAX(CASE WHEN config_key = 'BHARATPE_QR_SCORE'         THEN config_value END) AS bharatpe_qr_score,
        MAX(CASE WHEN config_key = 'OTHER_QR_SCORE'            THEN config_value END) AS other_qr_score,
        MAX(CASE WHEN config_key = 'SMALL_TICKET_SCORE'        THEN config_value END) AS small_ticket_score,
        MAX(CASE WHEN config_key = 'DEBIT_ONLY_SMALL_SCORE'    THEN config_value END) AS debit_only_small_score,
        MAX(CASE WHEN config_key = 'MOBILE_VPA_VENDOR_SCORE'   THEN config_value END) AS mobile_vpa_vendor_score,
        MAX(CASE WHEN config_key = 'RAZORPAY_SCORE'            THEN config_value END) AS razorpay_score,
        MAX(CASE WHEN config_key = 'PAYU_SCORE'                THEN config_value END) AS payu_score,
        MAX(CASE WHEN config_key = 'CASHFREE_SCORE'            THEN config_value END) AS cashfree_score,
        MAX(CASE WHEN config_key = 'BILLPAY_SCORE'             THEN config_value END) AS billpay_score,
        MAX(CASE WHEN config_key = 'REPEATED_TXN_SCORE'        THEN config_value END) AS repeated_txn_score,
        MAX(CASE WHEN config_key = 'DEBIT_ONLY_MERCHANT_SCORE' THEN config_value END) AS debit_only_merchant_score,
        MAX(CASE WHEN config_key = 'NON_MOBILE_VPA_SCORE'      THEN config_value END) AS non_mobile_vpa_score,
        MAX(CASE WHEN config_key = 'SMALL_TICKET_MEDIAN_MAX'   THEN config_value END) AS small_ticket_max
    FROM spendsense.ref_upi_classifier_config
)
SELECT
    r.user_id,
    r.counterparty_key,
    r.txn_count,
    r.debit_count,
    r.credit_count,
    r.median_debit_amt,
    r.is_bidirectional,
    r.is_debit_only,
    r.matched_handle_pattern,
    r.bank_confirmed_type,
    r.bank_confirmed_confidence,

    -- ── SELF_ACCOUNT score ────────────────────────────────────
    LEAST(100,
        CASE WHEN r.any_self_wording = 1
             THEN cfg.self_wording_score ELSE 0 END
        + CASE WHEN r.is_bidirectional = TRUE AND r.txn_count >= 2
               THEN cfg.bidirectional_score ELSE 0 END
        + CASE WHEN r.debit_count >= 2 AND r.credit_count >= 2
               THEN cfg.round_trip_score ELSE 0 END
        + CASE WHEN r.any_merchant_signal = 0
               THEN cfg.no_merchant_self_score ELSE 0 END
    )::INT                                                   AS self_account_score,

    -- ── PERSON score ──────────────────────────────────────────
    LEAST(100,
        CASE WHEN r.counterparty_key ~ '^[0-9]{10}(@|$)'
             THEN cfg.mobile_vpa_score ELSE 0 END
        + COALESCE(ps.provider_person_score, 0)
        + CASE WHEN r.any_name_prefix = 1
               THEN cfg.name_prefix_score ELSE 0 END
        + CASE WHEN r.any_merchant_signal = 0
               THEN cfg.no_merchant_person_score ELSE 0 END
        + CASE WHEN r.debit_count <= 5 AND r.credit_count = 0
               THEN cfg.low_repeat_score ELSE 0 END
    )::INT                                                   AS person_score,

    -- ── SMALL_MERCHANT score ──────────────────────────────────
    LEAST(100,
        CASE WHEN r.any_paytm_qr = 1
             THEN cfg.paytm_qr_score ELSE 0 END
        + CASE WHEN r.any_bharatpe_qr = 1 AND r.any_paytm_qr = 0
               THEN cfg.bharatpe_qr_score ELSE 0 END
        + CASE WHEN r.any_other_qr = 1
               AND r.any_paytm_qr = 0
               AND r.any_bharatpe_qr = 0
               THEN cfg.other_qr_score ELSE 0 END
        + CASE WHEN r.median_debit_amt IS NOT NULL
               AND r.median_debit_amt <= cfg.small_ticket_max
               THEN cfg.small_ticket_score ELSE 0 END
        + CASE WHEN r.is_debit_only = TRUE
               THEN cfg.debit_only_small_score ELSE 0 END
        + CASE WHEN r.counterparty_key ~ '^[0-9]{10}(@|$)'
               AND r.is_debit_only = TRUE
               AND r.txn_count >= 3
               THEN cfg.mobile_vpa_vendor_score ELSE 0 END
        + COALESCE(ps.provider_small_merchant_score, 0)
    )::INT                                                   AS small_merchant_score,

    -- ── MERCHANT score ────────────────────────────────────────
    LEAST(100,
        CASE WHEN r.any_razorpay = 1 THEN cfg.razorpay_score ELSE 0 END
        + CASE WHEN r.any_payu = 1     THEN cfg.payu_score    ELSE 0 END
        + CASE WHEN r.any_cashfree = 1 THEN cfg.cashfree_score ELSE 0 END
        + CASE WHEN r.any_billpay = 1  THEN cfg.billpay_score  ELSE 0 END
        + COALESCE(ps.provider_merchant_score, 0)
        + CASE WHEN r.txn_count >= 2
               THEN cfg.repeated_txn_score ELSE 0 END
        + CASE WHEN r.is_debit_only = TRUE
               THEN cfg.debit_only_merchant_score ELSE 0 END
        + CASE WHEN r.counterparty_key !~ '^[0-9]{10}(@|$)'
               THEN cfg.non_mobile_vpa_score ELSE 0 END
    )::INT                                                   AS merchant_score,

    COALESCE(ps.dominant_provider_type, 'NEUTRAL')          AS dominant_provider_type

FROM spendsense.vw_upi_counterparty_rollup r
CROSS JOIN cfg
LEFT JOIN spendsense.vw_upi_provider_scores ps
    ON ps.user_id = r.user_id
    AND ps.counterparty_key = r.counterparty_key;

-- ============================================================
-- STEP 7 — FINAL ENTITY CLASSIFICATION  (FIX-03 applied here)
--
-- Priority order:
--   1. bank_confirmed_type (Tier 0) — highest priority
--   2. matched_handle_pattern (Tier 1) — brand registry
--   3. max-score-above-threshold (Tier 2+3) — scoring engine
-- ============================================================

CREATE OR REPLACE VIEW spendsense.vw_upi_entity_final AS
WITH thresholds AS (
    SELECT
        MAX(CASE WHEN config_key = 'SELF_ACCOUNT_THRESHOLD'   THEN config_value END) AS self_thr,
        MAX(CASE WHEN config_key = 'PERSON_THRESHOLD'          THEN config_value END) AS person_thr,
        MAX(CASE WHEN config_key = 'SMALL_MERCHANT_THRESHOLD'  THEN config_value END) AS small_thr,
        MAX(CASE WHEN config_key = 'MERCHANT_THRESHOLD'        THEN config_value END) AS merchant_thr
    FROM spendsense.ref_upi_classifier_config
)
SELECT
    s.user_id,
    s.counterparty_key,
    s.self_account_score,
    s.person_score,
    s.small_merchant_score,
    s.merchant_score,
    s.dominant_provider_type,
    s.matched_handle_pattern,
    s.bank_confirmed_type,
    s.bank_confirmed_confidence,

    CASE
        -- ── Tier 0: bank-confirmed (highest priority) ─────────
        WHEN s.bank_confirmed_type IS NOT NULL
             THEN s.bank_confirmed_type

        -- ── Tier 1: major handle registry ─────────────────────
        WHEN s.matched_handle_pattern IS NOT NULL
             THEN 'MERCHANT'

        -- ── Tier 2+3: scoring engine ───────────────────────────
        -- All four scores below threshold → UNKNOWN
        WHEN GREATEST(
                CASE WHEN s.self_account_score  >= t.self_thr    THEN s.self_account_score  ELSE 0 END,
                CASE WHEN s.person_score         >= t.person_thr  THEN s.person_score         ELSE 0 END,
                CASE WHEN s.small_merchant_score >= t.small_thr   THEN s.small_merchant_score ELSE 0 END,
                CASE WHEN s.merchant_score        >= t.merchant_thr THEN s.merchant_score      ELSE 0 END
             ) = 0
             THEN 'UNKNOWN_MERCHANT'

        -- SELF_ACCOUNT: highest qualifying score, tie-break priority 1
        WHEN s.self_account_score >= t.self_thr
         AND s.self_account_score = GREATEST(
                CASE WHEN s.self_account_score  >= t.self_thr    THEN s.self_account_score  ELSE 0 END,
                CASE WHEN s.person_score         >= t.person_thr  THEN s.person_score         ELSE 0 END,
                CASE WHEN s.small_merchant_score >= t.small_thr   THEN s.small_merchant_score ELSE 0 END,
                CASE WHEN s.merchant_score        >= t.merchant_thr THEN s.merchant_score      ELSE 0 END)
             THEN 'SELF_ACCOUNT'

        -- PERSON: priority 2
        WHEN s.person_score >= t.person_thr
         AND s.person_score = GREATEST(
                CASE WHEN s.person_score         >= t.person_thr  THEN s.person_score         ELSE 0 END,
                CASE WHEN s.small_merchant_score >= t.small_thr   THEN s.small_merchant_score ELSE 0 END,
                CASE WHEN s.merchant_score        >= t.merchant_thr THEN s.merchant_score      ELSE 0 END)
             THEN 'PERSON'

        -- SMALL_MERCHANT: priority 3
        WHEN s.small_merchant_score >= t.small_thr
         AND s.small_merchant_score = GREATEST(
                CASE WHEN s.small_merchant_score >= t.small_thr   THEN s.small_merchant_score ELSE 0 END,
                CASE WHEN s.merchant_score        >= t.merchant_thr THEN s.merchant_score      ELSE 0 END)
             THEN 'SMALL_MERCHANT'

        -- MERCHANT: priority 4
        WHEN s.merchant_score >= t.merchant_thr
             THEN 'MERCHANT'

        ELSE 'UNKNOWN_MERCHANT'
    END AS entity_type,

    -- Classification source for audit trail
    CASE
        WHEN s.bank_confirmed_type IS NOT NULL      THEN 'TIER_0_BANK'
        WHEN s.matched_handle_pattern IS NOT NULL   THEN 'TIER_1_HANDLE'
        ELSE                                             'TIER_2_SCORING'
    END AS classification_source

FROM spendsense.vw_upi_entity_scoring s
CROSS JOIN thresholds t;

COMMENT ON VIEW spendsense.vw_upi_entity_final IS
'Three-tier classification: Tier 0 (bank signal) → Tier 1 (handle registry) → Tier 2+3 (scoring).
 bank_confirmed_type always wins when present.
 classification_source column tells you which tier decided each row.';

-- ============================================================
-- STEP 8 — PER-TRANSACTION OUTPUT VIEW
-- ============================================================

CREATE OR REPLACE VIEW spendsense.vw_upi_for_rulebooks AS
SELECT
    f.txn_id,
    f.user_id,
    f.upload_id,
    COALESCE(NULLIF(f.vpa, ''), f.vpa_handle)   AS counterparty_key,
    f.vpa_provider,

    e.entity_type                                AS upi_classified,
    e.classification_source,
    e.bank_confirmed_type,
    e.bank_confirmed_confidence,
    e.person_score,
    e.self_account_score,
    e.small_merchant_score,
    e.merchant_score,
    e.dominant_provider_type,

    COALESCE(f.merchant_label, e.matched_handle_pattern) AS merchant_label,
    f.merchant_category,
    f.merchant_subcategory

FROM spendsense.vw_upi_struct_features f
LEFT JOIN spendsense.vw_upi_entity_final e
    ON f.user_id = e.user_id
    AND COALESCE(NULLIF(f.vpa, ''), f.vpa_handle) = e.counterparty_key
-- Exclude reversals from the rulebook output
WHERE COALESCE(f.bank_confirmed_type, '') <> 'SKIP';

-- ============================================================
-- STEP 9 — OUTPUT TABLE  (FIX-05, FIX-06)
-- FIX-05: bank_confirmed_type + classification_source columns added
-- FIX-06: renamed to txn_upi_classified (clean break from v2)
-- ============================================================

CREATE TABLE IF NOT EXISTS spendsense.txn_upi_classified (
    -- Core transaction columns
    txn_id                   UUID          NOT NULL,
    user_id                  TEXT          NOT NULL,
    upload_id                UUID,
    txn_date                 DATE,
    amount                   NUMERIC(18,2),
    cr_dr                    CHAR(1),
    channel_type             TEXT,          -- FIX-01: was payment_channel
    raw_description          TEXT,
    normalized_description   TEXT,

    -- Parser output columns (carried through for reference)
    parse_format             TEXT,
    counterparty_name        TEXT,
    merchant_name            TEXT,
    counterparty_vpa         TEXT,

    -- UPI classification columns
    upi_classified           TEXT,
    classification_source    TEXT,          -- FIX-05: TIER_0_BANK / TIER_1_HANDLE / TIER_2_SCORING
    bank_confirmed_type      TEXT,          -- FIX-05: raw Tier 0 output for traceability
    bank_confirmed_confidence NUMERIC(4,2),
    person_score             INT,
    self_account_score       INT,
    small_merchant_score     INT,
    merchant_score           INT,
    dominant_provider_type   TEXT,
    merchant_label           TEXT,
    merchant_category        TEXT,
    merchant_subcategory     TEXT,
    counterparty_key         TEXT,
    vpa_provider             TEXT,

    -- Audit columns
    classified_at            TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    updated_at               TIMESTAMPTZ   NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_txn_upi_classified PRIMARY KEY (txn_id)
);

CREATE INDEX IF NOT EXISTS ix_txn_upi_cls_user
    ON spendsense.txn_upi_classified(user_id);
CREATE INDEX IF NOT EXISTS ix_txn_upi_cls_upload
    ON spendsense.txn_upi_classified(upload_id);
CREATE INDEX IF NOT EXISTS ix_txn_upi_cls_entity
    ON spendsense.txn_upi_classified(upi_classified);
CREATE INDEX IF NOT EXISTS ix_txn_upi_cls_date
    ON spendsense.txn_upi_classified(txn_date DESC);
CREATE INDEX IF NOT EXISTS ix_txn_upi_cls_user_entity
    ON spendsense.txn_upi_classified(user_id, upi_classified);
CREATE INDEX IF NOT EXISTS ix_txn_upi_cls_source
    ON spendsense.txn_upi_classified(classification_source);
CREATE INDEX IF NOT EXISTS ix_txn_upi_cls_format
    ON spendsense.txn_upi_classified(parse_format)
    WHERE parse_format IS NOT NULL;

COMMENT ON TABLE spendsense.txn_upi_classified IS
'v3: Three-tier UPI classification output. Replaces txn_parsed_UPI_updated.
 classification_source tells you which tier decided each row.
 bank_confirmed_type preserves raw Tier 0 output for debugging.
 Populated via populate_txn_upi_classified(). Safe to re-run (upsert).';

-- ============================================================
-- STEP 10 — POPULATE FUNCTION
-- ============================================================

CREATE OR REPLACE FUNCTION spendsense.populate_txn_upi_classified(
    p_upload_id UUID DEFAULT NULL
)
RETURNS TABLE (
    rows_upserted   BIGINT,
    rows_upi        BIGINT,
    rows_non_upi    BIGINT
)
LANGUAGE plpgsql AS $$
DECLARE
    v_rows_upi      BIGINT := 0;
    v_rows_non_upi  BIGINT := 0;
BEGIN
    -- ── Upsert UPI transactions with full classification ──────
    INSERT INTO spendsense.txn_upi_classified AS dest (
        txn_id, user_id, upload_id, txn_date, amount, cr_dr,
        channel_type, raw_description, normalized_description,
        parse_format, counterparty_name, merchant_name, counterparty_vpa,
        upi_classified, classification_source,
        bank_confirmed_type, bank_confirmed_confidence,
        person_score, self_account_score,
        small_merchant_score, merchant_score,
        dominant_provider_type, merchant_label,
        merchant_category, merchant_subcategory,
        counterparty_key, vpa_provider,
        classified_at, updated_at
    )
    SELECT
        t.fact_txn_id,
        t.user_id,
        t.upload_id,
        t.txn_date,
        t.amount,
        t.cr_dr,
        t.channel_type,
        t.raw_description,
        t.normalized_description,
        t.parse_format,
        t.counterparty_name,
        t.merchant_name,
        t.counterparty_vpa,
        u.upi_classified,
        u.classification_source,
        u.bank_confirmed_type,
        u.bank_confirmed_confidence,
        u.person_score,
        u.self_account_score,
        u.small_merchant_score,
        u.merchant_score,
        u.dominant_provider_type,
        u.merchant_label,
        u.merchant_category,
        u.merchant_subcategory,
        u.counterparty_key,
        u.vpa_provider,
        NOW(),
        NOW()
    FROM spendsense.txn_parsed t
    JOIN spendsense.vw_upi_for_rulebooks u
        ON t.fact_txn_id = u.txn_id
    WHERE t.channel_type = 'UPI'                -- FIX-01
      AND (p_upload_id IS NULL OR t.upload_id = p_upload_id)
    ON CONFLICT (txn_id) DO UPDATE SET
        upi_classified            = EXCLUDED.upi_classified,
        classification_source     = EXCLUDED.classification_source,
        bank_confirmed_type       = EXCLUDED.bank_confirmed_type,
        bank_confirmed_confidence = EXCLUDED.bank_confirmed_confidence,
        person_score              = EXCLUDED.person_score,
        self_account_score        = EXCLUDED.self_account_score,
        small_merchant_score      = EXCLUDED.small_merchant_score,
        merchant_score            = EXCLUDED.merchant_score,
        dominant_provider_type    = EXCLUDED.dominant_provider_type,
        merchant_label            = EXCLUDED.merchant_label,
        merchant_category         = EXCLUDED.merchant_category,
        merchant_subcategory      = EXCLUDED.merchant_subcategory,
        counterparty_key          = EXCLUDED.counterparty_key,
        updated_at                = NOW();

    GET DIAGNOSTICS v_rows_upi = ROW_COUNT;

    -- ── Upsert non-UPI transactions (classification NULLs) ───
    INSERT INTO spendsense.txn_upi_classified AS dest (
        txn_id, user_id, upload_id, txn_date, amount, cr_dr,
        channel_type, raw_description,
        upi_classified, classified_at, updated_at
    )
    SELECT
        t.fact_txn_id, t.user_id, t.upload_id,
        t.txn_date, t.amount, t.cr_dr,
        t.channel_type, t.raw_description,
        NULL,
        NOW(), NOW()
    FROM spendsense.txn_parsed t
    WHERE t.channel_type <> 'UPI'              -- FIX-01
      AND (p_upload_id IS NULL OR t.upload_id = p_upload_id)
    ON CONFLICT (txn_id) DO NOTHING;

    GET DIAGNOSTICS v_rows_non_upi = ROW_COUNT;

    RETURN QUERY SELECT
        (v_rows_upi + v_rows_non_upi),
        v_rows_upi,
        v_rows_non_upi;
END;
$$;

COMMENT ON FUNCTION spendsense.populate_txn_upi_classified IS
'Upsert-based populate for txn_upi_classified.
 Pass upload_id for incremental batch. Pass NULL for full rebuild.
 Safe to re-run: uses ON CONFLICT DO UPDATE for UPI, DO NOTHING for non-UPI.
 Example: SELECT * FROM spendsense.populate_txn_upi_classified(''<upload_uuid>'');';

-- ============================================================
-- STEP 11 — DIAGNOSTIC VIEWS
-- ============================================================

-- Distribution by upload + entity type
CREATE OR REPLACE VIEW spendsense.vw_upi_classification_summary AS
SELECT
    upload_id,
    upi_classified,
    classification_source,
    COUNT(*)                                                AS txn_count,
    ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER
        (PARTITION BY upload_id), 2)                       AS pct_share,
    ROUND(AVG(merchant_score), 1)                          AS avg_merchant_score,
    ROUND(AVG(person_score), 1)                            AS avg_person_score
FROM spendsense.txn_upi_classified
WHERE channel_type = 'UPI'
GROUP BY upload_id, upi_classified, classification_source
ORDER BY upload_id, txn_count DESC;

-- Full signal debug for a specific counterparty
CREATE OR REPLACE VIEW spendsense.vw_upi_counterparty_debug AS
SELECT
    e.user_id,
    e.counterparty_key,
    e.entity_type,
    e.classification_source,
    e.bank_confirmed_type,
    e.bank_confirmed_confidence,
    e.self_account_score,
    e.person_score,
    e.small_merchant_score,
    e.merchant_score,
    e.dominant_provider_type,
    e.matched_handle_pattern,
    r.txn_count,
    r.debit_count,
    r.credit_count,
    r.median_debit_amt,
    r.is_bidirectional,
    r.is_debit_only,
    r.any_paytm_qr,
    r.any_bharatpe_qr,
    r.any_razorpay,
    r.any_payu,
    r.any_cashfree,
    r.any_billpay,
    r.any_self_wording,
    r.any_name_prefix,
    r.providers_seen
FROM spendsense.vw_upi_entity_final e
JOIN spendsense.vw_upi_counterparty_rollup r
    ON r.user_id = e.user_id
    AND r.counterparty_key = e.counterparty_key;

-- Anomaly monitor
CREATE OR REPLACE VIEW spendsense.vw_upi_classification_anomalies AS
WITH dist AS (
    SELECT
        upload_id,
        ROUND(100.0 * COUNT(*) FILTER (WHERE upi_classified = 'PERSON')
              / NULLIF(COUNT(*) FILTER (WHERE channel_type = 'UPI'), 0), 2)
                                    AS person_pct,
        ROUND(100.0 * COUNT(*) FILTER (WHERE upi_classified = 'UNKNOWN_MERCHANT')
              / NULLIF(COUNT(*) FILTER (WHERE channel_type = 'UPI'), 0), 2)
                                    AS unknown_pct,
        ROUND(100.0 * COUNT(*) FILTER (WHERE upi_classified = 'SELF_ACCOUNT')
              / NULLIF(COUNT(*) FILTER (WHERE channel_type = 'UPI'), 0), 2)
                                    AS self_pct,
        ROUND(100.0 * COUNT(*) FILTER (WHERE classification_source = 'TIER_0_BANK')
              / NULLIF(COUNT(*) FILTER (WHERE channel_type = 'UPI'), 0), 2)
                                    AS tier0_pct
    FROM spendsense.txn_upi_classified
    GROUP BY upload_id
)
SELECT
    upload_id,
    person_pct,
    unknown_pct,
    self_pct,
    tier0_pct,
    CASE WHEN person_pct  < 30   THEN 'WARN: PERSON below 30%' END          AS person_alert,
    CASE WHEN unknown_pct > 20   THEN 'WARN: UNKNOWN_MERCHANT above 20%' END AS unknown_alert,
    CASE WHEN self_pct    > 10   THEN 'WARN: SELF_ACCOUNT above 10%' END     AS self_alert
FROM dist
WHERE person_pct < 30 OR unknown_pct > 20 OR self_pct > 10;

-- Misclassification review: P2A rows and how they resolved
CREATE OR REPLACE VIEW spendsense.vw_upi_p2a_review AS
SELECT
    c.txn_id,
    c.user_id,
    c.upload_id,
    c.txn_date,
    c.amount,
    c.raw_description,
    c.counterparty_name,
    c.parse_format,
    c.upi_classified,
    c.classification_source,
    c.bank_confirmed_type,
    c.bank_confirmed_confidence,
    c.person_score,
    c.merchant_score
FROM spendsense.txn_upi_classified c
WHERE c.parse_format IN ('UPI_P2A_SLASH', 'IMPS_P2A_SLASH')
ORDER BY c.txn_date DESC;

COMMENT ON VIEW spendsense.vw_upi_classification_summary  IS 'Distribution per upload. Run after each batch.';
COMMENT ON VIEW spendsense.vw_upi_counterparty_debug      IS 'All signals for one counterparty. Use WHERE user_id=X AND counterparty_key=Y.';
COMMENT ON VIEW spendsense.vw_upi_classification_anomalies IS 'Flags uploads outside expected distribution ranges.';
COMMENT ON VIEW spendsense.vw_upi_p2a_review              IS 'All P2A transactions with their classification decision. Use to catch misclassified names.';

COMMIT;

-- ============================================================
-- HOW TO RUN
-- ============================================================
--
-- Fresh install (first time — no existing data):
--   \i upi_classifier_v3.sql
--
-- Process a specific upload:
--   SELECT * FROM spendsense.populate_txn_upi_classified('<upload_uuid>');
--
-- Full rebuild (all historical data):
--   SELECT * FROM spendsense.populate_txn_upi_classified(NULL);
--
-- Monitor results:
--   SELECT * FROM spendsense.vw_upi_classification_summary
--   WHERE upload_id = '<upload_uuid>';
--
--   SELECT * FROM spendsense.vw_upi_classification_anomalies;
--
-- Review all P2A rows and how they classified:
--   SELECT * FROM spendsense.vw_upi_p2a_review
--   WHERE upload_id = '<upload_uuid>';
--
-- Debug a specific counterparty:
--   SELECT * FROM spendsense.vw_upi_counterparty_debug
--   WHERE user_id = '<uid>' AND counterparty_key ILIKE '%jyoti%';
--
-- Add a new business keyword (no code change needed):
--   INSERT INTO spendsense.ref_upi_p2a_name_patterns
--   (match_regex, pattern_type, confidence, priority, notes)
--   VALUES ('\bWHOLESALE\b', 'MERCHANT', 0.88, 80, 'Wholesale business');
--   -- Takes effect on next populate run automatically.
--
-- Check how any P2A row was classified and why:
--   SELECT
--       raw_description,
--       counterparty_name,
--       parse_format,
--       upi_classified,
--       classification_source,
--       bank_confirmed_type,
--       bank_confirmed_confidence
--   FROM spendsense.txn_upi_classified
--   WHERE parse_format = 'UPI_P2A_SLASH'
--     AND user_id = '<uid>'
--   ORDER BY txn_date DESC
--   LIMIT 50;
--
-- Tune a score threshold without code change:
--   UPDATE spendsense.ref_upi_classifier_config
--   SET config_value = 50
--   WHERE config_key = 'PERSON_THRESHOLD';
--   -- Re-run populate for affected uploads to apply.
--
-- Disable a stale name pattern:
--   UPDATE spendsense.ref_upi_p2a_name_patterns
--   SET is_active = FALSE
--   WHERE match_regex = '\bSERVICES?\b';
-- ============================================================
