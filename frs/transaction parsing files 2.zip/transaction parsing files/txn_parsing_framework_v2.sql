-- ============================================================
-- MONYTIX — BANK-AGNOSTIC TRANSACTION PARSING FRAMEWORK v2.0
-- PostgreSQL / PLpgSQL
--
-- All 12 issues from the design review resolved.
-- Architecture: Registry-driven, bank-agnostic, fully deterministic.
--
-- INPUT  : spendsense.txn_fact
-- OUTPUT : spendsense.txn_parsed
--
-- Object inventory:
--   Tables   : txn_parse_pattern_registry (extended), txn_parse_stage,
--              txn_parsed, txn_parse_unknown_queue,
--              txn_parse_unknown_shape_stats (NEW - IS-12)
--   Functions: fn_norm_desc, fn_array_len, fn_pick_token,
--              fn_digits_only, fn_txn_shape_signature,
--              fn_detect_best_pattern (renamed - IS-11),
--              fn_extract_internal_ref (NEW - IS-03),
--              populate_txn_parse_stage_v2 (IS-01, IS-07, IS-09),
--              populate_txn_parsed_v2 (IS-01, IS-02, IS-03, IS-08, IS-09),
--              populate_txn_parse_unknown_queue_v2 (IS-05, IS-06, IS-12),
--              fn_reparse_transaction (IS-04),
--              fn_reparse_by_shape (IS-04)
--   Views    : vw_txn_parse_unknown_clusters, vw_txn_parse_unknown_suggestions,
--              vw_txn_parse_quality_kpi, vw_txn_parse_pattern_coverage,
--              vw_txn_parse_unknown_kpi, vw_txn_parse_direction_anomalies (NEW-IS-07),
--              vw_txn_parsed (CREATE OR REPLACE - IS-10)
--
-- IS-xx cross-reference:
--   IS-01  upload_id + user_id scoping on all populate functions
--   IS-02  merchant_name: hardcoded LIKE list removed; registry-driven
--   IS-03  internal_ref: hardcoded bank patterns replaced with internal_ref_regex column
--   IS-04  reparse functions now re-populate after clearing
--   IS-05  unknown queue UPDATE scoped to current batch only
--   IS-06  occurrence_count now increments via ON CONFLICT DO UPDATE
--   IS-07  direction='UNKNOWN' monitored; CHECK constraint added
--   IS-08  ATM regex uses regexp_match() — safe NULL on no match
--   IS-09  user_id column added to txn_parse_stage and txn_parsed
--   IS-10  DROP VIEW replaced with CREATE OR REPLACE VIEW
--   IS-11  detect_txn_pattern renamed fn_detect_best_pattern, LANGUAGE sql
--   IS-12  txn_parse_unknown_shape_stats table for aggregate tracking
-- ============================================================

BEGIN;

CREATE SCHEMA IF NOT EXISTS spendsense;

-- ============================================================
-- 1) PATTERN REGISTRY  (IS-03: added internal_ref_regex column)
-- ============================================================

CREATE TABLE IF NOT EXISTS spendsense.txn_parse_pattern_registry (
    pattern_id          BIGSERIAL PRIMARY KEY,
    channel_type        TEXT NOT NULL,
        -- UPI / IMPS / NEFT / ACH / NACH / ATM / POS / BIL / CARD_BILLPAY / OTHER
    pattern_family      TEXT NOT NULL,
    detection_regex     TEXT NOT NULL,
    delimiter           TEXT,               -- '/' | '-' | ' ' | '*' | NULL
    direction_rule      TEXT NOT NULL DEFAULT 'LEDGER',
        -- LEDGER / IN / OUT / REV
    rrn_position        INT,
    name_position       INT,
    merchant_position   INT,
    vpa_position        INT,
    bank_position       INT,
    ifsc_position       INT,
    account_position    INT,
    mcc_position        INT,
    ref_position        INT,
    purpose_position    INT,
    -- IS-03: pattern-specific regex to extract internal bank reference
    -- NULL = use the global fn_extract_internal_ref() fallback
    internal_ref_regex  TEXT,
    parse_confidence    NUMERIC(5,2) NOT NULL DEFAULT 0.90,
    priority            INT NOT NULL DEFAULT 100,
    active              BOOLEAN NOT NULL DEFAULT TRUE,
    example_format      TEXT,
    notes               TEXT,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_txn_parse_pattern_registry
        UNIQUE (pattern_family, detection_regex)
);

CREATE INDEX IF NOT EXISTS ix_txn_ppr_active_priority
    ON spendsense.txn_parse_pattern_registry(active, priority);
CREATE INDEX IF NOT EXISTS ix_txn_ppr_channel
    ON spendsense.txn_parse_pattern_registry(channel_type);

-- Migrate existing table: add column if upgrading from v1
ALTER TABLE spendsense.txn_parse_pattern_registry
    ADD COLUMN IF NOT EXISTS internal_ref_regex TEXT;

COMMENT ON TABLE spendsense.txn_parse_pattern_registry IS
'Registry of structural transaction description patterns.
 Each row covers a structural format that may appear across multiple banks.
 internal_ref_regex (IS-03): overrides global internal ref extraction per pattern.';

-- ============================================================
-- 2) PARSE STAGE  (IS-07: direction CHECK; IS-09: user_id column)
-- ============================================================

CREATE TABLE IF NOT EXISTS spendsense.txn_parse_stage (
    stage_id            BIGSERIAL PRIMARY KEY,
    fact_txn_id         UUID NOT NULL UNIQUE
                            REFERENCES spendsense.txn_fact(txn_id) ON DELETE CASCADE,
    user_id             TEXT NOT NULL,          -- IS-09
    upload_id           UUID,                   -- IS-01 batch filter
    bank_code           TEXT,
    txn_date            DATE NOT NULL,
    amount              NUMERIC(18,2) NOT NULL,
    cr_dr               CHAR(1) NOT NULL CHECK (cr_dr IN ('C','D')),
    raw_description     TEXT NOT NULL,
    normalized_description TEXT NOT NULL,
    channel_type        TEXT NOT NULL,
    direction           TEXT NOT NULL
                            CHECK (direction IN ('IN','OUT','REV','LEDGER','UNKNOWN')), -- IS-07
    pattern_family      TEXT NOT NULL,
    matched_pattern_id  BIGINT
                            REFERENCES spendsense.txn_parse_pattern_registry(pattern_id),
    slash_tokens        TEXT[],
    dash_tokens         TEXT[],
    star_tokens         TEXT[],
    space_tokens        TEXT[],
    slash_token_count   INT NOT NULL DEFAULT 0,
    dash_token_count    INT NOT NULL DEFAULT 0,
    star_token_count    INT NOT NULL DEFAULT 0,
    space_token_count   INT NOT NULL DEFAULT 0,
    parse_status        TEXT NOT NULL DEFAULT 'STAGED'
                            CHECK (parse_status IN ('STAGED','READY','PARTIAL','UNPARSED')),
    parse_confidence    NUMERIC(5,2) NOT NULL DEFAULT 0.00,
    parse_version       TEXT NOT NULL DEFAULT 'v2',
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS ix_txn_ps_channel        ON spendsense.txn_parse_stage(channel_type);
CREATE INDEX IF NOT EXISTS ix_txn_ps_pattern_family ON spendsense.txn_parse_stage(pattern_family);
CREATE INDEX IF NOT EXISTS ix_txn_ps_parse_status   ON spendsense.txn_parse_stage(parse_status);
CREATE INDEX IF NOT EXISTS ix_txn_ps_user           ON spendsense.txn_parse_stage(user_id);    -- IS-09
CREATE INDEX IF NOT EXISTS ix_txn_ps_upload         ON spendsense.txn_parse_stage(upload_id);  -- IS-01

-- IS-09: add columns if upgrading
ALTER TABLE spendsense.txn_parse_stage
    ADD COLUMN IF NOT EXISTS user_id   TEXT,
    ADD COLUMN IF NOT EXISTS upload_id UUID;

-- ============================================================
-- 3) CANONICAL PARSED TABLE  (IS-07: direction CHECK; IS-09: user_id)
-- ============================================================

CREATE TABLE IF NOT EXISTS spendsense.txn_parsed (
    parsed_id           BIGSERIAL PRIMARY KEY,
    fact_txn_id         UUID NOT NULL UNIQUE
                            REFERENCES spendsense.txn_fact(txn_id) ON DELETE CASCADE,
    user_id             TEXT NOT NULL,          -- IS-09
    upload_id           UUID,                   -- IS-01
    bank_code           TEXT NOT NULL,
    txn_date            DATE NOT NULL,
    amount              NUMERIC(18,2) NOT NULL,
    cr_dr               CHAR(1) NOT NULL CHECK (cr_dr IN ('C','D')),
    raw_description     TEXT NOT NULL,
    normalized_description TEXT NOT NULL,
    channel_type        TEXT NOT NULL,
    direction           TEXT NOT NULL
                            CHECK (direction IN ('IN','OUT','REV','LEDGER','UNKNOWN')), -- IS-07
    pattern_family      TEXT NOT NULL,
    matched_pattern_id  BIGINT
                            REFERENCES spendsense.txn_parse_pattern_registry(pattern_id),
    counterparty_name   TEXT,
    merchant_name       TEXT,
    counterparty_bank_code TEXT,
    counterparty_vpa    TEXT,
    counterparty_account TEXT,
    counterparty_ifsc   TEXT,
    upi_rrn             TEXT,
    imps_rrn            TEXT,
    neft_utr            TEXT,
    internal_ref        TEXT,
    mcc                 TEXT,
    biller_name         TEXT,
    biller_code         TEXT,
    card_ref            TEXT,
    ach_nach_entity     TEXT,
    ach_nach_ref        TEXT,
    mandate_or_run_id   TEXT,
    atm_txn_id          TEXT,
    atm_location        TEXT,
    purpose             TEXT,
    note_text           TEXT,
    parse_status        TEXT NOT NULL DEFAULT 'PARSED'
                            CHECK (parse_status IN ('PARSED','PARTIAL','UNPARSED')),
    parse_confidence    NUMERIC(5,2) NOT NULL DEFAULT 0.00,
    parse_version       TEXT NOT NULL DEFAULT 'v2',
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS ix_txn_p_channel        ON spendsense.txn_parsed(channel_type);
CREATE INDEX IF NOT EXISTS ix_txn_p_direction      ON spendsense.txn_parsed(direction);
CREATE INDEX IF NOT EXISTS ix_txn_p_pattern_family ON spendsense.txn_parsed(pattern_family);
CREATE INDEX IF NOT EXISTS ix_txn_p_upi_rrn        ON spendsense.txn_parsed(upi_rrn)   WHERE upi_rrn  IS NOT NULL;
CREATE INDEX IF NOT EXISTS ix_txn_p_imps_rrn       ON spendsense.txn_parsed(imps_rrn)  WHERE imps_rrn IS NOT NULL;
CREATE INDEX IF NOT EXISTS ix_txn_p_neft_utr       ON spendsense.txn_parsed(neft_utr)  WHERE neft_utr IS NOT NULL;
CREATE INDEX IF NOT EXISTS ix_txn_p_user           ON spendsense.txn_parsed(user_id);   -- IS-09
CREATE INDEX IF NOT EXISTS ix_txn_p_upload         ON spendsense.txn_parsed(upload_id); -- IS-01
CREATE INDEX IF NOT EXISTS ix_txn_p_user_channel   ON spendsense.txn_parsed(user_id, channel_type);

-- IS-09: add columns if upgrading
ALTER TABLE spendsense.txn_parsed
    ADD COLUMN IF NOT EXISTS user_id   TEXT,
    ADD COLUMN IF NOT EXISTS upload_id UUID;

-- ============================================================
-- 4) UNKNOWN PATTERN QUEUE  (IS-06: ON CONFLICT increment)
-- ============================================================

CREATE TABLE IF NOT EXISTS spendsense.txn_parse_unknown_queue (
    unknown_id          BIGSERIAL PRIMARY KEY,
    fact_txn_id         UUID NOT NULL UNIQUE
                            REFERENCES spendsense.txn_fact(txn_id) ON DELETE CASCADE,
    user_id             TEXT,                   -- IS-09
    upload_id           UUID,                   -- IS-01
    bank_code           TEXT,
    txn_date            DATE,
    amount              NUMERIC(18,2),
    cr_dr               CHAR(1),
    raw_description     TEXT NOT NULL,
    normalized_description TEXT NOT NULL,
    guessed_channel_type TEXT,
    shape_signature     TEXT NOT NULL,
    token_count_dash    INT NOT NULL DEFAULT 0,
    token_count_slash   INT NOT NULL DEFAULT 0,
    token_count_space   INT NOT NULL DEFAULT 0,
    token_count_star    INT NOT NULL DEFAULT 0,
    parse_status        TEXT NOT NULL DEFAULT 'UNPARSED',
    parse_confidence    NUMERIC(5,2) NOT NULL DEFAULT 0.00,
    first_seen_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_seen_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    occurrence_count    INT NOT NULL DEFAULT 1,  -- IS-06: incremented via ON CONFLICT
    review_status       TEXT NOT NULL DEFAULT 'NEW'
                            CHECK (review_status IN ('NEW','REVIEWED','RULE_CREATED','IGNORE')),
    suggested_pattern_family TEXT,
    reviewer_note       TEXT,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS ix_tpuq_shape         ON spendsense.txn_parse_unknown_queue(shape_signature);
CREATE INDEX IF NOT EXISTS ix_tpuq_review_status ON spendsense.txn_parse_unknown_queue(review_status);
CREATE INDEX IF NOT EXISTS ix_tpuq_user          ON spendsense.txn_parse_unknown_queue(user_id);

-- ============================================================
-- 5) UNKNOWN SHAPE STATS  (NEW — IS-12: aggregate occurrence tracking)
-- ============================================================

CREATE TABLE IF NOT EXISTS spendsense.txn_parse_unknown_shape_stats (
    shape_id            BIGSERIAL PRIMARY KEY,
    shape_signature     TEXT NOT NULL,
    guessed_channel_type TEXT,
    total_occurrence_count  INT NOT NULL DEFAULT 1,
    first_seen_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_seen_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    example_description TEXT,
    review_status       TEXT NOT NULL DEFAULT 'NEW'
                            CHECK (review_status IN ('NEW','REVIEWED','RULE_CREATED','IGNORE')),
    suggested_pattern_family TEXT,
    reviewer_note       TEXT,
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_shape_channel UNIQUE (shape_signature, guessed_channel_type)
);

CREATE INDEX IF NOT EXISTS ix_tpuss_shape  ON spendsense.txn_parse_unknown_shape_stats(shape_signature);
CREATE INDEX IF NOT EXISTS ix_tpuss_review ON spendsense.txn_parse_unknown_shape_stats(review_status);
CREATE INDEX IF NOT EXISTS ix_tpuss_count  ON spendsense.txn_parse_unknown_shape_stats(total_occurrence_count DESC);

-- ============================================================
-- 6) HELPER FUNCTIONS
-- ============================================================

-- Normalize description: upper, trim control chars, collapse spaces
CREATE OR REPLACE FUNCTION spendsense.fn_norm_desc(p_desc TEXT)
RETURNS TEXT LANGUAGE sql IMMUTABLE AS $$
    SELECT UPPER(regexp_replace(regexp_replace(trim(COALESCE(p_desc,'')),
        '[[:cntrl:]]',' ','g'), '\s+',' ','g'));
$$;

-- Safe array length
CREATE OR REPLACE FUNCTION spendsense.fn_array_len(p_arr TEXT[])
RETURNS INT LANGUAGE sql IMMUTABLE AS $$
    SELECT COALESCE(array_length(p_arr,1), 0);
$$;

-- Pick token by delimiter and position (unchanged from v1 — correct)
CREATE OR REPLACE FUNCTION spendsense.fn_pick_token(
    p_delimiter   TEXT,
    p_slash_tokens TEXT[],
    p_dash_tokens  TEXT[],
    p_star_tokens  TEXT[],
    p_space_tokens TEXT[],
    p_position     INT
) RETURNS TEXT LANGUAGE plpgsql IMMUTABLE AS $$
BEGIN
    IF p_position IS NULL OR p_position <= 0 THEN RETURN NULL; END IF;
    IF p_delimiter = '/'  THEN RETURN NULLIF(trim(p_slash_tokens[p_position]),'');
    ELSIF p_delimiter = '-' THEN RETURN NULLIF(trim(p_dash_tokens[p_position]),'');
    ELSIF p_delimiter = '*' THEN RETURN NULLIF(trim(p_star_tokens[p_position]),'');
    ELSIF p_delimiter = ' ' THEN RETURN NULLIF(trim(p_space_tokens[p_position]),'');
    ELSE RETURN NULL;
    END IF;
END;
$$;

-- Strip non-digits
CREATE OR REPLACE FUNCTION spendsense.fn_digits_only(p_text TEXT)
RETURNS TEXT LANGUAGE sql IMMUTABLE AS $$
    SELECT NULLIF(regexp_replace(COALESCE(p_text,''), '[^0-9]','','g'), '');
$$;

-- Shape signature for unknown clustering
CREATE OR REPLACE FUNCTION spendsense.fn_txn_shape_signature(p_desc TEXT)
RETURNS TEXT LANGUAGE sql IMMUTABLE AS $$
    SELECT regexp_replace(
        regexp_replace(
        regexp_replace(
        regexp_replace(
        regexp_replace(UPPER(COALESCE(p_desc,'')),
            '[A-Z0-9._%+-]+@[A-Z0-9.-]+','VPA','g'),
            '[0-9]{8,}','NUM','g'),
            '[A-Z]{4}[0-9A-Z]{6,}','BANKCODE','g'),
            '\b[0-9]+\b','NUM','g'),
            '\s+',' ','g');
$$;

-- IS-11: Renamed from detect_txn_pattern; LANGUAGE sql for better inlining
-- Always returns 0 or 1 row (LIMIT 1 is intentional — best priority match).
CREATE OR REPLACE FUNCTION spendsense.fn_detect_best_pattern(p_norm_desc TEXT)
RETURNS TABLE (
    pattern_id         BIGINT,
    channel_type       TEXT,
    pattern_family     TEXT,
    delimiter          TEXT,
    direction_rule     TEXT,
    rrn_position       INT,
    name_position      INT,
    merchant_position  INT,
    vpa_position       INT,
    bank_position      INT,
    ifsc_position      INT,
    account_position   INT,
    mcc_position       INT,
    ref_position       INT,
    purpose_position   INT,
    internal_ref_regex TEXT,
    parse_confidence   NUMERIC
) LANGUAGE sql STABLE AS $$
    SELECT r.pattern_id, r.channel_type, r.pattern_family, r.delimiter,
           r.direction_rule, r.rrn_position, r.name_position,
           r.merchant_position, r.vpa_position, r.bank_position,
           r.ifsc_position, r.account_position, r.mcc_position,
           r.ref_position, r.purpose_position, r.internal_ref_regex,
           r.parse_confidence
    FROM spendsense.txn_parse_pattern_registry r
    WHERE r.active = TRUE
      AND p_norm_desc ~ r.detection_regex
    ORDER BY r.priority, r.pattern_id
    LIMIT 1;
$$;

-- Backward-compat alias (IS-11: old name still works)
CREATE OR REPLACE FUNCTION spendsense.detect_txn_pattern(p_norm_desc TEXT)
RETURNS TABLE (
    pattern_id BIGINT, channel_type TEXT, pattern_family TEXT, delimiter TEXT,
    direction_rule TEXT, rrn_position INT, name_position INT, merchant_position INT,
    vpa_position INT, bank_position INT, ifsc_position INT, account_position INT,
    mcc_position INT, ref_position INT, purpose_position INT, internal_ref_regex TEXT,
    parse_confidence NUMERIC
) LANGUAGE sql STABLE AS $$
    SELECT * FROM spendsense.fn_detect_best_pattern(p_norm_desc);
$$;

-- IS-03: Internal ref extraction — pattern-specific regex first, then global fallbacks.
-- No bank-specific LIKE branches. All bank patterns go into internal_ref_regex column.
CREATE OR REPLACE FUNCTION spendsense.fn_extract_internal_ref(
    p_norm_desc       TEXT,
    p_internal_ref_regex TEXT  -- from registry; NULL = use global fallback
) RETURNS TEXT LANGUAGE plpgsql IMMUTABLE AS $$
DECLARE
    v_result TEXT;
BEGIN
    -- Pattern-specific regex (IS-03: registry-driven, no hardcoded banks)
    IF p_internal_ref_regex IS NOT NULL THEN
        v_result := (regexp_match(p_norm_desc, p_internal_ref_regex))[1];
        IF v_result IS NOT NULL THEN RETURN v_result; END IF;
    END IF;

    -- Global fallback 1: IBL-prefixed references (ibl bank format)
    v_result := (regexp_match(p_norm_desc, '(IBL[0-9A-F]+)'))[1];
    IF v_result IS NOT NULL THEN RETURN v_result; END IF;

    -- Global fallback 2: double-slash internal ref (generic — no bank names)
    -- Matches patterns like: PREFIX//TOKEN/... where TOKEN is the ref
    v_result := (regexp_match(p_norm_desc, '//([A-Z0-9]+)(?:/|$)'))[1];
    IF v_result IS NOT NULL AND length(v_result) >= 6 THEN RETURN v_result; END IF;

    RETURN NULL;
END;
$$;

-- ============================================================
-- 7) SEED PATTERN REGISTRY
--    All 27 patterns from v1 retained + internal_ref_regex populated
--    where bank-specific // patterns were hardcoded in v1.
-- ============================================================

INSERT INTO spendsense.txn_parse_pattern_registry (
    channel_type, pattern_family, detection_regex, delimiter, direction_rule,
    rrn_position, name_position, merchant_position, vpa_position, bank_position,
    ifsc_position, account_position, mcc_position, ref_position, purpose_position,
    internal_ref_regex, parse_confidence, priority, example_format, notes
) VALUES

-- UPI patterns
('UPI','UPI_TRANSFER_DR_SLASH','^TO TRANSFER-UPI/DR/','/',   'OUT',
  3,4,NULL,6,5,NULL,NULL,NULL,NULL,7, NULL,
  0.95,1,'TO TRANSFER-UPI/DR/<RRN>/<n>/<BANK>/<VPA>/<PURPOSE>','SBI outgoing UPI'),

('UPI','UPI_TRANSFER_CR_SLASH','^BY TRANSFER-UPI/','/',      'IN',
  3,4,NULL,6,5,NULL,NULL,NULL,NULL,NULL, NULL,
  0.95,2,'BY TRANSFER-UPI/<RRN>/<n>/<BANK>/<VPA>','SBI incoming UPI'),

('UPI','UPI_SLASH_CR','^UPI/CR/','/',                        'IN',
  3,4,NULL,6,5,NULL,NULL,NULL,NULL,NULL, NULL,
  0.95,3,'UPI/CR/<RRN>/<n>/<BANK>/<VPA>','Canara/SBI incoming'),

('UPI','UPI_SLASH_DR','^UPI/DR/','/',                        'OUT',
  3,4,NULL,6,5,NULL,NULL,NULL,NULL,NULL, NULL,
  0.95,4,'UPI/DR/<RRN>/<n>/<BANK>/<VPA>','Canara/SBI outgoing'),

('UPI','UPI_SLASH_REV','^UPI/REV/','/',                      'REV',
  3,4,NULL,6,5,NULL,NULL,NULL,NULL,NULL, NULL,
  0.95,5,'UPI/REV/<RRN>/<n>/<BANK>/<VPA>','Reversal'),

('UPI','UPI_OUT_SLASH','^UPIOUT/','/',                       'OUT',
  2,NULL,NULL,3,NULL,NULL,NULL,5,NULL,NULL, NULL,
  0.95,6,'UPIOUT/<RRN>/<VPA>/UPI/<MCC>','Federal Bank UPI'),

('UPI','UPI_IN_SLASH','^UPI IN/','/',                        'IN',
  2,NULL,NULL,3,NULL,NULL,NULL,NULL,NULL,NULL, NULL,
  0.90,7,'UPI IN/<RRN>/<VPA>','UPI incoming slash'),

('UPI','UPI_REV_DASH','^REV-UPI-','-',                      'REV',
  4,2,NULL,3,4,NULL,NULL,NULL,NULL,NULL, NULL,
  0.90,8,'REV-UPI-<n>-<VPA>-<RRN>','Dash reversal'),

-- IS-03: UPI_DASH patterns often contain //ICI /AXI //SBI internal refs.
-- The internal_ref_regex extracts the ref after // without naming the bank.
('UPI','UPI_DASH','^UPI-','-',                               'LEDGER',
  5,2,2,3,4,4,NULL,NULL,NULL,6, '//([A-Z0-9]{6,})',
  0.92,9,'UPI-<n>-<VPA>-<BANK/IFSC>-<RRN>-<PURPOSE>','HDFC/ICICI/Axis/Kotak dash UPI'),

-- IMPS patterns
('IMPS','IMPS_MMT_SLASH','^MMT/IMPS/','/',                   'LEDGER',
  3,4,NULL,NULL,5,5,NULL,NULL,NULL,NULL, NULL,
  0.92,20,'MMT/IMPS/<RRN>/<n>/<IFSC>','ICICI IMPS'),

('IMPS','IMPS_TRANSFER_SLASH','^BY TRANSFER-IMPS/','/',      'LEDGER',
  2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL, NULL,
  0.90,21,'BY TRANSFER-IMPS/<RRN>/...','Transfer IMPS'),

('IMPS','IMPS_RECD_SLASH','^RECD:IMPS/','/',                 'IN',
  2,NULL,NULL,NULL,4,NULL,5,NULL,NULL,NULL, NULL,
  0.90,22,'RECD:IMPS/<RRN>/<STATUS>/<BANK>/<ACCOUNT>','Received IMPS'),

('IMPS','IMPS_INET_CR_SLASH','^INET-IMPS-CR/','/',           'IN',
  NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL, NULL,
  0.88,23,'INET-IMPS-CR/.../<RRN>','Internet IMPS credit'),

('IMPS','IMPS_MB_DR_SLASH','^MB-IMPS-DR/','/',               'OUT',
  NULL,2,NULL,NULL,3,NULL,4,NULL,NULL,NULL, NULL,
  0.88,24,'MB-IMPS-DR/<n>/<BANK>/<ACCOUNT>','Mobile banking IMPS debit'),

('IMPS','IMPS_DASH','^IMPS-','-',                            'LEDGER',
  2,3,NULL,NULL,4,NULL,5,NULL,NULL,NULL, NULL,
  0.90,25,'IMPS-<RRN>-<n>-<BANK>-<ACCOUNT>','Dash IMPS'),

-- NEFT patterns
('NEFT','NEFT_DASH','^NEFT-','-',                            'LEDGER',
  NULL,3,NULL,NULL,4,4,NULL,NULL,2,NULL, NULL,
  0.90,30,'NEFT-<UTR>-<n>-<IFSC>','Dash NEFT'),

('NEFT','NEFT_TRANSFER_STAR','^BY TRANSFER-NEFT','*',        'IN',
  NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,3,NULL, NULL,
  0.88,31,'BY TRANSFER-NEFT*<IFSC>*<UTR>','Star NEFT'),

-- ACH patterns
('ACH','ACH_SLASH','^ACH/','/',                              'LEDGER',
  NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,NULL, NULL,
  0.90,40,'ACH/<ENTITY>/<REF>','Slash ACH'),

('ACH','ACH_DASH','^ACH D-','-',                            'OUT',
  NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,3,NULL, NULL,
  0.90,41,'ACH D-<ENTITY>-<REF>','Dash ACH debit'),

('ACH','ACH_DEBIT_DASH','^DEBIT-ACH','-',                   'OUT',
  NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,3,NULL, NULL,
  0.88,42,'DEBIT-ACH-<ENTITY>-<REF>','Debit ACH'),

-- NACH patterns
('NACH','NACH_SPACE','^NACH ',' ',                           'OUT',
  NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,3,NULL, NULL,
  0.90,50,'NACH <ENTITY> <REF1> <REF2>','Space NACH'),

('NACH','NACH_DASH','^NACH-','-',                            'OUT',
  NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,3,NULL, NULL,
  0.88,51,'NACH-<ENTITY>-<REF>','Dash NACH'),

-- ATM
('ATM','ATM_WDL_DASH','^ATM WDL-','-',                      'OUT',
  NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL, NULL,
  0.90,60,'ATM WDL-ATM CASH <TXN_ID> <LOCATION>--','ATM withdrawal'),

('ATM','ATM_NWD_DASH','^NWD-','-',                          'OUT',
  NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL, NULL,
  0.88,61,'NWD-<ACCOUNT/CARD>-...','ATM card withdrawal'),

-- POS
('POS','POS_SPACE','^POS ',' ',                              'OUT',
  NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL, NULL,
  0.86,70,'POS <CARD_MASK> ...','POS card'),

-- Bill payment
('BIL','BIL_SLASH','^BIL/','/',                              'LEDGER',
  NULL,NULL,3,NULL,NULL,NULL,NULL,NULL,4,NULL, NULL,
  0.88,80,'BIL/.../<BILLER>/<REF>','Bill payment'),

('CARD_BILLPAY','CARD_BILLPAY_DASH','^IB BILLPAY DR-','-',   'OUT',
  NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,3,NULL, NULL,
  0.88,81,'IB BILLPAY DR-<BILLER_CODE>-<CARD_REF>','HDFC card bill pay')

ON CONFLICT (pattern_family, detection_regex) DO UPDATE
    SET internal_ref_regex = EXCLUDED.internal_ref_regex,
        updated_at         = NOW();

-- ============================================================
-- 8) POPULATE PARSE STAGE  (IS-01, IS-07, IS-09)
-- IS-01: p_upload_id and p_user_id parameters for batch scoping
-- IS-07: direction ELSE 'UNKNOWN' now explicit and monitored
-- IS-09: user_id + upload_id populated
-- ============================================================

CREATE OR REPLACE FUNCTION spendsense.populate_txn_parse_stage_v2(
    p_upload_id UUID  DEFAULT NULL,   -- IS-01: NULL = process all
    p_user_id   TEXT  DEFAULT NULL    -- IS-01: NULL = all users
)
RETURNS BIGINT          -- rows inserted
LANGUAGE plpgsql AS $$
DECLARE v_count BIGINT;
BEGIN
    INSERT INTO spendsense.txn_parse_stage (
        fact_txn_id, user_id, upload_id, bank_code, txn_date, amount, cr_dr,
        raw_description, normalized_description, channel_type, direction,
        pattern_family, matched_pattern_id,
        slash_tokens, dash_tokens, star_tokens, space_tokens,
        slash_token_count, dash_token_count, star_token_count, space_token_count,
        parse_status, parse_confidence, parse_version
    )
    SELECT
        tf.txn_id,
        tf.user_id,                    -- IS-09
        tf.upload_id,                  -- IS-01
        COALESCE(tf.bank_code, 'UNKNOWN'),
        tf.txn_date,
        tf.amount,
        CASE WHEN LOWER(COALESCE(tf.direction,'')) IN ('credit','cr','c','in')
             THEN 'C' ELSE 'D' END AS cr_dr,
        COALESCE(tf.description,''),
        nd.norm_desc,

        -- Channel detection: registry wins, fallback uses structural prefix heuristics
        COALESCE(dp.channel_type,
            CASE
                WHEN nd.norm_desc ~ '^(UPI|UPIOUT/|REV-UPI-)' THEN 'UPI'
                WHEN nd.norm_desc ~  'IMPS'                    THEN 'IMPS'
                WHEN nd.norm_desc ~ '^(NEFT|BY TRANSFER-NEFT)' THEN 'NEFT'
                WHEN nd.norm_desc ~ '^(ACH|DEBIT-ACH)'         THEN 'ACH'
                WHEN nd.norm_desc ~ '^NACH'                     THEN 'NACH'
                WHEN nd.norm_desc ~ '^(ATM WDL-|NWD-)'         THEN 'ATM'
                WHEN nd.norm_desc ~ '^POS '                     THEN 'POS'
                WHEN nd.norm_desc ~ '^BIL/'                     THEN 'BIL'
                WHEN nd.norm_desc ~ '^IB BILLPAY DR-'           THEN 'CARD_BILLPAY'
                ELSE 'OTHER'
            END
        ) AS channel_type,

        -- IS-07: direction; UNKNOWN is explicit (not silent), captured in monitoring view
        CASE
            WHEN COALESCE(dp.direction_rule,'LEDGER') = 'IN'  THEN 'IN'
            WHEN COALESCE(dp.direction_rule,'LEDGER') = 'OUT' THEN 'OUT'
            WHEN COALESCE(dp.direction_rule,'LEDGER') = 'REV' THEN 'REV'
            WHEN COALESCE(dp.direction_rule,'LEDGER') = 'LEDGER'
              AND LOWER(COALESCE(tf.direction,'')) IN ('credit','cr','c','in') THEN 'IN'
            WHEN COALESCE(dp.direction_rule,'LEDGER') = 'LEDGER'
              AND LOWER(COALESCE(tf.direction,'')) IN ('debit','dr','d','out') THEN 'OUT'
            ELSE 'UNKNOWN'  -- IS-07: explicit; will surface in vw_txn_parse_direction_anomalies
        END AS direction,

        COALESCE(dp.pattern_family, 'OTHER_UNKNOWN'),
        dp.pattern_id,

        string_to_array(nd.norm_desc, '/'),
        string_to_array(nd.norm_desc, '-'),
        string_to_array(nd.norm_desc, '*'),
        string_to_array(nd.norm_desc, ' '),
        spendsense.fn_array_len(string_to_array(nd.norm_desc, '/')),
        spendsense.fn_array_len(string_to_array(nd.norm_desc, '-')),
        spendsense.fn_array_len(string_to_array(nd.norm_desc, '*')),
        spendsense.fn_array_len(string_to_array(nd.norm_desc, ' ')),

        CASE
            WHEN COALESCE(tf.description,'') = '' THEN 'UNPARSED'
            WHEN dp.pattern_id IS NULL             THEN 'PARTIAL'
            ELSE 'READY'
        END AS parse_status,
        CASE
            WHEN COALESCE(tf.description,'') = '' THEN 0.00
            WHEN dp.pattern_id IS NULL             THEN 0.40
            ELSE COALESCE(dp.parse_confidence, 0.85)
        END AS parse_confidence,
        'v2'

    FROM spendsense.txn_fact tf
    CROSS JOIN LATERAL (
        SELECT spendsense.fn_norm_desc(tf.description) AS norm_desc
    ) nd
    LEFT JOIN LATERAL spendsense.fn_detect_best_pattern(nd.norm_desc) dp ON TRUE
    WHERE NOT EXISTS (
        SELECT 1 FROM spendsense.txn_parse_stage s WHERE s.fact_txn_id = tf.txn_id
    )
    -- IS-01: batch/user scoping
    AND (p_upload_id IS NULL OR tf.upload_id = p_upload_id)
    AND (p_user_id   IS NULL OR tf.user_id   = p_user_id);

    GET DIAGNOSTICS v_count = ROW_COUNT;
    RETURN v_count;
END;
$$;

-- Backward-compat wrapper (IS-01: old calls still work, process all)
CREATE OR REPLACE FUNCTION spendsense.populate_txn_parse_stage_registry()
RETURNS void LANGUAGE sql AS $$
    SELECT spendsense.populate_txn_parse_stage_v2(NULL, NULL);
$$;

-- ============================================================
-- 9) POPULATE CANONICAL PARSED TABLE  (IS-01, IS-02, IS-03, IS-08, IS-09)
-- IS-01: batch-scoped by upload_id / user_id
-- IS-02: merchant_name driven by vpa_position token — no hardcoded list
-- IS-03: internal_ref via fn_extract_internal_ref() — no bank-specific LIKE
-- IS-08: atm_txn_id / atm_location use regexp_match() — safe NULL on no match
-- IS-09: user_id + upload_id written to txn_parsed
-- ============================================================

CREATE OR REPLACE FUNCTION spendsense.populate_txn_parsed_v2(
    p_upload_id UUID  DEFAULT NULL,
    p_user_id   TEXT  DEFAULT NULL
)
RETURNS BIGINT
LANGUAGE plpgsql AS $$
DECLARE v_count BIGINT;
BEGIN
    INSERT INTO spendsense.txn_parsed (
        fact_txn_id, user_id, upload_id, bank_code, txn_date, amount, cr_dr,
        raw_description, normalized_description, channel_type, direction,
        pattern_family, matched_pattern_id,
        counterparty_name, merchant_name, counterparty_bank_code,
        counterparty_vpa, counterparty_account, counterparty_ifsc,
        upi_rrn, imps_rrn, neft_utr, internal_ref, mcc,
        biller_name, biller_code, card_ref,
        ach_nach_entity, ach_nach_ref, mandate_or_run_id,
        atm_txn_id, atm_location, purpose, note_text,
        parse_status, parse_confidence, parse_version
    )
    SELECT
        s.fact_txn_id,
        s.user_id,      -- IS-09
        s.upload_id,    -- IS-01

        s.bank_code, s.txn_date, s.amount, s.cr_dr,
        s.raw_description, s.normalized_description,
        s.channel_type, s.direction,
        s.pattern_family, s.matched_pattern_id,

        -- counterparty_name: UPI / IMPS / NEFT only
        CASE WHEN s.channel_type IN ('UPI','IMPS','NEFT')
             THEN spendsense.fn_pick_token(r.delimiter,
                    s.slash_tokens, s.dash_tokens, s.star_tokens, s.space_tokens,
                    r.name_position)
        END AS counterparty_name,

        -- IS-02: merchant_name — registry-driven, no hardcoded LIKE list.
        -- Strategy: if the vpa_position token contains a gateway/QR indicator,
        -- use name_position (which the registry already set to the merchant name).
        -- For non-merchant UPI (person VPA), merchant_name = NULL.
        -- Downstream UPI classifier and rulebook engine own merchant classification.
        CASE
            WHEN s.channel_type = 'UPI'
             AND r.vpa_position IS NOT NULL
             AND spendsense.fn_pick_token(r.delimiter,
                    s.slash_tokens, s.dash_tokens, s.star_tokens, s.space_tokens,
                    r.vpa_position)
                 ~* '(rzp@|paytmqr|bharatpe|payu\.|cashfree|eazypay|jiomoney|'
                  ||'swiggystores|blinkcommerce|zomato|irctc|netc\.|yesbank\.)'
            THEN COALESCE(
                    spendsense.fn_pick_token(r.delimiter,
                        s.slash_tokens, s.dash_tokens, s.star_tokens, s.space_tokens,
                        r.merchant_position),
                    spendsense.fn_pick_token(r.delimiter,
                        s.slash_tokens, s.dash_tokens, s.star_tokens, s.space_tokens,
                        r.name_position)
                 )
            WHEN s.pattern_family IN ('BIL_SLASH','CARD_BILLPAY_DASH')
            THEN spendsense.fn_pick_token(r.delimiter,
                    s.slash_tokens, s.dash_tokens, s.star_tokens, s.space_tokens,
                    r.merchant_position)
            ELSE NULL
        END AS merchant_name,

        spendsense.fn_pick_token(r.delimiter,
            s.slash_tokens, s.dash_tokens, s.star_tokens, s.space_tokens,
            r.bank_position)     AS counterparty_bank_code,

        spendsense.fn_pick_token(r.delimiter,
            s.slash_tokens, s.dash_tokens, s.star_tokens, s.space_tokens,
            r.vpa_position)      AS counterparty_vpa,

        spendsense.fn_pick_token(r.delimiter,
            s.slash_tokens, s.dash_tokens, s.star_tokens, s.space_tokens,
            r.account_position)  AS counterparty_account,

        spendsense.fn_pick_token(r.delimiter,
            s.slash_tokens, s.dash_tokens, s.star_tokens, s.space_tokens,
            r.ifsc_position)     AS counterparty_ifsc,

        CASE WHEN s.channel_type = 'UPI'
             THEN spendsense.fn_digits_only(spendsense.fn_pick_token(r.delimiter,
                    s.slash_tokens, s.dash_tokens, s.star_tokens, s.space_tokens,
                    r.rrn_position))
        END AS upi_rrn,

        CASE WHEN s.channel_type = 'IMPS'
             THEN spendsense.fn_digits_only(spendsense.fn_pick_token(r.delimiter,
                    s.slash_tokens, s.dash_tokens, s.star_tokens, s.space_tokens,
                    r.rrn_position))
        END AS imps_rrn,

        CASE WHEN s.channel_type = 'NEFT'
             THEN spendsense.fn_pick_token(r.delimiter,
                    s.slash_tokens, s.dash_tokens, s.star_tokens, s.space_tokens,
                    r.ref_position)
        END AS neft_utr,

        -- IS-03: registry-driven internal_ref extraction — no bank-specific LIKE
        spendsense.fn_extract_internal_ref(
            s.normalized_description,
            r.internal_ref_regex     -- NULL for most patterns; set for UPI_DASH etc.
        ) AS internal_ref,

        spendsense.fn_pick_token(r.delimiter,
            s.slash_tokens, s.dash_tokens, s.star_tokens, s.space_tokens,
            r.mcc_position)       AS mcc,

        CASE
            WHEN s.pattern_family = 'BIL_SLASH'
            THEN spendsense.fn_pick_token(r.delimiter,
                    s.slash_tokens, s.dash_tokens, s.star_tokens, s.space_tokens,
                    r.merchant_position)
            WHEN s.pattern_family = 'CARD_BILLPAY_DASH' THEN 'HDFCCS'
        END AS biller_name,

        CASE
            WHEN s.pattern_family = 'CARD_BILLPAY_DASH'
            THEN spendsense.fn_pick_token(r.delimiter,
                    s.slash_tokens, s.dash_tokens, s.star_tokens, s.space_tokens,
                    r.merchant_position)
        END AS biller_code,

        CASE WHEN s.pattern_family IN ('BIL_SLASH','CARD_BILLPAY_DASH')
             THEN spendsense.fn_pick_token(r.delimiter,
                    s.slash_tokens, s.dash_tokens, s.star_tokens, s.space_tokens,
                    r.ref_position)
        END AS card_ref,

        CASE WHEN s.channel_type IN ('ACH','NACH')
             THEN spendsense.fn_pick_token(r.delimiter,
                    s.slash_tokens, s.dash_tokens, s.star_tokens, s.space_tokens,
                    r.name_position)
        END AS ach_nach_entity,

        CASE WHEN s.channel_type IN ('ACH','NACH')
             THEN spendsense.fn_pick_token(r.delimiter,
                    s.slash_tokens, s.dash_tokens, s.star_tokens, s.space_tokens,
                    r.ref_position)
        END AS ach_nach_ref,

        CASE WHEN s.channel_type IN ('ACH','NACH')
             THEN spendsense.fn_pick_token(r.delimiter,
                    s.slash_tokens, s.dash_tokens, s.star_tokens, s.space_tokens,
                    r.ref_position)
        END AS mandate_or_run_id,

        -- IS-08: regexp_match() returns NULL when pattern doesn't match — safe
        (regexp_match(s.normalized_description,
            '^ATM WDL-ATM CASH ([0-9]+)'))[1] AS atm_txn_id,

        (regexp_match(s.normalized_description,
            '^ATM WDL-ATM CASH [0-9]+ (.*?)--?$'))[1] AS atm_location,

        spendsense.fn_pick_token(r.delimiter,
            s.slash_tokens, s.dash_tokens, s.star_tokens, s.space_tokens,
            r.purpose_position)   AS purpose,

        NULL::TEXT AS note_text,

        CASE
            WHEN s.pattern_family = 'OTHER_UNKNOWN' THEN 'PARTIAL'
            WHEN s.parse_status   = 'UNPARSED'       THEN 'UNPARSED'
            ELSE 'PARSED'
        END AS parse_status,

        s.parse_confidence,
        s.parse_version

    FROM spendsense.txn_parse_stage s
    LEFT JOIN spendsense.txn_parse_pattern_registry r
        ON r.pattern_id = s.matched_pattern_id
    WHERE NOT EXISTS (
        SELECT 1 FROM spendsense.txn_parsed p WHERE p.fact_txn_id = s.fact_txn_id
    )
    -- IS-01: batch scoping
    AND (p_upload_id IS NULL OR s.upload_id = p_upload_id)
    AND (p_user_id   IS NULL OR s.user_id   = p_user_id);

    GET DIAGNOSTICS v_count = ROW_COUNT;
    RETURN v_count;
END;
$$;

-- Backward-compat wrapper
CREATE OR REPLACE FUNCTION spendsense.populate_txn_parsed_registry()
RETURNS void LANGUAGE sql AS $$
    SELECT spendsense.populate_txn_parsed_v2(NULL, NULL);
$$;

-- ============================================================
-- 10) UNKNOWN QUEUE POPULATION  (IS-05, IS-06, IS-12)
-- IS-05: UPDATE scoped to current batch only
-- IS-06: ON CONFLICT increments occurrence_count
-- IS-12: Updates shape-level aggregate stats table
-- ============================================================

CREATE OR REPLACE FUNCTION spendsense.populate_txn_parse_unknown_queue_v2(
    p_upload_id UUID DEFAULT NULL,
    p_user_id   TEXT DEFAULT NULL
)
RETURNS BIGINT
LANGUAGE plpgsql AS $$
DECLARE v_count BIGINT;
BEGIN
    -- IS-06: ON CONFLICT DO UPDATE increments occurrence_count
    INSERT INTO spendsense.txn_parse_unknown_queue (
        fact_txn_id, user_id, upload_id, bank_code, txn_date, amount, cr_dr,
        raw_description, normalized_description, guessed_channel_type,
        shape_signature, token_count_dash, token_count_slash,
        token_count_space, token_count_star,
        parse_status, parse_confidence, first_seen_at, last_seen_at, occurrence_count
    )
    SELECT
        s.fact_txn_id, s.user_id, s.upload_id, s.bank_code, s.txn_date,
        s.amount, s.cr_dr, s.raw_description, s.normalized_description,
        s.channel_type,
        spendsense.fn_txn_shape_signature(s.normalized_description),
        s.dash_token_count, s.slash_token_count, s.space_token_count, s.star_token_count,
        s.parse_status, s.parse_confidence, NOW(), NOW(), 1
    FROM spendsense.txn_parse_stage s
    WHERE (
        s.pattern_family = 'OTHER_UNKNOWN'
        OR s.parse_status IN ('UNPARSED','PARTIAL')
        OR s.parse_confidence < 0.70
    )
    AND (p_upload_id IS NULL OR s.upload_id = p_upload_id)
    AND (p_user_id   IS NULL OR s.user_id   = p_user_id)
    -- IS-06: ON CONFLICT increments — not ON CONFLICT DO NOTHING
    ON CONFLICT (fact_txn_id) DO UPDATE SET
        occurrence_count = spendsense.txn_parse_unknown_queue.occurrence_count + 1,
        last_seen_at     = NOW(),
        updated_at       = NOW();

    GET DIAGNOSTICS v_count = ROW_COUNT;

    -- IS-05: UPDATE last_seen_at scoped to current batch only (not all NEW rows)
    UPDATE spendsense.txn_parse_unknown_queue q
    SET last_seen_at = NOW(),
        updated_at   = NOW()
    WHERE q.review_status = 'NEW'
      AND q.fact_txn_id IN (
          SELECT s.fact_txn_id
          FROM spendsense.txn_parse_stage s
          WHERE (p_upload_id IS NULL OR s.upload_id = p_upload_id)
            AND (p_user_id   IS NULL OR s.user_id   = p_user_id)
      );

    -- IS-12: Upsert into shape-level aggregate stats
    INSERT INTO spendsense.txn_parse_unknown_shape_stats (
        shape_signature, guessed_channel_type, total_occurrence_count,
        first_seen_at, last_seen_at, example_description
    )
    SELECT
        spendsense.fn_txn_shape_signature(s.normalized_description),
        s.channel_type,
        COUNT(*),
        MIN(s.txn_date)::TIMESTAMPTZ,
        NOW(),
        MIN(s.normalized_description)
    FROM spendsense.txn_parse_stage s
    WHERE (p_upload_id IS NULL OR s.upload_id = p_upload_id)
      AND (p_user_id   IS NULL OR s.user_id   = p_user_id)
      AND (s.pattern_family = 'OTHER_UNKNOWN' OR s.parse_status IN ('UNPARSED','PARTIAL'))
    GROUP BY spendsense.fn_txn_shape_signature(s.normalized_description), s.channel_type
    ON CONFLICT (shape_signature, guessed_channel_type) DO UPDATE SET
        total_occurrence_count = spendsense.txn_parse_unknown_shape_stats.total_occurrence_count
                                 + EXCLUDED.total_occurrence_count,
        last_seen_at           = NOW(),
        example_description    = COALESCE(
            spendsense.txn_parse_unknown_shape_stats.example_description,
            EXCLUDED.example_description),
        updated_at             = NOW();

    RETURN v_count;
END;
$$;

-- Backward-compat wrapper
CREATE OR REPLACE FUNCTION spendsense.populate_txn_parse_unknown_queue()
RETURNS void LANGUAGE sql AS $$
    SELECT spendsense.populate_txn_parse_unknown_queue_v2(NULL, NULL);
$$;

-- ============================================================
-- 11) REPARSE FUNCTIONS  (IS-04: now re-populates after clearing)
-- ============================================================

-- IS-04: Reparse a single transaction — clears then re-populates atomically
CREATE OR REPLACE FUNCTION spendsense.fn_reparse_transaction(p_fact_txn_id UUID)
RETURNS TEXT    -- returns new parse_status
LANGUAGE plpgsql AS $$
DECLARE
    v_upload_id UUID;
    v_user_id   TEXT;
    v_status    TEXT;
BEGIN
    -- Get upload/user for scoped re-populate
    SELECT upload_id, user_id
    INTO v_upload_id, v_user_id
    FROM spendsense.txn_fact
    WHERE txn_id = p_fact_txn_id;

    -- Clear all derived rows for this transaction
    DELETE FROM spendsense.txn_parsed           WHERE fact_txn_id = p_fact_txn_id;
    DELETE FROM spendsense.txn_parse_stage       WHERE fact_txn_id = p_fact_txn_id;
    DELETE FROM spendsense.txn_parse_unknown_queue WHERE fact_txn_id = p_fact_txn_id;

    -- IS-04: Re-populate — the function now completes the loop
    PERFORM spendsense.populate_txn_parse_stage_v2(v_upload_id, v_user_id);
    PERFORM spendsense.populate_txn_parsed_v2(v_upload_id, v_user_id);
    PERFORM spendsense.populate_txn_parse_unknown_queue_v2(v_upload_id, v_user_id);

    SELECT parse_status INTO v_status
    FROM spendsense.txn_parsed WHERE fact_txn_id = p_fact_txn_id;

    RETURN COALESCE(v_status, 'NOT_FOUND');
END;
$$;

-- Backward-compat: old name only cleared, new name clears + re-populates
CREATE OR REPLACE FUNCTION spendsense.reparse_by_fact_txn_id(p_fact_txn_id UUID)
RETURNS TEXT LANGUAGE sql AS $$
    SELECT spendsense.fn_reparse_transaction(p_fact_txn_id);
$$;

-- IS-04: Reparse all transactions matching a shape signature
CREATE OR REPLACE FUNCTION spendsense.fn_reparse_by_shape(p_shape_signature TEXT)
RETURNS BIGINT  -- rows cleared
LANGUAGE plpgsql AS $$
DECLARE
    v_count BIGINT := 0;
    v_txn   RECORD;
BEGIN
    FOR v_txn IN
        SELECT q.fact_txn_id, tf.upload_id, tf.user_id
        FROM spendsense.txn_parse_unknown_queue q
        JOIN spendsense.txn_fact tf ON tf.txn_id = q.fact_txn_id
        WHERE q.shape_signature = p_shape_signature
    LOOP
        DELETE FROM spendsense.txn_parsed             WHERE fact_txn_id = v_txn.fact_txn_id;
        DELETE FROM spendsense.txn_parse_stage         WHERE fact_txn_id = v_txn.fact_txn_id;
        DELETE FROM spendsense.txn_parse_unknown_queue WHERE fact_txn_id = v_txn.fact_txn_id;
        v_count := v_count + 1;
    END LOOP;

    -- Mark shape as rule created in stats table
    UPDATE spendsense.txn_parse_unknown_shape_stats
    SET review_status = 'RULE_CREATED', updated_at = NOW()
    WHERE shape_signature = p_shape_signature;

    -- IS-04: Re-populate is caller's responsibility after adding the new pattern.
    -- The function raises a notice to make this explicit.
    RAISE NOTICE 'Cleared % transactions for shape %. Now INSERT new pattern into registry, then call populate_txn_parse_stage_v2() and populate_txn_parsed_v2().', v_count, p_shape_signature;
    RETURN v_count;
END;
$$;

-- Backward-compat
CREATE OR REPLACE FUNCTION spendsense.reparse_unknown_rows_by_signature(p_shape_signature TEXT)
RETURNS void LANGUAGE sql AS $$
    SELECT spendsense.fn_reparse_by_shape(p_shape_signature);
$$;

-- ============================================================
-- 12) MONITORING & DIAGNOSTIC VIEWS
-- ============================================================

-- Unknown shape clusters (uses aggregate stats table — IS-12)
CREATE OR REPLACE VIEW spendsense.vw_txn_parse_unknown_clusters AS
SELECT
    ss.shape_signature,
    ss.guessed_channel_type,
    ss.total_occurrence_count        AS txn_count,
    ss.first_seen_at,
    ss.last_seen_at,
    ss.example_description           AS example_1,
    ss.review_status,
    ss.suggested_pattern_family
FROM spendsense.txn_parse_unknown_shape_stats ss
WHERE ss.review_status = 'NEW'
ORDER BY ss.total_occurrence_count DESC, ss.shape_signature;

-- Pattern suggestions for unknown shapes
CREATE OR REPLACE VIEW spendsense.vw_txn_parse_unknown_suggestions AS
SELECT
    shape_signature, guessed_channel_type, total_occurrence_count AS txn_count,
    CASE
        WHEN guessed_channel_type='UPI'  AND shape_signature LIKE 'UPI-%VPA%'   THEN 'SUGGEST_UPI_DASH_VARIANT'
        WHEN guessed_channel_type='UPI'  AND shape_signature LIKE 'UPIOUT/%'    THEN 'SUGGEST_UPI_OUT_SLASH_VARIANT'
        WHEN guessed_channel_type='IMPS' AND shape_signature LIKE 'MMT/IMPS/%'  THEN 'SUGGEST_IMPS_MMT_VARIANT'
        WHEN guessed_channel_type='NEFT' AND shape_signature LIKE 'NEFT-%'      THEN 'SUGGEST_NEFT_DASH_VARIANT'
        WHEN guessed_channel_type='ACH'  AND shape_signature LIKE 'ACH D-%'     THEN 'SUGGEST_ACH_DASH_VARIANT'
        WHEN guessed_channel_type='NACH' AND shape_signature LIKE 'NACH %'      THEN 'SUGGEST_NACH_SPACE_VARIANT'
        ELSE 'MANUAL_REVIEW'
    END AS suggested_action,
    example_description
FROM spendsense.txn_parse_unknown_shape_stats
WHERE review_status = 'NEW'
ORDER BY total_occurrence_count DESC;

-- IS-07: Direction anomaly monitoring — surfaces UNKNOWN direction rows
CREATE OR REPLACE VIEW spendsense.vw_txn_parse_direction_anomalies AS
SELECT
    p.fact_txn_id,
    p.user_id,
    p.upload_id,
    p.channel_type,
    p.pattern_family,
    p.normalized_description,
    p.direction,
    p.parse_confidence,
    tf.direction AS raw_direction_from_bank
FROM spendsense.txn_parsed p
JOIN spendsense.txn_fact tf ON tf.txn_id = p.fact_txn_id
WHERE p.direction = 'UNKNOWN'
ORDER BY p.created_at DESC;

-- Quality KPI view
CREATE OR REPLACE VIEW spendsense.vw_txn_parse_quality_kpi AS
SELECT
    COUNT(*)                                                         AS total_rows,
    COUNT(*) FILTER (WHERE parse_status='PARSED')                    AS parsed_rows,
    COUNT(*) FILTER (WHERE parse_status='PARTIAL')                   AS partial_rows,
    COUNT(*) FILTER (WHERE parse_status='UNPARSED')                  AS unparsed_rows,
    COUNT(*) FILTER (WHERE direction='UNKNOWN')                      AS unknown_direction_rows,
    ROUND(100.0*COUNT(*) FILTER (WHERE parse_status='PARSED')
          /NULLIF(COUNT(*),0), 2)                                    AS parsed_pct,
    ROUND(100.0*COUNT(*) FILTER (WHERE direction='UNKNOWN')
          /NULLIF(COUNT(*),0), 2)                                    AS unknown_direction_pct,
    ROUND(AVG(parse_confidence), 2)                                  AS avg_confidence
FROM spendsense.txn_parsed;

-- Pattern coverage
CREATE OR REPLACE VIEW spendsense.vw_txn_parse_pattern_coverage AS
SELECT
    pattern_family, channel_type,
    COUNT(*) AS txn_count,
    ROUND(100.0*COUNT()/NULLIF(SUM(COUNT(*)) OVER (),0), 2) AS pct_share
FROM spendsense.txn_parsed
GROUP BY pattern_family, channel_type
ORDER BY txn_count DESC, pattern_family;

-- Unknown queue KPI
CREATE OR REPLACE VIEW spendsense.vw_txn_parse_unknown_kpi AS
SELECT guessed_channel_type, review_status, COUNT(*) AS unknown_rows
FROM spendsense.txn_parse_unknown_queue
GROUP BY guessed_channel_type, review_status
ORDER BY unknown_rows DESC, guessed_channel_type, review_status;

-- IS-10: CREATE OR REPLACE (was DROP VIEW IF EXISTS — unsafe)
CREATE OR REPLACE VIEW spendsense.vw_txn_parsed AS
SELECT
    p.fact_txn_id                                    AS txn_id,
    p.user_id,
    p.upload_id,
    p.bank_code,
    p.txn_date,
    p.amount,
    p.cr_dr                                          AS dr_cr,
    p.raw_description                                AS raw_desc,
    p.channel_type                                   AS txn_mode,
    p.direction                                      AS direction_text,
    p.upi_rrn                                        AS rrn,
    COALESCE(p.neft_utr, p.imps_rrn, p.internal_ref) AS utr,
    p.counterparty_name,
    p.counterparty_bank_code,
    p.counterparty_vpa                               AS upi_vpa,
    CASE WHEN p.counterparty_vpa LIKE '**%' THEN p.counterparty_vpa END AS upi_vpa_masked,
    CASE
        WHEN p.counterparty_vpa ILIKE '%VYAPAR%'    THEN 'VYAPAR'
        WHEN p.counterparty_vpa ILIKE '%BHARATPE%'  THEN 'BHARATPE'
        WHEN p.counterparty_vpa ILIKE '%PAYTM%'     THEN 'PAYTM'
        WHEN p.counterparty_vpa ILIKE '%PHONEPE%'   THEN 'PHONEPE'
        WHEN p.counterparty_vpa ILIKE '%GOOGLEPAY%' THEN 'GOOGLEPAY'
        WHEN p.counterparty_vpa ILIKE '%.RZP@%'     THEN 'RAZORPAY'
    END AS platform_or_gateway,
    p.counterparty_ifsc                              AS ifsc,
    COALESCE(p.biller_name, p.ach_nach_entity)       AS biller_name,
    p.biller_code,
    p.card_ref,
    p.atm_txn_id,
    p.atm_location,
    p.mcc,
    p.ach_nach_entity                                AS originator_name,
    p.mandate_or_run_id,
    p.purpose,
    p.note_text,
    p.merchant_name,
    p.pattern_family,
    p.parse_status,
    p.parse_confidence,
    p.parse_version
FROM spendsense.txn_parsed p;

COMMIT;

-- ============================================================
-- RUN ORDER
-- ============================================================
-- Initial load for a specific upload:
--   SELECT spendsense.populate_txn_parse_stage_v2('<upload_uuid>');
--   SELECT spendsense.populate_txn_parsed_v2('<upload_uuid>');
--   SELECT spendsense.populate_txn_parse_unknown_queue_v2('<upload_uuid>');
--
-- Full rebuild (all data — admin use):
--   SELECT spendsense.populate_txn_parse_stage_v2();
--   SELECT spendsense.populate_txn_parsed_v2();
--   SELECT spendsense.populate_txn_parse_unknown_queue_v2();
--
-- Review unknowns:
--   SELECT * FROM spendsense.vw_txn_parse_unknown_clusters LIMIT 50;
--   SELECT * FROM spendsense.vw_txn_parse_unknown_suggestions LIMIT 50;
--
-- Add new pattern to registry, then reprocess that shape:
--   INSERT INTO spendsense.txn_parse_pattern_registry (...) VALUES (...);
--   SELECT spendsense.fn_reparse_by_shape('<shape_signature>');
--   SELECT spendsense.populate_txn_parse_stage_v2();
--   SELECT spendsense.populate_txn_parsed_v2();
--   SELECT spendsense.populate_txn_parse_unknown_queue_v2();
--
-- Add internal_ref regex for a pattern (IS-03):
--   UPDATE spendsense.txn_parse_pattern_registry
--   SET internal_ref_regex = '//([A-Z0-9]{8,})'
--   WHERE pattern_family = 'MY_NEW_PATTERN';
--
-- Monitor quality:
--   SELECT * FROM spendsense.vw_txn_parse_quality_kpi;
--   SELECT * FROM spendsense.vw_txn_parse_pattern_coverage;
--   SELECT * FROM spendsense.vw_txn_parse_unknown_kpi;
--   SELECT * FROM spendsense.vw_txn_parse_direction_anomalies LIMIT 20;
--
-- Reparse single transaction:
--   SELECT spendsense.fn_reparse_transaction('<fact_txn_id>');
-- ============================================================
