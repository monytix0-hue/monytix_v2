-- ============================================================
-- MONYTIX — BANK-AGNOSTIC TRANSACTION PARSING FRAMEWORK v3.0
-- PostgreSQL / PLpgSQL
--
-- UPGRADE FROM v2:
--   • Replaces positional slot model with token-classifier model
--   • Two new config tables: txn_channel_format_registry,
--     txn_channel_field_schema
--   • sub_type column added to txn_parsed and txn_parse_stage
--   • New functions: fn_classify_tokens, fn_parse_nach,
--     fn_detect_format_v3, populate_txn_parse_stage_v3,
--     populate_txn_parsed_v3
--   • v2 populate functions DROPPED — v3 is the sole pipeline
--   • PARSED threshold: min field confidence >= 0.70
--   • Truncated OTHER rows: park in unknown_queue, UNPARSED
--   • NACH: dedicated fn_parse_nach() regex extractor
--   • OTHER sub-types: channel_type=OTHER + sub_type column
--
-- Object inventory (new/changed):
--   Tables (new)  : txn_channel_format_registry
--                   txn_channel_field_schema
--   Tables (alter): txn_parsed        — add sub_type, parse_format
--                   txn_parse_stage   — add sub_type, parse_format
--   Tables (drop) : txn_parse_pattern_registry (v2 positional registry)
--   Functions (new): fn_detect_format_v3
--                    fn_classify_tokens
--                    fn_parse_nach
--                    fn_parse_other_subtype
--                    fn_derive_direction_v3
--                    populate_txn_parse_stage_v3
--                    populate_txn_parsed_v3
--   Functions (drop): populate_txn_parse_stage_v2
--                     populate_txn_parsed_v2
--                     populate_txn_parse_stage_registry
--                     populate_txn_parsed_registry
--                     fn_detect_best_pattern
--                     detect_txn_pattern
--                     fn_pick_token
-- ============================================================

BEGIN;

-- ============================================================
-- SECTION 1: NEW CONFIG TABLE — txn_channel_format_registry
--
-- One row per format shape.
-- detection_regex   : matched against normalised description
-- delimiter         : primary split character
-- direction_rule    : LEDGER | IN | OUT | REV | FROM_TOKEN
-- direction_token_pos: when FROM_TOKEN — which token index
--                      holds DR/CR/REV (0-based after split)
-- skip_positions    : array of token indices to discard as
--                     structural noise before scoring
-- prefix_strip_regex: optional — strip a leading noise prefix
--                     (e.g. timestamp, hex ref) before splitting
-- ============================================================

CREATE TABLE IF NOT EXISTS spendsense.txn_channel_format_registry (
    format_id           BIGSERIAL PRIMARY KEY,
    channel_type        TEXT NOT NULL,
    format_name         TEXT NOT NULL,
    detection_regex     TEXT NOT NULL,
    delimiter           TEXT NOT NULL DEFAULT '-',
    direction_rule      TEXT NOT NULL DEFAULT 'LEDGER'
                            CHECK (direction_rule IN
                                ('LEDGER','IN','OUT','REV','FROM_TOKEN')),
    direction_token_pos INT,
    skip_positions      INT[],
    prefix_strip_regex  TEXT,
    parse_confidence    NUMERIC(5,2) NOT NULL DEFAULT 0.90,
    priority            INT NOT NULL DEFAULT 100,
    active              BOOLEAN NOT NULL DEFAULT TRUE,
    notes               TEXT,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_channel_format UNIQUE (channel_type, format_name)
);

CREATE INDEX IF NOT EXISTS ix_cfr_channel
    ON spendsense.txn_channel_format_registry(channel_type);
CREATE INDEX IF NOT EXISTS ix_cfr_priority
    ON spendsense.txn_channel_format_registry(active, priority);

COMMENT ON TABLE spendsense.txn_channel_format_registry IS
'One row per structural format shape per channel.
 Token classifier uses this to detect format, split, and drop
 structural noise tokens before field scoring.';

-- ============================================================
-- SECTION 2: NEW CONFIG TABLE — txn_channel_field_schema
--
-- One row per (channel_type, field_name).
-- match_regex    : token must match this (case-insensitive)
-- exclude_regex  : token must NOT match this (disqualifier)
-- min_length / max_length : optional token length guards
-- confidence     : base score when match_regex fires
-- is_fallback    : TRUE = assigned only if nothing else claimed
--                  the token (purpose / note)
-- ============================================================

CREATE TABLE IF NOT EXISTS spendsense.txn_channel_field_schema (
    schema_id       BIGSERIAL PRIMARY KEY,
    channel_type    TEXT NOT NULL,
    field_name      TEXT NOT NULL,
    match_regex     TEXT NOT NULL,
    exclude_regex   TEXT,
    min_length      INT,
    max_length      INT,
    confidence      NUMERIC(5,2) NOT NULL DEFAULT 0.80,
    is_fallback     BOOLEAN NOT NULL DEFAULT FALSE,
    notes           TEXT,
    CONSTRAINT uq_channel_field UNIQUE (channel_type, field_name)
);

CREATE INDEX IF NOT EXISTS ix_cfs_channel
    ON spendsense.txn_channel_field_schema(channel_type);

COMMENT ON TABLE spendsense.txn_channel_field_schema IS
'Field signature rules per channel type.
 fn_classify_tokens scores every non-skip token against these
 and assigns each token to the highest-scoring field.';

-- ============================================================
-- SECTION 3: DROP v2 OBJECTS + ALTER EXISTING TABLES
--
-- Drop v2 functions and the positional pattern registry.
-- The new txn_channel_format_registry + txn_channel_field_schema
-- replace txn_parse_pattern_registry entirely.
-- The txn_parse_stage and txn_parsed tables are kept and extended.
-- ============================================================

-- Drop v2 populate functions (replaced by v3)
DROP FUNCTION IF EXISTS spendsense.populate_txn_parse_stage_v2(UUID, TEXT);
DROP FUNCTION IF EXISTS spendsense.populate_txn_parsed_v2(UUID, TEXT);
DROP FUNCTION IF EXISTS spendsense.populate_txn_parse_stage_registry();
DROP FUNCTION IF EXISTS spendsense.populate_txn_parsed_registry();

-- Drop v2 pattern-matching functions (replaced by fn_detect_format_v3)
DROP FUNCTION IF EXISTS spendsense.fn_detect_best_pattern(TEXT);
DROP FUNCTION IF EXISTS spendsense.detect_txn_pattern(TEXT);

-- Drop positional slot helper (replaced by fn_classify_tokens)
DROP FUNCTION IF EXISTS spendsense.fn_pick_token(TEXT, TEXT[], TEXT[], TEXT[], TEXT[], INT);

-- Drop v2 positional pattern registry
-- (data preserved in txn_channel_format_registry going forward)
DROP TABLE IF EXISTS spendsense.txn_parse_pattern_registry CASCADE;

-- Alter existing tables — add v3 columns
ALTER TABLE spendsense.txn_parsed
    ADD COLUMN IF NOT EXISTS sub_type TEXT,
    ADD COLUMN IF NOT EXISTS parse_format TEXT;

ALTER TABLE spendsense.txn_parse_stage
    ADD COLUMN IF NOT EXISTS sub_type TEXT,
    ADD COLUMN IF NOT EXISTS parse_format TEXT;

CREATE INDEX IF NOT EXISTS ix_txn_p_sub_type
    ON spendsense.txn_parsed(sub_type) WHERE sub_type IS NOT NULL;

COMMENT ON COLUMN spendsense.txn_parsed.sub_type IS
'For channel_type=OTHER: CC_PAYMENT, MOB_TRANSFER, EMI,
 INTEREST_CREDIT, CHEQUE, CASH_DEPOSIT, BILLDESK, TRUNCATED.
 NULL for all other channels.';

COMMENT ON COLUMN spendsense.txn_parsed.parse_format IS
'Format name from txn_channel_format_registry that matched,
 e.g. UPI_DASH, IMPS_P2A_SLASH, NEFT_CR_DASH.
 NULL if no format matched (OTHER_UNKNOWN).';

-- ============================================================
-- SECTION 4: SEED txn_channel_format_registry
-- ============================================================

INSERT INTO spendsense.txn_channel_format_registry (
    channel_type, format_name, detection_regex, delimiter,
    direction_rule, direction_token_pos, skip_positions,
    prefix_strip_regex, parse_confidence, priority, notes
) VALUES

-- ── UPI ─────────────────────────────────────────────────────
('UPI','UPI_DASH',
    '^UPI-', '-', 'LEDGER', NULL, ARRAY[0],
    NULL, 0.92, 10,
    'HDFC/ICICI/Axis/Kotak dash UPI. skip[0]=UPI prefix.
     2-token=truncated(name only). 6-token=canonical.
     7-token=gateway splits out between name and vpa.'),

('UPI','UPI_P2A_SLASH',
    '^UPI/P2A/', '/', 'OUT', NULL, ARRAY[0,1],
    NULL, 0.93, 11,
    'Slash P2A format. skip[0]=UPI, skip[1]=P2A label.
     Tokens: rrn, name, bank/purpose, bank.'),

('UPI','UPI_P2M_SLASH',
    '^UPI/P2M/', '/', 'OUT', NULL, ARRAY[0,1],
    NULL, 0.93, 12,
    'Slash P2M format. skip[0]=UPI, skip[1]=P2M label.
     Tokens: rrn, merchant_name, purpose/note, bank.'),

('UPI','UPI_CRDRREV_SLASH',
    '^UPI/(DR|CR|REV)/', '/', 'FROM_TOKEN', 1, ARRAY[0,1],
    NULL, 0.92, 13,
    'ICICI slash format. token[1]=DR/CR/REV sets direction.
     VPA is masked (**prefix). Internal ref in last slot.'),

('UPI','UPIOUT_SLASH',
    '^UPIOUT/', '/', 'OUT', NULL, ARRAY[0],
    NULL, 0.92, 14,
    'Federal Bank. skip[0]=UPIOUT. Tokens: rrn, vpa, purpose.'),

('UPI','UPI_IN_SLASH',
    '^UPI IN/', '/', 'IN', NULL, ARRAY[0],
    NULL, 0.92, 15,
    'skip[0]=UPI IN. Tokens: rrn, sender_vpa, purpose.'),

('UPI','REV_DASH',
    '^REV-UPI-', '-', 'REV', NULL, ARRAY[0,1],
    NULL, 0.92, 16,
    'Reversal. skip[0]=REV, skip[1]=UPI. RRN=14 digits.
     Last token may be "VPA SPACE ACCOUNT" — needs secondary split.'),

-- ── IMPS ────────────────────────────────────────────────────
('IMPS','IMPS_DASH',
    '^IMPS-', '-', 'LEDGER', NULL, ARRAY[0],
    NULL, 0.92, 20,
    'Most common IMPS format. skip[0]=IMPS.
     Tokens: rrn(12d), name, bank_code, masked_acct, purpose.'),

('IMPS','IMPS_P2A_SLASH',
    '^IMPS/P2A/', '/', 'LEDGER', NULL, ARRAY[0,1],
    NULL, 0.92, 21,
    'skip[0]=IMPS, skip[1]=P2A.
     Tokens: rrn, name(trunc), bank, purpose, internal_ref.'),

('IMPS','MOB_IMPS_SLASH',
    '(^|[\s/])(MOB|INET)-IMPS-(CR|DR)/', '/', 'FROM_TOKEN', NULL,
    ARRAY[]::INT[],
    '^[0-9A-Fa-f:]+\s+\d{12}\s+',
    0.90, 22,
    'ICICI MOB/INET IMPS. Has optional timestamp+hex prefix.
     prefix_strip_regex removes leading noise.
     CR/DR in first real token sets direction.
     Tokens: name, bank, rrn, purpose, acct/phone, date parts.'),

('IMPS','MMT_IMPS_SLASH',
    '^MMT/IMPS/', '/', 'LEDGER', NULL, ARRAY[0,1],
    NULL, 0.92, 23,
    'skip[0]=MMT, skip[1]=IMPS. Tokens: rrn, name, ifsc.'),

('IMPS','IMPS_FT_SLASH',
    '^FT IMPS/', '/', 'LEDGER', NULL, ARRAY[0],
    NULL, 0.88, 24,
    'Forex/FT IMPS. skip[0]=FT IMPS. Tokens: type, rrn, note.'),

-- ── NEFT ────────────────────────────────────────────────────
('NEFT','NEFT_SLASH',
    '^NEFT/(?!MB/|RETURN/)', '/', 'LEDGER', NULL, ARRAY[0],
    NULL, 0.93, 30,
    'Canonical slash NEFT. skip[0]=NEFT.
     Tokens: utr, name, bank, purpose.'),

('NEFT','NEFT_MB_SLASH',
    '^NEFT/MB/', '/', 'LEDGER', NULL, ARRAY[0,1],
    NULL, 0.92, 31,
    'Axis mobile NEFT. skip[0]=NEFT, skip[1]=MB.
     Tokens: utr(AXOMB…), name, bank, purpose.'),

('NEFT','NEFT_RETURN_SLASH',
    '^NEFT/RETURN/', '/', 'REV', NULL, ARRAY[0,1],
    NULL, 0.92, 32,
    'NEFT return. skip[0]=NEFT, skip[1]=RETURN.
     Tokens: utr, sender_code, name, alt_ref.'),

('NEFT','NEFT_CR_DASH',
    '^NEFT (CR|DR)-', '-', 'FROM_TOKEN', 0, ARRAY[]::INT[],
    NULL, 0.91, 33,
    'token[0]=NEFT CR/DR sets direction.
     Tokens: sender_ifsc, sender_org, purpose, beneficiary_name, utr.
     utr is in LAST slot (not slot 2).'),

('NEFT','NEFT_PLAIN_DASH',
    '^NEFT-', '-', 'LEDGER', NULL, ARRAY[0],
    NULL, 0.90, 34,
    'Plain dash NEFT. skip[0]=NEFT. Tokens: utr, name, ifsc.'),

-- ── ACH ─────────────────────────────────────────────────────
('ACH','ACH_DR_DASH',
    '^ACH-DR-', '-', 'OUT', NULL, ARRAY[0,1],
    NULL, 0.92, 40,
    'Most common ACH. skip[0]=ACH, skip[1]=DR.
     Tokens: entity_name, mandate_ref, bank_ifsc_fragment.'),

('ACH','ACH_D_DASH',
    '^ACH D-', '-', 'OUT', NULL, ARRAY[0],
    NULL, 0.90, 41,
    'Legacy ACH D format. skip[0]=ACH D (with space).
     Tokens: entity_name, mandate_ref, sub-refs.'),

('ACH','ACH_SLASH',
    '^ACH/', '/', 'LEDGER', NULL, ARRAY[0],
    NULL, 0.90, 42,
    'Slash ACH. skip[0]=ACH. Tokens: entity, ref.'),

-- ── NACH ────────────────────────────────────────────────────
-- NACH uses fn_parse_nach() — regex extraction, not token scoring.
-- Format registry entry triggers the right handler.
('NACH','NACH_SPACE_MF',
    '^NACH\s+[A-Z]{3,}[A-Z0-9]*\d{8}[A-Z]+', ' ', 'OUT', NULL,
    ARRAY[]::INT[],
    '^[0-9A-Fa-f/\s:]+(?=NACH\s)',
    0.93, 50,
    'Mutual fund SIP NACH. Dense concatenated token.
     Parsed by fn_parse_nach() — not token scorer.
     prefix_strip_regex removes leading timestamp/hex.'),

-- ── ATM ─────────────────────────────────────────────────────
('ATM','NWD_DASH',
    '^NWD-', '-', 'OUT', NULL, ARRAY[0],
    NULL, 0.92, 60,
    'skip[0]=NWD. Tokens: card(XXXXXX), atm_terminal_id, location.'),

('ATM','ATM_WDL_DASH',
    '^ATM WDL-ATM CASH', '-', 'OUT', NULL, ARRAY[0],
    NULL, 0.90, 61,
    'Full text regex. atm_id and location in first real token.'),

('ATM','ATM_CASH_SLASH',
    '^ATM-CASH/', '/', 'OUT', NULL, ARRAY[0],
    NULL, 0.90, 62,
    'Was misclassified as OTHER. skip[0]=ATM-CASH.
     Tokens: location_detail, city, date(DDMMYY).'),

('ATM','ATM_INTL_SLASH',
    '^TO INTL\. ATM MRK/', '/', 'OUT', NULL, ARRAY[0],
    NULL, 0.88, 63,
    'International ATM. Tokens: rrn, merchant_name.'),

-- ── POS ─────────────────────────────────────────────────────
('POS','POS_SPACE',
    '^POS [0-9A-Z]{12,}', ' ', 'OUT', NULL, ARRAY[0],
    NULL, 0.90, 70,
    'Space-delimited POS. skip[0]=POS.
     Tokens: card(XXXXXX masked), merchant_name.'),

('POS','POS_NOSPACE',
    '^POS[0-9]{6}', ' ', 'OUT', NULL, ARRAY[]::INT[],
    NULL, 0.85, 71,
    'No-space POS — card and merchant concatenated.
     Use regex extract: card=^POS(\d{6}X+\d{4}), merchant=remainder.'),

-- ── CARD_BILLPAY ─────────────────────────────────────────────
('CARD_BILLPAY','IBBILLPAYDR_DASH',
    '^IBBILLPAYDR-', '-', 'OUT', NULL, ARRAY[0],
    NULL, 0.92, 80,
    'HDFC internet banking card bill pay (no spaces in prefix).
     skip[0]=IBBILLPAYDR.
     Tokens: biller_code(HDFC4W/HDFCCS), card+ref(space-joined).
     card_ref = split on space: [0]=masked_card, [1]=txn_ref.'),

('CARD_BILLPAY','IB_BILLPAY_DR_DASH',
    '^IB BILLPAY DR-', '-', 'OUT', NULL, ARRAY[0],
    NULL, 0.92, 81,
    'Legacy with spaces. skip[0]=IB BILLPAY DR.
     Same structure as IBBILLPAYDR_DASH.'),

-- ── OTHER sub-types ──────────────────────────────────────────
('OTHER','CC_PAYMENT_SPACE',
    '^CreditCard Payment XX', ' ', 'OUT', NULL, ARRAY[0,1,2],
    NULL, 0.92, 90,
    'Credit card self-payment. skip[0]=CreditCard, [1]=Payment, [2]=XX.
     Tokens: card_last4, ref_token(Ref#…).'),

('OTHER','MOB_TPFT_SLASH',
    '^MOB/TPFT/', '/', 'OUT', NULL, ARRAY[0,1],
    NULL, 0.90, 91,
    'Mobile transfer. sub_type=MOB_TRANSFER.
     skip[0]=MOB, [1]=TPFT. Tokens: name, phone_or_account.'),

('OTHER','EMI_PPR',
    '^PPR\d+_EMI_', '_', 'OUT', NULL, ARRAY[]::INT[],
    NULL, 0.90, 92,
    'EMI deduction. sub_type=EMI. Underscore delimiter.
     Fields via regex: loan_ref, emi_date, borrower_name.'),

('OTHER','INTEREST_CREDIT_SPACE',
    '^INTEREST PAID|^INTERESTPAID|^Int\.Pd:|^SB:[0-9]', '-', 'IN',
    NULL, ARRAY[]::INT[],
    NULL, 0.90, 93,
    'Interest credit. sub_type=INTEREST_CREDIT.
     Fields via regex: account, period_from, period_to.'),

('OTHER','CHEQUE_PAID',
    '^CHQPAID-|^CHQ ', '-', 'OUT', NULL, ARRAY[0],
    NULL, 0.88, 94,
    'Cheque payment. sub_type=CHEQUE.
     Tokens: clearing_type, payee_name.'),

('OTHER','CASH_DEPOSIT',
    '^BY CASH DEPOSIT', '/', 'IN', NULL, ARRAY[0],
    NULL, 0.88, 95,
    'Cash deposit. sub_type=CASH_DEPOSIT.
     Tokens: branch_ref, amount_ref, date(DDMMYY), location.'),

('OTHER','BILLDESK',
    '^[A-Z0-9]{12,}/BILLDK', ' ', 'OUT', NULL, ARRAY[]::INT[],
    NULL, 0.88, 96,
    'BillDesk payment gateway. sub_type=BILLDESK.
     token[0]=txn_hash/BILLDK{biller_code}, token[1]=internal_ref.'),

('OTHER','POS_CC_BILL',
    '^POS[0-9]{6}X+[0-9]{4}[A-Z]{2}HDFC', ' ', 'OUT', NULL,
    ARRAY[]::INT[],
    NULL, 0.88, 97,
    'POS credit card bill pay. sub_type=CC_PAYMENT.
     Promote to CARD_BILLPAY channel in parsing.')

ON CONFLICT (channel_type, format_name) DO UPDATE
    SET detection_regex    = EXCLUDED.detection_regex,
        delimiter          = EXCLUDED.delimiter,
        direction_rule     = EXCLUDED.direction_rule,
        skip_positions     = EXCLUDED.skip_positions,
        prefix_strip_regex = EXCLUDED.prefix_strip_regex,
        parse_confidence   = EXCLUDED.parse_confidence,
        priority           = EXCLUDED.priority,
        notes              = EXCLUDED.notes,
        updated_at         = NOW();

-- ============================================================
-- SECTION 5: SEED txn_channel_field_schema
-- ============================================================

INSERT INTO spendsense.txn_channel_field_schema (
    channel_type, field_name, match_regex, exclude_regex,
    min_length, max_length, confidence, is_fallback, notes
) VALUES

-- ── UPI fields ───────────────────────────────────────────────
('UPI','upi_rrn',
    '^\d{12,14}$', NULL,
    12, 14, 0.99, FALSE,
    '12 digits for most formats, 14 for REV/HDFC.'),

('UPI','counterparty_vpa',
    '[a-z0-9._%+\-]+@[a-z]|\*\*[a-z0-9._%+\-]+@',
    NULL,
    5, 60, 0.98, FALSE,
    'Standard VPA (user@bank) or masked VPA (**prefix@bank).'),

('UPI','counterparty_name',
    '^[A-Z][A-Z0-9 .]{2,}$',
    '(@|BANK$|PAYMENTS$|^[0-9]+$|^(GPAY|PAYTM|PHONEPE|BHIM|AIRTEL|UPI|IN|OUT|DR|CR|REV|P2A|P2M|P2P|TRF|LEDGER|PAYMENTFROMPHONE|SENT|COLLECT)$)',
    3, 40, 0.82, FALSE,
    'Alpha name. Excludes bank names, VPAs, known keywords, pure digits.'),

('UPI','counterparty_bank',
    '(BANK|PAYMENTS BANK|BANK LTD|BANK LIMITED)$|^(SBI|HDFC|ICICI|AXIS|KOTAK|YES|CANARA|PNB|BOB|UNION|IDFC|AIRTEL|FEDERAL|INDUS|BANDHAN|CITI|HSBC|RBL|DCB|AUSFB|UTIB|SBIN|CNRB|HDFC0|ICIC0|YESB0|UBIN|MAHB|INDB)([0-9A-Z]*)$',
    NULL,
    2, 40, 0.95, FALSE,
    'Bank name or IFSC-style code.'),

('UPI','counterparty_ifsc',
    '^[A-Z]{4}0[A-Z0-9]{6}$',
    NULL,
    11, 11, 0.99, FALSE,
    'Standard 11-char IFSC.'),

('UPI','txn_type_code',
    '^(P2A|P2M|P2P|DR|CR|REV)$',
    NULL,
    2, 3, 0.99, FALSE,
    'UPI transaction type indicator.'),

('UPI','gateway_name',
    '^(GPAY|PAYTM|PHONEPE|BHIM|AIRTEL|YESPAY|AMAZONPAY|MOBIKWIK|FREECHARGE)$',
    '@',
    3, 15, 0.97, FALSE,
    'Standalone gateway name token (no @ = not a VPA).'),

('UPI','internal_ref',
    '[A-F0-9]{16,}|^[A-Z]{3,4}[0-9A-F]{12,}$',
    '^\d{12,14}$',
    10, 60, 0.90, FALSE,
    'Hex internal ref or bank-format ref. Excludes RRN digits.'),

('UPI','purpose',
    '.',
    NULL,
    1, 80, 0.50, TRUE,
    'Fallback — any unassigned token. is_fallback=TRUE.'),

-- ── IMPS fields ──────────────────────────────────────────────
('IMPS','imps_rrn',
    '^\d{12}$',
    NULL,
    12, 12, 0.99, FALSE,
    'IMPS RRN always exactly 12 digits.'),

('IMPS','counterparty_name',
    '^[A-Z][A-Z0-9 .]{2,}$',
    '(@|BANK$|PAYMENTS$|^[0-9]+$|^(TRF|SAVINGS|DONATION|RENT|IMPS|TRANSFER|TRANS|MAINTENANCE|OWN|AC|SELF|CUSTOMER|VENDORPA|REMITTER|HANDLOAN)$)',
    3, 40, 0.82, FALSE,
    'Person or org name. Excludes bank names and common keywords.'),

('IMPS','counterparty_bank',
    '(BANK$|BANK LTD$|BANK LIMITED$)|^(HDFC|ICICI|ICIC|SBIN|UBIN|MAHB|CNRB|HSBC|FDRL|YESB|INDB|IDFC|UTIB|AXIS|SBI|PNB|BOB)([0-9A-Z]*)$',
    NULL,
    2, 30, 0.95, FALSE,
    'Bank name or 4-char code.'),

('IMPS','counterparty_account',
    '^X{4,}[0-9]{4,}$|^[0-9]{9,18}$',
    '^\d{12}$',
    6, 20, 0.90, FALSE,
    'Masked account (XXXXX1234) or raw account number. Excludes RRN.'),

('IMPS','counterparty_ifsc',
    '^[A-Z]{4}0[A-Z0-9]{6}$',
    NULL,
    11, 11, 0.99, FALSE,
    'Standard IFSC.'),

('IMPS','internal_ref',
    '^[0-9]{16,}$|^[A-Z]{4}[0-9]{10,}$',
    '^\d{12}$',
    14, 30, 0.88, FALSE,
    'Long numeric internal ref or bank-format ref.'),

('IMPS','purpose',
    '.',
    NULL,
    1, 80, 0.50, TRUE,
    'Fallback.'),

-- ── NEFT fields ──────────────────────────────────────────────
('NEFT','neft_utr',
    '^[A-Z]{4}[HN]\d{11,}$|^[A-Z]{4}\d{2}\d{10,}$|^[A-Z]{3,6}\d{14,}$',
    NULL,
    12, 25, 0.99, FALSE,
    'UTR: HDFCH004…, CITIN256…, SBIN425…, AXOMB219….'),

('NEFT','counterparty_name',
    '^[A-Z][A-Za-z0-9 .]{3,}$',
    '(BANK$|BANK LTD$|BANK LIMITED$|^[0-9]+$|^(MB|RETURN|NEFT|SELF|ATTN|INB|NULL)$)',
    4, 50, 0.82, FALSE,
    'Person or org name. Excludes structural tokens.'),

('NEFT','counterparty_bank',
    '(BANK$|BANK LTD$|BANK LIMITED$)|^(HDFC|ICICI|SBIN|CITI|YES|AXIS|IDBI|CITI0)([0-9A-Z]*)$',
    NULL,
    3, 30, 0.95, FALSE,
    'Bank name.'),

('NEFT','counterparty_ifsc',
    '^[A-Z]{4}0[A-Z0-9]{6}$',
    NULL,
    11, 11, 0.99, FALSE,
    'Standard IFSC.'),

('NEFT','purpose',
    '.',
    NULL,
    1, 100, 0.50, TRUE,
    'Fallback — salary note, rent note, etc.'),

-- ── ACH fields ───────────────────────────────────────────────
('ACH','ach_entity',
    '^[A-Z][A-Z0-9_ .]{2,}$',
    '^(DR|CR|ACH|IN|OUT)$',
    3, 40, 0.85, FALSE,
    'Biller/entity name. e.g. BAJAJ FINANCE LTD, BD_HDFCMF.'),

('ACH','mandate_ref',
    '^[A-Z0-9]{6,}$',
    '^(DR|CR|ACH|UTIB|HDFC|ICIC|SBIN|AXIS|YESB|CNRB)([0-9A-Z]*)$',
    6, 30, 0.85, FALSE,
    'ACH mandate/run reference (alphanumeric or numeric).'),

('ACH','counterparty_ifsc',
    '^[A-Z]{4}0[A-Z0-9]{6}$|^[A-Z]{4}[0-9]{7,}$',
    NULL,
    8, 20, 0.90, FALSE,
    'Bank IFSC or partial IFSC fragment.'),

('ACH','purpose',
    '.',
    NULL,
    1, 60, 0.50, TRUE,
    'Fallback.'),

-- ── ATM fields ───────────────────────────────────────────────
('ATM','card_number',
    '^[0-9]{6}X+[0-9]{4}$|^[0-9]{6}X{4,}[0-9]{3,4}$',
    NULL,
    12, 20, 0.99, FALSE,
    'Masked card number. Pattern: 6 digits, X+, 4 digits.'),

('ATM','atm_terminal_id',
    '^[A-Z0-9]{6,10}$',
    '^(BANGALORE|HYDERABAD|MUMBAI|DELHI|CHENNAI|PUNE|KOLKATA|UJJAIN|KHAMMAM|UPI|ATM|NWD)$',
    4, 12, 0.85, FALSE,
    'ATM terminal code. Excludes city names.'),

('ATM','atm_location',
    '^[A-Z][A-Z ]{3,}$',
    '^(NWD|ATM|CASH|UPI|DR|CR)$',
    3, 40, 0.82, FALSE,
    'City or location name.'),

('ATM','atm_txn_id',
    '^\d{4,6}$',
    NULL,
    4, 6, 0.80, FALSE,
    'ATM transaction ID (short numeric, ATM WDL format).'),

('ATM','purpose',
    '.',
    NULL,
    1, 60, 0.50, TRUE,
    'Fallback.'),

-- ── POS fields ───────────────────────────────────────────────
('POS','card_number',
    '^[0-9]{6}X+[0-9]{4}$',
    NULL,
    12, 20, 0.99, FALSE,
    'Masked card.'),

('POS','merchant_name',
    '^[A-Z][A-Z0-9 .]{2,}$',
    '^(POS|UPI|DR|CR)$',
    3, 50, 0.80, FALSE,
    'Merchant name at POS terminal.'),

-- ── CARD_BILLPAY fields ──────────────────────────────────────
('CARD_BILLPAY','biller_code',
    '^HDFC(4W|CS|CC|PL|HL|LAP|GL|BL|AL|TWL)$|^[A-Z0-9]{4,12}$',
    NULL,
    4, 15, 0.90, FALSE,
    'Biller product code. HDFC4W=4-wheeler, HDFCCS=credit card.'),

('CARD_BILLPAY','card_ref',
    '^[0-9]{6}X+[0-9]{4}\s+[A-Z0-9]{10,}$|^[0-9]{6}X+[0-9]{4}$',
    NULL,
    12, 40, 0.92, FALSE,
    'Masked card + txn ref, space-separated in one token.'),

('CARD_BILLPAY','internal_ref',
    '^MB[0-9]{10,}[A-Z0-9]{2,}$',
    NULL,
    10, 25, 0.95, FALSE,
    'HDFC mobile banking ref e.g. MB07121523714T48.'),

-- ── OTHER sub-type fields ────────────────────────────────────
('OTHER','card_last4',
    '^\d{4}$',
    NULL,
    4, 4, 0.90, FALSE,
    'Last 4 digits of credit card (CC_PAYMENT format).'),

('OTHER','payment_ref',
    '^Ref#[A-Z0-9]{10,}$',
    NULL,
    8, 25, 0.95, FALSE,
    'Reference number with Ref# prefix (CC_PAYMENT).'),

('OTHER','counterparty_name',
    '^[A-Z][A-Za-z ]{3,}$',
    '^(MOB|TPFT|UPI|NACH|ACH|NEFT|IMPS)$',
    4, 40, 0.82, FALSE,
    'Name in MOB_TRANSFER and CHEQUE formats.'),

('OTHER','phone_or_account',
    '^[0-9]{10,16}$',
    NULL,
    10, 16, 0.88, FALSE,
    'Phone number or account number (MOB_TRANSFER).'),

('OTHER','purpose',
    '.',
    NULL,
    1, 100, 0.50, TRUE,
    'Fallback.')

ON CONFLICT (channel_type, field_name) DO UPDATE
    SET match_regex   = EXCLUDED.match_regex,
        exclude_regex = EXCLUDED.exclude_regex,
        min_length    = EXCLUDED.min_length,
        max_length    = EXCLUDED.max_length,
        confidence    = EXCLUDED.confidence,
        is_fallback   = EXCLUDED.is_fallback,
        notes         = EXCLUDED.notes;

COMMIT;

BEGIN;

-- ============================================================
-- SECTION 6: HELPER — fn_detect_format_v3
--
-- Matches a normalised description against
-- txn_channel_format_registry ordered by priority.
-- Returns the best matching format row.
-- Replaces fn_detect_best_pattern for v3 pipeline.
-- ============================================================

CREATE OR REPLACE FUNCTION spendsense.fn_detect_format_v3(
    p_norm_desc TEXT
)
RETURNS TABLE (
    format_id           BIGINT,
    channel_type        TEXT,
    format_name         TEXT,
    delimiter           TEXT,
    direction_rule      TEXT,
    direction_token_pos INT,
    skip_positions      INT[],
    prefix_strip_regex  TEXT,
    parse_confidence    NUMERIC
)
LANGUAGE sql STABLE AS $$
    SELECT
        r.format_id,
        r.channel_type,
        r.format_name,
        r.delimiter,
        r.direction_rule,
        r.direction_token_pos,
        r.skip_positions,
        r.prefix_strip_regex,
        r.parse_confidence
    FROM spendsense.txn_channel_format_registry r
    WHERE r.active = TRUE
      AND p_norm_desc ~* r.detection_regex
    ORDER BY r.priority, r.format_id
    LIMIT 1;
$$;

-- ============================================================
-- SECTION 7: CORE — fn_classify_tokens
--
-- The token-scoring engine.
--
-- Algorithm:
--   1. Strip leading noise via prefix_strip_regex (if set)
--   2. Split by delimiter → token array
--   3. Drop indices in skip_positions
--   4. Score each remaining token against every field in
--      txn_channel_field_schema for that channel_type
--   5. Assign each token to its highest-scoring field
--      (one token → one field; one field → one token)
--   6. Conflict: two tokens both best for same field →
--      higher raw confidence wins; loser becomes purpose/note
--   7. Fallback fields (purpose) absorb all unassigned tokens
--   8. Special: REV_DASH — last token split on first space
--      to separate VPA from account number
--
-- Returns JSONB: { "field_name": "value", ...,
--                  "_confidence": 0.91,
--                  "_assigned": {"field": pos} }
-- ============================================================

CREATE OR REPLACE FUNCTION spendsense.fn_classify_tokens(
    p_norm_desc     TEXT,
    p_channel_type  TEXT,
    p_format_name   TEXT,
    p_delimiter     TEXT,
    p_skip_pos      INT[],
    p_prefix_strip  TEXT
)
RETURNS JSONB
LANGUAGE plpgsql IMMUTABLE AS $$
DECLARE
    v_desc          TEXT;
    v_raw_tokens    TEXT[];
    v_tokens        TEXT[];
    v_n             INT;
    v_scores        NUMERIC[][];   -- [token_i][field_j] score matrix
    v_assigned_tok  INT[];         -- field_j → token_i winner (-1 = unassigned)
    v_assigned_fld  INT[];         -- token_i → field_j winner (-1 = unassigned)
    v_fields        TEXT[];
    v_field_conf    NUMERIC[];
    v_is_fallback   BOOLEAN[];
    v_nf            INT;
    v_best_score    NUMERIC;
    v_best_fld      INT;
    v_score         NUMERIC;
    v_tok           TEXT;
    v_fld           TEXT;
    v_result        JSONB := '{}'::JSONB;
    v_min_conf      NUMERIC := 1.0;
    v_purpose_parts TEXT[] := ARRAY[]::TEXT[];
    i               INT;
    j               INT;
    v_tmp           TEXT;
BEGIN
    -- Step 1: strip prefix noise
    v_desc := UPPER(TRIM(COALESCE(p_norm_desc, '')));
    IF p_prefix_strip IS NOT NULL THEN
        v_desc := regexp_replace(v_desc, p_prefix_strip, '', 'i');
        v_desc := TRIM(v_desc);
    END IF;

    -- Step 2: split
    v_raw_tokens := string_to_array(v_desc, UPPER(p_delimiter));

    -- Step 3: drop skip positions and empty tokens
    v_tokens := ARRAY[]::TEXT[];
    FOR i IN 1..array_length(v_raw_tokens, 1) LOOP
        -- skip_positions is 0-based
        IF NOT ((i - 1) = ANY(COALESCE(p_skip_pos, ARRAY[]::INT[])))
           AND TRIM(v_raw_tokens[i]) != '' THEN
            v_tokens := v_tokens || TRIM(v_raw_tokens[i]);
        END IF;
    END LOOP;

    v_n := COALESCE(array_length(v_tokens, 1), 0);
    IF v_n = 0 THEN
        RETURN jsonb_build_object('_confidence', 0.10, '_tokens', 0);
    END IF;

    -- Special: REV_DASH — split last token on first space
    -- to separate VPA from trailing account number
    IF p_format_name = 'REV_DASH' AND v_n >= 1 THEN
        v_tmp := v_tokens[v_n];
        IF v_tmp ~ '\s' THEN
            v_tokens[v_n]   := TRIM(split_part(v_tmp, ' ', 1));
            v_tokens        := v_tokens || TRIM(substring(v_tmp FROM position(' ' IN v_tmp) + 1));
            v_n             := v_n + 1;
        END IF;
    END IF;

    -- Special: CARD_BILLPAY — slot 2 (biller_code) and slot 3
    -- (card + ref in one space-joined token) need sub-split
    IF p_format_name IN ('IBBILLPAYDR_DASH','IB_BILLPAY_DR_DASH')
       AND v_n >= 2 THEN
        -- slot 2 onwards may be "652972XXXXXX2661 MB07121523714T48"
        -- treat as single card_ref token — no further split needed
        NULL;
    END IF;

    -- Step 4: load field schema for this channel
    v_fields     := ARRAY[]::TEXT[];
    v_field_conf := ARRAY[]::NUMERIC[];
    v_is_fallback:= ARRAY[]::BOOLEAN[];

    FOR v_fld, v_score, v_tmp IN
        SELECT field_name, confidence, is_fallback::TEXT
        FROM spendsense.txn_channel_field_schema
        WHERE channel_type = p_channel_type
        ORDER BY confidence DESC, schema_id
    LOOP
        v_fields      := v_fields      || v_fld;
        v_field_conf  := v_field_conf  || v_score;
        v_is_fallback := v_is_fallback || (v_tmp = 'true');
    END LOOP;

    v_nf := COALESCE(array_length(v_fields, 1), 0);
    IF v_nf = 0 THEN
        RETURN jsonb_build_object('_confidence', 0.50, '_tokens', v_n);
    END IF;

    -- Initialise assignment arrays
    v_assigned_tok := ARRAY(SELECT -1 FROM generate_series(1, v_nf));
    v_assigned_fld := ARRAY(SELECT -1 FROM generate_series(1, v_n));

    -- Step 5: greedy scoring — highest (field_conf × match_bonus) wins
    -- We do multiple passes: first non-fallback fields, then fallbacks
    FOR j IN 1..v_nf LOOP
        IF v_is_fallback[j] THEN CONTINUE; END IF;

        v_best_score := 0;
        v_best_fld   := -1; -- reusing as best token index

        FOR i IN 1..v_n LOOP
            IF v_assigned_fld[i] != -1 THEN CONTINUE; END IF; -- already claimed

            v_tok := v_tokens[i];

            -- Skip if too short/long for this field
            IF (SELECT min_length FROM spendsense.txn_channel_field_schema
                WHERE channel_type = p_channel_type
                  AND field_name   = v_fields[j]) IS NOT NULL THEN
                IF length(v_tok) < (SELECT min_length FROM spendsense.txn_channel_field_schema
                                    WHERE channel_type = p_channel_type
                                      AND field_name   = v_fields[j]) THEN
                    CONTINUE;
                END IF;
            END IF;
            IF (SELECT max_length FROM spendsense.txn_channel_field_schema
                WHERE channel_type = p_channel_type
                  AND field_name   = v_fields[j]) IS NOT NULL THEN
                IF length(v_tok) > (SELECT max_length FROM spendsense.txn_channel_field_schema
                                    WHERE channel_type = p_channel_type
                                      AND field_name   = v_fields[j]) THEN
                    CONTINUE;
                END IF;
            END IF;

            -- Does token match field regex?
            IF v_tok ~* (SELECT match_regex FROM spendsense.txn_channel_field_schema
                          WHERE channel_type = p_channel_type
                            AND field_name   = v_fields[j]) THEN
                -- Does token violate exclusion regex?
                IF (SELECT exclude_regex FROM spendsense.txn_channel_field_schema
                     WHERE channel_type = p_channel_type
                       AND field_name   = v_fields[j]) IS NOT NULL THEN
                    IF v_tok ~* (SELECT exclude_regex FROM spendsense.txn_channel_field_schema
                                  WHERE channel_type = p_channel_type
                                    AND field_name   = v_fields[j]) THEN
                        CONTINUE;
                    END IF;
                END IF;

                v_score := v_field_conf[j];
                IF v_score > v_best_score THEN
                    v_best_score := v_score;
                    v_best_fld   := i; -- best token index for this field
                END IF;
            END IF;
        END LOOP;

        -- Assign if we found a match
        IF v_best_fld > 0 THEN
            v_assigned_tok[j]        := v_best_fld;
            v_assigned_fld[v_best_fld] := j;
        END IF;
    END LOOP;

    -- Step 7: collect unassigned tokens into purpose (fallback)
    FOR i IN 1..v_n LOOP
        IF v_assigned_fld[i] = -1 THEN
            v_purpose_parts := v_purpose_parts || v_tokens[i];
        END IF;
    END LOOP;

    -- Step 8: build result JSONB + compute min confidence
    FOR j IN 1..v_nf LOOP
        IF v_assigned_tok[j] > 0 THEN
            v_result := v_result ||
                jsonb_build_object(v_fields[j], v_tokens[v_assigned_tok[j]]);
            IF v_field_conf[j] < v_min_conf THEN
                v_min_conf := v_field_conf[j];
            END IF;
        END IF;
    END LOOP;

    -- Add purpose from unassigned tokens
    IF array_length(v_purpose_parts, 1) > 0 THEN
        v_result := v_result ||
            jsonb_build_object('purpose', array_to_string(v_purpose_parts, ' '));
    END IF;

    -- If nothing was assigned, drop min_conf
    IF v_result = '{}'::JSONB THEN
        v_min_conf := 0.20;
    END IF;

    v_result := v_result ||
        jsonb_build_object(
            '_confidence', ROUND(v_min_conf, 2),
            '_tokens',     v_n,
            '_format',     p_format_name
        );

    RETURN v_result;
END;
$$;

-- ============================================================
-- SECTION 8: fn_parse_nach
--
-- NACH uses dense concatenated structure — not suitable for
-- token scoring. Dedicated regex extracts all fields.
--
-- Input:  normalised description
-- Output: JSONB with nach-specific fields
--
-- Structure:
--   [noise_prefix] NACH {ENTITY}{DDMMYYYY}{PLATFORM}
--     {mandate_id} {run_ref|short_ref} {subscriber_ifsc}
-- ============================================================

CREATE OR REPLACE FUNCTION spendsense.fn_parse_nach(
    p_norm_desc TEXT
)
RETURNS JSONB
LANGUAGE plpgsql IMMUTABLE AS $$
DECLARE
    v_desc          TEXT;
    v_match         TEXT[];
    v_result        JSONB := '{}'::JSONB;
    v_entity        TEXT;
    v_exec_date_raw TEXT;
    v_exec_date     DATE;
    v_platform      TEXT;
    v_mandate_id    TEXT;
    v_run_ref       TEXT;
    v_ifsc          TEXT;
    v_confidence    NUMERIC := 0.93;
BEGIN
    -- Strip leading noise (timestamp / hex prefix before NACH)
    v_desc := regexp_replace(
        UPPER(TRIM(COALESCE(p_norm_desc, ''))),
        '^[0-9A-F/:\s]+(?=NACH\s)', '', 'i'
    );
    v_desc := TRIM(v_desc);

    -- Primary parse: entity+date+platform fused token
    -- e.g. NACH NSEMFS05032025CAMS 5950850995240 5011386641 CNRB…
    v_match := regexp_match(v_desc,
        'NACH\s+([A-Z]{2,8})(\d{8})([A-Z]{2,6})\s+(\d{10,14})\s+(\d{4,12})\s+([A-Z0-9]{11,20})');

    IF v_match IS NOT NULL THEN
        v_entity        := v_match[1];
        v_exec_date_raw := v_match[2];  -- DDMMYYYY
        v_platform      := v_match[3];
        v_mandate_id    := v_match[4];
        v_run_ref       := v_match[5];
        v_ifsc          := v_match[6];

        -- Parse date DDMMYYYY → DATE
        BEGIN
            v_exec_date := TO_DATE(v_exec_date_raw, 'DDMMYYYY');
        EXCEPTION WHEN OTHERS THEN
            v_exec_date := NULL;
            v_confidence := 0.80;
        END;

        v_result := jsonb_build_object(
            'ach_nach_entity',    v_entity,
            'nach_platform',      v_platform,
            'nach_exec_date',     v_exec_date,
            'mandate_or_run_id',  v_mandate_id,
            'ach_nach_ref',       v_run_ref,
            'counterparty_ifsc',  v_ifsc,
            '_confidence',        v_confidence,
            '_format',            'NACH_SPACE_MF'
        );
        RETURN v_result;
    END IF;

    -- Fallback: partial parse — just extract what we can
    -- Try to get mandate_id (long number) and IFSC
    v_match := regexp_match(v_desc, 'NACH\s+([A-Z0-9]+)\s+(\d{10,14})');
    IF v_match IS NOT NULL THEN
        v_result := jsonb_build_object(
            'ach_nach_entity',   v_match[1],
            'mandate_or_run_id', v_match[2],
            '_confidence',       0.60,
            '_format',           'NACH_PARTIAL'
        );
        RETURN v_result;
    END IF;

    RETURN jsonb_build_object(
        '_confidence', 0.20,
        '_format',     'NACH_UNKNOWN'
    );
END;
$$;

-- ============================================================
-- SECTION 9: fn_parse_other_subtype
--
-- Handles OTHER channel sub-types that need dedicated regex
-- rather than token scoring:
--   EMI, INTEREST_CREDIT, BILLDESK, POS_CC_BILL
--
-- Returns JSONB with extracted fields + _sub_type + _confidence
-- ============================================================

CREATE OR REPLACE FUNCTION spendsense.fn_parse_other_subtype(
    p_norm_desc TEXT
)
RETURNS JSONB
LANGUAGE plpgsql IMMUTABLE AS $$
DECLARE
    v_desc  TEXT;
    v_match TEXT[];
    v_result JSONB;
BEGIN
    v_desc := UPPER(TRIM(COALESCE(p_norm_desc, '')));

    -- ── EMI (PPR…_EMI_…) ──────────────────────────────────
    IF v_desc ~* '^PPR\d+_EMI_' THEN
        v_match := regexp_match(v_desc,
            '^(PPR\d+)_EMI_(\d{2}-\d{2}-\d{4})_(.+)$');
        IF v_match IS NOT NULL THEN
            RETURN jsonb_build_object(
                'biller_code',    v_match[1],
                'purpose',        'EMI ' || v_match[2],
                'counterparty_name', TRIM(v_match[3]),
                '_sub_type',      'EMI',
                '_confidence',    0.90,
                '_format',        'EMI_PPR'
            );
        END IF;
        RETURN jsonb_build_object(
            '_sub_type',   'EMI',
            '_confidence', 0.60,
            '_format',     'EMI_PPR'
        );
    END IF;

    -- ── INTEREST_CREDIT ───────────────────────────────────
    IF v_desc ~* '^INTEREST PAID|^INTERESTPAID|^Int\.Pd:|^SB:[0-9]' THEN
        -- SB:ACCOUNT:Int.Pd:FROM to TO
        v_match := regexp_match(v_desc,
            'SB:(\d+):Int\.Pd:(\d{2}-\d{2}-\d{4})\s+to\s+(\d{2}-\d{2}-\d{4})');
        IF v_match IS NOT NULL THEN
            RETURN jsonb_build_object(
                'counterparty_account', v_match[1],
                'purpose',
                    'Interest ' || v_match[2] || ' to ' || v_match[3],
                '_sub_type',   'INTEREST_CREDIT',
                '_confidence', 0.90,
                '_format',     'INTEREST_CREDIT_SPACE'
            );
        END IF;
        -- Int.Pd:ACCOUNT:FROM to TO
        v_match := regexp_match(v_desc,
            'Int\.Pd:(\d+):(\d{2}-\d{2}-\d{4})\s+to\s+(\d{2}-\d{2}-\d{4})');
        IF v_match IS NOT NULL THEN
            RETURN jsonb_build_object(
                'counterparty_account', v_match[1],
                'purpose',
                    'Interest ' || v_match[2] || ' to ' || v_match[3],
                '_sub_type',   'INTEREST_CREDIT',
                '_confidence', 0.90,
                '_format',     'INTEREST_CREDIT_SPACE'
            );
        END IF;
        -- Plain "INTEREST PAID TILL DD-MON-YYYY"
        RETURN jsonb_build_object(
            'purpose',     TRIM(v_desc),
            '_sub_type',   'INTEREST_CREDIT',
            '_confidence', 0.75,
            '_format',     'INTEREST_CREDIT_SPACE'
        );
    END IF;

    -- ── BILLDESK ─────────────────────────────────────────
    IF v_desc ~* '[A-Z0-9]{12,}/BILLDK' THEN
        v_match := regexp_match(v_desc,
            '^([A-Z0-9]+)/BILLDK([A-Z0-9]+)\s+(\d{10,})');
        IF v_match IS NOT NULL THEN
            RETURN jsonb_build_object(
                'internal_ref',  v_match[1],
                'biller_code',   v_match[2],
                'mandate_or_run_id', v_match[3],
                '_sub_type',     'BILLDESK',
                '_confidence',   0.88,
                '_format',       'BILLDESK'
            );
        END IF;
        RETURN jsonb_build_object(
            '_sub_type',   'BILLDESK',
            '_confidence', 0.60,
            '_format',     'BILLDESK'
        );
    END IF;

    -- ── POS CC BILL (POS416021XXXXXX1514PZHDFCCCBILLP …) ─
    IF v_desc ~* '^POS[0-9]{6}X+[0-9]{4}[A-Z]{2}HDFC' THEN
        v_match := regexp_match(v_desc,
            '^POS([0-9]{6}X+[0-9]{4})([A-Z0-9]+)\s*(\d*)');
        IF v_match IS NOT NULL THEN
            RETURN jsonb_build_object(
                'card_ref',      v_match[1],
                'biller_code',   v_match[2],
                'internal_ref',  NULLIF(v_match[3], ''),
                '_sub_type',     'CC_PAYMENT',
                '_channel_override', 'CARD_BILLPAY',
                '_confidence',   0.88,
                '_format',       'POS_CC_BILL'
            );
        END IF;
    END IF;

    -- No specific sub-type matched
    RETURN jsonb_build_object(
        '_sub_type',   'TRUNCATED',
        '_confidence', 0.20,
        '_format',     'OTHER_UNKNOWN'
    );
END;
$$;

COMMIT;

BEGIN;

-- ============================================================
-- SECTION 10: fn_derive_direction_v3
--
-- Derives direction from:
--   a) format direction_rule (IN/OUT/REV → fixed)
--   b) FROM_TOKEN → look at token[direction_token_pos]
--   c) LEDGER → use cr_dr from source table
-- ============================================================

CREATE OR REPLACE FUNCTION spendsense.fn_derive_direction_v3(
    p_direction_rule      TEXT,
    p_direction_token_pos INT,
    p_norm_desc           TEXT,
    p_delimiter           TEXT,
    p_cr_dr               CHAR(1)
)
RETURNS TEXT
LANGUAGE plpgsql IMMUTABLE AS $$
DECLARE
    v_tokens TEXT[];
    v_tok    TEXT;
BEGIN
    CASE p_direction_rule
        WHEN 'IN'  THEN RETURN 'IN';
        WHEN 'OUT' THEN RETURN 'OUT';
        WHEN 'REV' THEN RETURN 'REV';
        WHEN 'FROM_TOKEN' THEN
            v_tokens := string_to_array(
                UPPER(TRIM(COALESCE(p_norm_desc, ''))), UPPER(p_delimiter));
            IF p_direction_token_pos IS NOT NULL
               AND array_length(v_tokens, 1) >= p_direction_token_pos + 1 THEN
                v_tok := TRIM(v_tokens[p_direction_token_pos + 1]);
                RETURN CASE
                    WHEN v_tok IN ('CR','CREDIT','IN')  THEN 'IN'
                    WHEN v_tok IN ('DR','DEBIT','OUT')  THEN 'OUT'
                    WHEN v_tok IN ('REV','REVERSAL')    THEN 'REV'
                    ELSE 'UNKNOWN'
                END;
            END IF;
            RETURN 'UNKNOWN';
        ELSE -- LEDGER
            RETURN CASE
                WHEN p_cr_dr = 'C' THEN 'IN'
                WHEN p_cr_dr = 'D' THEN 'OUT'
                ELSE 'UNKNOWN'
            END;
    END CASE;
END;
$$;

-- ============================================================
-- SECTION 11: populate_txn_parse_stage_v3
--
-- Extends v2 stage population:
--   • Uses fn_detect_format_v3 instead of fn_detect_best_pattern
--   • Populates parse_format and sub_type
--   • Channel detection now also covers ATM-CASH/, IBBILLPAYDR-,
--     MOB/TPFT/, PPR_EMI_, CreditCard Payment
-- ============================================================

CREATE OR REPLACE FUNCTION spendsense.populate_txn_parse_stage_v3(
    p_upload_id UUID  DEFAULT NULL,
    p_user_id   TEXT  DEFAULT NULL
)
RETURNS BIGINT
LANGUAGE plpgsql AS $$
DECLARE v_count BIGINT;
BEGIN
    INSERT INTO spendsense.txn_parse_stage (
        fact_txn_id, user_id, upload_id, bank_code, txn_date, amount, cr_dr,
        raw_description, normalized_description, channel_type, direction,
        pattern_family, matched_pattern_id, parse_format, sub_type,
        slash_tokens, dash_tokens, star_tokens, space_tokens,
        slash_token_count, dash_token_count, star_token_count, space_token_count,
        parse_status, parse_confidence, parse_version
    )
    SELECT
        tf.txn_id,
        tf.user_id,
        tf.upload_id,
        COALESCE(tf.bank_code, 'UNKNOWN'),
        tf.txn_date,
        tf.amount,
        CASE WHEN LOWER(COALESCE(tf.direction,'')) IN ('credit','cr','c','in')
             THEN 'C' ELSE 'D' END AS cr_dr,
        COALESCE(tf.description,''),
        nd.norm_desc,

        -- Channel detection (v3 expanded)
        COALESCE(fmt.channel_type,
            CASE
                WHEN nd.norm_desc ~* '^(UPI[/-]|REV-UPI-|UPIOUT/|UPI IN/)'
                    THEN 'UPI'
                WHEN nd.norm_desc ~* '(^IMPS[-/]|MMT/IMPS/|MOB-IMPS-|INET-IMPS-|FT IMPS/)'
                    THEN 'IMPS'
                WHEN nd.norm_desc ~* '^NEFT'
                    THEN 'NEFT'
                WHEN nd.norm_desc ~* '^(ACH-DR-|ACH D-|ACH/|DEBIT-ACH)'
                    THEN 'ACH'
                WHEN nd.norm_desc ~* '^NACH\s+[A-Z]'
                    THEN 'NACH'
                WHEN nd.norm_desc ~* '^(NWD-|ATM WDL-|ATM-CASH/|TO INTL\. ATM)'
                    THEN 'ATM'
                WHEN nd.norm_desc ~* '^POS [0-9A-Z]{12}'
                    THEN 'POS'
                WHEN nd.norm_desc ~* '^(IBBILLPAYDR-|IB BILLPAY DR-)'
                    THEN 'CARD_BILLPAY'
                ELSE 'OTHER'
            END
        ) AS channel_type,

        -- Direction (v3 — uses format rule)
        spendsense.fn_derive_direction_v3(
            COALESCE(fmt.direction_rule, 'LEDGER'),
            fmt.direction_token_pos,
            nd.norm_desc,
            COALESCE(fmt.delimiter, '-'),
            CASE WHEN LOWER(COALESCE(tf.direction,'')) IN ('credit','cr','c','in')
                 THEN 'C' ELSE 'D' END
        ) AS direction,

        -- Pattern family (format name for observability)
        COALESCE(fmt.format_name, 'OTHER_UNKNOWN') AS pattern_family,

        -- matched_pattern_id: NULL in v3 (v2 positional registry dropped)
        NULL::BIGINT AS matched_pattern_id,

        fmt.format_name AS parse_format,

        -- sub_type sourced from lateral so parse_status can reference it
        st.sub_type,

        string_to_array(nd.norm_desc, '/'),
        string_to_array(nd.norm_desc, '-'),
        string_to_array(nd.norm_desc, '*'),
        string_to_array(nd.norm_desc, ' '),
        spendsense.fn_array_len(string_to_array(nd.norm_desc, '/')),
        spendsense.fn_array_len(string_to_array(nd.norm_desc, '-')),
        spendsense.fn_array_len(string_to_array(nd.norm_desc, '*')),
        spendsense.fn_array_len(string_to_array(nd.norm_desc, ' ')),

        CASE
            WHEN COALESCE(tf.description,'') = '' THEN 'UNPARSED'
            WHEN st.sub_type = 'TRUNCATED'        THEN 'UNPARSED'
            WHEN fmt.format_id IS NULL             THEN 'PARTIAL'
            ELSE 'READY'
        END AS parse_status,

        CASE
            WHEN COALESCE(tf.description,'') = '' THEN 0.00
            WHEN st.sub_type = 'TRUNCATED'        THEN 0.10
            WHEN fmt.format_id IS NULL             THEN 0.40
            ELSE COALESCE(fmt.parse_confidence, 0.85)
        END AS parse_confidence,
        'v3'

    FROM spendsense.txn_fact tf
    CROSS JOIN LATERAL (
        SELECT spendsense.fn_norm_desc(tf.description) AS norm_desc
    ) nd
    LEFT JOIN LATERAL spendsense.fn_detect_format_v3(nd.norm_desc) fmt ON TRUE
    -- sub_type lateral: computed once, referenced by both parse_status and the SELECT list
    CROSS JOIN LATERAL (
        SELECT CASE
            WHEN nd.norm_desc ~* '^CreditCard Payment XX'   THEN 'CC_PAYMENT'
            WHEN nd.norm_desc ~* '^MOB/TPFT/'               THEN 'MOB_TRANSFER'
            WHEN nd.norm_desc ~* '^PPR\d+_EMI_'             THEN 'EMI'
            WHEN nd.norm_desc ~* '^INTEREST PAID|^INTERESTPAID|^Int\.Pd:|^SB:[0-9]'
                                                             THEN 'INTEREST_CREDIT'
            WHEN nd.norm_desc ~* '^CHQPAID-|^CHQ '          THEN 'CHEQUE'
            WHEN nd.norm_desc ~* '^BY CASH DEPOSIT'         THEN 'CASH_DEPOSIT'
            WHEN nd.norm_desc ~* '[A-Z0-9]{12,}/BILLDK'     THEN 'BILLDESK'
            WHEN nd.norm_desc ~* '^POS[0-9]{6}X+[0-9]{4}[A-Z]{2}HDFC'
                                                             THEN 'CC_PAYMENT'
            WHEN COALESCE(fmt.channel_type,'OTHER') = 'OTHER'
              AND (LENGTH(TRIM(nd.norm_desc)) <= 10
                OR nd.norm_desc ~* '^(NE|PHONE|MPHONE|HONE|E|AUTO)$')
                                                             THEN 'TRUNCATED'
            ELSE NULL
        END AS sub_type
    ) st
    WHERE NOT EXISTS (
        SELECT 1 FROM spendsense.txn_parse_stage s WHERE s.fact_txn_id = tf.txn_id
    )
    AND (p_upload_id IS NULL OR tf.upload_id = p_upload_id)
    AND (p_user_id   IS NULL OR tf.user_id   = p_user_id);

    GET DIAGNOSTICS v_count = ROW_COUNT;
    RETURN v_count;
END;
$$;

-- ============================================================
-- SECTION 12: populate_txn_parsed_v3
--
-- The main field-extraction function.
-- Routes each row to the appropriate extractor:
--   • NACH         → fn_parse_nach()
--   • OTHER (regex subtypes) → fn_parse_other_subtype()
--   • Everything else → fn_classify_tokens()
-- Then maps JSONB output to txn_parsed columns.
-- PARSED threshold: _confidence >= 0.70
-- ============================================================

CREATE OR REPLACE FUNCTION spendsense.populate_txn_parsed_v3(
    p_upload_id UUID  DEFAULT NULL,
    p_user_id   TEXT  DEFAULT NULL
)
RETURNS BIGINT
LANGUAGE plpgsql AS $$
DECLARE v_count BIGINT;
BEGIN
    INSERT INTO spendsense.txn_parsed (
        fact_txn_id, user_id, upload_id, bank_code, txn_date, amount, cr_dr,
        raw_description, normalized_description, channel_type, direction,
        pattern_family, matched_pattern_id, parse_format, sub_type,
        counterparty_name, merchant_name, counterparty_bank_code,
        counterparty_vpa, counterparty_account, counterparty_ifsc,
        upi_rrn, imps_rrn, neft_utr, internal_ref, mcc,
        biller_name, biller_code, card_ref,
        ach_nach_entity, ach_nach_ref, mandate_or_run_id,
        atm_txn_id, atm_location, purpose, note_text,
        parse_status, parse_confidence, parse_version
    )
    SELECT
        s.fact_txn_id,
        s.user_id,
        s.upload_id,
        s.bank_code, s.txn_date, s.amount, s.cr_dr,
        s.raw_description, s.normalized_description,

        -- Channel: honour _channel_override from fn_parse_other_subtype
        COALESCE(
            NULLIF(parsed.fields->>'_channel_override', ''),
            s.channel_type
        ) AS channel_type,

        s.direction,
        s.pattern_family,
        s.matched_pattern_id,
        COALESCE(parsed.fields->>'_format', s.parse_format) AS parse_format,
        COALESCE(parsed.fields->>'_sub_type', s.sub_type)   AS sub_type,

        -- ── counterparty_name ──────────────────────────────
        CASE
            WHEN s.channel_type IN ('UPI','IMPS','NEFT')
            THEN NULLIF(TRIM(COALESCE(
                parsed.fields->>'counterparty_name',
                parsed.fields->>'beneficiary_name'
            )), '')
            WHEN s.channel_type = 'OTHER'
              AND s.sub_type IN ('MOB_TRANSFER','CHEQUE')
            THEN NULLIF(TRIM(parsed.fields->>'counterparty_name'), '')
            ELSE NULL
        END AS counterparty_name,

        -- ── merchant_name ──────────────────────────────────
        CASE
            WHEN s.channel_type = 'UPI'
              AND (
                    parsed.fields->>'gateway_name' IS NOT NULL
                 OR parsed.fields->>'counterparty_vpa' ~*
                        '(rzp@|paytmqr|bharatpe|payu\.|cashfree|eazypay|'
                     || 'jiomoney|swiggystores|blinkcommerce|zomato|irctc|'
                     || 'yesbank\.|indmoney|groww|smallcase|cred)'
              )
            THEN NULLIF(TRIM(COALESCE(
                parsed.fields->>'counterparty_name',
                parsed.fields->>'gateway_name'
            )), '')
            WHEN s.channel_type IN ('CARD_BILLPAY','POS')
            THEN NULLIF(TRIM(parsed.fields->>'merchant_name'), '')
            ELSE NULL
        END AS merchant_name,

        -- ── counterparty_bank_code ─────────────────────────
        NULLIF(TRIM(COALESCE(
            parsed.fields->>'counterparty_bank',
            parsed.fields->>'sender_ifsc'
        )), '') AS counterparty_bank_code,

        -- ── counterparty_vpa ───────────────────────────────
        NULLIF(TRIM(parsed.fields->>'counterparty_vpa'), '')
            AS counterparty_vpa,

        -- ── counterparty_account ───────────────────────────
        NULLIF(TRIM(COALESCE(
            parsed.fields->>'counterparty_account',
            parsed.fields->>'phone_or_account'
        )), '') AS counterparty_account,

        -- ── counterparty_ifsc ──────────────────────────────
        NULLIF(TRIM(COALESCE(
            parsed.fields->>'counterparty_ifsc',
            parsed.fields->>'counterparty_bank'  -- fallback if IFSC format
        )), '') AS counterparty_ifsc,

        -- ── upi_rrn ───────────────────────────────────────
        CASE WHEN s.channel_type = 'UPI'
             THEN spendsense.fn_digits_only(parsed.fields->>'upi_rrn')
        END AS upi_rrn,

        -- ── imps_rrn ──────────────────────────────────────
        CASE WHEN s.channel_type = 'IMPS'
             THEN spendsense.fn_digits_only(parsed.fields->>'imps_rrn')
        END AS imps_rrn,

        -- ── neft_utr ──────────────────────────────────────
        CASE WHEN s.channel_type = 'NEFT'
             THEN NULLIF(TRIM(parsed.fields->>'neft_utr'), '')
        END AS neft_utr,

        -- ── internal_ref ──────────────────────────────────
        NULLIF(TRIM(COALESCE(
            parsed.fields->>'internal_ref',
            spendsense.fn_extract_internal_ref(s.normalized_description, NULL)
        )), '') AS internal_ref,

        -- ── mcc ───────────────────────────────────────────
        NULL::TEXT AS mcc,

        -- ── biller_name ───────────────────────────────────
        CASE
            WHEN s.channel_type IN ('ACH','NACH')
            THEN NULLIF(TRIM(COALESCE(
                parsed.fields->>'ach_nach_entity',
                parsed.fields->>'ach_entity'
            )), '')
            WHEN s.channel_type = 'CARD_BILLPAY'
            THEN NULLIF(TRIM(parsed.fields->>'biller_code'), '') -- human-readable via lookup
            WHEN s.sub_type = 'BILLDESK'
            THEN NULLIF(TRIM(parsed.fields->>'biller_code'), '')
        END AS biller_name,

        -- ── biller_code ───────────────────────────────────
        CASE
            WHEN s.channel_type = 'CARD_BILLPAY'
               OR s.sub_type IN ('EMI','BILLDESK')
            THEN NULLIF(TRIM(COALESCE(
                parsed.fields->>'biller_code',
                parsed.fields->>'loan_ref'
            )), '')
        END AS biller_code,

        -- ── card_ref ──────────────────────────────────────
        CASE
            WHEN s.channel_type = 'CARD_BILLPAY'
               OR s.sub_type = 'CC_PAYMENT'
            THEN NULLIF(TRIM(COALESCE(
                parsed.fields->>'card_ref',
                parsed.fields->>'payment_ref'
            )), '')
        END AS card_ref,

        -- ── ach_nach_entity ───────────────────────────────
        CASE WHEN s.channel_type IN ('ACH','NACH')
             THEN NULLIF(TRIM(COALESCE(
                parsed.fields->>'ach_nach_entity',
                parsed.fields->>'ach_entity'
             )), '')
        END AS ach_nach_entity,

        -- ── ach_nach_ref ──────────────────────────────────
        CASE WHEN s.channel_type IN ('ACH','NACH')
             THEN NULLIF(TRIM(COALESCE(
                parsed.fields->>'ach_nach_ref',
                parsed.fields->>'mandate_ref'
             )), '')
        END AS ach_nach_ref,

        -- ── mandate_or_run_id ─────────────────────────────
        CASE WHEN s.channel_type IN ('ACH','NACH')
             THEN NULLIF(TRIM(COALESCE(
                parsed.fields->>'mandate_or_run_id',
                parsed.fields->>'mandate_ref'
             )), '')
        END AS mandate_or_run_id,

        -- ── atm_txn_id ────────────────────────────────────
        CASE WHEN s.channel_type = 'ATM'
             THEN COALESCE(
                NULLIF(TRIM(parsed.fields->>'atm_txn_id'), ''),
                -- ATM WDL fallback: extract from raw
                (regexp_match(s.normalized_description,
                    '^ATM WDL-ATM CASH (\d+)'))[1]
             )
        END AS atm_txn_id,

        -- ── atm_location ──────────────────────────────────
        CASE WHEN s.channel_type = 'ATM'
             THEN COALESCE(
                NULLIF(TRIM(parsed.fields->>'atm_location'), ''),
                (regexp_match(s.normalized_description,
                    '^ATM WDL-ATM CASH \d+ (.*?)-?$'))[1]
             )
        END AS atm_location,

        -- ── purpose ───────────────────────────────────────
        NULLIF(TRIM(COALESCE(
            parsed.fields->>'purpose',
            parsed.fields->>'note'
        )), '') AS purpose,

        NULL::TEXT AS note_text,

        -- ── parse_status ──────────────────────────────────
        -- PARSED  : format matched AND min field confidence >= 0.70
        -- PARTIAL : format matched but confidence < 0.70,
        --           or format unmatched (OTHER_UNKNOWN)
        -- UNPARSED: empty description OR TRUNCATED fragment
        --           (TRUNCATED rows skipped below via WHERE clause;
        --            this CASE handles the empty-desc edge case only)
        CASE
            WHEN s.parse_status = 'UNPARSED'
                THEN 'UNPARSED'
            WHEN s.parse_format IS NULL
              OR s.pattern_family = 'OTHER_UNKNOWN'
                THEN 'PARTIAL'
            WHEN (parsed.fields->>'_confidence')::NUMERIC >= 0.70
                THEN 'PARSED'
            ELSE 'PARTIAL'
        END AS parse_status,

        -- ── parse_confidence ──────────────────────────────
        COALESCE(
            (parsed.fields->>'_confidence')::NUMERIC,
            s.parse_confidence
        ) AS parse_confidence,

        'v3' AS parse_version

    FROM spendsense.txn_parse_stage s
    -- ── Route to appropriate parser ──────────────────────
    CROSS JOIN LATERAL (
        SELECT
            CASE
                -- NACH: dedicated regex parser
                WHEN s.channel_type = 'NACH'
                THEN spendsense.fn_parse_nach(s.normalized_description)

                -- OTHER with regex-only sub-types
                WHEN s.channel_type = 'OTHER'
                  AND s.sub_type IN ('EMI','INTEREST_CREDIT','BILLDESK','CC_PAYMENT')
                THEN spendsense.fn_parse_other_subtype(s.normalized_description)

                -- POS no-space format: regex extract
                WHEN s.channel_type = 'POS'
                  AND s.parse_format = 'POS_NOSPACE'
                THEN (
                    SELECT jsonb_build_object(
                        'card_ref',
                            (regexp_match(s.normalized_description,
                                '^POS([0-9]{6}X+[0-9]{4})'))[1],
                        'merchant_name',
                            regexp_replace(s.normalized_description,
                                '^POS[0-9]{6}X+[0-9]{4}', ''),
                        '_confidence', 0.85,
                        '_format', 'POS_NOSPACE'
                    )
                )

                -- ATM WDL: regex extract (description is not simply tokenisable)
                WHEN s.channel_type = 'ATM'
                  AND s.parse_format = 'ATM_WDL_DASH'
                THEN (
                    SELECT jsonb_build_object(
                        'atm_txn_id',
                            (regexp_match(s.normalized_description,
                                '^ATM WDL-ATM CASH (\d+)'))[1],
                        'atm_location',
                            (regexp_match(s.normalized_description,
                                '^ATM WDL-ATM CASH \d+ ([A-Z ]+)-?$'))[1],
                        '_confidence', 0.88,
                        '_format', 'ATM_WDL_DASH'
                    )
                )

                -- CARD_BILLPAY: token classifier + secondary space split
                WHEN s.channel_type = 'CARD_BILLPAY'
                THEN (
                    WITH base AS (
                        SELECT spendsense.fn_classify_tokens(
                            s.normalized_description,
                            'CARD_BILLPAY',
                            s.parse_format,
                            '-',
                            ARRAY[0]::INT[],
                            NULL
                        ) AS f
                    ),
                    -- Sub-split the card_ref token on space
                    card_split AS (
                        SELECT
                            CASE
                                WHEN f->>'card_ref' ~ '\s'
                                THEN split_part(f->>'card_ref',' ',1)
                                ELSE f->>'card_ref'
                            END AS card_masked,
                            CASE
                                WHEN f->>'card_ref' ~ '\s'
                                THEN substring(f->>'card_ref'
                                     FROM position(' ' IN f->>'card_ref') + 1)
                                ELSE NULL
                            END AS txn_ref,
                            f
                        FROM base
                    )
                    SELECT f
                         || jsonb_build_object(
                                'card_ref',     card_masked,
                                'internal_ref', txn_ref
                            )
                    FROM card_split
                )

                -- All other channels: token classifier
                WHEN s.parse_format IS NOT NULL
                THEN (
                    SELECT spendsense.fn_classify_tokens(
                        s.normalized_description,
                        s.channel_type,
                        s.parse_format,
                        fmt2.delimiter,
                        fmt2.skip_positions,
                        fmt2.prefix_strip_regex
                    )
                    FROM spendsense.txn_channel_format_registry fmt2
                    WHERE fmt2.format_name  = s.parse_format
                      AND fmt2.channel_type = s.channel_type
                    LIMIT 1
                )

                -- No format matched: best-effort partial
                ELSE jsonb_build_object(
                    '_confidence', 0.20,
                    '_format',     'OTHER_UNKNOWN'
                )
            END AS fields
    ) parsed

    WHERE NOT EXISTS (
        SELECT 1 FROM spendsense.txn_parsed p WHERE p.fact_txn_id = s.fact_txn_id
    )
    -- TRUNCATED fragments skip txn_parsed entirely — routed to unknown_queue only
    AND COALESCE(s.sub_type, '') != 'TRUNCATED'
    AND (p_upload_id IS NULL OR s.upload_id = p_upload_id)
    AND (p_user_id   IS NULL OR s.user_id   = p_user_id);

    GET DIAGNOSTICS v_count = ROW_COUNT;
    RETURN v_count;
END;
$$;

-- ============================================================
-- SECTION 13: fn_reparse_transaction (v3)
-- ============================================================

CREATE OR REPLACE FUNCTION spendsense.fn_reparse_transaction(
    p_fact_txn_id UUID
)
RETURNS TEXT
LANGUAGE plpgsql AS $$
DECLARE
    v_upload_id UUID;
    v_user_id   TEXT;
    v_status    TEXT;
BEGIN
    SELECT upload_id, user_id
    INTO v_upload_id, v_user_id
    FROM spendsense.txn_fact
    WHERE txn_id = p_fact_txn_id;

    DELETE FROM spendsense.txn_parsed             WHERE fact_txn_id = p_fact_txn_id;
    DELETE FROM spendsense.txn_parse_stage         WHERE fact_txn_id = p_fact_txn_id;
    DELETE FROM spendsense.txn_parse_unknown_queue WHERE fact_txn_id = p_fact_txn_id;

    PERFORM spendsense.populate_txn_parse_stage_v3(v_upload_id, v_user_id);
    PERFORM spendsense.populate_txn_parsed_v3(v_upload_id, v_user_id);
    PERFORM spendsense.populate_txn_parse_unknown_queue_v3(v_upload_id, v_user_id);

    SELECT parse_status INTO v_status
    FROM spendsense.txn_parsed WHERE fact_txn_id = p_fact_txn_id;

    RETURN COALESCE(v_status, 'NOT_FOUND');
END;
$$;

-- ============================================================
-- SECTION 14: populate_txn_parse_unknown_queue_v3
--
-- Routes UNPARSED/PARTIAL/TRUNCATED rows into the unknown queue.
-- TRUNCATED rows: routed here directly (never entered txn_parsed).
-- Wraps v2 logic but uses v3 parse_status values.
-- ============================================================

CREATE OR REPLACE FUNCTION spendsense.populate_txn_parse_unknown_queue_v3(
    p_upload_id UUID DEFAULT NULL,
    p_user_id   TEXT DEFAULT NULL
)
RETURNS BIGINT
LANGUAGE plpgsql AS $$
DECLARE v_count BIGINT;
BEGIN
    INSERT INTO spendsense.txn_parse_unknown_queue (
        fact_txn_id, user_id, upload_id, bank_code, txn_date, amount, cr_dr,
        raw_description, normalized_description, guessed_channel_type,
        shape_signature, token_count_dash, token_count_slash,
        token_count_space, token_count_star,
        parse_status, parse_confidence, first_seen_at, last_seen_at, occurrence_count
    )
    SELECT
        s.fact_txn_id, s.user_id, s.upload_id, s.bank_code, s.txn_date,
        s.amount, s.cr_dr, s.raw_description, s.normalized_description,
        s.channel_type,
        spendsense.fn_txn_shape_signature(s.normalized_description),
        s.dash_token_count, s.slash_token_count,
        s.space_token_count, s.star_token_count,
        s.parse_status, s.parse_confidence, NOW(), NOW(), 1
    FROM spendsense.txn_parse_stage s
    WHERE (
        s.parse_status IN ('UNPARSED','PARTIAL')
        OR s.sub_type = 'TRUNCATED'
        OR s.parse_confidence < 0.70
    )
    AND (p_upload_id IS NULL OR s.upload_id = p_upload_id)
    AND (p_user_id   IS NULL OR s.user_id   = p_user_id)
    ON CONFLICT (fact_txn_id) DO UPDATE SET
        occurrence_count = spendsense.txn_parse_unknown_queue.occurrence_count + 1,
        last_seen_at     = NOW(),
        updated_at       = NOW();

    GET DIAGNOSTICS v_count = ROW_COUNT;

    -- Scope last_seen_at update to current batch only
    UPDATE spendsense.txn_parse_unknown_queue q
    SET last_seen_at = NOW(),
        updated_at   = NOW()
    WHERE q.review_status = 'NEW'
      AND q.fact_txn_id IN (
          SELECT s.fact_txn_id
          FROM spendsense.txn_parse_stage s
          WHERE (p_upload_id IS NULL OR s.upload_id = p_upload_id)
            AND (p_user_id   IS NULL OR s.user_id   = p_user_id)
      );

    -- Update shape-level aggregate stats
    INSERT INTO spendsense.txn_parse_unknown_shape_stats (
        shape_signature, guessed_channel_type, total_occurrence_count,
        first_seen_at, last_seen_at, example_description
    )
    SELECT
        spendsense.fn_txn_shape_signature(s.normalized_description),
        s.channel_type,
        COUNT(*),
        MIN(s.txn_date)::TIMESTAMPTZ,
        NOW(),
        MIN(s.normalized_description)
    FROM spendsense.txn_parse_stage s
    WHERE (p_upload_id IS NULL OR s.upload_id = p_upload_id)
      AND (p_user_id   IS NULL OR s.user_id   = p_user_id)
      AND (s.parse_status IN ('UNPARSED','PARTIAL')
           OR s.sub_type = 'TRUNCATED')
    GROUP BY spendsense.fn_txn_shape_signature(s.normalized_description), s.channel_type
    ON CONFLICT (shape_signature, guessed_channel_type) DO UPDATE SET
        total_occurrence_count =
            spendsense.txn_parse_unknown_shape_stats.total_occurrence_count
            + EXCLUDED.total_occurrence_count,
        last_seen_at    = NOW(),
        example_description = COALESCE(
            spendsense.txn_parse_unknown_shape_stats.example_description,
            EXCLUDED.example_description),
        updated_at      = NOW();

    RETURN v_count;
END;
$$;

-- ============================================================
-- fn_reparse_by_shape_v3
-- Clears all rows matching a shape, then re-runs the v3 pipeline.
-- Use after adding a new format to txn_channel_format_registry.
-- ============================================================

CREATE OR REPLACE FUNCTION spendsense.fn_reparse_by_shape_v3(
    p_shape_signature TEXT
)
RETURNS BIGINT
LANGUAGE plpgsql AS $$
DECLARE
    v_count BIGINT := 0;
    v_txn   RECORD;
BEGIN
    FOR v_txn IN
        SELECT q.fact_txn_id, tf.upload_id, tf.user_id
        FROM spendsense.txn_parse_unknown_queue q
        JOIN spendsense.txn_fact tf ON tf.txn_id = q.fact_txn_id
        WHERE q.shape_signature = p_shape_signature
    LOOP
        DELETE FROM spendsense.txn_parsed             WHERE fact_txn_id = v_txn.fact_txn_id;
        DELETE FROM spendsense.txn_parse_stage         WHERE fact_txn_id = v_txn.fact_txn_id;
        DELETE FROM spendsense.txn_parse_unknown_queue WHERE fact_txn_id = v_txn.fact_txn_id;
        v_count := v_count + 1;
    END LOOP;

    UPDATE spendsense.txn_parse_unknown_shape_stats
    SET review_status = 'RULE_CREATED', updated_at = NOW()
    WHERE shape_signature = p_shape_signature;

    RAISE NOTICE
        'Cleared % transactions for shape [%]. '
        'INSERT new format into txn_channel_format_registry, '
        'then call populate_txn_parse_stage_v3() and populate_txn_parsed_v3().',
        v_count, p_shape_signature;

    RETURN v_count;
END;
$$;

-- ============================================================
-- SECTION 15: UPDATED VIEWS
-- ============================================================

-- Add sub_type and parse_format to the main parsed view
CREATE OR REPLACE VIEW spendsense.vw_txn_parsed AS
SELECT
    p.fact_txn_id                                    AS txn_id,
    p.user_id,
    p.upload_id,
    p.bank_code,
    p.txn_date,
    p.amount,
    p.cr_dr                                          AS dr_cr,
    p.raw_description                                AS raw_desc,
    p.channel_type                                   AS txn_mode,
    p.sub_type,
    p.parse_format,
    p.direction                                      AS direction_text,
    p.upi_rrn                                        AS rrn,
    COALESCE(p.neft_utr, p.imps_rrn, p.internal_ref) AS utr,
    p.counterparty_name,
    p.counterparty_bank_code,
    p.counterparty_vpa                               AS upi_vpa,
    CASE
        WHEN p.counterparty_vpa ILIKE '%VYAPAR%'    THEN 'VYAPAR'
        WHEN p.counterparty_vpa ILIKE '%BHARATPE%'  THEN 'BHARATPE'
        WHEN p.counterparty_vpa ILIKE '%PAYTM%'     THEN 'PAYTM'
        WHEN p.counterparty_vpa ILIKE '%PHONEPE%'   THEN 'PHONEPE'
        WHEN p.counterparty_vpa ILIKE '%GOOGLEPAY%'
          OR p.counterparty_vpa ILIKE '%OKAXIS%'
          OR p.counterparty_vpa ILIKE '%OKBIZ%'     THEN 'GOOGLEPAY'
        WHEN p.counterparty_vpa ILIKE '%.RZP@%'
          OR p.counterparty_vpa ILIKE '%RAZORPAY%'  THEN 'RAZORPAY'
        WHEN p.counterparty_vpa ILIKE '%CRED%'      THEN 'CRED'
        WHEN p.counterparty_vpa ILIKE '%AMAZON%'    THEN 'AMAZONPAY'
    END                                              AS platform_or_gateway,
    p.counterparty_ifsc                              AS ifsc,
    COALESCE(p.biller_name, p.ach_nach_entity)       AS biller_name,
    p.biller_code,
    p.card_ref,
    p.atm_txn_id,
    p.atm_location,
    p.mcc,
    p.ach_nach_entity                                AS originator_name,
    p.mandate_or_run_id,
    p.purpose,
    p.note_text,
    p.merchant_name,
    p.pattern_family,
    p.parse_status,
    p.parse_confidence,
    p.parse_version
FROM spendsense.txn_parsed p;

-- Updated pattern coverage — includes parse_format breakdown
CREATE OR REPLACE VIEW spendsense.vw_txn_parse_pattern_coverage AS
SELECT
    channel_type,
    COALESCE(parse_format, pattern_family) AS format_or_family,
    sub_type,
    COUNT(*)                                                         AS txn_count,
    ROUND(100.0*COUNT()/NULLIF(SUM(COUNT(*)) OVER (),0), 2)          AS pct_share,
    ROUND(AVG(parse_confidence), 2)                                  AS avg_confidence,
    COUNT(*) FILTER (WHERE parse_status='PARSED')                    AS parsed_count,
    COUNT(*) FILTER (WHERE parse_status='PARTIAL')                   AS partial_count
FROM spendsense.txn_parsed
GROUP BY channel_type, COALESCE(parse_format, pattern_family), sub_type
ORDER BY txn_count DESC;

-- Quality KPI — unchanged but extended for v3
CREATE OR REPLACE VIEW spendsense.vw_txn_parse_quality_kpi AS
SELECT
    COUNT(*)                                                         AS total_rows,
    COUNT(*) FILTER (WHERE parse_status='PARSED')                   AS parsed_rows,
    COUNT(*) FILTER (WHERE parse_status='PARTIAL')                  AS partial_rows,
    COUNT(*) FILTER (WHERE parse_status='UNPARSED')                 AS unparsed_rows,
    COUNT(*) FILTER (WHERE direction='UNKNOWN')                     AS unknown_direction_rows,
    COUNT(*) FILTER (WHERE sub_type='TRUNCATED')                    AS truncated_rows,
    ROUND(100.0*COUNT(*) FILTER (WHERE parse_status='PARSED')
          /NULLIF(COUNT(*),0), 2)                                   AS parsed_pct,
    ROUND(100.0*COUNT(*) FILTER (WHERE parse_status='PARTIAL')
          /NULLIF(COUNT(*),0), 2)                                   AS partial_pct,
    ROUND(100.0*COUNT(*) FILTER (WHERE direction='UNKNOWN')
          /NULLIF(COUNT(*),0), 2)                                   AS unknown_direction_pct,
    ROUND(AVG(parse_confidence), 2)                                 AS avg_confidence,
    parse_version
FROM spendsense.txn_parsed
GROUP BY parse_version;

COMMIT;

-- ============================================================
-- RUN ORDER (v3)
-- ============================================================
-- Initial load for a specific upload:
--   SELECT spendsense.populate_txn_parse_stage_v3('<upload_uuid>');
--   SELECT spendsense.populate_txn_parsed_v3('<upload_uuid>');
--   SELECT spendsense.populate_txn_parse_unknown_queue_v3('<upload_uuid>');
--
-- Full rebuild (all data):
--   SELECT spendsense.populate_txn_parse_stage_v3();
--   SELECT spendsense.populate_txn_parsed_v3();
--   SELECT spendsense.populate_txn_parse_unknown_queue_v3();
--
-- Reparse single transaction:
--   SELECT spendsense.fn_reparse_transaction('<fact_txn_id>');
--
-- Add a new format, then reparse affected shape:
--   INSERT INTO spendsense.txn_channel_format_registry
--       (channel_type, format_name, detection_regex, delimiter, ...)
--   VALUES (...);
--   SELECT spendsense.fn_reparse_by_shape_v3('<shape_signature>');
--   SELECT spendsense.populate_txn_parse_stage_v3();
--   SELECT spendsense.populate_txn_parsed_v3();
--   SELECT spendsense.populate_txn_parse_unknown_queue_v3();
--
-- Add a new field signal for an existing channel:
--   INSERT INTO spendsense.txn_channel_field_schema
--       (channel_type, field_name, match_regex, ...)
--   VALUES (...);
--   -- Then reparse affected rows (no shape change needed if
--   --  the format already fires, just re-run populate_txn_parsed_v3)
--
-- Monitor quality:
--   SELECT * FROM spendsense.vw_txn_parse_quality_kpi;
--   SELECT * FROM spendsense.vw_txn_parse_pattern_coverage;
--   SELECT * FROM spendsense.vw_txn_parse_unknown_clusters LIMIT 50;
--   SELECT * FROM spendsense.vw_txn_parse_direction_anomalies LIMIT 20;
--
-- Test token classifier directly:
--   SELECT spendsense.fn_classify_tokens(
--     'UPI-PANDIT PAN-Q370212766@YBL-YESB0YBLUPI-116204307901-UPI',
--     'UPI', 'UPI_DASH', '-', ARRAY[0], NULL
--   );
--
-- Test NACH parser directly:
--   SELECT spendsense.fn_parse_nach(
--     'NACH NSEMFS05032025CAMS 5950850995240 5011386641 CNRB0000000003757718'
--   );
--
-- Test OTHER sub-type parser directly:
--   SELECT spendsense.fn_parse_other_subtype(
--     'PPR000812224265_EMI_05-10-2025_AAKASH VIRENDER SAB'
--   );
-- ============================================================
