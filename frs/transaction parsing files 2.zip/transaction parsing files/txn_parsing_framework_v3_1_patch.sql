-- ============================================================================
-- MONYTIX — TRANSACTION PARSING FRAMEWORK v3.1 PATCH
-- PostgreSQL / PLpgSQL
--
-- Applies on top of: txn_parsing_framework_v3.sql
--
-- What this patch adds:
--   1) Semantic metadata on txn_channel_field_schema
--      (semantic_type, priority_rank)
--   2) Token noise registry (txn_token_noise_registry)
--   3) Position bias registry (txn_field_position_bias)
--   4) Token normalizer + semantic feature extractor
--      (fn_norm_token_v31, fn_token_features_v31)
--   5) Coherence validator (fn_validate_parse_v31)
--   6) fn_classify_tokens full replacement — hybrid scorer:
--        regex score
--      + semantic bonus (is_rrn_like, is_vpa_like, is_utr_like …)
--      + soft position bias
--      - noise penalty
--      - cross-semantic mismatch penalty
--      + deterministic tie-break via priority_rank
--   7) UPI field schema tightening
--
-- Fixes applied vs original RTF:
--   - RTF corrupted regex quantifiers {N,M} → restored throughout
--   - RTF corrupted '{}'::JSONB literals → restored in validator
--   - RTF corrupted space-detection regex in rev_split CTE → restored
--   - Position bias lookup promoted from correlated subquery to CTE
--     (performance: O(1) join instead of O(T×F) subqueries per txn)
--   - Added is_utr_like semantic flag for NEFT UTR detection
--
-- Compatibility:
--   - Same function signature: spendsense.fn_classify_tokens(...)
--   - populate_txn_parsed_v3() continues unchanged
--   - Output JSONB gains: _assigned, _classifier_version='v3.1'
-- ============================================================================

BEGIN;

-- ============================================================================
-- 1) EXTEND FIELD SCHEMA WITH SEMANTIC METADATA
-- ============================================================================

ALTER TABLE spendsense.txn_channel_field_schema
    ADD COLUMN IF NOT EXISTS semantic_type  TEXT,
    ADD COLUMN IF NOT EXISTS priority_rank  INT NOT NULL DEFAULT 100;

COMMENT ON COLUMN spendsense.txn_channel_field_schema.semantic_type IS
'High-level semantic class: RRN, VPA, NAME, BANK, IFSC, ACCOUNT, PURPOSE,
 CARD, REF, ATM_LOC, ATM_TXN, TYPE_CODE, GATEWAY, ENTITY, MANDATE, UTR.';

COMMENT ON COLUMN spendsense.txn_channel_field_schema.priority_rank IS
'Tie-break rank when two fields score similarly for the same token.
 Lower = higher priority. Evaluated after final_score.';

-- Seed semantic_type
UPDATE spendsense.txn_channel_field_schema
SET semantic_type = CASE field_name
    WHEN 'upi_rrn'              THEN 'RRN'
    WHEN 'imps_rrn'             THEN 'RRN'
    WHEN 'neft_utr'             THEN 'UTR'   -- distinct from RRN: alphanumeric
    WHEN 'counterparty_vpa'     THEN 'VPA'
    WHEN 'counterparty_name'    THEN 'NAME'
    WHEN 'beneficiary_name'     THEN 'NAME'
    WHEN 'merchant_name'        THEN 'NAME'
    WHEN 'counterparty_bank'    THEN 'BANK'
    WHEN 'counterparty_ifsc'    THEN 'IFSC'
    WHEN 'counterparty_account' THEN 'ACCOUNT'
    WHEN 'phone_or_account'     THEN 'ACCOUNT'
    WHEN 'internal_ref'         THEN 'REF'
    WHEN 'payment_ref'          THEN 'REF'
    WHEN 'txn_type_code'        THEN 'TYPE_CODE'
    WHEN 'gateway_name'         THEN 'GATEWAY'
    WHEN 'purpose'              THEN 'PURPOSE'
    WHEN 'biller_code'          THEN 'ENTITY'
    WHEN 'ach_entity'           THEN 'ENTITY'
    WHEN 'mandate_ref'          THEN 'MANDATE'
    WHEN 'card_number'          THEN 'CARD'
    WHEN 'card_ref'             THEN 'CARD'
    WHEN 'card_last4'           THEN 'CARD'
    WHEN 'atm_terminal_id'      THEN 'REF'
    WHEN 'atm_location'         THEN 'ATM_LOC'
    WHEN 'atm_txn_id'           THEN 'ATM_TXN'
    ELSE COALESCE(semantic_type, 'GENERIC')
END
WHERE semantic_type IS NULL OR semantic_type = '';

-- Seed priority_rank (lower = wins tie-breaks first)
UPDATE spendsense.txn_channel_field_schema
SET priority_rank = CASE field_name
    WHEN 'upi_rrn'              THEN 10
    WHEN 'imps_rrn'             THEN 10
    WHEN 'neft_utr'             THEN 10
    WHEN 'atm_txn_id'           THEN 20
    WHEN 'counterparty_vpa'     THEN 20
    WHEN 'card_number'          THEN 20
    WHEN 'counterparty_ifsc'    THEN 25
    WHEN 'card_ref'             THEN 25
    WHEN 'counterparty_bank'    THEN 30
    WHEN 'card_last4'           THEN 30
    WHEN 'counterparty_account' THEN 35
    WHEN 'phone_or_account'     THEN 35
    WHEN 'atm_terminal_id'      THEN 35
    WHEN 'counterparty_name'    THEN 40
    WHEN 'beneficiary_name'     THEN 40
    WHEN 'merchant_name'        THEN 40
    WHEN 'atm_location'         THEN 40
    WHEN 'gateway_name'         THEN 45
    WHEN 'txn_type_code'        THEN 50
    WHEN 'internal_ref'         THEN 60
    WHEN 'payment_ref'          THEN 60
    WHEN 'biller_code'          THEN 70
    WHEN 'ach_entity'           THEN 70
    WHEN 'mandate_ref'          THEN 75
    WHEN 'purpose'              THEN 999
    ELSE priority_rank
END;

-- ============================================================================
-- 2) TOKEN NOISE REGISTRY
--
-- Tokens matching noise_regex are NOT discarded — they receive a
-- penalty_score deduction in the scorer. Keeps skip_positions intact
-- for structural prefixes, but handles variable-position narration junk.
-- ============================================================================

CREATE TABLE IF NOT EXISTS spendsense.txn_token_noise_registry (
    noise_id         BIGSERIAL PRIMARY KEY,
    channel_type     TEXT NOT NULL,
    format_name      TEXT,             -- NULL = applies to all formats
    noise_regex      TEXT NOT NULL,
    noise_type       TEXT NOT NULL DEFAULT 'GENERIC'
                         CHECK (noise_type IN ('STRUCTURAL','NOISE','GENERIC')),
    penalty_score    NUMERIC(6,2) NOT NULL DEFAULT 0.50
                         CHECK (penalty_score BETWEEN 0 AND 2),
    active           BOOLEAN NOT NULL DEFAULT TRUE,
    notes            TEXT,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS ix_tnr_channel_active
    ON spendsense.txn_token_noise_registry(channel_type, active);
CREATE INDEX IF NOT EXISTS ix_tnr_format_active
    ON spendsense.txn_token_noise_registry(channel_type, format_name, active);

COMMENT ON TABLE spendsense.txn_token_noise_registry IS
'Per-channel noise rules. Matching tokens receive penalty_score deduction
 during field scoring — penalized not blindly discarded.';

INSERT INTO spendsense.txn_token_noise_registry
    (channel_type, format_name, noise_regex, noise_type, penalty_score, notes)
SELECT
    x.channel_type, x.format_name, x.noise_regex,
    x.noise_type, x.penalty_score, x.notes
FROM (VALUES
    ('UPI', NULL,
        '^(UPI|P2A|P2M|P2P|DR|CR|REV|IN|OUT)$',
        'STRUCTURAL', 1.00,
        'UPI structural markers — never a real field value'),
    ('UPI', NULL,
        '^(IN APP|SENT USI|PAYMEN|PAYMENT|PAYMENTFROMPHONE|TRF|LEDGER|COLLECT|REQUEST|UPIINT|YESPAY)$',
        'NOISE', 0.90,
        'UPI bank narration garbage at variable positions'),
    ('IMPS', NULL,
        '^(IMPS|P2A|P2P|TRF|TRANSFER|TRANS|OWN|SELF|AC|DR|CR)$',
        'STRUCTURAL', 0.90,
        'IMPS structural markers'),
    ('NEFT', NULL,
        '^(NEFT|MB|RETURN|SELF|ATTN|INB|NULL|DR|CR)$',
        'STRUCTURAL', 0.90,
        'NEFT structural markers'),
    ('ATM', NULL,
        '^(ATM|CASH|NWD|WDL|DR|CR)$',
        'STRUCTURAL', 0.90,
        'ATM structural markers'),
    ('CARD_BILLPAY', NULL,
        '^(IBBILLPAYDR|IB BILLPAY DR|BILLPAY|CARDPAY|CCPAY)$',
        'STRUCTURAL', 0.95,
        'Card billpay structural prefix tokens'),
    ('OTHER', NULL,
        '^(MOB|TPFT|FT|TRF|TRANSFER|DR|CR)$',
        'STRUCTURAL', 0.85,
        'Other channel structural tokens')
) AS x(channel_type, format_name, noise_regex, noise_type, penalty_score, notes)
WHERE NOT EXISTS (
    SELECT 1
    FROM spendsense.txn_token_noise_registry t
    WHERE t.channel_type = x.channel_type
      AND COALESCE(t.format_name, '') = COALESCE(x.format_name, '')
      AND t.noise_regex = x.noise_regex
);

-- ============================================================================
-- 3) POSITION BIAS REGISTRY
--
-- Soft positional bonus. token_position and position_from_end are 1-based
-- after skip_positions have already been removed.
-- A token at the wrong position loses the bonus but is NOT disqualified.
-- ============================================================================

CREATE TABLE IF NOT EXISTS spendsense.txn_field_position_bias (
    bias_id             BIGSERIAL PRIMARY KEY,
    channel_type        TEXT NOT NULL,
    format_name         TEXT,
    field_name          TEXT NOT NULL,
    token_position      INT,             -- 1-based from start
    position_from_end   INT,             -- 1-based from end
    score_bonus         NUMERIC(6,2) NOT NULL DEFAULT 0.00,
    active              BOOLEAN NOT NULL DEFAULT TRUE,
    notes               TEXT,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT ck_tfpb_has_position
        CHECK (token_position IS NOT NULL OR position_from_end IS NOT NULL)
);

CREATE INDEX IF NOT EXISTS ix_tfpb_channel_active
    ON spendsense.txn_field_position_bias(channel_type, active);
CREATE INDEX IF NOT EXISTS ix_tfpb_format_field
    ON spendsense.txn_field_position_bias(channel_type, format_name, field_name, active);

COMMENT ON TABLE spendsense.txn_field_position_bias IS
'Soft position bonuses per channel/format/field.
 Added to final_score in fn_classify_tokens CTE scorer.';

INSERT INTO spendsense.txn_field_position_bias
    (channel_type, format_name, field_name,
     token_position, position_from_end, score_bonus, notes)
SELECT
    x.channel_type, x.format_name, x.field_name,
    x.token_position, x.position_from_end, x.score_bonus, x.notes
FROM (VALUES
    -- UPI slash formats
    ('UPI','UPI_P2A_SLASH','upi_rrn',           1, NULL, 1.50, 'RRN first usable token'),
    ('UPI','UPI_P2A_SLASH','counterparty_name', 2, NULL, 1.20, 'Name follows RRN'),
    ('UPI','UPI_P2A_SLASH','counterparty_bank', NULL, 1,  1.10, 'Bank often last'),
    ('UPI','UPI_P2M_SLASH','upi_rrn',           1, NULL, 1.50, 'RRN first'),
    ('UPI','UPI_P2M_SLASH','counterparty_name', 2, NULL, 1.25, 'Merchant follows RRN'),
    ('UPI','UPI_P2M_SLASH','merchant_name',     2, NULL, 1.25, 'Merchant follows RRN'),
    ('UPI','UPI_P2M_SLASH','counterparty_bank', NULL, 1,  1.10, 'Bank often last'),
    ('UPI','UPI_CRDRREV_SLASH','upi_rrn',       2, NULL, 1.40, 'RRN after DR/CR/REV'),
    ('UPI','UPI_CRDRREV_SLASH','counterparty_vpa', 3, NULL, 1.10, 'Masked VPA after RRN'),
    ('UPI','UPIOUT_SLASH','upi_rrn',            1, NULL, 1.50, 'RRN first'),
    ('UPI','UPIOUT_SLASH','counterparty_vpa',   2, NULL, 1.15, 'VPA next'),
    ('UPI','UPI_IN_SLASH','upi_rrn',            1, NULL, 1.50, 'RRN first'),
    ('UPI','UPI_IN_SLASH','counterparty_vpa',   2, NULL, 1.15, 'Sender VPA next'),
    ('UPI','REV_DASH','upi_rrn',                1, NULL, 1.40, 'RRN early in reversal'),
    ('UPI','REV_DASH','counterparty_vpa',       NULL, 2,  1.00, 'VPA near tail'),
    -- IMPS
    ('IMPS','IMPS_DASH','imps_rrn',             1, NULL, 1.40, 'RRN first after IMPS'),
    ('IMPS','IMPS_DASH','counterparty_name',    2, NULL, 1.10, 'Name after RRN'),
    ('IMPS','IMPS_DASH','counterparty_bank',    3, NULL, 0.90, 'Bank third'),
    ('IMPS','IMPS_P2A_SLASH','imps_rrn',        1, NULL, 1.40, 'RRN first'),
    ('IMPS','IMPS_P2A_SLASH','counterparty_name', 2, NULL, 1.10, 'Name second'),
    ('IMPS','IMPS_P2A_SLASH','counterparty_bank', 3, NULL, 0.90, 'Bank third'),
    ('IMPS','MMT_IMPS_SLASH','imps_rrn',        1, NULL, 1.40, 'RRN first'),
    ('IMPS','MMT_IMPS_SLASH','counterparty_name', 2, NULL, 1.10, 'Name second'),
    ('IMPS','MMT_IMPS_SLASH','counterparty_ifsc', NULL, 1, 0.95, 'IFSC often last'),
    -- NEFT
    ('NEFT','NEFT_SLASH','neft_utr',            1, NULL, 1.40, 'UTR first in canonical slash'),
    ('NEFT','NEFT_SLASH','counterparty_name',   2, NULL, 0.80, 'Name second'),
    ('NEFT','NEFT_SLASH','counterparty_bank',   NULL, 1,  0.90, 'Bank often last'),
    ('NEFT','NEFT_MB_SLASH','neft_utr',         1, NULL, 1.30, 'UTR first after MB skip'),
    ('NEFT','NEFT_CR_DASH','neft_utr',          NULL, 1,  1.20, 'UTR always last in NEFT CR dash'),
    -- ATM
    ('ATM','ATM_WDL_DASH','atm_txn_id',         1, NULL, 1.00, 'Short numeric txn id early'),
    ('ATM','ATM_WDL_DASH','atm_location',        NULL, 1,  1.00, 'Location last'),
    ('ATM','NWD_DASH','card_number',             1, NULL, 1.30, 'Card first after NWD'),
    ('ATM','NWD_DASH','atm_terminal_id',         2, NULL, 0.90, 'Terminal second'),
    ('ATM','NWD_DASH','atm_location',            NULL, 1,  1.00, 'Location last')
) AS x(channel_type, format_name, field_name,
        token_position, position_from_end, score_bonus, notes)
WHERE NOT EXISTS (
    SELECT 1
    FROM spendsense.txn_field_position_bias b
    WHERE b.channel_type = x.channel_type
      AND COALESCE(b.format_name, '') = COALESCE(x.format_name, '')
      AND b.field_name = x.field_name
      AND COALESCE(b.token_position, -1)    = COALESCE(x.token_position, -1)
      AND COALESCE(b.position_from_end, -1) = COALESCE(x.position_from_end, -1)
);

COMMIT;

-- ============================================================================
-- Functions block
-- ============================================================================

BEGIN;

-- ============================================================================
-- 4) TOKEN NORMALIZER + SEMANTIC FEATURE EXTRACTOR
--
-- fn_norm_token_v31: uppercase, collapse spaces, strip leading/trailing
--   punctuation (but keep @ and * for VPA detection).
--
-- fn_token_features_v31: returns JSONB feature flags used by the scorer.
--   FIX: RTF corrupted all regex quantifiers — restored throughout.
--   FIX: Added is_utr_like for NEFT UTR detection (alphanumeric, not digits-only).
-- ============================================================================

CREATE OR REPLACE FUNCTION spendsense.fn_norm_token_v31(p_token TEXT)
RETURNS TEXT
LANGUAGE sql IMMUTABLE AS $$
    SELECT NULLIF(
        TRIM(
            regexp_replace(
                regexp_replace(
                    UPPER(COALESCE(p_token, '')),
                    '[[:space:]]+', ' ', 'g'
                ),
                '^[^A-Z0-9@*]+|[^A-Z0-9@*]+$', '', 'g'
            )
        ),
        ''
    );
$$;

COMMENT ON FUNCTION spendsense.fn_norm_token_v31(TEXT) IS
'Normalises a token: uppercase, collapse spaces, strip leading/trailing
 punctuation. Keeps @ and * intact for VPA detection.';

CREATE OR REPLACE FUNCTION spendsense.fn_token_features_v31(p_token TEXT)
RETURNS JSONB
LANGUAGE sql IMMUTABLE AS $$
    WITH t AS (
        SELECT spendsense.fn_norm_token_v31(p_token) AS tok
    )
    SELECT jsonb_build_object(
        'token',         tok,
        'len',           COALESCE(length(tok), 0),
        'is_numeric',    COALESCE(tok ~ '^[0-9]+$', FALSE),
        -- RRN: exactly 12-14 consecutive digits (UPI/IMPS)
        'is_rrn_like',   COALESCE(tok ~ '^[0-9]{12,14}$', FALSE),
        -- UTR: alphanumeric, starts with letter(s), 12-22 chars (NEFT)
        'is_utr_like',   COALESCE(tok ~ '^[A-Z]{3,6}[0-9A-Z]{9,16}$', FALSE),
        -- VPA: local-part@bank or **masked@bank
        'is_vpa_like',   COALESCE(tok ~ '(^|\*\*)[A-Z0-9._%+\-]+@[A-Z][A-Z0-9._\-]*$', FALSE),
        -- IFSC: 4 letters + 0 + 6 alphanumeric
        'is_ifsc_like',  COALESCE(tok ~ '^[A-Z]{4}0[A-Z0-9]{6}$', FALSE),
        -- Bank: ends with BANK, PAYMENTS BANK, or is a known 4-char code
        'is_bank_like',  COALESCE(tok ~ '(BANK|PAYMENTS BANK|BANK LTD|BANK LIMITED)$'
                                   OR tok ~ '^(HDFC|ICIC|SBIN|UTIB|CNRB|YESB|AXIS|UBIN|MAHB|INDB|FDRL)([0-9A-Z]*)$',
                                  FALSE),
        -- Card: 6 digits + X-mask + 3-4 digits
        'is_card_like',  COALESCE(tok ~ '^[0-9]{6}X{4,}[0-9]{3,4}$', FALSE),
        -- Alpha name: starts with letter, mostly letters/spaces
        'is_alpha_like', COALESCE(tok ~ '^[A-Z][A-Z0-9 .&/_-]{2,}$', FALSE)
    )
    FROM t;
$$;

COMMENT ON FUNCTION spendsense.fn_token_features_v31(TEXT) IS
'Returns semantic feature flags for the v3.1 scorer.
 is_utr_like added for NEFT UTR detection (was missing from original patch).';

-- ============================================================================
-- 5) COHERENCE VALIDATOR
--
-- Post-processes scored field assignments. Drops obvious bad picks and
-- reduces confidence accordingly. Never reassigns — only removes.
-- FIX: RTF encoded '{}'::JSONB as '\\'::JSONB — restored throughout.
-- ============================================================================

CREATE OR REPLACE FUNCTION spendsense.fn_validate_parse_v31(
    p_channel_type TEXT,
    p_format_name  TEXT,
    p_fields       JSONB
)
RETURNS JSONB
LANGUAGE plpgsql IMMUTABLE AS $$
DECLARE
    v_result JSONB   := COALESCE(p_fields, '{}'::JSONB);
    v_conf   NUMERIC := COALESCE(
                            NULLIF((p_fields->>'_confidence'), '')::NUMERIC,
                            0.20);
    v_name   TEXT;
    v_bank   TEXT;
BEGIN
    IF v_result = '{}'::JSONB THEN
        RETURN jsonb_build_object(
            '_confidence', 0.20,
            '_format', p_format_name
        );
    END IF;

    IF p_channel_type = 'UPI' THEN
        -- Drop RRN if it fails shape check
        IF v_result ? 'upi_rrn'
           AND COALESCE(v_result->>'upi_rrn', '') !~ '^[0-9]{12,14}$' THEN
            v_result := v_result - 'upi_rrn';
            v_conf   := LEAST(v_conf, 0.60);
        END IF;

        -- Drop name if it duplicates bank
        v_name := NULLIF(TRIM(COALESCE(v_result->>'counterparty_name', '')), '');
        v_bank := NULLIF(TRIM(COALESCE(v_result->>'counterparty_bank', '')), '');
        IF v_name IS NOT NULL
           AND v_bank IS NOT NULL
           AND UPPER(v_name) = UPPER(v_bank) THEN
            v_result := v_result - 'counterparty_name';
            v_conf   := LEAST(v_conf, 0.65);
        END IF;

        -- Drop name if it is a known noise keyword
        IF v_result ? 'counterparty_name'
           AND UPPER(COALESCE(v_result->>'counterparty_name', ''))
               ~* '^(UPI|IN APP|SENT USI|PAYMEN|PAYMENT|DR|CR|REV|P2A|P2M|P2P|UPIINT|YESPAY)$'
        THEN
            v_result := v_result - 'counterparty_name';
            v_conf   := LEAST(v_conf, 0.62);
        END IF;

        -- Drop gateway if it was erroneously assigned the same token as VPA
        IF v_result ? 'counterparty_vpa'
           AND v_result ? 'gateway_name'
           AND UPPER(COALESCE(v_result->>'gateway_name', ''))
               = UPPER(COALESCE(v_result->>'counterparty_vpa', '')) THEN
            v_result := v_result - 'gateway_name';
            v_conf   := LEAST(v_conf, 0.70);
        END IF;
    END IF;

    IF p_channel_type = 'IMPS' THEN
        -- Drop RRN if not exactly 12 digits
        IF v_result ? 'imps_rrn'
           AND COALESCE(v_result->>'imps_rrn', '') !~ '^[0-9]{12}$' THEN
            v_result := v_result - 'imps_rrn';
            v_conf   := LEAST(v_conf, 0.60);
        END IF;
    END IF;

    IF p_channel_type = 'NEFT' THEN
        -- Drop UTR if implausibly short
        IF v_result ? 'neft_utr'
           AND length(COALESCE(v_result->>'neft_utr', '')) < 12 THEN
            v_result := v_result - 'neft_utr';
            v_conf   := LEAST(v_conf, 0.60);
        END IF;
    END IF;

    RETURN (v_result - '_confidence')
           || jsonb_build_object(
                  '_confidence', ROUND(v_conf, 2),
                  '_format',     p_format_name
              );
END;
$$;

COMMENT ON FUNCTION spendsense.fn_validate_parse_v31(TEXT, TEXT, JSONB) IS
'Post-scoring coherence checks. Drops bad field assignments and reduces
 confidence. Never reassigns — PARTIAL surfaces any dropped field.';

-- ============================================================================
-- 6) fn_classify_tokens REPLACEMENT (v3.1)
--
-- Same function signature as v3 — drop-in replacement, no pipeline changes.
--
-- Scoring formula per (token, field) pair:
--   regex score          (field.confidence if match_regex fires, else 0)
-- + semantic bonus       (is_rrn_like, is_vpa_like, is_utr_like, etc.)
-- + position bonus       (from txn_field_position_bias — pre-joined as CTE)
-- - noise penalty        (from txn_token_noise_registry)
-- - cross-semantic miss  (e.g. NAME field should not get a BANK-like token)
--
-- Assignment: window function rn_field=1 AND rn_token=1 ensures strict
-- 1 token → 1 field mapping with no double-assignment.
--
-- FIX vs original: position bias promoted from correlated subquery to CTE.
-- FIX vs original: REV_DASH space-split regex corrected (RTF had '\'' not ' ').
-- FIX vs original: is_utr_like wired into NEFT semantic bonus.
-- ============================================================================

CREATE OR REPLACE FUNCTION spendsense.fn_classify_tokens(
    p_norm_desc     TEXT,
    p_channel_type  TEXT,
    p_format_name   TEXT,
    p_delimiter     TEXT,
    p_skip_pos      INT[],
    p_prefix_strip  TEXT
)
RETURNS JSONB
LANGUAGE plpgsql STABLE AS $$
DECLARE
    v_desc       TEXT;
    v_raw_tokens TEXT[];
    v_result     JSONB := '{}'::JSONB;
BEGIN
    -- Strip prefix noise
    v_desc := UPPER(TRIM(COALESCE(p_norm_desc, '')));
    IF p_prefix_strip IS NOT NULL THEN
        v_desc := TRIM(regexp_replace(v_desc, p_prefix_strip, '', 'i'));
    END IF;

    v_raw_tokens := string_to_array(v_desc, UPPER(p_delimiter));

    IF COALESCE(array_length(v_raw_tokens, 1), 0) = 0 THEN
        RETURN jsonb_build_object(
            '_confidence',        0.10,
            '_tokens',            0,
            '_format',            p_format_name,
            '_classifier_version','v3.1'
        );
    END IF;

    WITH

    -- ── Step 1: tokenise and apply skip_positions ──────────────────────
    raw_tokens AS (
        SELECT
            (ordinality::INT - 1) AS raw_pos,
            spendsense.fn_norm_token_v31(token) AS token
        FROM unnest(v_raw_tokens) WITH ORDINALITY AS t(token, ordinality)
    ),
    usable_tokens AS (
        SELECT
            row_number() OVER (ORDER BY raw_pos) AS token_pos,
            raw_pos,
            token
        FROM raw_tokens
        WHERE token IS NOT NULL
          AND NOT ((raw_pos) = ANY(COALESCE(p_skip_pos, ARRAY[]::INT[])))
    ),

    -- ── Step 2: REV_DASH secondary split ──────────────────────────────
    -- Last token may be "VPA ACCOUNT" — split on first space.
    -- FIX: original RTF had ~ '\'' which is wrong. Correct: token ~ ' '
    rev_split AS (
        SELECT * FROM usable_tokens
        WHERE NOT (
            p_format_name = 'REV_DASH'
            AND token_pos = (SELECT max(token_pos) FROM usable_tokens)
            AND token ~ ' '
        )
        UNION ALL
        -- First half (VPA)
        SELECT
            u.token_pos,
            u.raw_pos,
            split_part(u.token, ' ', 1) AS token
        FROM usable_tokens u
        WHERE p_format_name = 'REV_DASH'
          AND u.token_pos = (SELECT max(token_pos) FROM usable_tokens)
          AND u.token ~ ' '
        UNION ALL
        -- Second half (account / tail)
        SELECT
            u.token_pos + 1000,
            u.raw_pos + 1000,
            NULLIF(TRIM(substring(u.token FROM position(' ' IN u.token) + 1)), '') AS token
        FROM usable_tokens u
        WHERE p_format_name = 'REV_DASH'
          AND u.token_pos = (SELECT max(token_pos) FROM usable_tokens)
          AND u.token ~ ' '
    ),
    norm_tokens AS (
        SELECT
            row_number() OVER (ORDER BY token_pos, raw_pos) AS token_pos,
            raw_pos,
            token
        FROM rev_split
        WHERE token IS NOT NULL
    ),

    -- ── Step 3: semantic features per token ───────────────────────────
    token_count AS (
        SELECT count(*)::INT AS n FROM norm_tokens
    ),
    token_features AS (
        SELECT
            t.token_pos,
            t.raw_pos,
            t.token,
            spendsense.fn_token_features_v31(t.token) AS feat
        FROM norm_tokens t
    ),

    -- ── Step 4: load field schema ──────────────────────────────────────
    field_schema AS (
        SELECT
            s.schema_id,
            s.field_name,
            s.match_regex,
            s.exclude_regex,
            s.min_length,
            s.max_length,
            s.confidence,
            s.is_fallback,
            COALESCE(s.semantic_type, 'GENERIC')  AS semantic_type,
            COALESCE(s.priority_rank, 100)         AS priority_rank
        FROM spendsense.txn_channel_field_schema s
        WHERE s.channel_type = p_channel_type
    ),
    non_fallback_fields AS (
        SELECT * FROM field_schema WHERE is_fallback = FALSE
    ),

    -- ── Step 5: pre-join noise hits ────────────────────────────────────
    noise_hits AS (
        SELECT
            t.token_pos,
            max(n.penalty_score) AS penalty_score
        FROM token_features t
        JOIN spendsense.txn_token_noise_registry n
          ON n.active       = TRUE
         AND n.channel_type = p_channel_type
         AND (n.format_name IS NULL OR n.format_name = p_format_name)
         AND t.token ~* n.noise_regex
        GROUP BY t.token_pos
    ),

    -- ── Step 6: pre-join position bonuses (FIX: was correlated subquery) ─
    position_bonuses AS (
        SELECT
            b.field_name,
            t.token_pos,
            max(b.score_bonus) AS score_bonus
        FROM token_features t
        CROSS JOIN token_count c
        JOIN spendsense.txn_field_position_bias b
          ON b.active       = TRUE
         AND b.channel_type = p_channel_type
         AND (b.format_name IS NULL OR b.format_name = p_format_name)
         AND (
               (b.token_position    IS NOT NULL AND b.token_position    = t.token_pos)
            OR (b.position_from_end IS NOT NULL AND b.position_from_end = (c.n - t.token_pos + 1))
         )
        GROUP BY b.field_name, t.token_pos
    ),

    -- ── Step 7: score every (token, field) pair ────────────────────────
    candidate_scores AS (
        SELECT
            t.token_pos,
            t.raw_pos,
            t.token,
            f.field_name,
            f.priority_rank,
            (
                -- Base: regex match score
                CASE
                    WHEN t.token ~* f.match_regex THEN f.confidence
                    ELSE 0
                END

                -- Semantic bonus
                + CASE
                    WHEN f.semantic_type = 'RRN'
                         AND COALESCE((t.feat->>'is_rrn_like')::BOOLEAN, FALSE)
                    THEN 0.80
                    WHEN f.semantic_type = 'UTR'
                         AND COALESCE((t.feat->>'is_utr_like')::BOOLEAN, FALSE)
                    THEN 0.80
                    WHEN f.semantic_type = 'VPA'
                         AND COALESCE((t.feat->>'is_vpa_like')::BOOLEAN, FALSE)
                    THEN 0.90
                    WHEN f.semantic_type = 'IFSC'
                         AND COALESCE((t.feat->>'is_ifsc_like')::BOOLEAN, FALSE)
                    THEN 0.90
                    WHEN f.semantic_type = 'BANK'
                         AND COALESCE((t.feat->>'is_bank_like')::BOOLEAN, FALSE)
                    THEN 0.75
                    WHEN f.semantic_type = 'CARD'
                         AND COALESCE((t.feat->>'is_card_like')::BOOLEAN, FALSE)
                    THEN 0.80
                    WHEN f.semantic_type = 'NAME'
                         AND COALESCE((t.feat->>'is_alpha_like')::BOOLEAN, FALSE)
                    THEN 0.30
                    WHEN f.semantic_type IN ('RRN','UTR','REF')
                         AND COALESCE((t.feat->>'is_numeric')::BOOLEAN, FALSE)
                         AND length(t.token) >= 8
                    THEN 0.15
                    ELSE 0
                END

                -- Position bonus (pre-joined — no correlated subquery)
                + COALESCE(pb.score_bonus, 0)

                -- Noise penalty
                - COALESCE(n.penalty_score, 0)

                -- Cross-semantic mismatch penalty
                - CASE
                    WHEN f.semantic_type = 'NAME'
                         AND COALESCE((t.feat->>'is_bank_like')::BOOLEAN, FALSE)
                    THEN 0.90
                    WHEN f.semantic_type = 'NAME'
                         AND COALESCE((t.feat->>'is_vpa_like')::BOOLEAN, FALSE)
                    THEN 1.00
                    WHEN f.semantic_type = 'BANK'
                         AND COALESCE((t.feat->>'is_vpa_like')::BOOLEAN, FALSE)
                    THEN 0.80
                    WHEN f.semantic_type = 'RRN'
                         AND NOT COALESCE((t.feat->>'is_rrn_like')::BOOLEAN, FALSE)
                    THEN 0.30
                    WHEN f.semantic_type = 'UTR'
                         AND NOT COALESCE((t.feat->>'is_utr_like')::BOOLEAN, FALSE)
                         AND NOT COALESCE((t.feat->>'is_rrn_like')::BOOLEAN, FALSE)
                    THEN 0.30
                    ELSE 0
                END
            )::NUMERIC(8,4) AS final_score

        FROM token_features  t
        CROSS JOIN non_fallback_fields f
        LEFT JOIN noise_hits      n  ON n.token_pos = t.token_pos
        LEFT JOIN position_bonuses pb ON pb.field_name = f.field_name
                                      AND pb.token_pos  = t.token_pos
        WHERE (f.min_length IS NULL OR length(t.token) >= f.min_length)
          AND (f.max_length IS NULL OR length(t.token) <= f.max_length)
          AND (f.exclude_regex IS NULL OR t.token !~* f.exclude_regex)
    ),
    positive_scores AS (
        SELECT * FROM candidate_scores WHERE final_score > 0
    ),

    -- ── Step 8: 1:1 assignment via window functions ────────────────────
    ranked AS (
        SELECT
            *,
            row_number() OVER (
                PARTITION BY field_name
                ORDER BY final_score DESC, priority_rank ASC,
                         token_pos ASC, length(token) DESC
            ) AS rn_field,
            row_number() OVER (
                PARTITION BY token_pos
                ORDER BY final_score DESC, priority_rank ASC,
                         length(token) DESC, field_name
            ) AS rn_token
        FROM positive_scores
    ),
    winners AS (
        SELECT token_pos, raw_pos, token, field_name, final_score, priority_rank
        FROM ranked
        WHERE rn_field = 1 AND rn_token = 1
    ),

    -- ── Step 9: unassigned tokens → purpose ───────────────────────────
    leftovers AS (
        SELECT string_agg(t.token, ' ' ORDER BY t.token_pos) AS purpose_text
        FROM token_features t
        WHERE NOT EXISTS (
            SELECT 1 FROM winners w WHERE w.token_pos = t.token_pos
        )
    ),

    -- ── Step 10: assemble output JSONB ────────────────────────────────
    assigned_map AS (
        SELECT jsonb_object_agg(field_name, token_pos) AS assigned_json
        FROM winners
    ),
    winner_payload AS (
        SELECT COALESCE(jsonb_object_agg(field_name, token), '{}'::JSONB) AS fields_json
        FROM winners
    ),
    confidence_calc AS (
        SELECT COALESCE(round(min(final_score)::NUMERIC, 2), 0.20) AS min_conf
        FROM winners
    )
    SELECT
        COALESCE(wp.fields_json, '{}'::JSONB)
        || CASE
             WHEN l.purpose_text IS NOT NULL AND btrim(l.purpose_text) <> ''
             THEN jsonb_build_object('purpose', l.purpose_text)
             ELSE '{}'::JSONB
           END
        || jsonb_build_object(
               '_confidence',         cc.min_conf,
               '_tokens',             (SELECT count(*) FROM token_features),
               '_format',             p_format_name,
               '_assigned',           COALESCE(am.assigned_json, '{}'::JSONB),
               '_classifier_version', 'v3.1'
           )
    INTO v_result
    FROM winner_payload wp
    CROSS JOIN confidence_calc cc
    CROSS JOIN leftovers l
    LEFT JOIN assigned_map am ON TRUE;

    -- Coherence validation pass
    v_result := spendsense.fn_validate_parse_v31(
        p_channel_type,
        p_format_name,
        v_result
    );

    -- Restore metadata the validator may have cleared
    v_result := v_result || jsonb_build_object(
        '_tokens', COALESCE(
            (v_result->>'_tokens')::INT,
            (SELECT count(*)::INT
             FROM unnest(v_raw_tokens) AS q(x)
             WHERE x IS NOT NULL AND btrim(x) <> '')
        ),
        '_format',             p_format_name,
        '_classifier_version', 'v3.1'
    );

    RETURN v_result;
END;
$$;

COMMENT ON FUNCTION spendsense.fn_classify_tokens(TEXT,TEXT,TEXT,TEXT,INT[],TEXT) IS
'v3.1 hybrid token classifier. Replaces v3 greedy loop.
 Scoring: regex + semantic bonus + position bias - noise - mismatch penalty.
 Window-function assignment guarantees strict 1:1 token→field.
 Followed by coherence validator. Same signature as v3 — drop-in compatible.';

-- ============================================================================
-- 7) UPI FIELD SCHEMA TIGHTENING
--
-- Directly fixes the check_parse.xlsx failures:
--   "paymen" was being assigned to counterparty_name in P2M slash rows
--   e.g. UPI/P2M/530525222697/CRED Club /paymen/AXIS BANK
-- ============================================================================

-- Block narration garbage from name fields
UPDATE spendsense.txn_channel_field_schema
SET exclude_regex =
    CASE
        WHEN exclude_regex IS NULL OR exclude_regex = ''
        THEN '(^(UPI|IN APP|SENT USI|PAYMEN|PAYMENT|UPIINT|YESPAY)$)'
        WHEN exclude_regex ~* '(UPIINT|YESPAY|PAYMEN|SENT.USI|IN.APP)'
        THEN exclude_regex   -- already has it
        ELSE '(' || exclude_regex || '|^(UPIINT|YESPAY|IN APP|SENT USI|PAYMEN|PAYMENT)$)'
    END
WHERE channel_type = 'UPI'
  AND field_name IN ('counterparty_name', 'merchant_name');

-- Ensure bank confidence is strong enough to beat a borderline name match
UPDATE spendsense.txn_channel_field_schema
SET confidence = GREATEST(confidence, 0.95)
WHERE channel_type = 'UPI'
  AND field_name = 'counterparty_bank';

-- Ensure RRN confidence floor
UPDATE spendsense.txn_channel_field_schema
SET confidence = GREATEST(confidence, 0.99)
WHERE channel_type = 'UPI'
  AND field_name = 'upi_rrn';

COMMIT;

-- ============================================================================
-- POST-PATCH USAGE
-- ============================================================================
-- Apply on top of v3:
--   \i txn_parsing_framework_v3.sql
--   \i txn_parsing_framework_v3_1_patch.sql
--
-- Re-run parsing after applying:
--   SELECT spendsense.populate_txn_parse_stage_v3('<upload_uuid>'::uuid);
--   SELECT spendsense.populate_txn_parsed_v3('<upload_uuid>'::uuid);
--
-- Or for all pending rows:
--   SELECT spendsense.populate_txn_parse_stage_v3();
--   SELECT spendsense.populate_txn_parsed_v3();
--   SELECT spendsense.populate_txn_parse_unknown_queue_v3();
--
-- Test the new classifier directly:
--   SELECT spendsense.fn_classify_tokens(
--     'UPI-PANDIT PAN-Q370212766@YBL-YESB0YBLUPI-116204307901-UPI',
--     'UPI', 'UPI_DASH', '-', ARRAY[0], NULL
--   );
--   SELECT spendsense.fn_classify_tokens(
--     'UPI/P2M/558004774745/CRED Club/paymen/AXIS BANK',
--     'UPI', 'UPI_P2M_SLASH', '/', ARRAY[0,1], NULL
--   );
--   SELECT spendsense.fn_token_features_v31('HDFCH00453269960');
--   -- should return is_utr_like=true, is_rrn_like=false
--
-- Recommended validation checks:
--   1) UPI rows with missing rrn/name/bank/vpa after patch
--   2) PARSED vs PARTIAL counts before/after
--   3) Inspect _assigned and _classifier_version in debug mode:
--      SELECT parsed.fields FROM spendsense.txn_parse_stage s
--      CROSS JOIN LATERAL spendsense.fn_classify_tokens(
--          s.normalized_description, s.channel_type, s.parse_format,
--          fmt.delimiter, fmt.skip_positions, fmt.prefix_strip_regex
--      ) parsed
--      JOIN spendsense.txn_channel_format_registry fmt
--        ON fmt.format_name = s.parse_format
--      WHERE s.channel_type = 'UPI' LIMIT 20;
-- ============================================================================
