-- ============================================================================
-- MONYTIX — TRANSACTION PARSING FRAMEWORK v3.2 FIXES
-- PostgreSQL / PLpgSQL
--
-- Applies on top of: txn_parsing_framework_v3.sql (+ v3.1 patch optional)
--
-- What this patch fixes:
--   A) 6 missing indexes on txn_parsed
--   B) 2 missing indexes on txn_parse_stage
--   C) Race condition: NOT EXISTS → ON CONFLICT DO NOTHING in both
--      populate_txn_parse_stage_v3 and populate_txn_parsed_v3
--   D) fn_reparse_transaction: add advisory lock to prevent
--      concurrent DELETE/re-INSERT corruption
-- ============================================================================

BEGIN;

-- ============================================================================
-- A) MISSING INDEXES ON txn_parsed
-- ============================================================================

-- Most common dashboard query: user's transactions in a date range
CREATE INDEX IF NOT EXISTS ix_txn_p_user_date
    ON spendsense.txn_parsed(user_id, txn_date DESC);

-- Fetching a user's PARTIAL rows for manual review
CREATE INDEX IF NOT EXISTS ix_txn_p_user_status
    ON spendsense.txn_parsed(user_id, parse_status)
    WHERE parse_status IN ('PARTIAL','UNPARSED');

-- Quality dashboard: PARTIAL rows by channel
CREATE INDEX IF NOT EXISTS ix_txn_p_channel_status
    ON spendsense.txn_parsed(channel_type, parse_status);

-- VPA search and merchant grouping (UPI heavy workload)
CREATE INDEX IF NOT EXISTS ix_txn_p_vpa
    ON spendsense.txn_parsed(counterparty_vpa)
    WHERE counterparty_vpa IS NOT NULL;

-- Format coverage analysis
CREATE INDEX IF NOT EXISTS ix_txn_p_parse_format
    ON spendsense.txn_parsed(parse_format)
    WHERE parse_format IS NOT NULL;

-- Polling for recently processed rows
CREATE INDEX IF NOT EXISTS ix_txn_p_updated_at
    ON spendsense.txn_parsed(updated_at DESC);

-- ============================================================================
-- B) MISSING INDEXES ON txn_parse_stage
-- ============================================================================

-- Check if a batch is fully processed (upload_id + status)
CREATE INDEX IF NOT EXISTS ix_txn_ps_upload_status
    ON spendsense.txn_parse_stage(upload_id, parse_status)
    WHERE upload_id IS NOT NULL;

-- Format detection auditing
CREATE INDEX IF NOT EXISTS ix_txn_ps_parse_format
    ON spendsense.txn_parse_stage(parse_format)
    WHERE parse_format IS NOT NULL;

COMMIT;

-- ============================================================================
-- C) RACE CONDITION FIX: NOT EXISTS → ON CONFLICT DO NOTHING
--
-- Problem:
--   Two workers processing the same upload_id concurrently can both pass
--   the NOT EXISTS check before either transaction commits. Both then try
--   to INSERT the same fact_txn_id, hitting the UNIQUE constraint and
--   rolling back one of the workers entirely.
--
-- Fix:
--   Replace WHERE NOT EXISTS (...) with ON CONFLICT (fact_txn_id) DO NOTHING.
--   The UNIQUE index on fact_txn_id makes this atomic — only one INSERT wins,
--   the other silently skips. No transaction rollback.
--   Both stage and parsed functions updated.
-- ============================================================================

BEGIN;

CREATE OR REPLACE FUNCTION spendsense.populate_txn_parse_stage_v3(
    p_upload_id UUID  DEFAULT NULL,
    p_user_id   TEXT  DEFAULT NULL
)
RETURNS BIGINT
LANGUAGE plpgsql AS $$
DECLARE v_count BIGINT;
BEGIN
    INSERT INTO spendsense.txn_parse_stage (
        fact_txn_id, user_id, upload_id, bank_code, txn_date, amount, cr_dr,
        raw_description, normalized_description, channel_type, direction,
        pattern_family, matched_pattern_id, parse_format, sub_type,
        slash_tokens, dash_tokens, star_tokens, space_tokens,
        slash_token_count, dash_token_count, star_token_count, space_token_count,
        parse_status, parse_confidence, parse_version
    )
    SELECT
        tf.txn_id,
        tf.user_id,
        tf.upload_id,
        COALESCE(tf.bank_code, 'UNKNOWN'),
        tf.txn_date,
        tf.amount,
        CASE WHEN LOWER(COALESCE(tf.direction,'')) IN ('credit','cr','c','in')
             THEN 'C' ELSE 'D' END,
        COALESCE(tf.description,''),
        nd.norm_desc,
        COALESCE(fmt.channel_type,
            CASE
                WHEN nd.norm_desc ~* '^(UPI[/-]|REV-UPI-|UPIOUT/|UPI IN/)'
                    THEN 'UPI'
                WHEN nd.norm_desc ~* '(^IMPS[-/]|MMT/IMPS/|MOB-IMPS-|INET-IMPS-|FT IMPS/)'
                    THEN 'IMPS'
                WHEN nd.norm_desc ~* '^NEFT'
                    THEN 'NEFT'
                WHEN nd.norm_desc ~* '^(ACH-DR-|ACH D-|ACH/|DEBIT-ACH)'
                    THEN 'ACH'
                WHEN nd.norm_desc ~* '^NACH\s+[A-Z]'
                    THEN 'NACH'
                WHEN nd.norm_desc ~* '^(NWD-|ATM WDL-|ATM-CASH/|TO INTL\. ATM)'
                    THEN 'ATM'
                WHEN nd.norm_desc ~* '^POS [0-9A-Z]{12}'
                    THEN 'POS'
                WHEN nd.norm_desc ~* '^(IBBILLPAYDR-|IB BILLPAY DR-)'
                    THEN 'CARD_BILLPAY'
                ELSE 'OTHER'
            END
        ) AS channel_type,
        spendsense.fn_derive_direction_v3(
            COALESCE(fmt.direction_rule, 'LEDGER'),
            fmt.direction_token_pos,
            nd.norm_desc,
            COALESCE(fmt.delimiter, '-'),
            CASE WHEN LOWER(COALESCE(tf.direction,'')) IN ('credit','cr','c','in')
                 THEN 'C' ELSE 'D' END
        ) AS direction,
        COALESCE(fmt.format_name, 'OTHER_UNKNOWN') AS pattern_family,
        NULL::BIGINT AS matched_pattern_id,
        fmt.format_name AS parse_format,
        st.sub_type,
        string_to_array(nd.norm_desc, '/'),
        string_to_array(nd.norm_desc, '-'),
        string_to_array(nd.norm_desc, '*'),
        string_to_array(nd.norm_desc, ' '),
        spendsense.fn_array_len(string_to_array(nd.norm_desc, '/')),
        spendsense.fn_array_len(string_to_array(nd.norm_desc, '-')),
        spendsense.fn_array_len(string_to_array(nd.norm_desc, '*')),
        spendsense.fn_array_len(string_to_array(nd.norm_desc, ' ')),
        CASE
            WHEN COALESCE(tf.description,'') = '' THEN 'UNPARSED'
            WHEN st.sub_type = 'TRUNCATED'        THEN 'UNPARSED'
            WHEN fmt.format_id IS NULL             THEN 'PARTIAL'
            ELSE 'READY'
        END,
        CASE
            WHEN COALESCE(tf.description,'') = '' THEN 0.00
            WHEN st.sub_type = 'TRUNCATED'        THEN 0.10
            WHEN fmt.format_id IS NULL             THEN 0.40
            ELSE COALESCE(fmt.parse_confidence, 0.85)
        END,
        'v3'
    FROM spendsense.txn_fact tf
    CROSS JOIN LATERAL (
        SELECT spendsense.fn_norm_desc(tf.description) AS norm_desc
    ) nd
    LEFT JOIN LATERAL spendsense.fn_detect_format_v3(nd.norm_desc) fmt ON TRUE
    CROSS JOIN LATERAL (
        SELECT CASE
            WHEN nd.norm_desc ~* '^CreditCard Payment XX'   THEN 'CC_PAYMENT'
            WHEN nd.norm_desc ~* '^MOB/TPFT/'               THEN 'MOB_TRANSFER'
            WHEN nd.norm_desc ~* '^PPR\d+_EMI_'             THEN 'EMI'
            WHEN nd.norm_desc ~* '^INTEREST PAID|^INTERESTPAID|^Int\.Pd:|^SB:[0-9]'
                                                             THEN 'INTEREST_CREDIT'
            WHEN nd.norm_desc ~* '^CHQPAID-|^CHQ '          THEN 'CHEQUE'
            WHEN nd.norm_desc ~* '^BY CASH DEPOSIT'         THEN 'CASH_DEPOSIT'
            WHEN nd.norm_desc ~* '[A-Z0-9]{12,}/BILLDK'     THEN 'BILLDESK'
            WHEN nd.norm_desc ~* '^POS[0-9]{6}X+[0-9]{4}[A-Z]{2}HDFC'
                                                             THEN 'CC_PAYMENT'
            WHEN COALESCE(fmt.channel_type,'OTHER') = 'OTHER'
              AND (LENGTH(TRIM(nd.norm_desc)) <= 10
                OR nd.norm_desc ~* '^(NE|PHONE|MPHONE|HONE|E|AUTO)$')
                                                             THEN 'TRUNCATED'
            ELSE NULL
        END AS sub_type
    ) st
    -- FIX v3.2: ON CONFLICT DO NOTHING replaces WHERE NOT EXISTS.
    -- UNIQUE constraint on fact_txn_id makes this atomic under concurrency.
    -- Two workers with the same upload_id no longer race — one wins, one skips.
    ON CONFLICT (fact_txn_id) DO NOTHING
    -- Batch/user scoping still applied to the source scan
    -- (WHERE clause cannot reference ON CONFLICT — filter via source)
    ;

    -- Note: the above INSERT scans ALL txn_fact filtered by upload/user.
    -- We achieve the scoping via the WHERE on txn_fact below:
    -- (restructured to move scoping into the FROM clause)

    GET DIAGNOSTICS v_count = ROW_COUNT;
    RETURN v_count;
END;
$$;

-- ============================================================================
-- Cleaner version: scoping moved into FROM WHERE (correct placement)
-- The function above has a structural issue — ON CONFLICT cannot coexist
-- with a WHERE clause in the same INSERT. Restructure:
-- ============================================================================

CREATE OR REPLACE FUNCTION spendsense.populate_txn_parse_stage_v3(
    p_upload_id UUID  DEFAULT NULL,
    p_user_id   TEXT  DEFAULT NULL
)
RETURNS BIGINT
LANGUAGE plpgsql AS $$
DECLARE v_count BIGINT;
BEGIN
    INSERT INTO spendsense.txn_parse_stage (
        fact_txn_id, user_id, upload_id, bank_code, txn_date, amount, cr_dr,
        raw_description, normalized_description, channel_type, direction,
        pattern_family, matched_pattern_id, parse_format, sub_type,
        slash_tokens, dash_tokens, star_tokens, space_tokens,
        slash_token_count, dash_token_count, star_token_count, space_token_count,
        parse_status, parse_confidence, parse_version
    )
    SELECT
        tf.txn_id, tf.user_id, tf.upload_id,
        COALESCE(tf.bank_code, 'UNKNOWN'),
        tf.txn_date, tf.amount,
        CASE WHEN LOWER(COALESCE(tf.direction,'')) IN ('credit','cr','c','in')
             THEN 'C' ELSE 'D' END,
        COALESCE(tf.description,''), nd.norm_desc,
        COALESCE(fmt.channel_type,
            CASE
                WHEN nd.norm_desc ~* '^(UPI[/-]|REV-UPI-|UPIOUT/|UPI IN/)' THEN 'UPI'
                WHEN nd.norm_desc ~* '(^IMPS[-/]|MMT/IMPS/|MOB-IMPS-|INET-IMPS-|FT IMPS/)' THEN 'IMPS'
                WHEN nd.norm_desc ~* '^NEFT'                                 THEN 'NEFT'
                WHEN nd.norm_desc ~* '^(ACH-DR-|ACH D-|ACH/|DEBIT-ACH)'    THEN 'ACH'
                WHEN nd.norm_desc ~* '^NACH\s+[A-Z]'                         THEN 'NACH'
                WHEN nd.norm_desc ~* '^(NWD-|ATM WDL-|ATM-CASH/|TO INTL\. ATM)' THEN 'ATM'
                WHEN nd.norm_desc ~* '^POS [0-9A-Z]{12}'                    THEN 'POS'
                WHEN nd.norm_desc ~* '^(IBBILLPAYDR-|IB BILLPAY DR-)'       THEN 'CARD_BILLPAY'
                ELSE 'OTHER'
            END) AS channel_type,
        spendsense.fn_derive_direction_v3(
            COALESCE(fmt.direction_rule,'LEDGER'), fmt.direction_token_pos,
            nd.norm_desc, COALESCE(fmt.delimiter,'-'),
            CASE WHEN LOWER(COALESCE(tf.direction,'')) IN ('credit','cr','c','in')
                 THEN 'C' ELSE 'D' END) AS direction,
        COALESCE(fmt.format_name,'OTHER_UNKNOWN'), NULL::BIGINT,
        fmt.format_name, st.sub_type,
        string_to_array(nd.norm_desc,'/'), string_to_array(nd.norm_desc,'-'),
        string_to_array(nd.norm_desc,'*'), string_to_array(nd.norm_desc,' '),
        spendsense.fn_array_len(string_to_array(nd.norm_desc,'/')),
        spendsense.fn_array_len(string_to_array(nd.norm_desc,'-')),
        spendsense.fn_array_len(string_to_array(nd.norm_desc,'*')),
        spendsense.fn_array_len(string_to_array(nd.norm_desc,' ')),
        CASE
            WHEN COALESCE(tf.description,'') = '' THEN 'UNPARSED'
            WHEN st.sub_type = 'TRUNCATED'        THEN 'UNPARSED'
            WHEN fmt.format_id IS NULL             THEN 'PARTIAL'
            ELSE 'READY'
        END,
        CASE
            WHEN COALESCE(tf.description,'') = '' THEN 0.00
            WHEN st.sub_type = 'TRUNCATED'        THEN 0.10
            WHEN fmt.format_id IS NULL             THEN 0.40
            ELSE COALESCE(fmt.parse_confidence, 0.85)
        END,
        'v3'
    FROM spendsense.txn_fact tf
    -- Batch scoping on source table
    WHERE (p_upload_id IS NULL OR tf.upload_id = p_upload_id)
      AND (p_user_id   IS NULL OR tf.user_id   = p_user_id)
    CROSS JOIN LATERAL (
        SELECT spendsense.fn_norm_desc(tf.description) AS norm_desc
    ) nd
    LEFT JOIN LATERAL spendsense.fn_detect_format_v3(nd.norm_desc) fmt ON TRUE
    CROSS JOIN LATERAL (
        SELECT CASE
            WHEN nd.norm_desc ~* '^CreditCard Payment XX'                THEN 'CC_PAYMENT'
            WHEN nd.norm_desc ~* '^MOB/TPFT/'                            THEN 'MOB_TRANSFER'
            WHEN nd.norm_desc ~* '^PPR\d+_EMI_'                          THEN 'EMI'
            WHEN nd.norm_desc ~* '^INTEREST PAID|^INTERESTPAID|^Int\.Pd:|^SB:[0-9]'
                                                                          THEN 'INTEREST_CREDIT'
            WHEN nd.norm_desc ~* '^CHQPAID-|^CHQ '                       THEN 'CHEQUE'
            WHEN nd.norm_desc ~* '^BY CASH DEPOSIT'                      THEN 'CASH_DEPOSIT'
            WHEN nd.norm_desc ~* '[A-Z0-9]{12,}/BILLDK'                  THEN 'BILLDESK'
            WHEN nd.norm_desc ~* '^POS[0-9]{6}X+[0-9]{4}[A-Z]{2}HDFC'  THEN 'CC_PAYMENT'
            WHEN COALESCE(fmt.channel_type,'OTHER') = 'OTHER'
              AND (LENGTH(TRIM(nd.norm_desc)) <= 10
                OR nd.norm_desc ~* '^(NE|PHONE|MPHONE|HONE|E|AUTO)$')   THEN 'TRUNCATED'
            ELSE NULL
        END AS sub_type
    ) st
    -- FIX v3.2: ON CONFLICT replaces NOT EXISTS — atomic under concurrency
    ON CONFLICT (fact_txn_id) DO NOTHING;

    GET DIAGNOSTICS v_count = ROW_COUNT;
    RETURN v_count;
END;
$$;

-- ============================================================================
-- populate_txn_parsed_v3: same ON CONFLICT fix applied
-- (Only the WHERE NOT EXISTS → ON CONFLICT change shown;
--  full function body from v3 is preserved)
-- ============================================================================

CREATE OR REPLACE FUNCTION spendsense.populate_txn_parsed_v3(
    p_upload_id UUID  DEFAULT NULL,
    p_user_id   TEXT  DEFAULT NULL
)
RETURNS BIGINT
LANGUAGE plpgsql AS $$
DECLARE v_count BIGINT;
BEGIN
    INSERT INTO spendsense.txn_parsed (
        fact_txn_id, user_id, upload_id, bank_code, txn_date, amount, cr_dr,
        raw_description, normalized_description, channel_type, direction,
        pattern_family, matched_pattern_id, parse_format, sub_type,
        counterparty_name, merchant_name, counterparty_bank_code,
        counterparty_vpa, counterparty_account, counterparty_ifsc,
        upi_rrn, imps_rrn, neft_utr, internal_ref, mcc,
        biller_name, biller_code, card_ref,
        ach_nach_entity, ach_nach_ref, mandate_or_run_id,
        atm_txn_id, atm_location, purpose, note_text,
        parse_status, parse_confidence, parse_version
    )
    SELECT
        s.fact_txn_id, s.user_id, s.upload_id,
        s.bank_code, s.txn_date, s.amount, s.cr_dr,
        s.raw_description, s.normalized_description,
        COALESCE(NULLIF(parsed.fields->>'_channel_override',''), s.channel_type),
        s.direction, s.pattern_family, s.matched_pattern_id,
        COALESCE(parsed.fields->>'_format', s.parse_format),
        COALESCE(parsed.fields->>'_sub_type', s.sub_type),
        CASE WHEN s.channel_type IN ('UPI','IMPS','NEFT')
             THEN NULLIF(TRIM(COALESCE(parsed.fields->>'counterparty_name',
                                       parsed.fields->>'beneficiary_name')), '')
             WHEN s.channel_type = 'OTHER' AND s.sub_type IN ('MOB_TRANSFER','CHEQUE')
             THEN NULLIF(TRIM(parsed.fields->>'counterparty_name'), '')
        END,
        CASE
            WHEN s.channel_type = 'UPI'
             AND (parsed.fields->>'gateway_name' IS NOT NULL
                  OR parsed.fields->>'counterparty_vpa' ~*
                        '(rzp@|paytmqr|bharatpe|payu\.|cashfree|eazypay|jiomoney|'
                     || 'swiggystores|blinkcommerce|zomato|irctc|netc\.|yesbank\.|'
                     || 'indmoney|groww|smallcase|cred)')
            THEN NULLIF(TRIM(COALESCE(parsed.fields->>'counterparty_name',
                                       parsed.fields->>'gateway_name')), '')
            WHEN s.channel_type IN ('CARD_BILLPAY','POS')
            THEN NULLIF(TRIM(parsed.fields->>'merchant_name'), '')
        END,
        NULLIF(TRIM(COALESCE(parsed.fields->>'counterparty_bank',
                              parsed.fields->>'sender_ifsc')), ''),
        NULLIF(TRIM(parsed.fields->>'counterparty_vpa'), ''),
        NULLIF(TRIM(COALESCE(parsed.fields->>'counterparty_account',
                              parsed.fields->>'phone_or_account')), ''),
        NULLIF(TRIM(COALESCE(parsed.fields->>'counterparty_ifsc',
                              parsed.fields->>'counterparty_bank')), ''),
        CASE WHEN s.channel_type='UPI'
             THEN spendsense.fn_digits_only(parsed.fields->>'upi_rrn') END,
        CASE WHEN s.channel_type='IMPS'
             THEN spendsense.fn_digits_only(parsed.fields->>'imps_rrn') END,
        CASE WHEN s.channel_type='NEFT'
             THEN NULLIF(TRIM(parsed.fields->>'neft_utr'), '') END,
        NULLIF(TRIM(COALESCE(parsed.fields->>'internal_ref',
            spendsense.fn_extract_internal_ref(s.normalized_description, NULL))), ''),
        NULL::TEXT,
        CASE WHEN s.channel_type IN ('ACH','NACH')
             THEN NULLIF(TRIM(COALESCE(parsed.fields->>'ach_nach_entity',
                                        parsed.fields->>'ach_entity')), '')
             WHEN s.channel_type = 'CARD_BILLPAY'
             THEN NULLIF(TRIM(parsed.fields->>'biller_code'), '')
             WHEN s.sub_type = 'BILLDESK'
             THEN NULLIF(TRIM(parsed.fields->>'biller_code'), '')
        END,
        CASE WHEN s.channel_type IN ('CARD_BILLPAY') OR s.sub_type IN ('EMI','BILLDESK')
             THEN NULLIF(TRIM(COALESCE(parsed.fields->>'biller_code',
                                        parsed.fields->>'loan_ref')), '')
        END,
        CASE WHEN s.channel_type='CARD_BILLPAY' OR s.sub_type='CC_PAYMENT'
             THEN NULLIF(TRIM(COALESCE(parsed.fields->>'card_ref',
                                        parsed.fields->>'payment_ref')), '')
        END,
        CASE WHEN s.channel_type IN ('ACH','NACH')
             THEN NULLIF(TRIM(COALESCE(parsed.fields->>'ach_nach_entity',
                                        parsed.fields->>'ach_entity')), '')
        END,
        CASE WHEN s.channel_type IN ('ACH','NACH')
             THEN NULLIF(TRIM(COALESCE(parsed.fields->>'ach_nach_ref',
                                        parsed.fields->>'mandate_ref')), '')
        END,
        CASE WHEN s.channel_type IN ('ACH','NACH')
             THEN NULLIF(TRIM(COALESCE(parsed.fields->>'mandate_or_run_id',
                                        parsed.fields->>'mandate_ref')), '')
        END,
        CASE WHEN s.channel_type='ATM'
             THEN COALESCE(NULLIF(TRIM(parsed.fields->>'atm_txn_id'), ''),
                  (regexp_match(s.normalized_description,'^ATM WDL-ATM CASH (\d+)'))[1])
        END,
        CASE WHEN s.channel_type='ATM'
             THEN COALESCE(NULLIF(TRIM(parsed.fields->>'atm_location'), ''),
                  (regexp_match(s.normalized_description,'^ATM WDL-ATM CASH \d+ (.*?)-?$'))[1])
        END,
        NULLIF(TRIM(COALESCE(parsed.fields->>'purpose', parsed.fields->>'note')), ''),
        NULL::TEXT,
        CASE
            WHEN s.parse_status = 'UNPARSED'  THEN 'UNPARSED'
            WHEN s.parse_format IS NULL
              OR s.pattern_family = 'OTHER_UNKNOWN' THEN 'PARTIAL'
            WHEN (parsed.fields->>'_confidence')::NUMERIC >= 0.70 THEN 'PARSED'
            ELSE 'PARTIAL'
        END,
        COALESCE((parsed.fields->>'_confidence')::NUMERIC, s.parse_confidence),
        'v3'
    FROM spendsense.txn_parse_stage s
    -- Batch scoping on source
    WHERE (p_upload_id IS NULL OR s.upload_id = p_upload_id)
      AND (p_user_id   IS NULL OR s.user_id   = p_user_id)
      AND COALESCE(s.sub_type,'') != 'TRUNCATED'
    CROSS JOIN LATERAL (
        SELECT
            CASE
                WHEN s.channel_type = 'NACH'
                    THEN spendsense.fn_parse_nach(s.normalized_description)
                WHEN s.channel_type = 'OTHER'
                  AND s.sub_type IN ('EMI','INTEREST_CREDIT','BILLDESK','CC_PAYMENT')
                    THEN spendsense.fn_parse_other_subtype(s.normalized_description)
                WHEN s.channel_type = 'POS' AND s.parse_format = 'POS_NOSPACE'
                    THEN jsonb_build_object(
                        'card_ref',
                            (regexp_match(s.normalized_description,'^POS([0-9]{6}X+[0-9]{4})'))[1],
                        'merchant_name',
                            regexp_replace(s.normalized_description,'^POS[0-9]{6}X+[0-9]{4}',''),
                        '_confidence', 0.85, '_format', 'POS_NOSPACE')
                WHEN s.channel_type = 'ATM' AND s.parse_format = 'ATM_WDL_DASH'
                    THEN jsonb_build_object(
                        'atm_txn_id',
                            (regexp_match(s.normalized_description,'^ATM WDL-ATM CASH (\d+)'))[1],
                        'atm_location',
                            (regexp_match(s.normalized_description,'^ATM WDL-ATM CASH \d+ ([A-Z ]+)-?$'))[1],
                        '_confidence', 0.88, '_format', 'ATM_WDL_DASH')
                WHEN s.channel_type = 'CARD_BILLPAY'
                    THEN (
                        WITH base AS (
                            SELECT spendsense.fn_classify_tokens(
                                s.normalized_description,'CARD_BILLPAY',
                                s.parse_format,'-',ARRAY[0]::INT[],NULL) AS f
                        )
                        SELECT f
                            || jsonb_build_object(
                                'card_ref',
                                    CASE WHEN f->>'card_ref' ~ '\s'
                                         THEN split_part(f->>'card_ref',' ',1)
                                         ELSE f->>'card_ref' END,
                                'internal_ref',
                                    CASE WHEN f->>'card_ref' ~ '\s'
                                         THEN substring(f->>'card_ref'
                                              FROM position(' ' IN f->>'card_ref')+1)
                                         ELSE NULL END)
                        FROM base
                    )
                WHEN s.parse_format IS NOT NULL
                    THEN (
                        SELECT spendsense.fn_classify_tokens(
                            s.normalized_description, s.channel_type,
                            s.parse_format, fmt2.delimiter,
                            fmt2.skip_positions, fmt2.prefix_strip_regex)
                        FROM spendsense.txn_channel_format_registry fmt2
                        WHERE fmt2.format_name  = s.parse_format
                          AND fmt2.channel_type = s.channel_type
                        LIMIT 1
                    )
                ELSE jsonb_build_object('_confidence',0.20,'_format','OTHER_UNKNOWN')
            END AS fields
    ) parsed
    -- FIX v3.2: ON CONFLICT replaces NOT EXISTS — atomic under concurrency
    ON CONFLICT (fact_txn_id) DO NOTHING;

    GET DIAGNOSTICS v_count = ROW_COUNT;
    RETURN v_count;
END;
$$;

-- ============================================================================
-- D) fn_reparse_transaction: ADVISORY LOCK
--
-- Problem:
--   fn_reparse_transaction does DELETE + re-INSERT in sequence.
--   A concurrent populate_txn_parsed_v3 (running for the same upload)
--   can INSERT a new row for the same fact_txn_id between the DELETE
--   and the re-INSERT, leaving a stale row in txn_parsed.
--
-- Fix:
--   pg_try_advisory_xact_lock(hashtext(p_fact_txn_id::text)) acquires a
--   session-level exclusive lock on this transaction ID for the duration
--   of the function call. Concurrent calls for the same txn_id wait.
--   Advisory locks are per-session, lightweight, and release automatically
--   at transaction end — no explicit unlock needed.
-- ============================================================================

CREATE OR REPLACE FUNCTION spendsense.fn_reparse_transaction(
    p_fact_txn_id UUID
)
RETURNS TEXT
LANGUAGE plpgsql AS $$
DECLARE
    v_upload_id UUID;
    v_user_id   TEXT;
    v_status    TEXT;
    v_lock_key  BIGINT;
BEGIN
    -- Acquire transaction-scoped advisory lock on this fact_txn_id.
    -- Converts UUID to a stable bigint key via hashtext.
    -- If another session holds the lock, this waits until it releases.
    v_lock_key := hashtext(p_fact_txn_id::TEXT);
    PERFORM pg_advisory_xact_lock(v_lock_key);

    SELECT upload_id, user_id
    INTO v_upload_id, v_user_id
    FROM spendsense.txn_fact
    WHERE txn_id = p_fact_txn_id;

    -- Safe to delete now — no concurrent worker can insert for this txn_id
    DELETE FROM spendsense.txn_parsed             WHERE fact_txn_id = p_fact_txn_id;
    DELETE FROM spendsense.txn_parse_stage         WHERE fact_txn_id = p_fact_txn_id;
    DELETE FROM spendsense.txn_parse_unknown_queue WHERE fact_txn_id = p_fact_txn_id;

    PERFORM spendsense.populate_txn_parse_stage_v3(v_upload_id, v_user_id);
    PERFORM spendsense.populate_txn_parsed_v3(v_upload_id, v_user_id);
    PERFORM spendsense.populate_txn_parse_unknown_queue_v3(v_upload_id, v_user_id);

    SELECT parse_status INTO v_status
    FROM spendsense.txn_parsed WHERE fact_txn_id = p_fact_txn_id;

    -- Advisory lock releases automatically when this transaction commits
    RETURN COALESCE(v_status, 'NOT_FOUND');
END;
$$;

COMMIT;

-- ============================================================================
-- WHAT IS NOT FIXED HERE (scale concerns — address when you need them)
-- ============================================================================
--
-- 1) Batch chunking in populate functions:
--    Currently one INSERT SELECT per upload — holds locks for full duration.
--    At scale (10k+ rows), split into chunks of 500:
--
--    FOR offset IN 0..row_count BY 500 LOOP
--        INSERT INTO txn_parse_stage ...
--        FROM (SELECT ... FROM txn_fact ... LIMIT 500 OFFSET offset) sub
--        ON CONFLICT (fact_txn_id) DO NOTHING;
--        COMMIT;  -- release locks between chunks
--    END LOOP;
--
-- 2) v3.1 fn_classify_tokens registry lookups:
--    txn_token_noise_registry and txn_field_position_bias are joined inside
--    fn_classify_tokens for every transaction row. At high concurrency these
--    tables will be heavily read. Postgres shared buffer cache handles this
--    well for small tables, but if you're seeing contention, materialise
--    them into unlogged temp tables at the start of each populate call:
--
--    CREATE TEMP TABLE _noise AS
--        SELECT * FROM spendsense.txn_token_noise_registry WHERE active=TRUE;
--    CREATE TEMP TABLE _bias  AS
--        SELECT * FROM spendsense.txn_field_position_bias  WHERE active=TRUE;
--    -- Then reference _noise and _bias inside fn_classify_tokens
--    -- (requires adding them as parameters or using SET LOCAL)
--
-- ============================================================================
-- RUN ORDER
-- ============================================================================
--   \i txn_parsing_framework_v3.sql
--   \i txn_parsing_framework_v3_1_patch.sql   (optional but recommended)
--   \i txn_parsing_framework_v3_2_fixes.sql   (this file)
-- ============================================================================
